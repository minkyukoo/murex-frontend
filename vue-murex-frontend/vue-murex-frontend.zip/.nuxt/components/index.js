export const AdvisoryCards = () => import('../..\\components\\AdvisoryCards.vue' /* webpackChunkName: "components/advisory-cards" */).then(c => wrapFunctional(c.default || c))
export const Banner = () => import('../..\\components\\Banner.vue' /* webpackChunkName: "components/banner" */).then(c => wrapFunctional(c.default || c))
export const BannerState = () => import('../..\\components\\BannerState.vue' /* webpackChunkName: "components/banner-state" */).then(c => wrapFunctional(c.default || c))
export const ContactInfoItem = () => import('../..\\components\\ContactInfoItem.vue' /* webpackChunkName: "components/contact-info-item" */).then(c => wrapFunctional(c.default || c))
export const Filters = () => import('../..\\components\\Filters.vue' /* webpackChunkName: "components/filters" */).then(c => wrapFunctional(c.default || c))
export const Footer = () => import('../..\\components\\Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const FounderCards = () => import('../..\\components\\FounderCards.vue' /* webpackChunkName: "components/founder-cards" */).then(c => wrapFunctional(c.default || c))
export const Header = () => import('../..\\components\\Header.vue' /* webpackChunkName: "components/header" */).then(c => wrapFunctional(c.default || c))
export const LanguageInput = () => import('../..\\components\\LanguageInput.vue' /* webpackChunkName: "components/language-input" */).then(c => wrapFunctional(c.default || c))
export const LoadingBar = () => import('../..\\components\\LoadingBar.vue' /* webpackChunkName: "components/loading-bar" */).then(c => wrapFunctional(c.default || c))
export const Modal = () => import('../..\\components\\Modal.vue' /* webpackChunkName: "components/modal" */).then(c => wrapFunctional(c.default || c))
export const NuxtLogo = () => import('../..\\components\\NuxtLogo.vue' /* webpackChunkName: "components/nuxt-logo" */).then(c => wrapFunctional(c.default || c))
export const TeamCard = () => import('../..\\components\\TeamCard.vue' /* webpackChunkName: "components/team-card" */).then(c => wrapFunctional(c.default || c))
export const TeamCards = () => import('../..\\components\\TeamCards.vue' /* webpackChunkName: "components/team-cards" */).then(c => wrapFunctional(c.default || c))
export const TopHeading = () => import('../..\\components\\TopHeading.vue' /* webpackChunkName: "components/top-heading" */).then(c => wrapFunctional(c.default || c))
export const Tutorial = () => import('../..\\components\\Tutorial.vue' /* webpackChunkName: "components/tutorial" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
