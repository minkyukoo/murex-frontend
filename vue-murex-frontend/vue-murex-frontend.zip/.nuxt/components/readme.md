# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<AdvisoryCards>` | `<advisory-cards>` (components/AdvisoryCards.vue)
- `<Banner>` | `<banner>` (components/Banner.vue)
- `<BannerState>` | `<banner-state>` (components/BannerState.vue)
- `<ContactInfoItem>` | `<contact-info-item>` (components/ContactInfoItem.vue)
- `<Filters>` | `<filters>` (components/Filters.vue)
- `<Footer>` | `<footer>` (components/Footer.vue)
- `<FounderCards>` | `<founder-cards>` (components/FounderCards.vue)
- `<Header>` | `<header>` (components/Header.vue)
- `<LanguageInput>` | `<language-input>` (components/LanguageInput.vue)
- `<LoadingBar>` | `<loading-bar>` (components/LoadingBar.vue)
- `<Modal>` | `<modal>` (components/Modal.vue)
- `<NuxtLogo>` | `<nuxt-logo>` (components/NuxtLogo.vue)
- `<TeamCard>` | `<team-card>` (components/TeamCard.vue)
- `<TeamCards>` | `<team-cards>` (components/TeamCards.vue)
- `<TopHeading>` | `<top-heading>` (components/TopHeading.vue)
- `<Tutorial>` | `<tutorial>` (components/Tutorial.vue)
