import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _b9de8116 = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _245b8a88 = () => interopDefault(import('..\\pages\\contact.vue' /* webpackChunkName: "pages/contact" */))
const _502aa6e2 = () => interopDefault(import('..\\pages\\contents.vue' /* webpackChunkName: "pages/contents" */))
const _5444216c = () => interopDefault(import('..\\pages\\founders.vue' /* webpackChunkName: "pages/founders" */))
const _7a6ecb8c = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _424c1bb9 = () => interopDefault(import('..\\pages\\philosophy.vue' /* webpackChunkName: "pages/philosophy" */))
const _f96e66b6 = () => interopDefault(import('..\\pages\\team.vue' /* webpackChunkName: "pages/team" */))
const _08327470 = () => interopDefault(import('..\\pages\\users.vue' /* webpackChunkName: "pages/users" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _b9de8116,
    name: "about___en"
  }, {
    path: "/contact",
    component: _245b8a88,
    name: "contact___en"
  }, {
    path: "/contents",
    component: _502aa6e2,
    name: "contents___en"
  }, {
    path: "/founders",
    component: _5444216c,
    name: "founders___en"
  }, {
    path: "/fr",
    component: _7a6ecb8c,
    name: "index___fr"
  }, {
    path: "/kr",
    component: _7a6ecb8c,
    name: "index___kr"
  }, {
    path: "/philosophy",
    component: _424c1bb9,
    name: "philosophy___en"
  }, {
    path: "/team",
    component: _f96e66b6,
    name: "team___en"
  }, {
    path: "/users",
    component: _08327470,
    name: "users___en"
  }, {
    path: "/fr/about",
    component: _b9de8116,
    name: "about___fr"
  }, {
    path: "/fr/contact",
    component: _245b8a88,
    name: "contact___fr"
  }, {
    path: "/fr/contents",
    component: _502aa6e2,
    name: "contents___fr"
  }, {
    path: "/fr/founders",
    component: _5444216c,
    name: "founders___fr"
  }, {
    path: "/fr/philosophy",
    component: _424c1bb9,
    name: "philosophy___fr"
  }, {
    path: "/fr/team",
    component: _f96e66b6,
    name: "team___fr"
  }, {
    path: "/fr/users",
    component: _08327470,
    name: "users___fr"
  }, {
    path: "/kr/about",
    component: _b9de8116,
    name: "about___kr"
  }, {
    path: "/kr/contact",
    component: _245b8a88,
    name: "contact___kr"
  }, {
    path: "/kr/contents",
    component: _502aa6e2,
    name: "contents___kr"
  }, {
    path: "/kr/founders",
    component: _5444216c,
    name: "founders___kr"
  }, {
    path: "/kr/philosophy",
    component: _424c1bb9,
    name: "philosophy___kr"
  }, {
    path: "/kr/team",
    component: _f96e66b6,
    name: "team___kr"
  }, {
    path: "/kr/users",
    component: _08327470,
    name: "users___kr"
  }, {
    path: "/",
    component: _7a6ecb8c,
    name: "index___en"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
