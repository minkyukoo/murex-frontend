<template>
  <div>
      <h3>{{$t(`contents.emptyError`)}}</h3>
  </div>
</template>

<script>
export default {
    name: "ContentEmpty",

}
</script>

<style>

</style>