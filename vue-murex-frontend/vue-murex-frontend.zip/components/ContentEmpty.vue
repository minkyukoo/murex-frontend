<template>
  <div>
      <h3>No Contents Avialable</h3>
  </div>
</template>

<script>
export default {
    name: "ContentEmpty",

}
</script>

<style>

</style>