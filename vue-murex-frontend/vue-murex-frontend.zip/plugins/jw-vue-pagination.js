import Vue from "vue";
import JwPagination from "jw-vue-pagination";


Vue.component("jw-pagination", JwPagination);
