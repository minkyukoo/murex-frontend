<template>
  <div class="contents">
    <h1>contents</h1>
  </div>
</template>

<script>
  export default {
    name: 'contents'
  }
</script>

<style lang="scss" scoped>

</style>
