function _mergeNamespaces(n, m) {
  for (var i = 0; i < m.length; i++) {
    const e = m[i];
    if (typeof e !== 'string' && !Array.isArray(e)) { for (const k in e) {
      if (k !== 'default' && !(k in n)) {
        const d = Object.getOwnPropertyDescriptor(e, k);
        if (d) {
          Object.defineProperty(n, k, d.get ? d : {
            enumerable: true,
            get: function () { return e[k]; }
          });
        }
      }
    } }
  }
  return Object.freeze(n);
}

var filters$1 = {};

var ids = filters$1.ids = [5];
var modules = filters$1.modules = {
  132: function(module, exports2, __webpack_require__) {
    var content = __webpack_require__(142);
    if (content.__esModule)
      content = content.default;
    if (typeof content === "string")
      content = [[module.i, content, ""]];
    if (content.locals)
      module.exports = content.locals;
    var add = __webpack_require__(5).default;
    module.exports.__inject__ = function(context) {
      add("d619fdf0", content, true, context);
    };
  },
  141: function(module, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_Filters_vue_vue_type_style_index_0_id_655f3ed2_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(132);
    for (var __WEBPACK_IMPORT_KEY__ in _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_Filters_vue_vue_type_style_index_0_id_655f3ed2_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__)
      if (["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0)
        (function(key) {
          __webpack_require__.d(__webpack_exports__, key, function() {
            return _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_Filters_vue_vue_type_style_index_0_id_655f3ed2_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key];
          });
        })(__WEBPACK_IMPORT_KEY__);
  },
  142: function(module, exports2, __webpack_require__) {
    var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
    var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(7);
    var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(8);
    var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(9);
    var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(10);
    var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(11);
    var ___CSS_LOADER_URL_IMPORT_4___ = __webpack_require__(12);
    var ___CSS_LOADER_URL_IMPORT_5___ = __webpack_require__(13);
    var ___CSS_LOADER_URL_IMPORT_6___ = __webpack_require__(14);
    var ___CSS_LOADER_URL_IMPORT_7___ = __webpack_require__(15);
    var ___CSS_LOADER_URL_IMPORT_8___ = __webpack_require__(16);
    var ___CSS_LOADER_URL_IMPORT_9___ = __webpack_require__(17);
    var ___CSS_LOADER_URL_IMPORT_10___ = __webpack_require__(18);
    var ___CSS_LOADER_URL_IMPORT_11___ = __webpack_require__(19);
    var ___CSS_LOADER_URL_IMPORT_12___ = __webpack_require__(20);
    var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i) {
      return i[1];
    });
    var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
    var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
    var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
    var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
    var ___CSS_LOADER_URL_REPLACEMENT_4___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_4___);
    var ___CSS_LOADER_URL_REPLACEMENT_5___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_5___);
    var ___CSS_LOADER_URL_REPLACEMENT_6___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_6___);
    var ___CSS_LOADER_URL_REPLACEMENT_7___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_7___);
    var ___CSS_LOADER_URL_REPLACEMENT_8___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_8___);
    var ___CSS_LOADER_URL_REPLACEMENT_9___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_9___);
    var ___CSS_LOADER_URL_REPLACEMENT_10___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_10___);
    var ___CSS_LOADER_URL_REPLACEMENT_11___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_11___);
    var ___CSS_LOADER_URL_REPLACEMENT_12___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_12___);
    ___CSS_LOADER_EXPORT___.push([module.i, '/*purgecss start ignore*/\nbody[data-v-655f3ed2],html[data-v-655f3ed2]{\n  font-family:"Poppins","Pretendard",sans-serif\n}\n.container[data-v-655f3ed2]{\n  width:100%;\n  margin:0 auto\n}\n.divider-1[data-v-655f3ed2]{\n  display:block;\n  width:100%;\n  height:1px;\n  background-color:#cfcfcf\n}\n.heading-1[data-v-655f3ed2]{\n  font-size:52px;\n  letter-spacing:-.02em\n}\n.heading-1[data-v-655f3ed2],.heading-2[data-v-655f3ed2]{\n  font-family:"Poppins","Pretendard",sans-serif;\n  font-style:normal;\n  font-weight:500;\n  line-height:100%;\n  color:#181818\n}\n.heading-2[data-v-655f3ed2]{\n  font-size:32px\n}\n.fluidContainer[data-v-655f3ed2]{\n  padding:0 36px\n}\n@media screen and (max-width:767px){\n.fluidContainer[data-v-655f3ed2]{\n    padding:0\n}\n}\n.custom-checkbox[data-v-655f3ed2]{\n  display:block;\n  position:relative;\n  padding-left:30px;\n  margin-bottom:12px;\n  cursor:pointer;\n  font-size:22px;\n  -webkit-user-select:none;\n  -moz-user-select:none;\n  -ms-user-select:none;\n  user-select:none\n}\n.custom-checkbox input[data-v-655f3ed2]{\n  position:absolute;\n  opacity:0;\n  cursor:pointer;\n  height:0;\n  width:0\n}\n.checkmark[data-v-655f3ed2]{\n  position:absolute;\n  top:0;\n  left:0;\n  height:16px;\n  width:16px;\n  background-color:#fff;\n  border:1px solid #bdbdbd\n}\n.custom-checkbox:hover input~.checkmark[data-v-655f3ed2]{\n  background-color:#ececec\n}\n.custom-checkbox input:checked~.checkmark[data-v-655f3ed2]{\n  background-color:#57195c;\n  border:1px solid #57195c\n}\n.checkmark[data-v-655f3ed2]:after{\n  content:"";\n  position:absolute;\n  display:block\n}\n.custom-checkbox input:checked~.checkmark[data-v-655f3ed2]:after{\n  display:block\n}\n.custom-checkbox .checkmark[data-v-655f3ed2]:after{\n  left:5px;\n  top:1px;\n  width:5px;\n  height:10px;\n  border:solid #bdbdbd;\n  border-width:0 1px 1px 0;\n  transform:rotate(45deg)\n}\n.icon-location-pin[data-v-655f3ed2]{\n  background:url(' + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-call[data-v-655f3ed2],.icon-location-pin[data-v-655f3ed2]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-call[data-v-655f3ed2]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax[data-v-655f3ed2]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax[data-v-655f3ed2],.icon-mail[data-v-655f3ed2]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-mail[data-v-655f3ed2]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-train[data-v-655f3ed2]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-bus[data-v-655f3ed2],.icon-train[data-v-655f3ed2]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-bus[data-v-655f3ed2]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb[data-v-655f3ed2]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb[data-v-655f3ed2],.icon-ln[data-v-655f3ed2]{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-ln[data-v-655f3ed2]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu[data-v-655f3ed2]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_8___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu[data-v-655f3ed2],.icon-menu-violet-bg[data-v-655f3ed2]{\n  height:18px;\n  width:26px;\n  display:inline-block\n}\n.icon-menu-violet-bg[data-v-655f3ed2]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_9___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-cross[data-v-655f3ed2]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_10___ + ") no-repeat 50%;\n  background-size:100%;\n  height:19px;\n  width:19px;\n  display:inline-block\n}\n.icon-linkedin-dark[data-v-655f3ed2]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_11___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-facebook-dark[data-v-655f3ed2],.icon-linkedin-dark[data-v-655f3ed2]{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-facebook-dark[data-v-655f3ed2]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_12___ + ') no-repeat 50%;\n  background-size:100%\n}\n.filters[data-v-655f3ed2]{\n  margin-right:50px\n}\n.filters[data-v-655f3ed2]:last-child{\n  margin-right:0\n}\n.dropdown[data-v-655f3ed2]{\n  position:relative\n}\n.dropdown .dropdown-opener[data-v-655f3ed2]{\n  cursor:pointer;\n  position:relative;\n  padding-left:18px\n}\n.dropdown .dropdown-opener[data-v-655f3ed2]:before{\n  content:"";\n  width:8px;\n  height:8px;\n  border:5px solid transparent;\n  border-top-color:#713976;\n  position:absolute;\n  left:0;\n  top:7px\n}\n.dropdown-menu[data-v-655f3ed2]{\n  display:none;\n  position:absolute;\n  top:35px;\n  left:0;\n  z-index:9;\n  padding:12px 24px;\n  min-width:150px;\n  background:#fff;\n  box-shadow:0 3px 10px rgba(0,0,0,.1);\n  border-top:1px solid #000\n}\n.dropdown-menu.active[data-v-655f3ed2]{\n  display:block\n}\n.dropdown-menu .dropdown-item[data-v-655f3ed2]{\n  margin-bottom:16px\n}\n.dropdown-menu .dropdown-item label[data-v-655f3ed2]{\n  font-size:14px;\n  line-height:21px\n}\n.dropdown-menu .clear-filter[data-v-655f3ed2]{\n  color:#695094;\n  font-size:14px;\n  font-weight:500\n}\n\n/*purgecss end ignore*/', ""]);
    ___CSS_LOADER_EXPORT___.locals = {};
    module.exports = ___CSS_LOADER_EXPORT___;
  },
  150: function(module, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var render = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", { staticClass: "flex mb-10" }, [_vm._ssrNode('<div role="button" class="filters" data-v-655f3ed2>All</div> <div class="filters dropdown" data-v-655f3ed2><h4 class="dropdown-opener" data-v-655f3ed2>Sector</h4> <div' + _vm._ssrClass(null, [_vm.sectorState ? "dropdown-menu active" : "dropdown-menu"]) + " data-v-655f3ed2>" + _vm._ssrList(_vm.sectors, function(item, index) {
        return '<div class="dropdown-item" data-v-655f3ed2><label class="custom-checkbox" data-v-655f3ed2>' + _vm._ssrEscape(_vm._s(item.name) + "\n          ") + '<input type="checkbox"' + _vm._ssrAttr("value", item.name) + _vm._ssrAttr("checked", Array.isArray(item.selected) ? _vm._i(item.selected, item.name) > -1 : item.selected) + ' data-v-655f3ed2> <span class="checkmark" data-v-655f3ed2></span></label></div>';
      }) + ' <div data-v-655f3ed2><button class="clear-filter" data-v-655f3ed2>\n          Clear Filter\n        </button></div></div></div> <div class="filters dropdown" data-v-655f3ed2><h4 class="dropdown-opener" data-v-655f3ed2>Status</h4> <div' + _vm._ssrClass(null, [_vm.statusState ? "dropdown-menu active" : "dropdown-menu"]) + " data-v-655f3ed2>" + _vm._ssrList(_vm.status, function(item, index) {
        return '<div class="dropdown-item" data-v-655f3ed2><label class="custom-checkbox" data-v-655f3ed2>' + _vm._ssrEscape(_vm._s(item.name) + "\n          ") + '<input type="checkbox"' + _vm._ssrAttr("value", item.name) + _vm._ssrAttr("checked", Array.isArray(item.selected) ? _vm._i(item.selected, item.name) > -1 : item.selected) + ' data-v-655f3ed2> <span class="checkmark" data-v-655f3ed2></span></label></div>';
      }) + ' <div data-v-655f3ed2><button class="clear-filter" data-v-655f3ed2>\n          Clear Filter\n        </button></div></div></div>')]);
    };
    var staticRenderFns = [];
    var Filtersvue_type_script_lang_js_ = {
      name: "Filters",
      data() {
        return {
          sectors: [{
            id: "01",
            name: "Consumer",
            selected: false
          }, {
            id: "02",
            name: "Enterprise",
            selected: false
          }, {
            id: "03",
            name: "Healthcare",
            selected: false
          }, {
            id: "04",
            name: "Crypto",
            selected: false
          }],
          status: [{
            id: "01",
            name: "Current",
            selected: false
          }, {
            id: "02",
            name: "Alumni",
            selected: false
          }],
          sectorState: false,
          statusState: false,
          check: false
        };
      },
      methods: {
        openSector() {
          this.sectorState = !this.sectorState;
          this.statusState = false;
        },
        openState() {
          this.statusState = !this.statusState;
          this.sectorState = false;
        },
        clearSectors() {
          this.sectors.forEach((item) => item.selected = false);
          console.log("Sector cleared");
        },
        clearStatus() {
          this.status.forEach((i) => i.selected = false);
        },
        filterIt(event) {
          console.log(event.target.value);
        }
      }
    };
    var components_Filtersvue_type_script_lang_js_ = Filtersvue_type_script_lang_js_;
    var componentNormalizer = __webpack_require__(2);
    function injectStyles(context) {
      var style0 = __webpack_require__(141);
      if (style0.__inject__)
        style0.__inject__(context);
    }
    var component = Object(componentNormalizer["a"])(components_Filtersvue_type_script_lang_js_, render, staticRenderFns, false, injectStyles, "655f3ed2", "653c53c0");
    __webpack_exports__["default"] = component.exports;
  }
};

const filters = /*#__PURE__*/Object.freeze(/*#__PURE__*/_mergeNamespaces({
  __proto__: null,
  'default': filters$1,
  ids: ids,
  modules: modules
}, [filters$1]));

export { filters as f };
