import { createError } from 'h3';
import { withLeadingSlash, withoutTrailingSlash, parseURL } from 'ufo';
import { promises } from 'fs';
import { resolve, dirname } from 'pathe';
import { fileURLToPath } from 'url';

const assets = {
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"21bc-XwkmumvsWAWQvKTShmzlcL3xoys\"",
    "mtime": "2022-01-04T08:01:06.007Z",
    "path": "../public/favicon.ico"
  },
  "/keyword.js": {
    "type": "application/javascript",
    "etag": "\"608-HocAf1Q4hxn74DoCwsaXKaTt0VM\"",
    "mtime": "2022-01-05T11:50:26.234Z",
    "path": "../public/keyword.js"
  },
  "/_nuxt/15d1434.js": {
    "type": "application/javascript",
    "etag": "\"a2a-eC9IrQpBu9xKbA51ep6vS31KT4s\"",
    "mtime": "2022-01-18T13:06:21.458Z",
    "path": "../public/_nuxt/15d1434.js"
  },
  "/_nuxt/16085ba.js": {
    "type": "application/javascript",
    "etag": "\"426-1n9h/kEw89JTBI3DlUdBKK+wOyo\"",
    "mtime": "2022-01-18T13:06:21.457Z",
    "path": "../public/_nuxt/16085ba.js"
  },
  "/_nuxt/1ec1868.js": {
    "type": "application/javascript",
    "etag": "\"7c8-ss8T2p64Z6PiYSx1bQScV/AsFPU\"",
    "mtime": "2022-01-18T13:06:21.457Z",
    "path": "../public/_nuxt/1ec1868.js"
  },
  "/_nuxt/251de1c.js": {
    "type": "application/javascript",
    "etag": "\"1031-RxVS0kpMetwIy3XT0Isxr3pwdFY\"",
    "mtime": "2022-01-18T13:06:21.459Z",
    "path": "../public/_nuxt/251de1c.js"
  },
  "/_nuxt/256fa14.js": {
    "type": "application/javascript",
    "etag": "\"48b0-g+gv8aCRKBNL+Y6aBY4vLTKkREc\"",
    "mtime": "2022-01-18T13:06:21.457Z",
    "path": "../public/_nuxt/256fa14.js"
  },
  "/_nuxt/2f25cf0.js": {
    "type": "application/javascript",
    "etag": "\"1405-c3k7HnF/kk0YlI5EENjtVGyRhs0\"",
    "mtime": "2022-01-18T13:06:21.457Z",
    "path": "../public/_nuxt/2f25cf0.js"
  },
  "/_nuxt/36fe957.js": {
    "type": "application/javascript",
    "etag": "\"176-1wCg+OjW9wCzC9K4/8lBy9orM5Y\"",
    "mtime": "2022-01-18T13:06:21.458Z",
    "path": "../public/_nuxt/36fe957.js"
  },
  "/_nuxt/59411f5.js": {
    "type": "application/javascript",
    "etag": "\"19a-5EK6wbzzBbzIamVl3fDwfjQdaGA\"",
    "mtime": "2022-01-18T13:06:21.458Z",
    "path": "../public/_nuxt/59411f5.js"
  },
  "/_nuxt/68de08f.js": {
    "type": "application/javascript",
    "etag": "\"8782-4sqYqAQAbE/cdZGoYFATdLo5GRs\"",
    "mtime": "2022-01-18T13:06:21.458Z",
    "path": "../public/_nuxt/68de08f.js"
  },
  "/_nuxt/71edb36.js": {
    "type": "application/javascript",
    "etag": "\"4b66-mnb+Kw1u0qA/0c8O6fY73aXSVLk\"",
    "mtime": "2022-01-18T13:06:21.458Z",
    "path": "../public/_nuxt/71edb36.js"
  },
  "/_nuxt/76b498a.js": {
    "type": "application/javascript",
    "etag": "\"1f7e-YHYIEOeAZt6mq1bHQttdEo4YsLA\"",
    "mtime": "2022-01-18T13:06:21.453Z",
    "path": "../public/_nuxt/76b498a.js"
  },
  "/_nuxt/7d7fb85.js": {
    "type": "application/javascript",
    "etag": "\"1731-TQ2dMiiRoIshlQySz9tEMGaRXtU\"",
    "mtime": "2022-01-18T13:06:21.453Z",
    "path": "../public/_nuxt/7d7fb85.js"
  },
  "/_nuxt/7f27cee.js": {
    "type": "application/javascript",
    "etag": "\"284f-dgT7prmF7iIoREpuLH5/6o2w2l0\"",
    "mtime": "2022-01-18T13:06:21.457Z",
    "path": "../public/_nuxt/7f27cee.js"
  },
  "/_nuxt/8a47d14.js": {
    "type": "application/javascript",
    "etag": "\"2102c-AZMoteiKyl2XTCut3O8moRuBF3Q\"",
    "mtime": "2022-01-18T13:06:21.453Z",
    "path": "../public/_nuxt/8a47d14.js"
  },
  "/_nuxt/94062ee.js": {
    "type": "application/javascript",
    "etag": "\"2e19-eA0rzs1XWxHzDfd+4i5M5kxTpwY\"",
    "mtime": "2022-01-18T13:06:21.453Z",
    "path": "../public/_nuxt/94062ee.js"
  },
  "/_nuxt/95ae82f.js": {
    "type": "application/javascript",
    "etag": "\"238b0-wA9W4QM7Koke6Nj6Sw09g8nyfhM\"",
    "mtime": "2022-01-18T13:06:21.459Z",
    "path": "../public/_nuxt/95ae82f.js"
  },
  "/_nuxt/95ce8fa.js": {
    "type": "application/javascript",
    "etag": "\"476f-U9qkCTvcqtvgMCK16rJygvbHICE\"",
    "mtime": "2022-01-18T13:06:21.453Z",
    "path": "../public/_nuxt/95ce8fa.js"
  },
  "/_nuxt/9f8d3f9.js": {
    "type": "application/javascript",
    "etag": "\"444e-rfdjVUcgAYlUlISAh2ghUUIaYuQ\"",
    "mtime": "2022-01-18T13:06:21.453Z",
    "path": "../public/_nuxt/9f8d3f9.js"
  },
  "/_nuxt/a73827a.js": {
    "type": "application/javascript",
    "etag": "\"168-RGx1UCyPvIIh731/llMD99lRz4o\"",
    "mtime": "2022-01-18T13:06:21.458Z",
    "path": "../public/_nuxt/a73827a.js"
  },
  "/_nuxt/c32de7f.js": {
    "type": "application/javascript",
    "etag": "\"22ad-5KgKjfJseoJQsJ6q4ZCpLZqyiz0\"",
    "mtime": "2022-01-18T13:06:21.453Z",
    "path": "../public/_nuxt/c32de7f.js"
  },
  "/_nuxt/cfefb2e.js": {
    "type": "application/javascript",
    "etag": "\"19b-6Qq7JyaMl5aRsDtKN7yNQfDseEc\"",
    "mtime": "2022-01-18T13:06:21.457Z",
    "path": "../public/_nuxt/cfefb2e.js"
  },
  "/_nuxt/d1cfdc5.js": {
    "type": "application/javascript",
    "etag": "\"2ffc-k5Nq2inRP+53fMCt1Z+c/Gl6VJo\"",
    "mtime": "2022-01-18T13:06:21.457Z",
    "path": "../public/_nuxt/d1cfdc5.js"
  },
  "/_nuxt/e7a5bc2.js": {
    "type": "application/javascript",
    "etag": "\"1a58-1t/H8iJ21QFOo4jgEldyw+iHT8A\"",
    "mtime": "2022-01-18T13:06:21.454Z",
    "path": "../public/_nuxt/e7a5bc2.js"
  },
  "/_nuxt/ea0615d.js": {
    "type": "application/javascript",
    "etag": "\"35e58-BHNuxmW27JrzBxR6NrSAxa2tI2s\"",
    "mtime": "2022-01-18T13:06:21.453Z",
    "path": "../public/_nuxt/ea0615d.js"
  },
  "/_nuxt/f4afbe1.js": {
    "type": "application/javascript",
    "etag": "\"1a87-lV//M9i9YNLn2/v9C7bwU+hesjk\"",
    "mtime": "2022-01-18T13:06:21.457Z",
    "path": "../public/_nuxt/f4afbe1.js"
  },
  "/_nuxt/img/Advisory1.b24910a.png": {
    "type": "image/png",
    "etag": "\"30989-IxyGA4Wlb/Qj9lxDNLOQ6Aa+24A\"",
    "mtime": "2022-01-18T13:06:21.445Z",
    "path": "../public/_nuxt/img/Advisory1.b24910a.png"
  },
  "/_nuxt/img/Advisory2.e53a553.png": {
    "type": "image/png",
    "etag": "\"304be-veLuCJ5VtZN+8IXny/jQ0oj4dEY\"",
    "mtime": "2022-01-18T13:06:21.444Z",
    "path": "../public/_nuxt/img/Advisory2.e53a553.png"
  },
  "/_nuxt/img/Advisory3.ea295b4.png": {
    "type": "image/png",
    "etag": "\"2d1f6-x3cpBnU37wuXkdHp6lMBZnPHNMU\"",
    "mtime": "2022-01-18T13:06:21.445Z",
    "path": "../public/_nuxt/img/Advisory3.ea295b4.png"
  },
  "/_nuxt/img/Advisory4.d1a9db8.png": {
    "type": "image/png",
    "etag": "\"2bb29-oBGFkv2dMCzOX8sFT6wQmV76f9o\"",
    "mtime": "2022-01-18T13:06:21.445Z",
    "path": "../public/_nuxt/img/Advisory4.d1a9db8.png"
  },
  "/_nuxt/img/Advisory5.362d840.png": {
    "type": "image/png",
    "etag": "\"23908-2yA02vtyzv/h+7k7KnMHYVDqi4k\"",
    "mtime": "2022-01-18T13:06:21.447Z",
    "path": "../public/_nuxt/img/Advisory5.362d840.png"
  },
  "/_nuxt/img/banner-img.65af04a.png": {
    "type": "image/png",
    "etag": "\"aa911-KA8cIeHOqe6mj988/K4LasuBqkk\"",
    "mtime": "2022-01-18T13:06:21.446Z",
    "path": "../public/_nuxt/img/banner-img.65af04a.png"
  },
  "/_nuxt/img/bus.97cd89d.svg": {
    "type": "image/svg+xml",
    "etag": "\"809-gvEOINLqsErQtLZXtPwhqna+Ux0\"",
    "mtime": "2022-01-18T13:06:21.442Z",
    "path": "../public/_nuxt/img/bus.97cd89d.svg"
  },
  "/_nuxt/img/call.5036bc5.svg": {
    "type": "image/svg+xml",
    "etag": "\"56c-1VL670sWM1rvEy005UDJ7PbSvxk\"",
    "mtime": "2022-01-18T13:06:21.438Z",
    "path": "../public/_nuxt/img/call.5036bc5.svg"
  },
  "/_nuxt/img/founder-logo.b9621cc.png": {
    "type": "image/png",
    "etag": "\"1435-ZMMzaqMM+q6vEDq3uvqhPdUzkto\"",
    "mtime": "2022-01-18T13:06:21.448Z",
    "path": "../public/_nuxt/img/founder-logo.b9621cc.png"
  },
  "/_nuxt/img/site-logo-white.e4d9897.svg": {
    "type": "image/svg+xml",
    "etag": "\"d51a-sDDDYf/G/B5f7nJHq8coR9raJsg\"",
    "mtime": "2022-01-18T13:06:21.443Z",
    "path": "../public/_nuxt/img/site-logo-white.e4d9897.svg"
  },
  "/_nuxt/img/site-logo.4909022.svg": {
    "type": "image/svg+xml",
    "etag": "\"fddb-jUY21T3Iq7F8/u2X75pVH+Kj0yY\"",
    "mtime": "2022-01-18T13:06:21.443Z",
    "path": "../public/_nuxt/img/site-logo.4909022.svg"
  },
  "/_nuxt/img/team-01.ab440f2.jpg": {
    "type": "image/jpeg",
    "etag": "\"1f9d1-Bb8po0qQHfOAOVzb0lbYzcseTcA\"",
    "mtime": "2022-01-18T13:06:21.444Z",
    "path": "../public/_nuxt/img/team-01.ab440f2.jpg"
  },
  "/_nuxt/img/team-02.a3e9697.jpg": {
    "type": "image/jpeg",
    "etag": "\"204e4-16rOlBBYzrCSh/zF+ztTTdwU2ZU\"",
    "mtime": "2022-01-18T13:06:21.448Z",
    "path": "../public/_nuxt/img/team-02.a3e9697.jpg"
  },
  "/_nuxt/img/team-03.0f324f2.jpg": {
    "type": "image/jpeg",
    "etag": "\"223b1-NZtyJgjiekEscHwNJq0Q+2iGTv8\"",
    "mtime": "2022-01-18T13:06:21.448Z",
    "path": "../public/_nuxt/img/team-03.0f324f2.jpg"
  },
  "/_nuxt/img/team-04.2b04ab2.jpg": {
    "type": "image/jpeg",
    "etag": "\"23e27-tANwPGxLYngbjqfSP9qaSh9nJeU\"",
    "mtime": "2022-01-18T13:06:21.453Z",
    "path": "../public/_nuxt/img/team-04.2b04ab2.jpg"
  },
  "/_nuxt/img/team-05.92858aa.jpg": {
    "type": "image/jpeg",
    "etag": "\"18895-Vsv7l5kiwQ0lXmT9/9RzlHt8wx4\"",
    "mtime": "2022-01-18T13:06:21.454Z",
    "path": "../public/_nuxt/img/team-05.92858aa.jpg"
  },
  "/_nuxt/img/team-06.2a0717d.jpg": {
    "type": "image/jpeg",
    "etag": "\"2f41c-HJ6s3XTdK97xBKmhb8Vt7lrkuKM\"",
    "mtime": "2022-01-18T13:06:21.454Z",
    "path": "../public/_nuxt/img/team-06.2a0717d.jpg"
  },
  "/_nuxt/img/team-07.1a260eb.jpg": {
    "type": "image/jpeg",
    "etag": "\"2546c-jN0GUjppQ1N13U5869jR8H/2Gz4\"",
    "mtime": "2022-01-18T13:06:21.454Z",
    "path": "../public/_nuxt/img/team-07.1a260eb.jpg"
  },
  "/_nuxt/img/team-08.95c65ac.jpg": {
    "type": "image/jpeg",
    "etag": "\"21198-tygKE4WhEepdnfh3rGhWP3GWKMk\"",
    "mtime": "2022-01-18T13:06:21.454Z",
    "path": "../public/_nuxt/img/team-08.95c65ac.jpg"
  },
  "/_nuxt/img/team-09.b18340d.jpg": {
    "type": "image/jpeg",
    "etag": "\"1548d-NJiXoX6CxjlKs7JyjdkzNrdhXaE\"",
    "mtime": "2022-01-18T13:06:21.455Z",
    "path": "../public/_nuxt/img/team-09.b18340d.jpg"
  },
  "/_nuxt/img/train.3020f72.svg": {
    "type": "image/svg+xml",
    "etag": "\"5bb-0FxFhIQk6X0S7Id2//SGLoxfRyg\"",
    "mtime": "2022-01-18T13:06:21.451Z",
    "path": "../public/_nuxt/img/train.3020f72.svg"
  }
};

const mainDir = dirname(fileURLToPath(globalThis.entryURL));

function readAsset (id) {
  return promises.readFile(resolve(mainDir, getAsset(id).path))
}

function getAsset (id) {
  return assets[id]
}

const METHODS = ["HEAD", "GET"];
const PUBLIC_PATH = "/_nuxt/";
const TWO_DAYS = 2 * 60 * 60 * 24;
const STATIC_ASSETS_BASE = "/_nuxt/static" + "/" + "1642511113";
async function serveStatic(req, res) {
  if (!METHODS.includes(req.method)) {
    return;
  }
  let id = withLeadingSlash(withoutTrailingSlash(parseURL(req.url).pathname));
  let asset = getAsset(id);
  if (!asset) {
    const _id = id + "/index.html";
    const _asset = getAsset(_id);
    if (_asset) {
      asset = _asset;
      id = _id;
    }
  }
  if (!asset) {
    if (id.startsWith(PUBLIC_PATH) && !id.startsWith(STATIC_ASSETS_BASE)) {
      throw createError({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = req.headers["if-none-match"] === asset.etag;
  if (ifNotMatch) {
    res.statusCode = 304;
    return res.end("Not Modified (etag)");
  }
  const ifModifiedSinceH = req.headers["if-modified-since"];
  if (ifModifiedSinceH && asset.mtime) {
    if (new Date(ifModifiedSinceH) >= new Date(asset.mtime)) {
      res.statusCode = 304;
      return res.end("Not Modified (mtime)");
    }
  }
  if (asset.type) {
    res.setHeader("Content-Type", asset.type);
  }
  if (asset.etag) {
    res.setHeader("ETag", asset.etag);
  }
  if (asset.mtime) {
    res.setHeader("Last-Modified", asset.mtime);
  }
  if (id.startsWith(PUBLIC_PATH)) {
    res.setHeader("Cache-Control", `max-age=${TWO_DAYS}, immutable`);
  }
  const contents = await readAsset(id);
  return res.end(contents);
}

export { serveStatic as default };
