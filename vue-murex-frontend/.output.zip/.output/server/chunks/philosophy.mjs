function _mergeNamespaces(n, m) {
  for (var i = 0; i < m.length; i++) {
    const e = m[i];
    if (typeof e !== 'string' && !Array.isArray(e)) { for (const k in e) {
      if (k !== 'default' && !(k in n)) {
        const d = Object.getOwnPropertyDescriptor(e, k);
        if (d) {
          Object.defineProperty(n, k, d.get ? d : {
            enumerable: true,
            get: function () { return e[k]; }
          });
        }
      }
    } }
  }
  return Object.freeze(n);
}

var philosophy$1 = {};

var ids = philosophy$1.ids = [18];
var modules = philosophy$1.modules = {
  175: function(module, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var render = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", { staticClass: "philosophy" }, [_vm._ssrNode("<h1 data-v-7855ca6e>" + _vm._ssrEscape("philosophy -- " + _vm._s(_vm.$route.path)) + "</h1>")]);
    };
    var staticRenderFns = [];
    var philosophyvue_type_script_lang_js_ = {
      name: "philosophy"
    };
    var pages_philosophyvue_type_script_lang_js_ = philosophyvue_type_script_lang_js_;
    var componentNormalizer = __webpack_require__(2);
    function injectStyles(context) {
    }
    var component = Object(componentNormalizer["a"])(pages_philosophyvue_type_script_lang_js_, render, staticRenderFns, false, injectStyles, "7855ca6e", "24c55e54");
    __webpack_exports__["default"] = component.exports;
  }
};

const philosophy = /*#__PURE__*/Object.freeze(/*#__PURE__*/_mergeNamespaces({
  __proto__: null,
  'default': philosophy$1,
  ids: ids,
  modules: modules
}, [philosophy$1]));

export { philosophy as p };
