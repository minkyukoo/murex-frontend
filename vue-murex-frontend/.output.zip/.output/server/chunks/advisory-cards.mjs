function _mergeNamespaces(n, m) {
  for (var i = 0; i < m.length; i++) {
    const e = m[i];
    if (typeof e !== 'string' && !Array.isArray(e)) { for (const k in e) {
      if (k !== 'default' && !(k in n)) {
        const d = Object.getOwnPropertyDescriptor(e, k);
        if (d) {
          Object.defineProperty(n, k, d.get ? d : {
            enumerable: true,
            get: function () { return e[k]; }
          });
        }
      }
    } }
  }
  return Object.freeze(n);
}

var advisoryCards$1 = {};

var ids = advisoryCards$1.ids = [1, 9];
var modules = advisoryCards$1.modules = {
  101: function(module, exports2) {
    module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTIiIGN5PSIxMiIgcj0iMTEuNSIgc3Ryb2tlPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNOS41IDdWMTZNMTMuNSA3VjE2IiBzdHJva2U9IndoaXRlIi8+Cjwvc3ZnPgo=";
  },
  102: function(module, exports2, __webpack_require__) {
    var content = __webpack_require__(125);
    if (content.__esModule)
      content = content.default;
    if (typeof content === "string")
      content = [[module.i, content, ""]];
    if (content.locals)
      module.exports = content.locals;
    var add = __webpack_require__(5).default;
    module.exports.__inject__ = function(context) {
      add("c402a25c", content, true, context);
    };
  },
  103: function(module, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var render = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", { staticClass: "team-item", on: { "click": _vm.MemberInfo } }, [_vm._ssrNode("<img" + _vm._ssrAttr("src", "" + __webpack_require__(105)("./" + _vm.bgImage)) + _vm._ssrAttr("alt", "" + _vm.name) + " data-v-7dffd1bf> "), _vm._ssrNode('<div class="team-desc" data-v-7dffd1bf>', "</div>", [_vm._ssrNode('<div class="team-desc-cont" data-v-7dffd1bf><p class="name" data-v-7dffd1bf>' + _vm._ssrEscape(_vm._s(_vm.name)) + '</p> <p class="designation" data-v-7dffd1bf>' + _vm._ssrEscape(_vm._s(_vm.designation)) + "</p></div> "), "" + _vm.$nuxt.$route.path === "/team" ? _vm._ssrNode('<div class="sns-links" data-v-7dffd1bf>', "</div>", [_vm.snsLnLink ? _c("nuxt-link", { staticClass: "sns-link", attrs: { "to": "" + _vm.snsLnLink } }, [_c("i", { staticClass: "icon-ln" })]) : _vm._e(), _vm._ssrNode(" "), _vm.snsFbLink ? _c("nuxt-link", { staticClass: "sns-link", attrs: { "to": "" + _vm.snsFbLink } }, [_c("i", { staticClass: "icon-fb" })]) : _vm._e()], 2) : "" + _vm.$nuxt.$route.path === "/founders" ? _vm._ssrNode('<div class="sns-links" data-v-7dffd1bf>', "</div>", [_c("nuxt-link", { staticClass: "sns-link", attrs: { "to": "/#" } }, [_c("img", { attrs: { "src": __webpack_require__(123) } })])], 1) : _vm._e()], 2)], 2);
    };
    var staticRenderFns = [];
    var TeamCardvue_type_script_lang_js_ = {
      name: "TeamCard",
      props: {
        bgImage: String,
        name: String,
        designation: String,
        snsFbLink: String,
        snsLnLink: String
      },
      methods: {
        MemberInfo() {
          this.$emit("openModal", true);
          console.log("member clicked");
        }
      }
    };
    var components_TeamCardvue_type_script_lang_js_ = TeamCardvue_type_script_lang_js_;
    var componentNormalizer = __webpack_require__(2);
    function injectStyles(context) {
      var style0 = __webpack_require__(124);
      if (style0.__inject__)
        style0.__inject__(context);
    }
    var component = Object(componentNormalizer["a"])(components_TeamCardvue_type_script_lang_js_, render, staticRenderFns, false, injectStyles, "7dffd1bf", "1be7cbb8");
    __webpack_exports__["default"] = component.exports;
  },
  104: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/team-01.ab440f2.jpg";
  },
  105: function(module, exports2, __webpack_require__) {
    var map = {
      "./Advisory1.png": 106,
      "./Advisory2.png": 107,
      "./Advisory3.png": 108,
      "./Advisory4.png": 109,
      "./Advisory5.png": 110,
      "./banner-img.png": 111,
      "./founder-logo.png": 112,
      "./pause.svg": 101,
      "./site-logo-white.svg": 71,
      "./site-logo.svg": 72,
      "./team-01.jpg": 104,
      "./team-02.jpg": 113,
      "./team-03.jpg": 114,
      "./team-04.jpg": 115,
      "./team-05.jpg": 116,
      "./team-06.jpg": 117,
      "./team-07.jpg": 118,
      "./team-08.jpg": 119,
      "./team-09.jpg": 120,
      "./track.svg": 121
    };
    function webpackContext(req) {
      var id = webpackContextResolve(req);
      return __webpack_require__(id);
    }
    function webpackContextResolve(req) {
      if (!__webpack_require__.o(map, req)) {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = "MODULE_NOT_FOUND";
        throw e;
      }
      return map[req];
    }
    webpackContext.keys = function webpackContextKeys() {
      return Object.keys(map);
    };
    webpackContext.resolve = webpackContextResolve;
    module.exports = webpackContext;
    webpackContext.id = 105;
  },
  106: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/Advisory1.b24910a.png";
  },
  107: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/Advisory2.e53a553.png";
  },
  108: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/Advisory3.ea295b4.png";
  },
  109: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/Advisory4.d1a9db8.png";
  },
  110: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/Advisory5.362d840.png";
  },
  111: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/banner-img.65af04a.png";
  },
  112: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/founder-logo.b9621cc.png";
  },
  113: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/team-02.a3e9697.jpg";
  },
  114: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/team-03.0f324f2.jpg";
  },
  115: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/team-04.2b04ab2.jpg";
  },
  116: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/team-05.92858aa.jpg";
  },
  117: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/team-06.2a0717d.jpg";
  },
  118: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/team-07.1a260eb.jpg";
  },
  119: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/team-08.95c65ac.jpg";
  },
  120: function(module, exports2, __webpack_require__) {
    module.exports = __webpack_require__.p + "img/team-09.b18340d.jpg";
  },
  121: function(module, exports2) {
    module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzk4IiBoZWlnaHQ9IjIiIHZpZXdCb3g9IjAgMCAzOTggMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGxpbmUgeTE9IjEuNSIgeDI9IjM5OCIgeTI9IjEuNSIgc3Ryb2tlPSIjNjY2NjY2Ii8+CjxsaW5lIHkxPSIxIiB4Mj0iOTkuNSIgeTI9IjEiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMiIvPgo8L3N2Zz4K";
  },
  123: function(module, exports2) {
    module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTYiIGhlaWdodD0iNjEiIHZpZXdCb3g9IjAgMCA1NiA2MSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTI3Ljk2OTIgMC4xNjY2MjZWNjAuODMzM00wLjI5MDAzOSAzMC41SDU1LjY0ODQiIHN0cm9rZT0iIzE4MTgxOCIgc3Ryb2tlLXdpZHRoPSIxLjUiLz4KPC9zdmc+Cg==";
  },
  124: function(module, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_TeamCard_vue_vue_type_style_index_0_id_7dffd1bf_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(102);
    for (var __WEBPACK_IMPORT_KEY__ in _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_TeamCard_vue_vue_type_style_index_0_id_7dffd1bf_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__)
      if (["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0)
        (function(key) {
          __webpack_require__.d(__webpack_exports__, key, function() {
            return _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_TeamCard_vue_vue_type_style_index_0_id_7dffd1bf_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key];
          });
        })(__WEBPACK_IMPORT_KEY__);
  },
  125: function(module, exports2, __webpack_require__) {
    var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
    var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(7);
    var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(8);
    var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(9);
    var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(10);
    var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(11);
    var ___CSS_LOADER_URL_IMPORT_4___ = __webpack_require__(12);
    var ___CSS_LOADER_URL_IMPORT_5___ = __webpack_require__(13);
    var ___CSS_LOADER_URL_IMPORT_6___ = __webpack_require__(14);
    var ___CSS_LOADER_URL_IMPORT_7___ = __webpack_require__(15);
    var ___CSS_LOADER_URL_IMPORT_8___ = __webpack_require__(16);
    var ___CSS_LOADER_URL_IMPORT_9___ = __webpack_require__(17);
    var ___CSS_LOADER_URL_IMPORT_10___ = __webpack_require__(18);
    var ___CSS_LOADER_URL_IMPORT_11___ = __webpack_require__(19);
    var ___CSS_LOADER_URL_IMPORT_12___ = __webpack_require__(20);
    var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i) {
      return i[1];
    });
    var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
    var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
    var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
    var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
    var ___CSS_LOADER_URL_REPLACEMENT_4___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_4___);
    var ___CSS_LOADER_URL_REPLACEMENT_5___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_5___);
    var ___CSS_LOADER_URL_REPLACEMENT_6___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_6___);
    var ___CSS_LOADER_URL_REPLACEMENT_7___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_7___);
    var ___CSS_LOADER_URL_REPLACEMENT_8___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_8___);
    var ___CSS_LOADER_URL_REPLACEMENT_9___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_9___);
    var ___CSS_LOADER_URL_REPLACEMENT_10___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_10___);
    var ___CSS_LOADER_URL_REPLACEMENT_11___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_11___);
    var ___CSS_LOADER_URL_REPLACEMENT_12___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_12___);
    ___CSS_LOADER_EXPORT___.push([module.i, '/*purgecss start ignore*/\nbody[data-v-7dffd1bf],html[data-v-7dffd1bf]{\n  font-family:"Poppins","Pretendard",sans-serif\n}\n.container[data-v-7dffd1bf]{\n  width:100%;\n  margin:0 auto\n}\n.divider-1[data-v-7dffd1bf]{\n  display:block;\n  width:100%;\n  height:1px;\n  background-color:#cfcfcf\n}\n.heading-1[data-v-7dffd1bf]{\n  font-size:52px;\n  letter-spacing:-.02em\n}\n.heading-1[data-v-7dffd1bf],.heading-2[data-v-7dffd1bf]{\n  font-family:"Poppins","Pretendard",sans-serif;\n  font-style:normal;\n  font-weight:500;\n  line-height:100%;\n  color:#181818\n}\n.heading-2[data-v-7dffd1bf]{\n  font-size:32px\n}\n.fluidContainer[data-v-7dffd1bf]{\n  padding:0 36px\n}\n@media screen and (max-width:767px){\n.fluidContainer[data-v-7dffd1bf]{\n    padding:0\n}\n}\n.custom-checkbox[data-v-7dffd1bf]{\n  display:block;\n  position:relative;\n  padding-left:30px;\n  margin-bottom:12px;\n  cursor:pointer;\n  font-size:22px;\n  -webkit-user-select:none;\n  -moz-user-select:none;\n  -ms-user-select:none;\n  user-select:none\n}\n.custom-checkbox input[data-v-7dffd1bf]{\n  position:absolute;\n  opacity:0;\n  cursor:pointer;\n  height:0;\n  width:0\n}\n.checkmark[data-v-7dffd1bf]{\n  position:absolute;\n  top:0;\n  left:0;\n  height:16px;\n  width:16px;\n  background-color:#fff;\n  border:1px solid #bdbdbd\n}\n.custom-checkbox:hover input~.checkmark[data-v-7dffd1bf]{\n  background-color:#ececec\n}\n.custom-checkbox input:checked~.checkmark[data-v-7dffd1bf]{\n  background-color:#57195c;\n  border:1px solid #57195c\n}\n.checkmark[data-v-7dffd1bf]:after{\n  content:"";\n  position:absolute;\n  display:block\n}\n.custom-checkbox input:checked~.checkmark[data-v-7dffd1bf]:after{\n  display:block\n}\n.custom-checkbox .checkmark[data-v-7dffd1bf]:after{\n  left:5px;\n  top:1px;\n  width:5px;\n  height:10px;\n  border:solid #bdbdbd;\n  border-width:0 1px 1px 0;\n  transform:rotate(45deg)\n}\n.icon-location-pin[data-v-7dffd1bf]{\n  background:url(' + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-call[data-v-7dffd1bf],.icon-location-pin[data-v-7dffd1bf]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-call[data-v-7dffd1bf]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax[data-v-7dffd1bf]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax[data-v-7dffd1bf],.icon-mail[data-v-7dffd1bf]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-mail[data-v-7dffd1bf]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-train[data-v-7dffd1bf]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-bus[data-v-7dffd1bf],.icon-train[data-v-7dffd1bf]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-bus[data-v-7dffd1bf]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb[data-v-7dffd1bf]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb[data-v-7dffd1bf],.icon-ln[data-v-7dffd1bf]{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-ln[data-v-7dffd1bf]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu[data-v-7dffd1bf]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_8___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu[data-v-7dffd1bf],.icon-menu-violet-bg[data-v-7dffd1bf]{\n  height:18px;\n  width:26px;\n  display:inline-block\n}\n.icon-menu-violet-bg[data-v-7dffd1bf]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_9___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-cross[data-v-7dffd1bf]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_10___ + ") no-repeat 50%;\n  background-size:100%;\n  height:19px;\n  width:19px;\n  display:inline-block\n}\n.icon-linkedin-dark[data-v-7dffd1bf]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_11___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-facebook-dark[data-v-7dffd1bf],.icon-linkedin-dark[data-v-7dffd1bf]{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-facebook-dark[data-v-7dffd1bf]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_12___ + ') no-repeat 50%;\n  background-size:100%\n}\n.team-item[data-v-7dffd1bf]{\n  background-repeat:no-repeat;\n  background-position:50%;\n  background-size:cover;\n  position:relative;\n  overflow:hidden\n}\n.team-item:hover .team-desc .sns-links[data-v-7dffd1bf]{\n  transform:translateY(0);\n  opacity:1;\n  transition:all .3s ease\n}\n.team-item img[data-v-7dffd1bf]{\n  width:100%\n}\n.team-item .team-desc[data-v-7dffd1bf]{\n  position:absolute;\n  bottom:0;\n  display:flex;\n  justify-content:space-between;\n  align-items:center;\n  width:100%;\n  padding:25px 5px 25px 25px\n}\n@media screen and (max-width:767px){\n.team-item .team-desc[data-v-7dffd1bf]{\n    padding:15px\n}\n}\n.team-item .team-desc .team-desc-cont .name[data-v-7dffd1bf]{\n  font-family:"Poppins","Pretendard",sans-serif;\n  font-style:normal;\n  font-weight:600;\n  font-size:24px;\n  line-height:130%;\n  letter-spacing:.02em;\n  color:#fff;\n  margin-bottom:4px\n}\n@media screen and (max-width:767px){\n.team-item .team-desc .team-desc-cont .name[data-v-7dffd1bf]{\n    font-size:14px\n}\n}\n.team-item .team-desc .team-desc-cont .designation[data-v-7dffd1bf]{\n  font-family:"Poppins","Pretendard",sans-serif;\n  font-style:normal;\n  font-weight:400;\n  font-size:14px;\n  line-height:17px;\n  color:#fff\n}\n@media screen and (max-width:767px){\n.team-item .team-desc .team-desc-cont .designation[data-v-7dffd1bf]{\n    font-size:10px\n}\n}\n.team-item .team-desc .sns-links[data-v-7dffd1bf]{\n  transform:translateY(100%);\n  opacity:0;\n  transition:all .3s ease\n}\n.team-item .team-desc .sns-links .sns-link[data-v-7dffd1bf]{\n  display:inline-block;\n  margin-right:12px;\n  vertical-align:middle\n}\n.team-item .team-desc .sns-links .sns-link[data-v-7dffd1bf]:last-child{\n  margin-right:0\n}\n\n/*purgecss end ignore*/', ""]);
    ___CSS_LOADER_EXPORT___.locals = {};
    module.exports = ___CSS_LOADER_EXPORT___;
  },
  153: function(module, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var render = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", { staticClass: "grid grid-cols-2 lg:grid-cols-4 md:gap-4 lg:gap-8" }, _vm._l(_vm.teams, function(team, i) {
        return _c("TeamCard", { key: team.id || i + 1, attrs: { "bgImage": team.image, "name": team.name, "designation": team.designation, "snsFbLink": team.sns_links.fb, "snsLnLink": team.sns_links.ln }, on: { "openModal": _vm.OpenModal } });
      }), 1);
    };
    var staticRenderFns = [];
    var TeamCard = __webpack_require__(103);
    var AdvisoryCardsvue_type_script_lang_js_ = {
      name: "TeamCards",
      components: {
        TeamCard: TeamCard["default"]
      },
      data() {
        return {
          pageHeading: "Our Team",
          teams: [{
            id: 1,
            name: "\uAE40\uD0DD\uB3D9",
            designation: "\uBCA4\uCC98\uD30C\uD2B8\uB108 / \uB808\uC774\uD06C\uD22C\uC790\uC790\uBB38 \uB300\uD45C\uC774\uC0AC",
            image: "Advisory1.png",
            sns_links: {
              fb: "https://facebook.com",
              ln: "https://linkedin.com"
            }
          }, {
            id: 2,
            name: "\uAC15\uB3D9\uBBFC",
            designation: "\uBD80\uC0AC\uC7A5 / Co-Founder",
            image: "Advisory2.png",
            sns_links: {
              fb: "https://facebook.com",
              ln: "https://linkedin.com"
            }
          }, {
            id: 3,
            name: "\uC624\uC9C0\uC131",
            designation: "\uBD80\uC0AC\uC7A5 / Co-Founder",
            image: "Advisory3.png",
            sns_links: {
              fb: "https://facebook.com",
              ln: "https://linkedin.com"
            }
          }, {
            id: 4,
            name: "\uBC15\uC9C4\uC601",
            designation: "\uC218\uC11D",
            image: "Advisory4.png",
            sns_links: {
              fb: "https://facebook.com",
              ln: "https://linkedin.com"
            }
          }, {
            id: 5,
            name: "\uAE40\uC138\uC9C4",
            designation: "\uC218\uC11D",
            image: "Advisory5.png",
            sns_links: {
              fb: "https://facebook.com",
              ln: "https://linkedin.com"
            }
          }]
        };
      },
      methods: {
        OpenModal() {
          this.$emit("openModal", true);
          console.log("member click passed");
        }
      }
    };
    var components_AdvisoryCardsvue_type_script_lang_js_ = AdvisoryCardsvue_type_script_lang_js_;
    var componentNormalizer = __webpack_require__(2);
    function injectStyles(context) {
    }
    var component = Object(componentNormalizer["a"])(components_AdvisoryCardsvue_type_script_lang_js_, render, staticRenderFns, false, injectStyles, "8387bed6", "100caf0f");
    __webpack_exports__["default"] = component.exports;
    installComponents(component, { TeamCard: __webpack_require__(103).default });
  }
};

const advisoryCards = /*#__PURE__*/Object.freeze(/*#__PURE__*/_mergeNamespaces({
  __proto__: null,
  'default': advisoryCards$1,
  ids: ids,
  modules: modules
}, [advisoryCards$1]));

export { advisoryCards as a };
