import { g as getDefaultExportFromNamespaceIfNotNamed, c as commonjsGlobal } from './_commonjsHelpers.mjs';
import * as ufo from 'ufo';
import * as cookieEs from 'cookie-es';
import * as esnext_set_addAll from 'core-js/modules/esnext.set.add-all.js';
import * as esnext_set_deleteAll from 'core-js/modules/esnext.set.delete-all.js';
import * as esnext_set_difference from 'core-js/modules/esnext.set.difference.js';
import * as esnext_set_every from 'core-js/modules/esnext.set.every.js';
import * as esnext_set_filter from 'core-js/modules/esnext.set.filter.js';
import * as esnext_set_find from 'core-js/modules/esnext.set.find.js';
import * as esnext_set_intersection from 'core-js/modules/esnext.set.intersection.js';
import * as esnext_set_isDisjointFrom from 'core-js/modules/esnext.set.is-disjoint-from.js';
import * as esnext_set_isSubsetOf from 'core-js/modules/esnext.set.is-subset-of.js';
import * as esnext_set_isSupersetOf from 'core-js/modules/esnext.set.is-superset-of.js';
import * as esnext_set_join from 'core-js/modules/esnext.set.join.js';
import * as esnext_set_map from 'core-js/modules/esnext.set.map.js';
import * as esnext_set_reduce from 'core-js/modules/esnext.set.reduce.js';
import * as esnext_set_some from 'core-js/modules/esnext.set.some.js';
import * as esnext_set_symmetricDifference from 'core-js/modules/esnext.set.symmetric-difference.js';
import * as esnext_set_union from 'core-js/modules/esnext.set.union.js';
import * as cookie from 'cookie';
import * as esnext_map_deleteAll from 'core-js/modules/esnext.map.delete-all.js';
import * as esnext_map_every from 'core-js/modules/esnext.map.every.js';
import * as esnext_map_filter from 'core-js/modules/esnext.map.filter.js';
import * as esnext_map_find from 'core-js/modules/esnext.map.find.js';
import * as esnext_map_findKey from 'core-js/modules/esnext.map.find-key.js';
import * as esnext_map_includes from 'core-js/modules/esnext.map.includes.js';
import * as esnext_map_keyOf from 'core-js/modules/esnext.map.key-of.js';
import * as esnext_map_mapKeys from 'core-js/modules/esnext.map.map-keys.js';
import * as esnext_map_mapValues from 'core-js/modules/esnext.map.map-values.js';
import * as esnext_map_merge from 'core-js/modules/esnext.map.merge.js';
import * as esnext_map_reduce from 'core-js/modules/esnext.map.reduce.js';
import * as esnext_map_some from 'core-js/modules/esnext.map.some.js';
import * as esnext_map_update from 'core-js/modules/esnext.map.update.js';
import * as murmurhashEs from 'murmurhash-es';
import * as h3 from 'h3';
import * as destr from 'destr';
import * as hookable from 'hookable';
import * as esnext_weakMap_deleteAll from 'core-js/modules/esnext.weak-map.delete-all.js';
import * as deepmerge from 'deepmerge';
import * as jsCookie from 'js-cookie';
import * as url from 'url';
import * as devalue from 'devalue';

var server$2 = {exports: {}};

const require$$0 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(ufo);

const require$$1 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(cookieEs);

const require$$2 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_addAll);

const require$$3 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_deleteAll);

const require$$4 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_difference);

const require$$5 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_every);

const require$$6 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_filter);

const require$$7 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_find);

const require$$8 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_intersection);

const require$$9 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_isDisjointFrom);

const require$$10 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_isSubsetOf);

const require$$11 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_isSupersetOf);

const require$$12 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_join);

const require$$13 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_map);

const require$$14 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_reduce);

const require$$15 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_some);

const require$$16 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_symmetricDifference);

const require$$17 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_set_union);

const require$$18 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(cookie);

const require$$19 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_map_deleteAll);

const require$$20 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_map_every);

const require$$21 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_map_filter);

const require$$22 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_map_find);

const require$$23 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_map_findKey);

const require$$24 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_map_includes);

const require$$25 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_map_keyOf);

const require$$26 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_map_mapKeys);

const require$$27 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_map_mapValues);

const require$$28 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_map_merge);

const require$$29 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_map_reduce);

const require$$30 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_map_some);

const require$$31 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_map_update);

const require$$32 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(murmurhashEs);

const require$$33 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(h3);

const require$$34 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(destr);

const require$$35 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(hookable);

const require$$36 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(esnext_weakMap_deleteAll);

const require$$37 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(deepmerge);

const require$$38 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(jsCookie);

const require$$39 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(url);

const require$$40 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(devalue);

(function (module) {
module.exports = function(modules) {
  var installedModules = {};
  var installedChunks = {
    0: 0
  };
  function __webpack_require__(moduleId) {
    if (installedModules[moduleId]) {
      return installedModules[moduleId].exports;
    }
    var module2 = installedModules[moduleId] = {
      i: moduleId,
      l: false,
      exports: {}
    };
    modules[moduleId].call(module2.exports, module2, module2.exports, __webpack_require__);
    module2.l = true;
    return module2.exports;
  }
  __webpack_require__.e = function requireEnsure(chunkId) {
    var promises = [];
    var installedChunkData = installedChunks[chunkId];
    if (installedChunkData !== 0) {
      if (installedChunkData) {
        promises.push(installedChunkData[2]);
      } else {
        var promise = new Promise(function(resolve, reject) {
          installedChunkData = installedChunks[chunkId] = [resolve, reject];
          import('./_dynamic-require.mjs').then(r => r.default || r).then(dynamicRequire => dynamicRequire( ({ "1": "components/advisory-cards", "2": "components/banner", "3": "components/banner-state", "4": "components/contact-info-item", "5": "components/filters", "6": "components/founder-cards", "7": "components/modal", "8": "components/nuxt-logo", "9": "components/team-card", "10": "components/team-cards", "11": "components/top-heading", "12": "components/tutorial", "13": "pages/about", "14": "pages/contact", "15": "pages/contents", "16": "pages/founders", "17": "pages/index", "18": "pages/philosophy", "19": "pages/team", "20": "pages/users" }[chunkId] || chunkId) + ".js")).then((chunk) => {
            var moreModules = chunk.modules, chunkIds = chunk.ids;
            for (var moduleId in moreModules) {
              modules[moduleId] = moreModules[moduleId];
            }
            var callbacks = [];
            for (var i = 0; i < chunkIds.length; i++) {
              if (installedChunks[chunkIds[i]])
                callbacks = callbacks.concat(installedChunks[chunkIds[i]][0]);
              installedChunks[chunkIds[i]] = 0;
            }
            for (i = 0; i < callbacks.length; i++)
              callbacks[i]();
          });
        });
        promises.push(installedChunkData[2] = promise);
      }
    }
    return Promise.all(promises);
  };
  __webpack_require__.m = modules;
  __webpack_require__.c = installedModules;
  __webpack_require__.d = function(exports, name, getter) {
    if (!__webpack_require__.o(exports, name)) {
      Object.defineProperty(exports, name, { enumerable: true, get: getter });
    }
  };
  __webpack_require__.r = function(exports) {
    if (typeof Symbol !== "undefined" && Symbol.toStringTag) {
      Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
    }
    Object.defineProperty(exports, "__esModule", { value: true });
  };
  __webpack_require__.t = function(value, mode) {
    if (mode & 1)
      value = __webpack_require__(value);
    if (mode & 8)
      return value;
    if (mode & 4 && typeof value === "object" && value && value.__esModule)
      return value;
    var ns = Object.create(null);
    __webpack_require__.r(ns);
    Object.defineProperty(ns, "default", { enumerable: true, value });
    if (mode & 2 && typeof value != "string")
      for (var key in value)
        __webpack_require__.d(ns, key, function(key2) {
          return value[key2];
        }.bind(null, key));
    return ns;
  };
  __webpack_require__.n = function(module2) {
    var getter = module2 && module2.__esModule ? function getDefault() {
      return module2["default"];
    } : function getModuleExports() {
      return module2;
    };
    __webpack_require__.d(getter, "a", getter);
    return getter;
  };
  __webpack_require__.o = function(object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  __webpack_require__.p = "/_nuxt/";
  __webpack_require__.oe = function(err) {
    process.nextTick(function() {
      throw err;
    });
  };
  return __webpack_require__(__webpack_require__.s = 74);
}([
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.d(__webpack_exports__, "a", function() {
      return EffectScope;
    });
    __webpack_require__.d(__webpack_exports__, "b", function() {
      return computed;
    });
    __webpack_require__.d(__webpack_exports__, "c", function() {
      return createApp;
    });
    __webpack_require__.d(__webpack_exports__, "d", function() {
      return createRef;
    });
    __webpack_require__.d(__webpack_exports__, "e", function() {
      return customRef;
    });
    __webpack_require__.d(__webpack_exports__, "f", function() {
      return Plugin;
    });
    __webpack_require__.d(__webpack_exports__, "g", function() {
      return defineAsyncComponent;
    });
    __webpack_require__.d(__webpack_exports__, "h", function() {
      return defineComponent;
    });
    __webpack_require__.d(__webpack_exports__, "i", function() {
      return del;
    });
    __webpack_require__.d(__webpack_exports__, "j", function() {
      return effectScope;
    });
    __webpack_require__.d(__webpack_exports__, "k", function() {
      return getCurrentInstance;
    });
    __webpack_require__.d(__webpack_exports__, "l", function() {
      return getCurrentScope;
    });
    __webpack_require__.d(__webpack_exports__, "m", function() {
      return createElement;
    });
    __webpack_require__.d(__webpack_exports__, "n", function() {
      return inject;
    });
    __webpack_require__.d(__webpack_exports__, "o", function() {
      return isRaw;
    });
    __webpack_require__.d(__webpack_exports__, "p", function() {
      return isReactive;
    });
    __webpack_require__.d(__webpack_exports__, "q", function() {
      return isReadonly;
    });
    __webpack_require__.d(__webpack_exports__, "r", function() {
      return isRef;
    });
    __webpack_require__.d(__webpack_exports__, "s", function() {
      return markRaw;
    });
    __webpack_require__.d(__webpack_exports__, "t", function() {
      return nextTick;
    });
    __webpack_require__.d(__webpack_exports__, "u", function() {
      return onActivated;
    });
    __webpack_require__.d(__webpack_exports__, "v", function() {
      return onBeforeMount;
    });
    __webpack_require__.d(__webpack_exports__, "w", function() {
      return onBeforeUnmount;
    });
    __webpack_require__.d(__webpack_exports__, "x", function() {
      return onBeforeUpdate;
    });
    __webpack_require__.d(__webpack_exports__, "y", function() {
      return onDeactivated;
    });
    __webpack_require__.d(__webpack_exports__, "z", function() {
      return onErrorCaptured;
    });
    __webpack_require__.d(__webpack_exports__, "A", function() {
      return onMounted;
    });
    __webpack_require__.d(__webpack_exports__, "B", function() {
      return onScopeDispose;
    });
    __webpack_require__.d(__webpack_exports__, "C", function() {
      return onServerPrefetch;
    });
    __webpack_require__.d(__webpack_exports__, "D", function() {
      return onUnmounted;
    });
    __webpack_require__.d(__webpack_exports__, "E", function() {
      return onUpdated;
    });
    __webpack_require__.d(__webpack_exports__, "F", function() {
      return provide;
    });
    __webpack_require__.d(__webpack_exports__, "G", function() {
      return proxyRefs;
    });
    __webpack_require__.d(__webpack_exports__, "H", function() {
      return reactive;
    });
    __webpack_require__.d(__webpack_exports__, "I", function() {
      return readonly;
    });
    __webpack_require__.d(__webpack_exports__, "J", function() {
      return ref;
    });
    __webpack_require__.d(__webpack_exports__, "K", function() {
      return set$1;
    });
    __webpack_require__.d(__webpack_exports__, "L", function() {
      return shallowReactive;
    });
    __webpack_require__.d(__webpack_exports__, "M", function() {
      return shallowReadonly;
    });
    __webpack_require__.d(__webpack_exports__, "N", function() {
      return shallowRef;
    });
    __webpack_require__.d(__webpack_exports__, "O", function() {
      return toRaw;
    });
    __webpack_require__.d(__webpack_exports__, "P", function() {
      return toRef;
    });
    __webpack_require__.d(__webpack_exports__, "Q", function() {
      return toRefs;
    });
    __webpack_require__.d(__webpack_exports__, "R", function() {
      return triggerRef;
    });
    __webpack_require__.d(__webpack_exports__, "S", function() {
      return unref;
    });
    __webpack_require__.d(__webpack_exports__, "T", function() {
      return useAttrs;
    });
    __webpack_require__.d(__webpack_exports__, "U", function() {
      return useCSSModule;
    });
    __webpack_require__.d(__webpack_exports__, "V", function() {
      return useCssModule;
    });
    __webpack_require__.d(__webpack_exports__, "W", function() {
      return useSlots;
    });
    __webpack_require__.d(__webpack_exports__, "X", function() {
      return warn;
    });
    __webpack_require__.d(__webpack_exports__, "Y", function() {
      return watch;
    });
    __webpack_require__.d(__webpack_exports__, "Z", function() {
      return watchEffect;
    });
    __webpack_require__.d(__webpack_exports__, "ab", function() {
      return watchPostEffect;
    });
    __webpack_require__.d(__webpack_exports__, "bb", function() {
      return watchSyncEffect;
    });
    __webpack_require__(77);
    __webpack_require__(25);
    __webpack_require__(26);
    __webpack_require__(27);
    __webpack_require__(28);
    __webpack_require__(29);
    __webpack_require__(30);
    __webpack_require__(31);
    __webpack_require__(32);
    __webpack_require__(33);
    __webpack_require__(34);
    __webpack_require__(35);
    __webpack_require__(36);
    __webpack_require__(37);
    __webpack_require__(38);
    __webpack_require__(39);
    __webpack_require__(40);
    __webpack_require__(45);
    __webpack_require__(46);
    __webpack_require__(47);
    __webpack_require__(48);
    __webpack_require__(49);
    __webpack_require__(50);
    __webpack_require__(51);
    __webpack_require__(52);
    __webpack_require__(53);
    __webpack_require__(54);
    __webpack_require__(55);
    __webpack_require__(56);
    __webpack_require__(57);
    var vue__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(1);
    var toString = function(x) {
      return Object.prototype.toString.call(x);
    };
    function isNative(Ctor) {
      return typeof Ctor === "function" && /native code/.test(Ctor.toString());
    }
    var hasSymbol = typeof Symbol !== "undefined" && isNative(Symbol) && typeof Reflect !== "undefined" && isNative(Reflect.ownKeys);
    var noopFn = function(_) {
      return _;
    };
    function proxy(target, key, _a) {
      var get2 = _a.get, set2 = _a.set;
      Object.defineProperty(target, key, {
        enumerable: true,
        configurable: true,
        get: get2 || noopFn,
        set: set2 || noopFn
      });
    }
    function def(obj, key, val, enumerable) {
      Object.defineProperty(obj, key, {
        value: val,
        enumerable: !!enumerable,
        writable: true,
        configurable: true
      });
    }
    function hasOwn(obj, key) {
      return Object.hasOwnProperty.call(obj, key);
    }
    function assert(condition, msg) {
      if (!condition) {
        throw new Error("[vue-composition-api] " + msg);
      }
    }
    function isArray(x) {
      return Array.isArray(x);
    }
    var objectToString = Object.prototype.toString;
    var toTypeString = function(value) {
      return objectToString.call(value);
    };
    var isMap = function(val) {
      return toTypeString(val) === "[object Map]";
    };
    var isSet = function(val) {
      return toTypeString(val) === "[object Set]";
    };
    var MAX_VALID_ARRAY_LENGTH = 4294967295;
    function isValidArrayIndex(val) {
      var n = parseFloat(String(val));
      return n >= 0 && Math.floor(n) === n && isFinite(val) && n <= MAX_VALID_ARRAY_LENGTH;
    }
    function isObject(val) {
      return val !== null && typeof val === "object";
    }
    function isPlainObject(x) {
      return toString(x) === "[object Object]";
    }
    function isFunction(x) {
      return typeof x === "function";
    }
    function warn$1(msg, vm) {
      vue__WEBPACK_IMPORTED_MODULE_30__["default"].util.warn(msg, vm);
    }
    function logError(err, vm, info) {
      {
        throw err;
      }
    }
    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.
    
    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.
    
    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    var extendStatics = function(d, b) {
      extendStatics = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function(d2, b2) {
        d2.__proto__ = b2;
      } || function(d2, b2) {
        for (var p in b2)
          if (Object.prototype.hasOwnProperty.call(b2, p))
            d2[p] = b2[p];
      };
      return extendStatics(d, b);
    };
    function __extends(d, b) {
      if (typeof b !== "function" && b !== null)
        throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
      extendStatics(d, b);
      function __() {
        this.constructor = d;
      }
      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    var __assign = function() {
      __assign = Object.assign || function __assign2(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p))
              t[p] = s[p];
        }
        return t;
      };
      return __assign.apply(this, arguments);
    };
    function __values(o) {
      var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
      if (m)
        return m.call(o);
      if (o && typeof o.length === "number")
        return {
          next: function() {
            if (o && i >= o.length)
              o = void 0;
            return {
              value: o && o[i++],
              done: !o
            };
          }
        };
      throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read(o, n) {
      var m = typeof Symbol === "function" && o[Symbol.iterator];
      if (!m)
        return o;
      var i = m.call(o), r, ar = [], e;
      try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
          ar.push(r.value);
      } catch (error) {
        e = {
          error
        };
      } finally {
        try {
          if (r && !r.done && (m = i["return"]))
            m.call(i);
        } finally {
          if (e)
            throw e.error;
        }
      }
      return ar;
    }
    function __spreadArray(to, from) {
      for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
      return to;
    }
    function warn(message) {
      var _a;
      warn$1(message, (_a = getCurrentInstance()) === null || _a === void 0 ? void 0 : _a.proxy);
    }
    var activeEffectScope;
    var effectScopeStack = [];
    var EffectScopeImpl = function() {
      function EffectScopeImpl2(vm) {
        this.active = true;
        this.effects = [];
        this.cleanups = [];
        this.vm = vm;
      }
      EffectScopeImpl2.prototype.run = function(fn) {
        if (this.active) {
          try {
            this.on();
            return fn();
          } finally {
            this.off();
          }
        }
        return;
      };
      EffectScopeImpl2.prototype.on = function() {
        if (this.active) {
          effectScopeStack.push(this);
          activeEffectScope = this;
        }
      };
      EffectScopeImpl2.prototype.off = function() {
        if (this.active) {
          effectScopeStack.pop();
          activeEffectScope = effectScopeStack[effectScopeStack.length - 1];
        }
      };
      EffectScopeImpl2.prototype.stop = function() {
        if (this.active) {
          this.vm.$destroy();
          this.effects.forEach(function(e) {
            return e.stop();
          });
          this.cleanups.forEach(function(cleanup) {
            return cleanup();
          });
          this.active = false;
        }
      };
      return EffectScopeImpl2;
    }();
    var EffectScope = function(_super) {
      __extends(EffectScope2, _super);
      function EffectScope2(detached) {
        if (detached === void 0) {
          detached = false;
        }
        var _this = this;
        var vm = void 0;
        withCurrentInstanceTrackingDisabled(function() {
          vm = defineComponentInstance(getVueConstructor());
        });
        _this = _super.call(this, vm) || this;
        if (!detached) {
          recordEffectScope(_this);
        }
        return _this;
      }
      return EffectScope2;
    }(EffectScopeImpl);
    function recordEffectScope(effect, scope) {
      var _a;
      scope = scope || activeEffectScope;
      if (scope && scope.active) {
        scope.effects.push(effect);
        return;
      }
      var vm = (_a = getCurrentInstance()) === null || _a === void 0 ? void 0 : _a.proxy;
      vm && vm.$on("hook:destroyed", function() {
        return effect.stop();
      });
    }
    function effectScope(detached) {
      return new EffectScope(detached);
    }
    function getCurrentScope() {
      return activeEffectScope;
    }
    function onScopeDispose(fn) {
      if (activeEffectScope) {
        activeEffectScope.cleanups.push(fn);
      }
    }
    function getCurrentScopeVM() {
      var _a, _b;
      return ((_a = getCurrentScope()) === null || _a === void 0 ? void 0 : _a.vm) || ((_b = getCurrentInstance()) === null || _b === void 0 ? void 0 : _b.proxy);
    }
    function bindCurrentScopeToVM(vm) {
      if (!vm.scope) {
        var scope_1 = new EffectScopeImpl(vm.proxy);
        vm.scope = scope_1;
        vm.proxy.$on("hook:destroyed", function() {
          return scope_1.stop();
        });
      }
      return vm.scope;
    }
    var vueDependency = void 0;
    try {
      var requiredVue = __webpack_require__(1);
      if (requiredVue && isVue(requiredVue)) {
        vueDependency = requiredVue;
      } else if (requiredVue && "default" in requiredVue && isVue(requiredVue.default)) {
        vueDependency = requiredVue.default;
      }
    } catch (_a) {
    }
    var vueConstructor = null;
    var currentInstance = null;
    var currentInstanceTracking = true;
    var PluginInstalledFlag = "__composition_api_installed__";
    function isVue(obj) {
      return obj && isFunction(obj) && obj.name === "Vue";
    }
    function isVueRegistered(Vue) {
      return hasOwn(Vue, PluginInstalledFlag);
    }
    function getVueConstructor() {
      return vueConstructor;
    }
    function getRegisteredVueOrDefault() {
      var constructor = vueConstructor || vueDependency;
      return constructor;
    }
    function setVueConstructor(Vue) {
      vueConstructor = Vue;
      Object.defineProperty(Vue, PluginInstalledFlag, {
        configurable: true,
        writable: true,
        value: true
      });
    }
    function withCurrentInstanceTrackingDisabled(fn) {
      var prev = currentInstanceTracking;
      currentInstanceTracking = false;
      try {
        fn();
      } finally {
        currentInstanceTracking = prev;
      }
    }
    function setCurrentInstance(instance) {
      if (!currentInstanceTracking)
        return;
      var prev = currentInstance;
      prev === null || prev === void 0 ? void 0 : prev.scope.off();
      currentInstance = instance;
      currentInstance === null || currentInstance === void 0 ? void 0 : currentInstance.scope.on();
    }
    function getCurrentInstance() {
      return currentInstance;
    }
    var instanceMapCache = /* @__PURE__ */ new WeakMap();
    function toVue3ComponentInstance(vm) {
      if (instanceMapCache.has(vm)) {
        return instanceMapCache.get(vm);
      }
      var instance = {
        proxy: vm,
        update: vm.$forceUpdate,
        type: vm.$options,
        uid: vm._uid,
        emit: vm.$emit.bind(vm),
        parent: null,
        root: null
      };
      bindCurrentScopeToVM(instance);
      var instanceProps = ["data", "props", "attrs", "refs", "vnode", "slots"];
      instanceProps.forEach(function(prop) {
        proxy(instance, prop, {
          get: function() {
            return vm["$" + prop];
          }
        });
      });
      proxy(instance, "isMounted", {
        get: function() {
          return vm._isMounted;
        }
      });
      proxy(instance, "isUnmounted", {
        get: function() {
          return vm._isDestroyed;
        }
      });
      proxy(instance, "isDeactivated", {
        get: function() {
          return vm._inactive;
        }
      });
      proxy(instance, "emitted", {
        get: function() {
          return vm._events;
        }
      });
      instanceMapCache.set(vm, instance);
      if (vm.$parent) {
        instance.parent = toVue3ComponentInstance(vm.$parent);
      }
      if (vm.$root) {
        instance.root = toVue3ComponentInstance(vm.$root);
      }
      return instance;
    }
    function getCurrentInstanceForFn(hook, target) {
      target = target || getCurrentInstance();
      return target;
    }
    function defineComponentInstance(Ctor, options) {
      if (options === void 0) {
        options = {};
      }
      var silent = Ctor.config.silent;
      Ctor.config.silent = true;
      var vm = new Ctor(options);
      Ctor.config.silent = silent;
      return vm;
    }
    function isComponentInstance(obj) {
      var Vue = getVueConstructor();
      return Vue && obj instanceof Vue;
    }
    function createSlotProxy(vm, slotName) {
      return function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        if (!vm.$scopedSlots[slotName]) {
          return;
        }
        return vm.$scopedSlots[slotName].apply(vm, args);
      };
    }
    function resolveSlots(slots, normalSlots) {
      var res;
      if (!slots) {
        res = {};
      } else if (slots._normalized) {
        return slots._normalized;
      } else {
        res = {};
        for (var key in slots) {
          if (slots[key] && key[0] !== "$") {
            res[key] = true;
          }
        }
      }
      for (var key in normalSlots) {
        if (!(key in res)) {
          res[key] = true;
        }
      }
      return res;
    }
    var vueInternalClasses;
    var getVueInternalClasses = function() {
      if (!vueInternalClasses) {
        var vm = defineComponentInstance(getVueConstructor(), {
          computed: {
            value: function() {
              return 0;
            }
          }
        });
        var Watcher = vm._computedWatchers.value.constructor;
        var Dep = vm._data.__ob__.dep.constructor;
        vueInternalClasses = {
          Watcher,
          Dep
        };
        vm.$destroy();
      }
      return vueInternalClasses;
    };
    function createSymbol(name) {
      return hasSymbol ? Symbol.for(name) : name;
    }
    var WatcherPreFlushQueueKey = createSymbol("composition-api.preFlushQueue");
    var WatcherPostFlushQueueKey = createSymbol("composition-api.postFlushQueue");
    var RefKey = "composition-api.refKey";
    var accessModifiedSet = /* @__PURE__ */ new WeakMap();
    var rawSet = /* @__PURE__ */ new WeakMap();
    var readonlySet = /* @__PURE__ */ new WeakMap();
    function set$1(target, key, val) {
      var Vue = getVueConstructor();
      var _a = Vue.util; _a.warn; var defineReactive = _a.defineReactive;
      var ob = target.__ob__;
      function ssrMockReactivity() {
        if (ob && isObject(val) && !hasOwn(val, "__ob__")) {
          mockReactivityDeep(val);
        }
      }
      if (isArray(target)) {
        if (isValidArrayIndex(key)) {
          target.length = Math.max(target.length, key);
          target.splice(key, 1, val);
          ssrMockReactivity();
          return val;
        } else if (key === "length" && val !== target.length) {
          target.length = val;
          ob === null || ob === void 0 ? void 0 : ob.dep.notify();
          return val;
        }
      }
      if (key in target && !(key in Object.prototype)) {
        target[key] = val;
        ssrMockReactivity();
        return val;
      }
      if (target._isVue || ob && ob.vmCount) {
        return val;
      }
      if (!ob) {
        target[key] = val;
        return val;
      }
      defineReactive(ob.value, key, val);
      defineAccessControl(target, key, val);
      ssrMockReactivity();
      ob.dep.notify();
      return val;
    }
    var RefImpl = function() {
      function RefImpl2(_a) {
        var get2 = _a.get, set2 = _a.set;
        proxy(this, "value", {
          get: get2,
          set: set2
        });
      }
      return RefImpl2;
    }();
    function createRef(options, isReadonly2, isComputed) {
      if (isReadonly2 === void 0) {
        isReadonly2 = false;
      }
      if (isComputed === void 0) {
        isComputed = false;
      }
      var r = new RefImpl(options);
      if (isComputed)
        r.effect = true;
      var sealed = Object.seal(r);
      if (isReadonly2)
        readonlySet.set(sealed, true);
      return sealed;
    }
    function ref(raw) {
      var _a;
      if (isRef(raw)) {
        return raw;
      }
      var value = reactive((_a = {}, _a[RefKey] = raw, _a));
      return createRef({
        get: function() {
          return value[RefKey];
        },
        set: function(v) {
          return value[RefKey] = v;
        }
      });
    }
    function isRef(value) {
      return value instanceof RefImpl;
    }
    function unref(ref2) {
      return isRef(ref2) ? ref2.value : ref2;
    }
    function toRefs(obj) {
      if (!isPlainObject(obj))
        return obj;
      var ret = {};
      for (var key in obj) {
        ret[key] = toRef(obj, key);
      }
      return ret;
    }
    function customRef(factory) {
      var version2 = ref(0);
      return createRef(factory(function() {
        return void version2.value;
      }, function() {
        ++version2.value;
      }));
    }
    function toRef(object, key) {
      if (!(key in object))
        set$1(object, key, void 0);
      var v = object[key];
      if (isRef(v))
        return v;
      return createRef({
        get: function() {
          return object[key];
        },
        set: function(v2) {
          return object[key] = v2;
        }
      });
    }
    function shallowRef(raw) {
      var _a;
      if (isRef(raw)) {
        return raw;
      }
      var value = shallowReactive((_a = {}, _a[RefKey] = raw, _a));
      return createRef({
        get: function() {
          return value[RefKey];
        },
        set: function(v) {
          return value[RefKey] = v;
        }
      });
    }
    function triggerRef(value) {
      if (!isRef(value))
        return;
      value.value = value.value;
    }
    function proxyRefs(objectWithRefs) {
      var _a, e_1, _b;
      if (isReactive(objectWithRefs)) {
        return objectWithRefs;
      }
      var value = reactive((_a = {}, _a[RefKey] = objectWithRefs, _a));
      def(value, RefKey, value[RefKey], false);
      var _loop_1 = function(key2) {
        proxy(value, key2, {
          get: function() {
            if (isRef(value[RefKey][key2])) {
              return value[RefKey][key2].value;
            }
            return value[RefKey][key2];
          },
          set: function(v) {
            if (isRef(value[RefKey][key2])) {
              return value[RefKey][key2].value = unref(v);
            }
            value[RefKey][key2] = unref(v);
          }
        });
      };
      try {
        for (var _c = __values(Object.keys(objectWithRefs)), _d = _c.next(); !_d.done; _d = _c.next()) {
          var key = _d.value;
          _loop_1(key);
        }
      } catch (e_1_1) {
        e_1 = {
          error: e_1_1
        };
      } finally {
        try {
          if (_d && !_d.done && (_b = _c.return))
            _b.call(_c);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      return value;
    }
    function isRaw(obj) {
      var _a;
      return Boolean(obj && hasOwn(obj, "__ob__") && typeof obj.__ob__ === "object" && ((_a = obj.__ob__) === null || _a === void 0 ? void 0 : _a.__raw__));
    }
    function isReactive(obj) {
      var _a;
      return Boolean(obj && hasOwn(obj, "__ob__") && typeof obj.__ob__ === "object" && !((_a = obj.__ob__) === null || _a === void 0 ? void 0 : _a.__raw__));
    }
    function setupAccessControl(target) {
      if (!isPlainObject(target) || isRaw(target) || isArray(target) || isRef(target) || isComponentInstance(target) || accessModifiedSet.has(target))
        return;
      accessModifiedSet.set(target, true);
      var keys = Object.keys(target);
      for (var i = 0; i < keys.length; i++) {
        defineAccessControl(target, keys[i]);
      }
    }
    function defineAccessControl(target, key, val) {
      if (key === "__ob__")
        return;
      if (isRaw(target[key]))
        return;
      var getter;
      var setter;
      var property = Object.getOwnPropertyDescriptor(target, key);
      if (property) {
        if (property.configurable === false) {
          return;
        }
        getter = property.get;
        setter = property.set;
        if ((!getter || setter) && arguments.length === 2) {
          val = target[key];
        }
      }
      setupAccessControl(val);
      proxy(target, key, {
        get: function getterHandler() {
          var value = getter ? getter.call(target) : val;
          if (key !== RefKey && isRef(value)) {
            return value.value;
          } else {
            return value;
          }
        },
        set: function setterHandler(newVal) {
          if (getter && !setter)
            return;
          if (key !== RefKey && isRef(val) && !isRef(newVal)) {
            val.value = newVal;
          } else if (setter) {
            setter.call(target, newVal);
            val = newVal;
          } else {
            val = newVal;
          }
          setupAccessControl(newVal);
        }
      });
    }
    function observe(obj) {
      var Vue = getRegisteredVueOrDefault();
      var observed;
      if (Vue.observable) {
        observed = Vue.observable(obj);
      } else {
        var vm = defineComponentInstance(Vue, {
          data: {
            $$state: obj
          }
        });
        observed = vm._data.$$state;
      }
      if (!hasOwn(observed, "__ob__")) {
        mockReactivityDeep(observed);
      }
      return observed;
    }
    function mockReactivityDeep(obj, seen) {
      var e_1, _a;
      if (seen === void 0) {
        seen = /* @__PURE__ */ new Set();
      }
      if (seen.has(obj) || hasOwn(obj, "__ob__") || !Object.isExtensible(obj))
        return;
      def(obj, "__ob__", mockObserver(obj));
      seen.add(obj);
      try {
        for (var _b = __values(Object.keys(obj)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var key = _c.value;
          var value = obj[key];
          if (!(isPlainObject(value) || isArray(value)) || isRaw(value) || !Object.isExtensible(value)) {
            continue;
          }
          mockReactivityDeep(value, seen);
        }
      } catch (e_1_1) {
        e_1 = {
          error: e_1_1
        };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
    }
    function mockObserver(value) {
      if (value === void 0) {
        value = {};
      }
      return {
        value,
        dep: {
          notify: noopFn,
          depend: noopFn,
          addSub: noopFn,
          removeSub: noopFn
        }
      };
    }
    function createObserver() {
      return observe({}).__ob__;
    }
    function shallowReactive(obj) {
      var e_2, _a;
      if (!isObject(obj)) {
        return obj;
      }
      if (!(isPlainObject(obj) || isArray(obj)) || isRaw(obj) || !Object.isExtensible(obj)) {
        return obj;
      }
      var observed = observe(isArray(obj) ? [] : {});
      setupAccessControl(observed);
      var ob = observed.__ob__;
      var _loop_1 = function(key2) {
        var val = obj[key2];
        var getter;
        var setter;
        var property = Object.getOwnPropertyDescriptor(obj, key2);
        if (property) {
          if (property.configurable === false) {
            return "continue";
          }
          getter = property.get;
          setter = property.set;
        }
        proxy(observed, key2, {
          get: function getterHandler() {
            var _a2;
            var value = getter ? getter.call(obj) : val;
            (_a2 = ob.dep) === null || _a2 === void 0 ? void 0 : _a2.depend();
            return value;
          },
          set: function setterHandler(newVal) {
            var _a2;
            if (getter && !setter)
              return;
            if (setter) {
              setter.call(obj, newVal);
            } else {
              val = newVal;
            }
            (_a2 = ob.dep) === null || _a2 === void 0 ? void 0 : _a2.notify();
          }
        });
      };
      try {
        for (var _b = __values(Object.keys(obj)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var key = _c.value;
          _loop_1(key);
        }
      } catch (e_2_1) {
        e_2 = {
          error: e_2_1
        };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_2)
            throw e_2.error;
        }
      }
      return observed;
    }
    function reactive(obj) {
      if (!isObject(obj)) {
        return obj;
      }
      if (!(isPlainObject(obj) || isArray(obj)) || isRaw(obj) || !Object.isExtensible(obj)) {
        return obj;
      }
      var observed = observe(obj);
      setupAccessControl(observed);
      return observed;
    }
    function markRaw(obj) {
      if (!(isPlainObject(obj) || isArray(obj)) || !Object.isExtensible(obj)) {
        return obj;
      }
      var ob = createObserver();
      ob.__raw__ = true;
      def(obj, "__ob__", ob);
      rawSet.set(obj, true);
      return obj;
    }
    function toRaw(observed) {
      var _a, _b;
      if (isRaw(observed) || !Object.isExtensible(observed)) {
        return observed;
      }
      return ((_b = (_a = observed) === null || _a === void 0 ? void 0 : _a.__ob__) === null || _b === void 0 ? void 0 : _b.value) || observed;
    }
    function isReadonly(obj) {
      return readonlySet.has(obj);
    }
    function readonly(target) {
      {
        readonlySet.set(target, true);
      }
      return target;
    }
    function shallowReadonly(obj) {
      var e_1, _a;
      if (!isObject(obj)) {
        return obj;
      }
      if (!(isPlainObject(obj) || isArray(obj)) || !Object.isExtensible(obj) && !isRef(obj)) {
        return obj;
      }
      var readonlyObj = isRef(obj) ? new RefImpl({}) : isReactive(obj) ? observe({}) : {};
      var source = reactive({});
      var ob = source.__ob__;
      var _loop_1 = function(key2) {
        var val = obj[key2];
        var getter;
        var property = Object.getOwnPropertyDescriptor(obj, key2);
        if (property) {
          if (property.configurable === false && !isRef(obj)) {
            return "continue";
          }
          getter = property.get;
        }
        proxy(readonlyObj, key2, {
          get: function getterHandler() {
            var value = getter ? getter.call(obj) : val;
            ob.dep.depend();
            return value;
          },
          set: function(v) {
          }
        });
      };
      try {
        for (var _b = __values(Object.keys(obj)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var key = _c.value;
          _loop_1(key);
        }
      } catch (e_1_1) {
        e_1 = {
          error: e_1_1
        };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      readonlySet.set(readonlyObj, true);
      return readonlyObj;
    }
    function del(target, key) {
      var Vue = getVueConstructor();
      Vue.util.warn;
      if (isArray(target) && isValidArrayIndex(key)) {
        target.splice(key, 1);
        return;
      }
      var ob = target.__ob__;
      if (target._isVue || ob && ob.vmCount) {
        return;
      }
      if (!hasOwn(target, key)) {
        return;
      }
      delete target[key];
      if (!ob) {
        return;
      }
      ob.dep.notify();
    }
    var genName = function(name) {
      return "on" + (name[0].toUpperCase() + name.slice(1));
    };
    function createLifeCycle(lifeCyclehook) {
      return function(callback, target) {
        var instance = getCurrentInstanceForFn(genName(lifeCyclehook), target);
        return instance && injectHookOption(getVueConstructor(), instance, lifeCyclehook, callback);
      };
    }
    function injectHookOption(Vue, instance, hook, val) {
      var options = instance.proxy.$options;
      var mergeFn = Vue.config.optionMergeStrategies[hook];
      var wrappedHook = wrapHookCall(instance, val);
      options[hook] = mergeFn(options[hook], wrappedHook);
      return wrappedHook;
    }
    function wrapHookCall(instance, fn) {
      return function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        var prev = getCurrentInstance();
        setCurrentInstance(instance);
        try {
          return fn.apply(void 0, __spreadArray([], __read(args), false));
        } finally {
          setCurrentInstance(prev);
        }
      };
    }
    var onBeforeMount = createLifeCycle("beforeMount");
    var onMounted = createLifeCycle("mounted");
    var onBeforeUpdate = createLifeCycle("beforeUpdate");
    var onUpdated = createLifeCycle("updated");
    var onBeforeUnmount = createLifeCycle("beforeDestroy");
    var onUnmounted = createLifeCycle("destroyed");
    var onErrorCaptured = createLifeCycle("errorCaptured");
    var onActivated = createLifeCycle("activated");
    var onDeactivated = createLifeCycle("deactivated");
    var onServerPrefetch = createLifeCycle("serverPrefetch");
    var fallbackVM;
    function flushPreQueue() {
      flushQueue(this, WatcherPreFlushQueueKey);
    }
    function flushPostQueue() {
      flushQueue(this, WatcherPostFlushQueueKey);
    }
    function hasWatchEnv(vm) {
      return vm[WatcherPreFlushQueueKey] !== void 0;
    }
    function installWatchEnv(vm) {
      vm[WatcherPreFlushQueueKey] = [];
      vm[WatcherPostFlushQueueKey] = [];
      vm.$on("hook:beforeUpdate", flushPreQueue);
      vm.$on("hook:updated", flushPostQueue);
    }
    function getWatcherOption(options) {
      return __assign({
        immediate: false,
        deep: false,
        flush: "pre"
      }, options);
    }
    function getWatchEffectOption(options) {
      return __assign({
        flush: "pre"
      }, options);
    }
    function getWatcherVM() {
      var vm = getCurrentScopeVM();
      if (!vm) {
        if (!fallbackVM) {
          fallbackVM = defineComponentInstance(getVueConstructor());
        }
        vm = fallbackVM;
      } else if (!hasWatchEnv(vm)) {
        installWatchEnv(vm);
      }
      return vm;
    }
    function flushQueue(vm, key) {
      var queue = vm[key];
      for (var index = 0; index < queue.length; index++) {
        queue[index]();
      }
      queue.length = 0;
    }
    function queueFlushJob(vm, fn, mode) {
      var fallbackFlush = function() {
        vm.$nextTick(function() {
          if (vm[WatcherPreFlushQueueKey].length) {
            flushQueue(vm, WatcherPreFlushQueueKey);
          }
          if (vm[WatcherPostFlushQueueKey].length) {
            flushQueue(vm, WatcherPostFlushQueueKey);
          }
        });
      };
      switch (mode) {
        case "pre":
          fallbackFlush();
          vm[WatcherPreFlushQueueKey].push(fn);
          break;
        case "post":
          fallbackFlush();
          vm[WatcherPostFlushQueueKey].push(fn);
          break;
        default:
          assert(false, 'flush must be one of ["post", "pre", "sync"], but got ' + mode);
          break;
      }
    }
    function createVueWatcher(vm, getter, callback, options) {
      var index = vm._watchers.length;
      vm.$watch(getter, callback, {
        immediate: options.immediateInvokeCallback,
        deep: options.deep,
        lazy: options.noRun,
        sync: options.sync,
        before: options.before
      });
      return vm._watchers[index];
    }
    function patchWatcherTeardown(watcher, runCleanup) {
      var _teardown = watcher.teardown;
      watcher.teardown = function() {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        _teardown.apply(watcher, args);
        runCleanup();
      };
    }
    function createWatcher(vm, source, cb, options) {
      var _a;
      var flushMode = options.flush;
      var isSync = flushMode === "sync";
      var cleanup;
      var registerCleanup = function(fn) {
        cleanup = function() {
          try {
            fn();
          } catch (error) {
            logError(error);
          }
        };
      };
      var runCleanup = function() {
        if (cleanup) {
          cleanup();
          cleanup = null;
        }
      };
      var createScheduler = function(fn) {
        if (isSync || vm === fallbackVM) {
          return fn;
        }
        return function() {
          var args = [];
          for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
          }
          return queueFlushJob(vm, function() {
            fn.apply(void 0, __spreadArray([], __read(args)));
          }, flushMode);
        };
      };
      if (cb === null) {
        var running_1 = false;
        var getter_1 = function() {
          if (running_1) {
            return;
          }
          try {
            running_1 = true;
            source(registerCleanup);
          } finally {
            running_1 = false;
          }
        };
        var watcher_1 = createVueWatcher(vm, getter_1, noopFn, {
          deep: options.deep || false,
          sync: isSync,
          before: runCleanup
        });
        patchWatcherTeardown(watcher_1, runCleanup);
        watcher_1.lazy = false;
        var originGet = watcher_1.get.bind(watcher_1);
        watcher_1.get = createScheduler(originGet);
        return function() {
          watcher_1.teardown();
        };
      }
      var deep = options.deep;
      var isMultiSource = false;
      var getter;
      if (isRef(source)) {
        getter = function() {
          return source.value;
        };
      } else if (isReactive(source)) {
        getter = function() {
          return source;
        };
        deep = true;
      } else if (isArray(source)) {
        isMultiSource = true;
        getter = function() {
          return source.map(function(s) {
            if (isRef(s)) {
              return s.value;
            } else if (isReactive(s)) {
              return traverse(s);
            } else if (isFunction(s)) {
              return s();
            } else {
              return noopFn;
            }
          });
        };
      } else if (isFunction(source)) {
        getter = source;
      } else {
        getter = noopFn;
      }
      if (deep) {
        var baseGetter_1 = getter;
        getter = function() {
          return traverse(baseGetter_1());
        };
      }
      var applyCb = function(n, o) {
        if (!deep && isMultiSource && n.every(function(v, i) {
          return Object.is(v, o[i]);
        }))
          return;
        runCleanup();
        return cb(n, o, registerCleanup);
      };
      var callback = createScheduler(applyCb);
      if (options.immediate) {
        var originalCallback_1 = callback;
        var shiftCallback_1 = function(n, o) {
          shiftCallback_1 = originalCallback_1;
          return applyCb(n, isArray(n) ? [] : o);
        };
        callback = function(n, o) {
          return shiftCallback_1(n, o);
        };
      }
      var stop = vm.$watch(getter, callback, {
        immediate: options.immediate,
        deep,
        sync: isSync
      });
      var watcher = vm._watchers[vm._watchers.length - 1];
      if (isReactive(watcher.value) && ((_a = watcher.value.__ob__) === null || _a === void 0 ? void 0 : _a.dep) && deep) {
        watcher.value.__ob__.dep.addSub({
          update: function() {
            watcher.run();
          }
        });
      }
      patchWatcherTeardown(watcher, runCleanup);
      return function() {
        stop();
      };
    }
    function watchEffect(effect, options) {
      var opts = getWatchEffectOption(options);
      var vm = getWatcherVM();
      return createWatcher(vm, effect, null, opts);
    }
    function watchPostEffect(effect) {
      return watchEffect(effect, {
        flush: "post"
      });
    }
    function watchSyncEffect(effect) {
      return watchEffect(effect, {
        flush: "sync"
      });
    }
    function watch(source, cb, options) {
      var callback = null;
      if (isFunction(cb)) {
        callback = cb;
      } else {
        options = cb;
        callback = null;
      }
      var opts = getWatcherOption(options);
      var vm = getWatcherVM();
      return createWatcher(vm, source, callback, opts);
    }
    function traverse(value, seen) {
      if (seen === void 0) {
        seen = /* @__PURE__ */ new Set();
      }
      if (!isObject(value) || seen.has(value)) {
        return value;
      }
      seen.add(value);
      if (isRef(value)) {
        traverse(value.value, seen);
      } else if (isArray(value)) {
        for (var i = 0; i < value.length; i++) {
          traverse(value[i], seen);
        }
      } else if (isSet(value) || isMap(value)) {
        value.forEach(function(v) {
          traverse(v, seen);
        });
      } else if (isPlainObject(value)) {
        for (var key in value) {
          traverse(value[key], seen);
        }
      }
      return value;
    }
    function computed(getterOrOptions) {
      var vm = getCurrentScopeVM();
      var getter;
      var setter;
      if (isFunction(getterOrOptions)) {
        getter = getterOrOptions;
      } else {
        getter = getterOrOptions.get;
        setter = getterOrOptions.set;
      }
      var computedSetter;
      var computedGetter;
      if (vm && !vm.$isServer) {
        var _a = getVueInternalClasses(), Watcher_1 = _a.Watcher, Dep_1 = _a.Dep;
        var watcher_1;
        computedGetter = function() {
          if (!watcher_1) {
            watcher_1 = new Watcher_1(vm, getter, noopFn, {
              lazy: true
            });
          }
          if (watcher_1.dirty) {
            watcher_1.evaluate();
          }
          if (Dep_1.target) {
            watcher_1.depend();
          }
          return watcher_1.value;
        };
        computedSetter = function(v) {
          if (setter) {
            setter(v);
          }
        };
      } else {
        var computedHost_1 = defineComponentInstance(getVueConstructor(), {
          computed: {
            $$state: {
              get: getter,
              set: setter
            }
          }
        });
        vm && vm.$on("hook:destroyed", function() {
          return computedHost_1.$destroy();
        });
        computedGetter = function() {
          return computedHost_1.$$state;
        };
        computedSetter = function(v) {
          computedHost_1.$$state = v;
        };
      }
      return createRef({
        get: computedGetter,
        set: computedSetter
      }, !setter, true);
    }
    var NOT_FOUND = {};
    function resolveInject(provideKey, vm) {
      var source = vm;
      while (source) {
        if (source._provided && hasOwn(source._provided, provideKey)) {
          return source._provided[provideKey];
        }
        source = source.$parent;
      }
      return NOT_FOUND;
    }
    function provide(key, value) {
      var _a;
      var vm = (_a = getCurrentInstanceForFn()) === null || _a === void 0 ? void 0 : _a.proxy;
      if (!vm)
        return;
      if (!vm._provided) {
        var provideCache_1 = {};
        proxy(vm, "_provided", {
          get: function() {
            return provideCache_1;
          },
          set: function(v) {
            return Object.assign(provideCache_1, v);
          }
        });
      }
      vm._provided[key] = value;
    }
    function inject(key, defaultValue, treatDefaultAsFactory) {
      var _a;
      if (treatDefaultAsFactory === void 0) {
        treatDefaultAsFactory = false;
      }
      var vm = (_a = getCurrentInstance()) === null || _a === void 0 ? void 0 : _a.proxy;
      if (!vm) {
        return;
      }
      if (!key) {
        return defaultValue;
      }
      var val = resolveInject(key, vm);
      if (val !== NOT_FOUND) {
        return val;
      }
      if (defaultValue === void 0 && false) {
        warn$1('Injection "' + String(key) + '" not found', vm);
      }
      return treatDefaultAsFactory && isFunction(defaultValue) ? defaultValue() : defaultValue;
    }
    var EMPTY_OBJ = {};
    var useCssModule = function(name) {
      var _a;
      if (name === void 0) {
        name = "$style";
      }
      var instance = getCurrentInstance();
      if (!instance) {
        return EMPTY_OBJ;
      }
      var mod = (_a = instance.proxy) === null || _a === void 0 ? void 0 : _a[name];
      if (!mod) {
        return EMPTY_OBJ;
      }
      return mod;
    };
    var useCSSModule = useCssModule;
    function createApp(rootComponent, rootProps) {
      if (rootProps === void 0) {
        rootProps = void 0;
      }
      var V = getVueConstructor();
      var mountedVM = void 0;
      var app = {
        config: V.config,
        use: V.use.bind(V),
        mixin: V.mixin.bind(V),
        component: V.component.bind(V),
        directive: function(name, dir) {
          if (dir) {
            V.directive(name, dir);
            return app;
          } else {
            return V.directive(name);
          }
        },
        mount: function(el, hydrating) {
          if (!mountedVM) {
            mountedVM = new V(__assign({
              propsData: rootProps
            }, rootComponent));
            mountedVM.$mount(el, hydrating);
            return mountedVM;
          } else {
            return mountedVM;
          }
        },
        unmount: function() {
          if (mountedVM) {
            mountedVM.$destroy();
            mountedVM = void 0;
          }
        }
      };
      return app;
    }
    var nextTick = function nextTick2() {
      var _a;
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return (_a = getVueConstructor()) === null || _a === void 0 ? void 0 : _a.nextTick.apply(this, args);
    };
    var fallbackCreateElement;
    var createElement = function createElement2() {
      var _a;
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      var instance = (_a = getCurrentInstance()) === null || _a === void 0 ? void 0 : _a.proxy;
      if (!instance) {
        if (!fallbackCreateElement) {
          fallbackCreateElement = defineComponentInstance(getVueConstructor()).$createElement;
        }
        return fallbackCreateElement.apply(fallbackCreateElement, args);
      }
      return instance.$createElement.apply(instance, args);
    };
    function useSlots() {
      return getContext().slots;
    }
    function useAttrs() {
      return getContext().attrs;
    }
    function getContext() {
      var i = getCurrentInstance();
      return i.setupContext;
    }
    function set(vm, key, value) {
      var state = vm.__composition_api_state__ = vm.__composition_api_state__ || {};
      state[key] = value;
    }
    function get(vm, key) {
      return (vm.__composition_api_state__ || {})[key];
    }
    var vmStateManager = {
      set,
      get
    };
    function asVmProperty(vm, propName, propValue) {
      var props = vm.$options.props;
      if (!(propName in vm) && !(props && hasOwn(props, propName))) {
        if (isRef(propValue)) {
          proxy(vm, propName, {
            get: function() {
              return propValue.value;
            },
            set: function(val) {
              propValue.value = val;
            }
          });
        } else {
          proxy(vm, propName, {
            get: function() {
              if (isReactive(propValue)) {
                propValue.__ob__.dep.depend();
              }
              return propValue;
            },
            set: function(val) {
              propValue = val;
            }
          });
        }
      }
    }
    function updateTemplateRef(vm) {
      var rawBindings = vmStateManager.get(vm, "rawBindings") || {};
      if (!rawBindings || !Object.keys(rawBindings).length)
        return;
      var refs = vm.$refs;
      var oldRefKeys = vmStateManager.get(vm, "refs") || [];
      for (var index = 0; index < oldRefKeys.length; index++) {
        var key = oldRefKeys[index];
        var setupValue = rawBindings[key];
        if (!refs[key] && setupValue && isRef(setupValue)) {
          setupValue.value = null;
        }
      }
      var newKeys = Object.keys(refs);
      var validNewKeys = [];
      for (var index = 0; index < newKeys.length; index++) {
        var key = newKeys[index];
        var setupValue = rawBindings[key];
        if (refs[key] && setupValue && isRef(setupValue)) {
          setupValue.value = refs[key];
          validNewKeys.push(key);
        }
      }
      vmStateManager.set(vm, "refs", validNewKeys);
    }
    function updateVmAttrs(vm, ctx) {
      var e_1, _a;
      if (!vm) {
        return;
      }
      var attrBindings = vmStateManager.get(vm, "attrBindings");
      if (!attrBindings && !ctx) {
        return;
      }
      if (!attrBindings) {
        var observedData = reactive({});
        attrBindings = {
          ctx,
          data: observedData
        };
        vmStateManager.set(vm, "attrBindings", attrBindings);
        proxy(ctx, "attrs", {
          get: function() {
            return attrBindings === null || attrBindings === void 0 ? void 0 : attrBindings.data;
          },
          set: function() {
          }
        });
      }
      var source = vm.$attrs;
      var _loop_1 = function(attr2) {
        if (!hasOwn(attrBindings.data, attr2)) {
          proxy(attrBindings.data, attr2, {
            get: function() {
              return vm.$attrs[attr2];
            }
          });
        }
      };
      try {
        for (var _b = __values(Object.keys(source)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var attr = _c.value;
          _loop_1(attr);
        }
      } catch (e_1_1) {
        e_1 = {
          error: e_1_1
        };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
    }
    function resolveScopedSlots(vm, slotsProxy) {
      var parentVNode = vm.$options._parentVnode;
      if (!parentVNode)
        return;
      var prevSlots = vmStateManager.get(vm, "slots") || [];
      var curSlots = resolveSlots(parentVNode.data.scopedSlots, vm.$slots);
      for (var index = 0; index < prevSlots.length; index++) {
        var key = prevSlots[index];
        if (!curSlots[key]) {
          delete slotsProxy[key];
        }
      }
      var slotNames = Object.keys(curSlots);
      for (var index = 0; index < slotNames.length; index++) {
        var key = slotNames[index];
        if (!slotsProxy[key]) {
          slotsProxy[key] = createSlotProxy(vm, key);
        }
      }
      vmStateManager.set(vm, "slots", slotNames);
    }
    function activateCurrentInstance(instance, fn, onError) {
      var preVm = getCurrentInstance();
      setCurrentInstance(instance);
      try {
        return fn(instance);
      } catch (err) {
        if (onError) {
          onError(err);
        } else {
          throw err;
        }
      } finally {
        setCurrentInstance(preVm);
      }
    }
    function mixin(Vue) {
      Vue.mixin({
        beforeCreate: functionApiInit,
        mounted: function() {
          updateTemplateRef(this);
        },
        beforeUpdate: function() {
          updateVmAttrs(this);
        },
        updated: function() {
          var _a;
          updateTemplateRef(this);
          if ((_a = this.$vnode) === null || _a === void 0 ? void 0 : _a.context) {
            updateTemplateRef(this.$vnode.context);
          }
        }
      });
      function functionApiInit() {
        var vm = this;
        var $options = vm.$options;
        var setup = $options.setup, render = $options.render;
        if (render) {
          $options.render = function() {
            var _this = this;
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
              args[_i] = arguments[_i];
            }
            return activateCurrentInstance(toVue3ComponentInstance(vm), function() {
              return render.apply(_this, args);
            });
          };
        }
        if (!setup) {
          return;
        }
        if (!isFunction(setup)) {
          return;
        }
        var data = $options.data;
        $options.data = function wrappedData() {
          initSetup(vm, vm.$props);
          return isFunction(data) ? data.call(vm, vm) : data || {};
        };
      }
      function initSetup(vm, props) {
        if (props === void 0) {
          props = {};
        }
        var setup = vm.$options.setup;
        var ctx = createSetupContext(vm);
        var instance = toVue3ComponentInstance(vm);
        instance.setupContext = ctx;
        def(props, "__ob__", createObserver());
        resolveScopedSlots(vm, ctx.slots);
        var binding;
        activateCurrentInstance(instance, function() {
          binding = setup(props, ctx);
        });
        if (!binding)
          return;
        if (isFunction(binding)) {
          var bindingFunc_1 = binding;
          vm.$options.render = function() {
            resolveScopedSlots(vm, ctx.slots);
            return activateCurrentInstance(instance, function() {
              return bindingFunc_1();
            });
          };
          return;
        } else if (isPlainObject(binding)) {
          if (isReactive(binding)) {
            binding = toRefs(binding);
          }
          vmStateManager.set(vm, "rawBindings", binding);
          var bindingObj_1 = binding;
          Object.keys(bindingObj_1).forEach(function(name) {
            var bindingValue = bindingObj_1[name];
            if (!isRef(bindingValue)) {
              if (!isReactive(bindingValue)) {
                if (isFunction(bindingValue)) {
                  var copy_1 = bindingValue;
                  bindingValue = bindingValue.bind(vm);
                  Object.keys(copy_1).forEach(function(ele) {
                    bindingValue[ele] = copy_1[ele];
                  });
                } else if (!isObject(bindingValue)) {
                  bindingValue = ref(bindingValue);
                } else if (hasReactiveArrayChild(bindingValue)) {
                  customReactive(bindingValue);
                }
              } else if (isArray(bindingValue)) {
                bindingValue = ref(bindingValue);
              }
            }
            asVmProperty(vm, name, bindingValue);
          });
          return;
        }
      }
      function customReactive(target, seen) {
        if (seen === void 0) {
          seen = /* @__PURE__ */ new Set();
        }
        if (seen.has(target))
          return;
        if (!isPlainObject(target) || isRef(target) || isReactive(target) || isRaw(target))
          return;
        var Vue2 = getVueConstructor();
        var defineReactive = Vue2.util.defineReactive;
        Object.keys(target).forEach(function(k) {
          var val = target[k];
          defineReactive(target, k, val);
          if (val) {
            seen.add(val);
            customReactive(val, seen);
          }
          return;
        });
      }
      function hasReactiveArrayChild(target, visited) {
        if (visited === void 0) {
          visited = /* @__PURE__ */ new Map();
        }
        if (visited.has(target)) {
          return visited.get(target);
        }
        visited.set(target, false);
        if (isArray(target) && isReactive(target)) {
          visited.set(target, true);
          return true;
        }
        if (!isPlainObject(target) || isRaw(target) || isRef(target)) {
          return false;
        }
        return Object.keys(target).some(function(x) {
          return hasReactiveArrayChild(target[x], visited);
        });
      }
      function createSetupContext(vm) {
        var ctx = {
          slots: {}
        };
        var propsPlain = ["root", "parent", "refs", "listeners", "isServer", "ssrContext"];
        var methodReturnVoid = ["emit"];
        propsPlain.forEach(function(key) {
          var srcKey = "$" + key;
          proxy(ctx, key, {
            get: function() {
              return vm[srcKey];
            },
            set: function() {
            }
          });
        });
        updateVmAttrs(vm, ctx);
        methodReturnVoid.forEach(function(key) {
          var srcKey = "$" + key;
          proxy(ctx, key, {
            get: function() {
              return function() {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                  args[_i] = arguments[_i];
                }
                var fn = vm[srcKey];
                fn.apply(vm, args);
              };
            }
          });
        });
        return ctx;
      }
    }
    function mergeData(from, to) {
      if (!from)
        return to;
      if (!to)
        return from;
      var key;
      var toVal;
      var fromVal;
      var keys = hasSymbol ? Reflect.ownKeys(from) : Object.keys(from);
      for (var i = 0; i < keys.length; i++) {
        key = keys[i];
        if (key === "__ob__")
          continue;
        toVal = to[key];
        fromVal = from[key];
        if (!hasOwn(to, key)) {
          to[key] = fromVal;
        } else if (toVal !== fromVal && isPlainObject(toVal) && !isRef(toVal) && isPlainObject(fromVal) && !isRef(fromVal)) {
          mergeData(fromVal, toVal);
        }
      }
      return to;
    }
    function install(Vue) {
      if (isVueRegistered(Vue)) {
        return;
      }
      Vue.config.optionMergeStrategies.setup = function(parent, child) {
        return function mergedSetupFn(props, context) {
          return mergeData(isFunction(parent) ? parent(props, context) || {} : void 0, isFunction(child) ? child(props, context) || {} : void 0);
        };
      };
      setVueConstructor(Vue);
      mixin(Vue);
    }
    var Plugin = {
      install: function(Vue) {
        return install(Vue);
      }
    };
    function defineComponent(options) {
      return options;
    }
    function defineAsyncComponent(source) {
      if (isFunction(source)) {
        source = {
          loader: source
        };
      }
      var loader = source.loader, loadingComponent = source.loadingComponent, errorComponent = source.errorComponent, _a = source.delay, delay = _a === void 0 ? 200 : _a, timeout = source.timeout; source.suspensible; var userOnError = source.onError;
      var pendingRequest = null;
      var retries = 0;
      var retry = function() {
        retries++;
        pendingRequest = null;
        return load();
      };
      var load = function() {
        var thisRequest;
        return pendingRequest || (thisRequest = pendingRequest = loader().catch(function(err) {
          err = err instanceof Error ? err : new Error(String(err));
          if (userOnError) {
            return new Promise(function(resolve, reject) {
              var userRetry = function() {
                return resolve(retry());
              };
              var userFail = function() {
                return reject(err);
              };
              userOnError(err, userRetry, userFail, retries + 1);
            });
          } else {
            throw err;
          }
        }).then(function(comp) {
          if (thisRequest !== pendingRequest && pendingRequest) {
            return pendingRequest;
          }
          if (comp && (comp.__esModule || comp[Symbol.toStringTag] === "Module")) {
            comp = comp.default;
          }
          return comp;
        }));
      };
      return function() {
        var component = load();
        return {
          component,
          delay,
          timeout,
          error: errorComponent,
          loading: loadingComponent
        };
      };
    }
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    __webpack_require__.d(__webpack_exports__, "EffectScope", function() {
      return vue_composition_api["a"];
    });
    __webpack_require__.d(__webpack_exports__, "computed", function() {
      return vue_composition_api["b"];
    });
    __webpack_require__.d(__webpack_exports__, "createApp", function() {
      return vue_composition_api["c"];
    });
    __webpack_require__.d(__webpack_exports__, "createRef", function() {
      return vue_composition_api["d"];
    });
    __webpack_require__.d(__webpack_exports__, "customRef", function() {
      return vue_composition_api["e"];
    });
    __webpack_require__.d(__webpack_exports__, "defineAsyncComponent", function() {
      return vue_composition_api["g"];
    });
    __webpack_require__.d(__webpack_exports__, "defineComponent", function() {
      return vue_composition_api["h"];
    });
    __webpack_require__.d(__webpack_exports__, "del", function() {
      return vue_composition_api["i"];
    });
    __webpack_require__.d(__webpack_exports__, "effectScope", function() {
      return vue_composition_api["j"];
    });
    __webpack_require__.d(__webpack_exports__, "getCurrentInstance", function() {
      return vue_composition_api["k"];
    });
    __webpack_require__.d(__webpack_exports__, "getCurrentScope", function() {
      return vue_composition_api["l"];
    });
    __webpack_require__.d(__webpack_exports__, "h", function() {
      return vue_composition_api["m"];
    });
    __webpack_require__.d(__webpack_exports__, "inject", function() {
      return vue_composition_api["n"];
    });
    __webpack_require__.d(__webpack_exports__, "isRaw", function() {
      return vue_composition_api["o"];
    });
    __webpack_require__.d(__webpack_exports__, "isReactive", function() {
      return vue_composition_api["p"];
    });
    __webpack_require__.d(__webpack_exports__, "isReadonly", function() {
      return vue_composition_api["q"];
    });
    __webpack_require__.d(__webpack_exports__, "isRef", function() {
      return vue_composition_api["r"];
    });
    __webpack_require__.d(__webpack_exports__, "markRaw", function() {
      return vue_composition_api["s"];
    });
    __webpack_require__.d(__webpack_exports__, "nextTick", function() {
      return vue_composition_api["t"];
    });
    __webpack_require__.d(__webpack_exports__, "onActivated", function() {
      return vue_composition_api["u"];
    });
    __webpack_require__.d(__webpack_exports__, "onBeforeMount", function() {
      return vue_composition_api["v"];
    });
    __webpack_require__.d(__webpack_exports__, "onBeforeUnmount", function() {
      return vue_composition_api["w"];
    });
    __webpack_require__.d(__webpack_exports__, "onBeforeUpdate", function() {
      return vue_composition_api["x"];
    });
    __webpack_require__.d(__webpack_exports__, "onDeactivated", function() {
      return vue_composition_api["y"];
    });
    __webpack_require__.d(__webpack_exports__, "onErrorCaptured", function() {
      return vue_composition_api["z"];
    });
    __webpack_require__.d(__webpack_exports__, "onMounted", function() {
      return vue_composition_api["A"];
    });
    __webpack_require__.d(__webpack_exports__, "onScopeDispose", function() {
      return vue_composition_api["B"];
    });
    __webpack_require__.d(__webpack_exports__, "onServerPrefetch", function() {
      return vue_composition_api["C"];
    });
    __webpack_require__.d(__webpack_exports__, "onUnmounted", function() {
      return vue_composition_api["D"];
    });
    __webpack_require__.d(__webpack_exports__, "onUpdated", function() {
      return vue_composition_api["E"];
    });
    __webpack_require__.d(__webpack_exports__, "provide", function() {
      return vue_composition_api["F"];
    });
    __webpack_require__.d(__webpack_exports__, "proxyRefs", function() {
      return vue_composition_api["G"];
    });
    __webpack_require__.d(__webpack_exports__, "reactive", function() {
      return vue_composition_api["H"];
    });
    __webpack_require__.d(__webpack_exports__, "readonly", function() {
      return vue_composition_api["I"];
    });
    __webpack_require__.d(__webpack_exports__, "ref", function() {
      return vue_composition_api["J"];
    });
    __webpack_require__.d(__webpack_exports__, "set", function() {
      return vue_composition_api["K"];
    });
    __webpack_require__.d(__webpack_exports__, "shallowReactive", function() {
      return vue_composition_api["L"];
    });
    __webpack_require__.d(__webpack_exports__, "shallowReadonly", function() {
      return vue_composition_api["M"];
    });
    __webpack_require__.d(__webpack_exports__, "shallowRef", function() {
      return vue_composition_api["N"];
    });
    __webpack_require__.d(__webpack_exports__, "toRaw", function() {
      return vue_composition_api["O"];
    });
    __webpack_require__.d(__webpack_exports__, "toRef", function() {
      return vue_composition_api["P"];
    });
    __webpack_require__.d(__webpack_exports__, "toRefs", function() {
      return vue_composition_api["Q"];
    });
    __webpack_require__.d(__webpack_exports__, "triggerRef", function() {
      return vue_composition_api["R"];
    });
    __webpack_require__.d(__webpack_exports__, "unref", function() {
      return vue_composition_api["S"];
    });
    __webpack_require__.d(__webpack_exports__, "useAttrs", function() {
      return vue_composition_api["T"];
    });
    __webpack_require__.d(__webpack_exports__, "useCSSModule", function() {
      return vue_composition_api["U"];
    });
    __webpack_require__.d(__webpack_exports__, "useCssModule", function() {
      return vue_composition_api["V"];
    });
    __webpack_require__.d(__webpack_exports__, "useSlots", function() {
      return vue_composition_api["W"];
    });
    __webpack_require__.d(__webpack_exports__, "warn", function() {
      return vue_composition_api["X"];
    });
    __webpack_require__.d(__webpack_exports__, "watch", function() {
      return vue_composition_api["Y"];
    });
    __webpack_require__.d(__webpack_exports__, "watchEffect", function() {
      return vue_composition_api["Z"];
    });
    __webpack_require__.d(__webpack_exports__, "watchPostEffect", function() {
      return vue_composition_api["ab"];
    });
    __webpack_require__.d(__webpack_exports__, "watchSyncEffect", function() {
      return vue_composition_api["bb"];
    });
    __webpack_require__.d(__webpack_exports__, "isFunction", function() {
      return isFunction;
    });
    __webpack_require__.d(__webpack_exports__, "default", function() {
      return vue_runtime_esm;
    });
    __webpack_require__.d(__webpack_exports__, "Vue2", function() {
      return Vue2;
    });
    __webpack_require__.d(__webpack_exports__, "isVue2", function() {
      return isVue2;
    });
    __webpack_require__.d(__webpack_exports__, "isVue3", function() {
      return isVue3;
    });
    __webpack_require__.d(__webpack_exports__, "install", function() {
      return install;
    });
    __webpack_require__.d(__webpack_exports__, "version", function() {
      return version;
    });
    __webpack_require__(25);
    __webpack_require__(26);
    __webpack_require__(27);
    __webpack_require__(28);
    __webpack_require__(29);
    __webpack_require__(30);
    __webpack_require__(31);
    __webpack_require__(32);
    __webpack_require__(33);
    __webpack_require__(34);
    __webpack_require__(35);
    __webpack_require__(36);
    __webpack_require__(37);
    __webpack_require__(38);
    __webpack_require__(39);
    __webpack_require__(40);
    /*!
     * Vue.js v2.6.14
     * (c) 2014-2021 Evan You
     * Released under the MIT License.
     */
    var emptyObject = Object.freeze({});
    function isUndef(v) {
      return v === void 0 || v === null;
    }
    function isDef(v) {
      return v !== void 0 && v !== null;
    }
    function isTrue(v) {
      return v === true;
    }
    function isFalse(v) {
      return v === false;
    }
    function isPrimitive(value) {
      return typeof value === "string" || typeof value === "number" || typeof value === "symbol" || typeof value === "boolean";
    }
    function isObject(obj) {
      return obj !== null && typeof obj === "object";
    }
    var _toString = Object.prototype.toString;
    function toRawType(value) {
      return _toString.call(value).slice(8, -1);
    }
    function isPlainObject(obj) {
      return _toString.call(obj) === "[object Object]";
    }
    function isRegExp(v) {
      return _toString.call(v) === "[object RegExp]";
    }
    function isValidArrayIndex(val) {
      var n = parseFloat(String(val));
      return n >= 0 && Math.floor(n) === n && isFinite(val);
    }
    function isPromise(val) {
      return isDef(val) && typeof val.then === "function" && typeof val.catch === "function";
    }
    function vue_runtime_esm_toString(val) {
      return val == null ? "" : Array.isArray(val) || isPlainObject(val) && val.toString === _toString ? JSON.stringify(val, null, 2) : String(val);
    }
    function toNumber(val) {
      var n = parseFloat(val);
      return isNaN(n) ? val : n;
    }
    function makeMap(str, expectsLowerCase) {
      var map = Object.create(null);
      var list = str.split(",");
      for (var i = 0; i < list.length; i++) {
        map[list[i]] = true;
      }
      return expectsLowerCase ? function(val) {
        return map[val.toLowerCase()];
      } : function(val) {
        return map[val];
      };
    }
    makeMap("slot,component", true);
    var isReservedAttribute = makeMap("key,ref,slot,slot-scope,is");
    function remove(arr, item) {
      if (arr.length) {
        var index2 = arr.indexOf(item);
        if (index2 > -1) {
          return arr.splice(index2, 1);
        }
      }
    }
    var vue_runtime_esm_hasOwnProperty = Object.prototype.hasOwnProperty;
    function hasOwn(obj, key) {
      return vue_runtime_esm_hasOwnProperty.call(obj, key);
    }
    function cached(fn) {
      var cache = Object.create(null);
      return function cachedFn(str) {
        var hit = cache[str];
        return hit || (cache[str] = fn(str));
      };
    }
    var camelizeRE = /-(\w)/g;
    var camelize = cached(function(str) {
      return str.replace(camelizeRE, function(_, c) {
        return c ? c.toUpperCase() : "";
      });
    });
    var capitalize = cached(function(str) {
      return str.charAt(0).toUpperCase() + str.slice(1);
    });
    var hyphenateRE = /\B([A-Z])/g;
    var hyphenate = cached(function(str) {
      return str.replace(hyphenateRE, "-$1").toLowerCase();
    });
    function polyfillBind(fn, ctx) {
      function boundFn(a) {
        var l = arguments.length;
        return l ? l > 1 ? fn.apply(ctx, arguments) : fn.call(ctx, a) : fn.call(ctx);
      }
      boundFn._length = fn.length;
      return boundFn;
    }
    function nativeBind(fn, ctx) {
      return fn.bind(ctx);
    }
    var bind = Function.prototype.bind ? nativeBind : polyfillBind;
    function toArray(list, start) {
      start = start || 0;
      var i = list.length - start;
      var ret = new Array(i);
      while (i--) {
        ret[i] = list[i + start];
      }
      return ret;
    }
    function extend(to, _from) {
      for (var key in _from) {
        to[key] = _from[key];
      }
      return to;
    }
    function toObject(arr) {
      var res = {};
      for (var i = 0; i < arr.length; i++) {
        if (arr[i]) {
          extend(res, arr[i]);
        }
      }
      return res;
    }
    function noop(a, b, c) {
    }
    var no = function(a, b, c) {
      return false;
    };
    var identity = function(_) {
      return _;
    };
    function looseEqual(a, b) {
      if (a === b) {
        return true;
      }
      var isObjectA = isObject(a);
      var isObjectB = isObject(b);
      if (isObjectA && isObjectB) {
        try {
          var isArrayA = Array.isArray(a);
          var isArrayB = Array.isArray(b);
          if (isArrayA && isArrayB) {
            return a.length === b.length && a.every(function(e, i) {
              return looseEqual(e, b[i]);
            });
          } else if (a instanceof Date && b instanceof Date) {
            return a.getTime() === b.getTime();
          } else if (!isArrayA && !isArrayB) {
            var keysA = Object.keys(a);
            var keysB = Object.keys(b);
            return keysA.length === keysB.length && keysA.every(function(key) {
              return looseEqual(a[key], b[key]);
            });
          } else {
            return false;
          }
        } catch (e) {
          return false;
        }
      } else if (!isObjectA && !isObjectB) {
        return String(a) === String(b);
      } else {
        return false;
      }
    }
    function looseIndexOf(arr, val) {
      for (var i = 0; i < arr.length; i++) {
        if (looseEqual(arr[i], val)) {
          return i;
        }
      }
      return -1;
    }
    function once(fn) {
      var called = false;
      return function() {
        if (!called) {
          called = true;
          fn.apply(this, arguments);
        }
      };
    }
    var SSR_ATTR = "data-server-rendered";
    var ASSET_TYPES = ["component", "directive", "filter"];
    var LIFECYCLE_HOOKS = ["beforeCreate", "created", "beforeMount", "mounted", "beforeUpdate", "updated", "beforeDestroy", "destroyed", "activated", "deactivated", "errorCaptured", "serverPrefetch"];
    var config = {
      optionMergeStrategies: Object.create(null),
      silent: false,
      productionTip: false,
      devtools: false,
      performance: false,
      errorHandler: null,
      warnHandler: null,
      ignoredElements: [],
      keyCodes: Object.create(null),
      isReservedTag: no,
      isReservedAttr: no,
      isUnknownElement: no,
      getTagNamespace: noop,
      parsePlatformTagName: identity,
      mustUseProp: no,
      async: true,
      _lifecycleHooks: LIFECYCLE_HOOKS
    };
    var unicodeRegExp = /a-zA-Z\u00B7\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u037D\u037F-\u1FFF\u200C-\u200D\u203F-\u2040\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD/;
    function isReserved(str) {
      var c = (str + "").charCodeAt(0);
      return c === 36 || c === 95;
    }
    function def(obj, key, val, enumerable) {
      Object.defineProperty(obj, key, {
        value: val,
        enumerable: !!enumerable,
        writable: true,
        configurable: true
      });
    }
    var bailRE = new RegExp("[^" + unicodeRegExp.source + ".$_\\d]");
    function parsePath(path) {
      if (bailRE.test(path)) {
        return;
      }
      var segments = path.split(".");
      return function(obj) {
        for (var i = 0; i < segments.length; i++) {
          if (!obj) {
            return;
          }
          obj = obj[segments[i]];
        }
        return obj;
      };
    }
    var hasProto = "__proto__" in {};
    var inBrowser = false;
    var inWeex = typeof WXEnvironment !== "undefined" && !!WXEnvironment.platform;
    var weexPlatform = inWeex && WXEnvironment.platform.toLowerCase();
    var UA = inBrowser ;
    var isIE9 = UA ;
    var isIOS = weexPlatform === "ios";
    var isFF = UA ;
    var nativeWatch = {}.watch;
    var _isServer;
    var isServerRendering = function() {
      if (_isServer === void 0) {
        if (!inWeex && typeof commonjsGlobal !== "undefined") {
          _isServer = commonjsGlobal["process"] && commonjsGlobal["process"].env.VUE_ENV === "server";
        } else {
          _isServer = false;
        }
      }
      return _isServer;
    };
    function isNative(Ctor) {
      return typeof Ctor === "function" && /native code/.test(Ctor.toString());
    }
    var hasSymbol = typeof Symbol !== "undefined" && isNative(Symbol) && typeof Reflect !== "undefined" && isNative(Reflect.ownKeys);
    var _Set;
    if (typeof Set !== "undefined" && isNative(Set)) {
      _Set = Set;
    } else {
      _Set = /* @__PURE__ */ function() {
        function Set2() {
          this.set = Object.create(null);
        }
        Set2.prototype.has = function has2(key) {
          return this.set[key] === true;
        };
        Set2.prototype.add = function add2(key) {
          this.set[key] = true;
        };
        Set2.prototype.clear = function clear() {
          this.set = Object.create(null);
        };
        return Set2;
      }();
    }
    var warn = noop;
    var uid = 0;
    var Dep = function Dep2() {
      this.id = uid++;
      this.subs = [];
    };
    Dep.prototype.addSub = function addSub(sub) {
      this.subs.push(sub);
    };
    Dep.prototype.removeSub = function removeSub(sub) {
      remove(this.subs, sub);
    };
    Dep.prototype.depend = function depend() {
      if (Dep.target) {
        Dep.target.addDep(this);
      }
    };
    Dep.prototype.notify = function notify() {
      var subs = this.subs.slice();
      for (var i = 0, l = subs.length; i < l; i++) {
        subs[i].update();
      }
    };
    Dep.target = null;
    var targetStack = [];
    function pushTarget(target2) {
      targetStack.push(target2);
      Dep.target = target2;
    }
    function popTarget() {
      targetStack.pop();
      Dep.target = targetStack[targetStack.length - 1];
    }
    var VNode = function VNode2(tag, data, children, text, elm, context, componentOptions, asyncFactory) {
      this.tag = tag;
      this.data = data;
      this.children = children;
      this.text = text;
      this.elm = elm;
      this.ns = void 0;
      this.context = context;
      this.fnContext = void 0;
      this.fnOptions = void 0;
      this.fnScopeId = void 0;
      this.key = data && data.key;
      this.componentOptions = componentOptions;
      this.componentInstance = void 0;
      this.parent = void 0;
      this.raw = false;
      this.isStatic = false;
      this.isRootInsert = true;
      this.isComment = false;
      this.isCloned = false;
      this.isOnce = false;
      this.asyncFactory = asyncFactory;
      this.asyncMeta = void 0;
      this.isAsyncPlaceholder = false;
    };
    var prototypeAccessors = {
      child: {
        configurable: true
      }
    };
    prototypeAccessors.child.get = function() {
      return this.componentInstance;
    };
    Object.defineProperties(VNode.prototype, prototypeAccessors);
    var createEmptyVNode = function(text) {
      if (text === void 0)
        text = "";
      var node = new VNode();
      node.text = text;
      node.isComment = true;
      return node;
    };
    function createTextVNode(val) {
      return new VNode(void 0, void 0, void 0, String(val));
    }
    function cloneVNode(vnode) {
      var cloned = new VNode(vnode.tag, vnode.data, vnode.children && vnode.children.slice(), vnode.text, vnode.elm, vnode.context, vnode.componentOptions, vnode.asyncFactory);
      cloned.ns = vnode.ns;
      cloned.isStatic = vnode.isStatic;
      cloned.key = vnode.key;
      cloned.isComment = vnode.isComment;
      cloned.fnContext = vnode.fnContext;
      cloned.fnOptions = vnode.fnOptions;
      cloned.fnScopeId = vnode.fnScopeId;
      cloned.asyncMeta = vnode.asyncMeta;
      cloned.isCloned = true;
      return cloned;
    }
    var arrayProto = Array.prototype;
    var arrayMethods = Object.create(arrayProto);
    var methodsToPatch = ["push", "pop", "shift", "unshift", "splice", "sort", "reverse"];
    methodsToPatch.forEach(function(method) {
      var original = arrayProto[method];
      def(arrayMethods, method, function mutator() {
        var args = [], len = arguments.length;
        while (len--)
          args[len] = arguments[len];
        var result = original.apply(this, args);
        var ob = this.__ob__;
        var inserted;
        switch (method) {
          case "push":
          case "unshift":
            inserted = args;
            break;
          case "splice":
            inserted = args.slice(2);
            break;
        }
        if (inserted) {
          ob.observeArray(inserted);
        }
        ob.dep.notify();
        return result;
      });
    });
    var arrayKeys = Object.getOwnPropertyNames(arrayMethods);
    var shouldObserve = true;
    function toggleObserving(value) {
      shouldObserve = value;
    }
    var Observer = function Observer2(value) {
      this.value = value;
      this.dep = new Dep();
      this.vmCount = 0;
      def(value, "__ob__", this);
      if (Array.isArray(value)) {
        if (hasProto) {
          protoAugment(value, arrayMethods);
        } else {
          copyAugment(value, arrayMethods, arrayKeys);
        }
        this.observeArray(value);
      } else {
        this.walk(value);
      }
    };
    Observer.prototype.walk = function walk(obj) {
      var keys = Object.keys(obj);
      for (var i = 0; i < keys.length; i++) {
        defineReactive$$1(obj, keys[i]);
      }
    };
    Observer.prototype.observeArray = function observeArray(items) {
      for (var i = 0, l = items.length; i < l; i++) {
        observe(items[i]);
      }
    };
    function protoAugment(target2, src) {
      target2.__proto__ = src;
    }
    function copyAugment(target2, src, keys) {
      for (var i = 0, l = keys.length; i < l; i++) {
        var key = keys[i];
        def(target2, key, src[key]);
      }
    }
    function observe(value, asRootData) {
      if (!isObject(value) || value instanceof VNode) {
        return;
      }
      var ob;
      if (hasOwn(value, "__ob__") && value.__ob__ instanceof Observer) {
        ob = value.__ob__;
      } else if (shouldObserve && !isServerRendering() && (Array.isArray(value) || isPlainObject(value)) && Object.isExtensible(value) && !value._isVue) {
        ob = new Observer(value);
      }
      if (asRootData && ob) {
        ob.vmCount++;
      }
      return ob;
    }
    function defineReactive$$1(obj, key, val, customSetter, shallow) {
      var dep = new Dep();
      var property = Object.getOwnPropertyDescriptor(obj, key);
      if (property && property.configurable === false) {
        return;
      }
      var getter = property && property.get;
      var setter = property && property.set;
      if ((!getter || setter) && arguments.length === 2) {
        val = obj[key];
      }
      var childOb = !shallow && observe(val);
      Object.defineProperty(obj, key, {
        enumerable: true,
        configurable: true,
        get: function reactiveGetter() {
          var value = getter ? getter.call(obj) : val;
          if (Dep.target) {
            dep.depend();
            if (childOb) {
              childOb.dep.depend();
              if (Array.isArray(value)) {
                dependArray(value);
              }
            }
          }
          return value;
        },
        set: function reactiveSetter(newVal) {
          var value = getter ? getter.call(obj) : val;
          if (newVal === value || newVal !== newVal && value !== value) {
            return;
          }
          if (getter && !setter) {
            return;
          }
          if (setter) {
            setter.call(obj, newVal);
          } else {
            val = newVal;
          }
          childOb = !shallow && observe(newVal);
          dep.notify();
        }
      });
    }
    function set(target2, key, val) {
      if (Array.isArray(target2) && isValidArrayIndex(key)) {
        target2.length = Math.max(target2.length, key);
        target2.splice(key, 1, val);
        return val;
      }
      if (key in target2 && !(key in Object.prototype)) {
        target2[key] = val;
        return val;
      }
      var ob = target2.__ob__;
      if (target2._isVue || ob && ob.vmCount) {
        return val;
      }
      if (!ob) {
        target2[key] = val;
        return val;
      }
      defineReactive$$1(ob.value, key, val);
      ob.dep.notify();
      return val;
    }
    function del(target2, key) {
      if (Array.isArray(target2) && isValidArrayIndex(key)) {
        target2.splice(key, 1);
        return;
      }
      var ob = target2.__ob__;
      if (target2._isVue || ob && ob.vmCount) {
        return;
      }
      if (!hasOwn(target2, key)) {
        return;
      }
      delete target2[key];
      if (!ob) {
        return;
      }
      ob.dep.notify();
    }
    function dependArray(value) {
      for (var e = void 0, i = 0, l = value.length; i < l; i++) {
        e = value[i];
        e && e.__ob__ && e.__ob__.dep.depend();
        if (Array.isArray(e)) {
          dependArray(e);
        }
      }
    }
    var strats = config.optionMergeStrategies;
    function mergeData(to, from) {
      if (!from) {
        return to;
      }
      var key, toVal, fromVal;
      var keys = hasSymbol ? Reflect.ownKeys(from) : Object.keys(from);
      for (var i = 0; i < keys.length; i++) {
        key = keys[i];
        if (key === "__ob__") {
          continue;
        }
        toVal = to[key];
        fromVal = from[key];
        if (!hasOwn(to, key)) {
          set(to, key, fromVal);
        } else if (toVal !== fromVal && isPlainObject(toVal) && isPlainObject(fromVal)) {
          mergeData(toVal, fromVal);
        }
      }
      return to;
    }
    function mergeDataOrFn(parentVal, childVal, vm) {
      if (!vm) {
        if (!childVal) {
          return parentVal;
        }
        if (!parentVal) {
          return childVal;
        }
        return function mergedDataFn() {
          return mergeData(typeof childVal === "function" ? childVal.call(this, this) : childVal, typeof parentVal === "function" ? parentVal.call(this, this) : parentVal);
        };
      } else {
        return function mergedInstanceDataFn() {
          var instanceData = typeof childVal === "function" ? childVal.call(vm, vm) : childVal;
          var defaultData = typeof parentVal === "function" ? parentVal.call(vm, vm) : parentVal;
          if (instanceData) {
            return mergeData(instanceData, defaultData);
          } else {
            return defaultData;
          }
        };
      }
    }
    strats.data = function(parentVal, childVal, vm) {
      if (!vm) {
        if (childVal && typeof childVal !== "function") {
          return parentVal;
        }
        return mergeDataOrFn(parentVal, childVal);
      }
      return mergeDataOrFn(parentVal, childVal, vm);
    };
    function mergeHook(parentVal, childVal) {
      var res = childVal ? parentVal ? parentVal.concat(childVal) : Array.isArray(childVal) ? childVal : [childVal] : parentVal;
      return res ? dedupeHooks(res) : res;
    }
    function dedupeHooks(hooks2) {
      var res = [];
      for (var i = 0; i < hooks2.length; i++) {
        if (res.indexOf(hooks2[i]) === -1) {
          res.push(hooks2[i]);
        }
      }
      return res;
    }
    LIFECYCLE_HOOKS.forEach(function(hook) {
      strats[hook] = mergeHook;
    });
    function mergeAssets(parentVal, childVal, vm, key) {
      var res = Object.create(parentVal || null);
      if (childVal) {
        return extend(res, childVal);
      } else {
        return res;
      }
    }
    ASSET_TYPES.forEach(function(type) {
      strats[type + "s"] = mergeAssets;
    });
    strats.watch = function(parentVal, childVal, vm, key) {
      if (parentVal === nativeWatch) {
        parentVal = void 0;
      }
      if (childVal === nativeWatch) {
        childVal = void 0;
      }
      if (!childVal) {
        return Object.create(parentVal || null);
      }
      if (!parentVal) {
        return childVal;
      }
      var ret = {};
      extend(ret, parentVal);
      for (var key$1 in childVal) {
        var parent = ret[key$1];
        var child = childVal[key$1];
        if (parent && !Array.isArray(parent)) {
          parent = [parent];
        }
        ret[key$1] = parent ? parent.concat(child) : Array.isArray(child) ? child : [child];
      }
      return ret;
    };
    strats.props = strats.methods = strats.inject = strats.computed = function(parentVal, childVal, vm, key) {
      if (childVal && false) {
        assertObjectType(key, childVal);
      }
      if (!parentVal) {
        return childVal;
      }
      var ret = Object.create(null);
      extend(ret, parentVal);
      if (childVal) {
        extend(ret, childVal);
      }
      return ret;
    };
    strats.provide = mergeDataOrFn;
    var defaultStrat = function(parentVal, childVal) {
      return childVal === void 0 ? parentVal : childVal;
    };
    function normalizeProps(options, vm) {
      var props2 = options.props;
      if (!props2) {
        return;
      }
      var res = {};
      var i, val, name;
      if (Array.isArray(props2)) {
        i = props2.length;
        while (i--) {
          val = props2[i];
          if (typeof val === "string") {
            name = camelize(val);
            res[name] = {
              type: null
            };
          }
        }
      } else if (isPlainObject(props2)) {
        for (var key in props2) {
          val = props2[key];
          name = camelize(key);
          res[name] = isPlainObject(val) ? val : {
            type: val
          };
        }
      } else ;
      options.props = res;
    }
    function normalizeInject(options, vm) {
      var inject = options.inject;
      if (!inject) {
        return;
      }
      var normalized = options.inject = {};
      if (Array.isArray(inject)) {
        for (var i = 0; i < inject.length; i++) {
          normalized[inject[i]] = {
            from: inject[i]
          };
        }
      } else if (isPlainObject(inject)) {
        for (var key in inject) {
          var val = inject[key];
          normalized[key] = isPlainObject(val) ? extend({
            from: key
          }, val) : {
            from: val
          };
        }
      } else ;
    }
    function normalizeDirectives(options) {
      var dirs = options.directives;
      if (dirs) {
        for (var key in dirs) {
          var def$$1 = dirs[key];
          if (typeof def$$1 === "function") {
            dirs[key] = {
              bind: def$$1,
              update: def$$1
            };
          }
        }
      }
    }
    function assertObjectType(name, value, vm) {
      if (!isPlainObject(value)) {
        warn('Invalid value for option "' + name + '": expected an Object, but got ' + toRawType(value) + ".");
      }
    }
    function mergeOptions(parent, child, vm) {
      if (typeof child === "function") {
        child = child.options;
      }
      normalizeProps(child);
      normalizeInject(child);
      normalizeDirectives(child);
      if (!child._base) {
        if (child.extends) {
          parent = mergeOptions(parent, child.extends, vm);
        }
        if (child.mixins) {
          for (var i = 0, l = child.mixins.length; i < l; i++) {
            parent = mergeOptions(parent, child.mixins[i], vm);
          }
        }
      }
      var options = {};
      var key;
      for (key in parent) {
        mergeField(key);
      }
      for (key in child) {
        if (!hasOwn(parent, key)) {
          mergeField(key);
        }
      }
      function mergeField(key2) {
        var strat = strats[key2] || defaultStrat;
        options[key2] = strat(parent[key2], child[key2], vm, key2);
      }
      return options;
    }
    function resolveAsset(options, type, id, warnMissing) {
      if (typeof id !== "string") {
        return;
      }
      var assets = options[type];
      if (hasOwn(assets, id)) {
        return assets[id];
      }
      var camelizedId = camelize(id);
      if (hasOwn(assets, camelizedId)) {
        return assets[camelizedId];
      }
      var PascalCaseId = capitalize(camelizedId);
      if (hasOwn(assets, PascalCaseId)) {
        return assets[PascalCaseId];
      }
      var res = assets[id] || assets[camelizedId] || assets[PascalCaseId];
      return res;
    }
    function validateProp(key, propOptions, propsData, vm) {
      var prop = propOptions[key];
      var absent = !hasOwn(propsData, key);
      var value = propsData[key];
      var booleanIndex = getTypeIndex(Boolean, prop.type);
      if (booleanIndex > -1) {
        if (absent && !hasOwn(prop, "default")) {
          value = false;
        } else if (value === "" || value === hyphenate(key)) {
          var stringIndex = getTypeIndex(String, prop.type);
          if (stringIndex < 0 || booleanIndex < stringIndex) {
            value = true;
          }
        }
      }
      if (value === void 0) {
        value = getPropDefaultValue(vm, prop, key);
        var prevShouldObserve = shouldObserve;
        toggleObserving(true);
        observe(value);
        toggleObserving(prevShouldObserve);
      }
      return value;
    }
    function getPropDefaultValue(vm, prop, key) {
      if (!hasOwn(prop, "default")) {
        return void 0;
      }
      var def2 = prop.default;
      if (vm && vm.$options.propsData && vm.$options.propsData[key] === void 0 && vm._props[key] !== void 0) {
        return vm._props[key];
      }
      return typeof def2 === "function" && getType(prop.type) !== "Function" ? def2.call(vm) : def2;
    }
    var functionTypeCheckRE = /^\s*function (\w+)/;
    function getType(fn) {
      var match = fn && fn.toString().match(functionTypeCheckRE);
      return match ? match[1] : "";
    }
    function isSameType(a, b) {
      return getType(a) === getType(b);
    }
    function getTypeIndex(type, expectedTypes) {
      if (!Array.isArray(expectedTypes)) {
        return isSameType(expectedTypes, type) ? 0 : -1;
      }
      for (var i = 0, len = expectedTypes.length; i < len; i++) {
        if (isSameType(expectedTypes[i], type)) {
          return i;
        }
      }
      return -1;
    }
    function handleError(err, vm, info) {
      pushTarget();
      try {
        if (vm) {
          var cur = vm;
          while (cur = cur.$parent) {
            var hooks2 = cur.$options.errorCaptured;
            if (hooks2) {
              for (var i = 0; i < hooks2.length; i++) {
                try {
                  var capture = hooks2[i].call(cur, err, vm, info) === false;
                  if (capture) {
                    return;
                  }
                } catch (e) {
                  globalHandleError(e, cur, "errorCaptured hook");
                }
              }
            }
          }
        }
        globalHandleError(err, vm, info);
      } finally {
        popTarget();
      }
    }
    function invokeWithErrorHandling(handler, context, args, vm, info) {
      var res;
      try {
        res = args ? handler.apply(context, args) : handler.call(context);
        if (res && !res._isVue && isPromise(res) && !res._handled) {
          res.catch(function(e) {
            return handleError(e, vm, info + " (Promise/async)");
          });
          res._handled = true;
        }
      } catch (e) {
        handleError(e, vm, info);
      }
      return res;
    }
    function globalHandleError(err, vm, info) {
      if (config.errorHandler) {
        try {
          return config.errorHandler.call(null, err, vm, info);
        } catch (e) {
          if (e !== err) {
            logError(e);
          }
        }
      }
      logError(err);
    }
    function logError(err, vm, info) {
      if ((inWeex) && typeof console !== "undefined") {
        console.error(err);
      } else {
        throw err;
      }
    }
    var isUsingMicroTask = false;
    var callbacks = [];
    var pending = false;
    function flushCallbacks() {
      pending = false;
      var copies = callbacks.slice(0);
      callbacks.length = 0;
      for (var i = 0; i < copies.length; i++) {
        copies[i]();
      }
    }
    var timerFunc;
    if (typeof Promise !== "undefined" && isNative(Promise)) {
      var p = Promise.resolve();
      timerFunc = function() {
        p.then(flushCallbacks);
        if (isIOS) {
          setTimeout(noop);
        }
      };
      isUsingMicroTask = true;
    } else if (typeof MutationObserver !== "undefined" && (isNative(MutationObserver) || MutationObserver.toString() === "[object MutationObserverConstructor]")) {
      var counter = 1;
      var observer = new MutationObserver(flushCallbacks);
      var textNode = document.createTextNode(String(counter));
      observer.observe(textNode, {
        characterData: true
      });
      timerFunc = function() {
        counter = (counter + 1) % 2;
        textNode.data = String(counter);
      };
      isUsingMicroTask = true;
    } else if (typeof setImmediate !== "undefined" && isNative(setImmediate)) {
      timerFunc = function() {
        setImmediate(flushCallbacks);
      };
    } else {
      timerFunc = function() {
        setTimeout(flushCallbacks, 0);
      };
    }
    function nextTick(cb, ctx) {
      var _resolve;
      callbacks.push(function() {
        if (cb) {
          try {
            cb.call(ctx);
          } catch (e) {
            handleError(e, ctx, "nextTick");
          }
        } else if (_resolve) {
          _resolve(ctx);
        }
      });
      if (!pending) {
        pending = true;
        timerFunc();
      }
      if (!cb && typeof Promise !== "undefined") {
        return new Promise(function(resolve) {
          _resolve = resolve;
        });
      }
    }
    var seenObjects = new _Set();
    function traverse(val) {
      _traverse(val, seenObjects);
      seenObjects.clear();
    }
    function _traverse(val, seen) {
      var i, keys;
      var isA = Array.isArray(val);
      if (!isA && !isObject(val) || Object.isFrozen(val) || val instanceof VNode) {
        return;
      }
      if (val.__ob__) {
        var depId = val.__ob__.dep.id;
        if (seen.has(depId)) {
          return;
        }
        seen.add(depId);
      }
      if (isA) {
        i = val.length;
        while (i--) {
          _traverse(val[i], seen);
        }
      } else {
        keys = Object.keys(val);
        i = keys.length;
        while (i--) {
          _traverse(val[keys[i]], seen);
        }
      }
    }
    var normalizeEvent = cached(function(name) {
      var passive = name.charAt(0) === "&";
      name = passive ? name.slice(1) : name;
      var once$$1 = name.charAt(0) === "~";
      name = once$$1 ? name.slice(1) : name;
      var capture = name.charAt(0) === "!";
      name = capture ? name.slice(1) : name;
      return {
        name,
        once: once$$1,
        capture,
        passive
      };
    });
    function createFnInvoker(fns, vm) {
      function invoker() {
        var arguments$1 = arguments;
        var fns2 = invoker.fns;
        if (Array.isArray(fns2)) {
          var cloned = fns2.slice();
          for (var i = 0; i < cloned.length; i++) {
            invokeWithErrorHandling(cloned[i], null, arguments$1, vm, "v-on handler");
          }
        } else {
          return invokeWithErrorHandling(fns2, null, arguments, vm, "v-on handler");
        }
      }
      invoker.fns = fns;
      return invoker;
    }
    function updateListeners(on, oldOn, add2, remove$$1, createOnceHandler2, vm) {
      var name, cur, old, event;
      for (name in on) {
        cur = on[name];
        old = oldOn[name];
        event = normalizeEvent(name);
        if (isUndef(cur)) ; else if (isUndef(old)) {
          if (isUndef(cur.fns)) {
            cur = on[name] = createFnInvoker(cur, vm);
          }
          if (isTrue(event.once)) {
            cur = on[name] = createOnceHandler2(event.name, cur, event.capture);
          }
          add2(event.name, cur, event.capture, event.passive, event.params);
        } else if (cur !== old) {
          old.fns = cur;
          on[name] = old;
        }
      }
      for (name in oldOn) {
        if (isUndef(on[name])) {
          event = normalizeEvent(name);
          remove$$1(event.name, oldOn[name], event.capture);
        }
      }
    }
    function mergeVNodeHook(def2, hookKey, hook) {
      if (def2 instanceof VNode) {
        def2 = def2.data.hook || (def2.data.hook = {});
      }
      var invoker;
      var oldHook = def2[hookKey];
      function wrappedHook() {
        hook.apply(this, arguments);
        remove(invoker.fns, wrappedHook);
      }
      if (isUndef(oldHook)) {
        invoker = createFnInvoker([wrappedHook]);
      } else {
        if (isDef(oldHook.fns) && isTrue(oldHook.merged)) {
          invoker = oldHook;
          invoker.fns.push(wrappedHook);
        } else {
          invoker = createFnInvoker([oldHook, wrappedHook]);
        }
      }
      invoker.merged = true;
      def2[hookKey] = invoker;
    }
    function extractPropsFromVNodeData(data, Ctor, tag) {
      var propOptions = Ctor.options.props;
      if (isUndef(propOptions)) {
        return;
      }
      var res = {};
      var attrs2 = data.attrs;
      var props2 = data.props;
      if (isDef(attrs2) || isDef(props2)) {
        for (var key in propOptions) {
          var altKey = hyphenate(key);
          checkProp(res, props2, key, altKey, true) || checkProp(res, attrs2, key, altKey, false);
        }
      }
      return res;
    }
    function checkProp(res, hash, key, altKey, preserve) {
      if (isDef(hash)) {
        if (hasOwn(hash, key)) {
          res[key] = hash[key];
          if (!preserve) {
            delete hash[key];
          }
          return true;
        } else if (hasOwn(hash, altKey)) {
          res[key] = hash[altKey];
          if (!preserve) {
            delete hash[altKey];
          }
          return true;
        }
      }
      return false;
    }
    function simpleNormalizeChildren(children) {
      for (var i = 0; i < children.length; i++) {
        if (Array.isArray(children[i])) {
          return Array.prototype.concat.apply([], children);
        }
      }
      return children;
    }
    function normalizeChildren(children) {
      return isPrimitive(children) ? [createTextVNode(children)] : Array.isArray(children) ? normalizeArrayChildren(children) : void 0;
    }
    function isTextNode(node) {
      return isDef(node) && isDef(node.text) && isFalse(node.isComment);
    }
    function normalizeArrayChildren(children, nestedIndex) {
      var res = [];
      var i, c, lastIndex, last;
      for (i = 0; i < children.length; i++) {
        c = children[i];
        if (isUndef(c) || typeof c === "boolean") {
          continue;
        }
        lastIndex = res.length - 1;
        last = res[lastIndex];
        if (Array.isArray(c)) {
          if (c.length > 0) {
            c = normalizeArrayChildren(c, (nestedIndex || "") + "_" + i);
            if (isTextNode(c[0]) && isTextNode(last)) {
              res[lastIndex] = createTextVNode(last.text + c[0].text);
              c.shift();
            }
            res.push.apply(res, c);
          }
        } else if (isPrimitive(c)) {
          if (isTextNode(last)) {
            res[lastIndex] = createTextVNode(last.text + c);
          } else if (c !== "") {
            res.push(createTextVNode(c));
          }
        } else {
          if (isTextNode(c) && isTextNode(last)) {
            res[lastIndex] = createTextVNode(last.text + c.text);
          } else {
            if (isTrue(children._isVList) && isDef(c.tag) && isUndef(c.key) && isDef(nestedIndex)) {
              c.key = "__vlist" + nestedIndex + "_" + i + "__";
            }
            res.push(c);
          }
        }
      }
      return res;
    }
    function initProvide(vm) {
      var provide = vm.$options.provide;
      if (provide) {
        vm._provided = typeof provide === "function" ? provide.call(vm) : provide;
      }
    }
    function initInjections(vm) {
      var result = resolveInject(vm.$options.inject, vm);
      if (result) {
        toggleObserving(false);
        Object.keys(result).forEach(function(key) {
          {
            defineReactive$$1(vm, key, result[key]);
          }
        });
        toggleObserving(true);
      }
    }
    function resolveInject(inject, vm) {
      if (inject) {
        var result = Object.create(null);
        var keys = hasSymbol ? Reflect.ownKeys(inject) : Object.keys(inject);
        for (var i = 0; i < keys.length; i++) {
          var key = keys[i];
          if (key === "__ob__") {
            continue;
          }
          var provideKey = inject[key].from;
          var source = vm;
          while (source) {
            if (source._provided && hasOwn(source._provided, provideKey)) {
              result[key] = source._provided[provideKey];
              break;
            }
            source = source.$parent;
          }
          if (!source) {
            if ("default" in inject[key]) {
              var provideDefault = inject[key].default;
              result[key] = typeof provideDefault === "function" ? provideDefault.call(vm) : provideDefault;
            }
          }
        }
        return result;
      }
    }
    function resolveSlots(children, context) {
      if (!children || !children.length) {
        return {};
      }
      var slots = {};
      for (var i = 0, l = children.length; i < l; i++) {
        var child = children[i];
        var data = child.data;
        if (data && data.attrs && data.attrs.slot) {
          delete data.attrs.slot;
        }
        if ((child.context === context || child.fnContext === context) && data && data.slot != null) {
          var name = data.slot;
          var slot = slots[name] || (slots[name] = []);
          if (child.tag === "template") {
            slot.push.apply(slot, child.children || []);
          } else {
            slot.push(child);
          }
        } else {
          (slots.default || (slots.default = [])).push(child);
        }
      }
      for (var name$1 in slots) {
        if (slots[name$1].every(isWhitespace)) {
          delete slots[name$1];
        }
      }
      return slots;
    }
    function isWhitespace(node) {
      return node.isComment && !node.asyncFactory || node.text === " ";
    }
    function isAsyncPlaceholder(node) {
      return node.isComment && node.asyncFactory;
    }
    function normalizeScopedSlots(slots, normalSlots, prevSlots) {
      var res;
      var hasNormalSlots = Object.keys(normalSlots).length > 0;
      var isStable = slots ? !!slots.$stable : !hasNormalSlots;
      var key = slots && slots.$key;
      if (!slots) {
        res = {};
      } else if (slots._normalized) {
        return slots._normalized;
      } else if (isStable && prevSlots && prevSlots !== emptyObject && key === prevSlots.$key && !hasNormalSlots && !prevSlots.$hasNormal) {
        return prevSlots;
      } else {
        res = {};
        for (var key$1 in slots) {
          if (slots[key$1] && key$1[0] !== "$") {
            res[key$1] = normalizeScopedSlot(normalSlots, key$1, slots[key$1]);
          }
        }
      }
      for (var key$2 in normalSlots) {
        if (!(key$2 in res)) {
          res[key$2] = proxyNormalSlot(normalSlots, key$2);
        }
      }
      if (slots && Object.isExtensible(slots)) {
        slots._normalized = res;
      }
      def(res, "$stable", isStable);
      def(res, "$key", key);
      def(res, "$hasNormal", hasNormalSlots);
      return res;
    }
    function normalizeScopedSlot(normalSlots, key, fn) {
      var normalized = function() {
        var res = arguments.length ? fn.apply(null, arguments) : fn({});
        res = res && typeof res === "object" && !Array.isArray(res) ? [res] : normalizeChildren(res);
        var vnode = res && res[0];
        return res && (!vnode || res.length === 1 && vnode.isComment && !isAsyncPlaceholder(vnode)) ? void 0 : res;
      };
      if (fn.proxy) {
        Object.defineProperty(normalSlots, key, {
          get: normalized,
          enumerable: true,
          configurable: true
        });
      }
      return normalized;
    }
    function proxyNormalSlot(slots, key) {
      return function() {
        return slots[key];
      };
    }
    function renderList(val, render) {
      var ret, i, l, keys, key;
      if (Array.isArray(val) || typeof val === "string") {
        ret = new Array(val.length);
        for (i = 0, l = val.length; i < l; i++) {
          ret[i] = render(val[i], i);
        }
      } else if (typeof val === "number") {
        ret = new Array(val);
        for (i = 0; i < val; i++) {
          ret[i] = render(i + 1, i);
        }
      } else if (isObject(val)) {
        if (hasSymbol && val[Symbol.iterator]) {
          ret = [];
          var iterator = val[Symbol.iterator]();
          var result = iterator.next();
          while (!result.done) {
            ret.push(render(result.value, ret.length));
            result = iterator.next();
          }
        } else {
          keys = Object.keys(val);
          ret = new Array(keys.length);
          for (i = 0, l = keys.length; i < l; i++) {
            key = keys[i];
            ret[i] = render(val[key], key, i);
          }
        }
      }
      if (!isDef(ret)) {
        ret = [];
      }
      ret._isVList = true;
      return ret;
    }
    function renderSlot(name, fallbackRender, props2, bindObject) {
      var scopedSlotFn = this.$scopedSlots[name];
      var nodes;
      if (scopedSlotFn) {
        props2 = props2 || {};
        if (bindObject) {
          props2 = extend(extend({}, bindObject), props2);
        }
        nodes = scopedSlotFn(props2) || (typeof fallbackRender === "function" ? fallbackRender() : fallbackRender);
      } else {
        nodes = this.$slots[name] || (typeof fallbackRender === "function" ? fallbackRender() : fallbackRender);
      }
      var target2 = props2 && props2.slot;
      if (target2) {
        return this.$createElement("template", {
          slot: target2
        }, nodes);
      } else {
        return nodes;
      }
    }
    function resolveFilter(id) {
      return resolveAsset(this.$options, "filters", id) || identity;
    }
    function isKeyNotMatch(expect, actual) {
      if (Array.isArray(expect)) {
        return expect.indexOf(actual) === -1;
      } else {
        return expect !== actual;
      }
    }
    function checkKeyCodes(eventKeyCode, key, builtInKeyCode, eventKeyName, builtInKeyName) {
      var mappedKeyCode = config.keyCodes[key] || builtInKeyCode;
      if (builtInKeyName && eventKeyName && !config.keyCodes[key]) {
        return isKeyNotMatch(builtInKeyName, eventKeyName);
      } else if (mappedKeyCode) {
        return isKeyNotMatch(mappedKeyCode, eventKeyCode);
      } else if (eventKeyName) {
        return hyphenate(eventKeyName) !== key;
      }
      return eventKeyCode === void 0;
    }
    function bindObjectProps(data, tag, value, asProp, isSync) {
      if (value) {
        if (!isObject(value)) ; else {
          if (Array.isArray(value)) {
            value = toObject(value);
          }
          var hash;
          var loop = function(key2) {
            if (key2 === "class" || key2 === "style" || isReservedAttribute(key2)) {
              hash = data;
            } else {
              var type = data.attrs && data.attrs.type;
              hash = asProp || config.mustUseProp(tag, type, key2) ? data.domProps || (data.domProps = {}) : data.attrs || (data.attrs = {});
            }
            var camelizedKey = camelize(key2);
            var hyphenatedKey = hyphenate(key2);
            if (!(camelizedKey in hash) && !(hyphenatedKey in hash)) {
              hash[key2] = value[key2];
              if (isSync) {
                var on = data.on || (data.on = {});
                on["update:" + key2] = function($event) {
                  value[key2] = $event;
                };
              }
            }
          };
          for (var key in value)
            loop(key);
        }
      }
      return data;
    }
    function renderStatic(index2, isInFor) {
      var cached2 = this._staticTrees || (this._staticTrees = []);
      var tree = cached2[index2];
      if (tree && !isInFor) {
        return tree;
      }
      tree = cached2[index2] = this.$options.staticRenderFns[index2].call(this._renderProxy, null, this);
      markStatic(tree, "__static__" + index2, false);
      return tree;
    }
    function markOnce(tree, index2, key) {
      markStatic(tree, "__once__" + index2 + (key ? "_" + key : ""), true);
      return tree;
    }
    function markStatic(tree, key, isOnce) {
      if (Array.isArray(tree)) {
        for (var i = 0; i < tree.length; i++) {
          if (tree[i] && typeof tree[i] !== "string") {
            markStaticNode(tree[i], key + "_" + i, isOnce);
          }
        }
      } else {
        markStaticNode(tree, key, isOnce);
      }
    }
    function markStaticNode(node, key, isOnce) {
      node.isStatic = true;
      node.key = key;
      node.isOnce = isOnce;
    }
    function bindObjectListeners(data, value) {
      if (value) {
        if (!isPlainObject(value)) ; else {
          var on = data.on = data.on ? extend({}, data.on) : {};
          for (var key in value) {
            var existing = on[key];
            var ours = value[key];
            on[key] = existing ? [].concat(existing, ours) : ours;
          }
        }
      }
      return data;
    }
    function resolveScopedSlots(fns, res, hasDynamicKeys, contentHashKey) {
      res = res || {
        $stable: !hasDynamicKeys
      };
      for (var i = 0; i < fns.length; i++) {
        var slot = fns[i];
        if (Array.isArray(slot)) {
          resolveScopedSlots(slot, res, hasDynamicKeys);
        } else if (slot) {
          if (slot.proxy) {
            slot.fn.proxy = true;
          }
          res[slot.key] = slot.fn;
        }
      }
      if (contentHashKey) {
        res.$key = contentHashKey;
      }
      return res;
    }
    function bindDynamicKeys(baseObj, values) {
      for (var i = 0; i < values.length; i += 2) {
        var key = values[i];
        if (typeof key === "string" && key) {
          baseObj[values[i]] = values[i + 1];
        }
      }
      return baseObj;
    }
    function prependModifier(value, symbol) {
      return typeof value === "string" ? symbol + value : value;
    }
    function installRenderHelpers(target2) {
      target2._o = markOnce;
      target2._n = toNumber;
      target2._s = vue_runtime_esm_toString;
      target2._l = renderList;
      target2._t = renderSlot;
      target2._q = looseEqual;
      target2._i = looseIndexOf;
      target2._m = renderStatic;
      target2._f = resolveFilter;
      target2._k = checkKeyCodes;
      target2._b = bindObjectProps;
      target2._v = createTextVNode;
      target2._e = createEmptyVNode;
      target2._u = resolveScopedSlots;
      target2._g = bindObjectListeners;
      target2._d = bindDynamicKeys;
      target2._p = prependModifier;
    }
    function FunctionalRenderContext(data, props2, children, parent, Ctor) {
      var this$1$1 = this;
      var options = Ctor.options;
      var contextVm;
      if (hasOwn(parent, "_uid")) {
        contextVm = Object.create(parent);
        contextVm._original = parent;
      } else {
        contextVm = parent;
        parent = parent._original;
      }
      var isCompiled = isTrue(options._compiled);
      var needNormalization = !isCompiled;
      this.data = data;
      this.props = props2;
      this.children = children;
      this.parent = parent;
      this.listeners = data.on || emptyObject;
      this.injections = resolveInject(options.inject, parent);
      this.slots = function() {
        if (!this$1$1.$slots) {
          normalizeScopedSlots(data.scopedSlots, this$1$1.$slots = resolveSlots(children, parent));
        }
        return this$1$1.$slots;
      };
      Object.defineProperty(this, "scopedSlots", {
        enumerable: true,
        get: function get() {
          return normalizeScopedSlots(data.scopedSlots, this.slots());
        }
      });
      if (isCompiled) {
        this.$options = options;
        this.$slots = this.slots();
        this.$scopedSlots = normalizeScopedSlots(data.scopedSlots, this.$slots);
      }
      if (options._scopeId) {
        this._c = function(a, b, c, d) {
          var vnode = createElement(contextVm, a, b, c, d, needNormalization);
          if (vnode && !Array.isArray(vnode)) {
            vnode.fnScopeId = options._scopeId;
            vnode.fnContext = parent;
          }
          return vnode;
        };
      } else {
        this._c = function(a, b, c, d) {
          return createElement(contextVm, a, b, c, d, needNormalization);
        };
      }
    }
    installRenderHelpers(FunctionalRenderContext.prototype);
    function createFunctionalComponent(Ctor, propsData, data, contextVm, children) {
      var options = Ctor.options;
      var props2 = {};
      var propOptions = options.props;
      if (isDef(propOptions)) {
        for (var key in propOptions) {
          props2[key] = validateProp(key, propOptions, propsData || emptyObject);
        }
      } else {
        if (isDef(data.attrs)) {
          mergeProps(props2, data.attrs);
        }
        if (isDef(data.props)) {
          mergeProps(props2, data.props);
        }
      }
      var renderContext = new FunctionalRenderContext(data, props2, children, contextVm, Ctor);
      var vnode = options.render.call(null, renderContext._c, renderContext);
      if (vnode instanceof VNode) {
        return cloneAndMarkFunctionalResult(vnode, data, renderContext.parent, options);
      } else if (Array.isArray(vnode)) {
        var vnodes = normalizeChildren(vnode) || [];
        var res = new Array(vnodes.length);
        for (var i = 0; i < vnodes.length; i++) {
          res[i] = cloneAndMarkFunctionalResult(vnodes[i], data, renderContext.parent, options);
        }
        return res;
      }
    }
    function cloneAndMarkFunctionalResult(vnode, data, contextVm, options, renderContext) {
      var clone = cloneVNode(vnode);
      clone.fnContext = contextVm;
      clone.fnOptions = options;
      if (data.slot) {
        (clone.data || (clone.data = {})).slot = data.slot;
      }
      return clone;
    }
    function mergeProps(to, from) {
      for (var key in from) {
        to[camelize(key)] = from[key];
      }
    }
    var componentVNodeHooks = {
      init: function init(vnode, hydrating) {
        if (vnode.componentInstance && !vnode.componentInstance._isDestroyed && vnode.data.keepAlive) {
          var mountedNode = vnode;
          componentVNodeHooks.prepatch(mountedNode, mountedNode);
        } else {
          var child = vnode.componentInstance = createComponentInstanceForVnode(vnode, activeInstance);
          child.$mount(hydrating ? vnode.elm : void 0, hydrating);
        }
      },
      prepatch: function prepatch(oldVnode, vnode) {
        var options = vnode.componentOptions;
        var child = vnode.componentInstance = oldVnode.componentInstance;
        updateChildComponent(child, options.propsData, options.listeners, vnode, options.children);
      },
      insert: function insert(vnode) {
        var context = vnode.context;
        var componentInstance = vnode.componentInstance;
        if (!componentInstance._isMounted) {
          componentInstance._isMounted = true;
          callHook(componentInstance, "mounted");
        }
        if (vnode.data.keepAlive) {
          if (context._isMounted) {
            queueActivatedComponent(componentInstance);
          } else {
            activateChildComponent(componentInstance, true);
          }
        }
      },
      destroy: function destroy(vnode) {
        var componentInstance = vnode.componentInstance;
        if (!componentInstance._isDestroyed) {
          if (!vnode.data.keepAlive) {
            componentInstance.$destroy();
          } else {
            deactivateChildComponent(componentInstance, true);
          }
        }
      }
    };
    var hooksToMerge = Object.keys(componentVNodeHooks);
    function createComponent(Ctor, data, context, children, tag) {
      if (isUndef(Ctor)) {
        return;
      }
      var baseCtor = context.$options._base;
      if (isObject(Ctor)) {
        Ctor = baseCtor.extend(Ctor);
      }
      if (typeof Ctor !== "function") {
        return;
      }
      var asyncFactory;
      if (isUndef(Ctor.cid)) {
        asyncFactory = Ctor;
        Ctor = resolveAsyncComponent(asyncFactory, baseCtor);
        if (Ctor === void 0) {
          return createAsyncPlaceholder(asyncFactory, data, context, children, tag);
        }
      }
      data = data || {};
      resolveConstructorOptions(Ctor);
      if (isDef(data.model)) {
        transformModel(Ctor.options, data);
      }
      var propsData = extractPropsFromVNodeData(data, Ctor);
      if (isTrue(Ctor.options.functional)) {
        return createFunctionalComponent(Ctor, propsData, data, context, children);
      }
      var listeners = data.on;
      data.on = data.nativeOn;
      if (isTrue(Ctor.options.abstract)) {
        var slot = data.slot;
        data = {};
        if (slot) {
          data.slot = slot;
        }
      }
      installComponentHooks(data);
      var name = Ctor.options.name || tag;
      var vnode = new VNode("vue-component-" + Ctor.cid + (name ? "-" + name : ""), data, void 0, void 0, void 0, context, {
        Ctor,
        propsData,
        listeners,
        tag,
        children
      }, asyncFactory);
      return vnode;
    }
    function createComponentInstanceForVnode(vnode, parent) {
      var options = {
        _isComponent: true,
        _parentVnode: vnode,
        parent
      };
      var inlineTemplate = vnode.data.inlineTemplate;
      if (isDef(inlineTemplate)) {
        options.render = inlineTemplate.render;
        options.staticRenderFns = inlineTemplate.staticRenderFns;
      }
      return new vnode.componentOptions.Ctor(options);
    }
    function installComponentHooks(data) {
      var hooks2 = data.hook || (data.hook = {});
      for (var i = 0; i < hooksToMerge.length; i++) {
        var key = hooksToMerge[i];
        var existing = hooks2[key];
        var toMerge = componentVNodeHooks[key];
        if (existing !== toMerge && !(existing && existing._merged)) {
          hooks2[key] = existing ? mergeHook$1(toMerge, existing) : toMerge;
        }
      }
    }
    function mergeHook$1(f1, f2) {
      var merged = function(a, b) {
        f1(a, b);
        f2(a, b);
      };
      merged._merged = true;
      return merged;
    }
    function transformModel(options, data) {
      var prop = options.model && options.model.prop || "value";
      var event = options.model && options.model.event || "input";
      (data.attrs || (data.attrs = {}))[prop] = data.model.value;
      var on = data.on || (data.on = {});
      var existing = on[event];
      var callback = data.model.callback;
      if (isDef(existing)) {
        if (Array.isArray(existing) ? existing.indexOf(callback) === -1 : existing !== callback) {
          on[event] = [callback].concat(existing);
        }
      } else {
        on[event] = callback;
      }
    }
    var SIMPLE_NORMALIZE = 1;
    var ALWAYS_NORMALIZE = 2;
    function createElement(context, tag, data, children, normalizationType, alwaysNormalize) {
      if (Array.isArray(data) || isPrimitive(data)) {
        normalizationType = children;
        children = data;
        data = void 0;
      }
      if (isTrue(alwaysNormalize)) {
        normalizationType = ALWAYS_NORMALIZE;
      }
      return _createElement(context, tag, data, children, normalizationType);
    }
    function _createElement(context, tag, data, children, normalizationType) {
      if (isDef(data) && isDef(data.__ob__)) {
        return createEmptyVNode();
      }
      if (isDef(data) && isDef(data.is)) {
        tag = data.is;
      }
      if (!tag) {
        return createEmptyVNode();
      }
      if (Array.isArray(children) && typeof children[0] === "function") {
        data = data || {};
        data.scopedSlots = {
          default: children[0]
        };
        children.length = 0;
      }
      if (normalizationType === ALWAYS_NORMALIZE) {
        children = normalizeChildren(children);
      } else if (normalizationType === SIMPLE_NORMALIZE) {
        children = simpleNormalizeChildren(children);
      }
      var vnode, ns;
      if (typeof tag === "string") {
        var Ctor;
        ns = context.$vnode && context.$vnode.ns || config.getTagNamespace(tag);
        if (config.isReservedTag(tag)) {
          vnode = new VNode(config.parsePlatformTagName(tag), data, children, void 0, void 0, context);
        } else if ((!data || !data.pre) && isDef(Ctor = resolveAsset(context.$options, "components", tag))) {
          vnode = createComponent(Ctor, data, context, children, tag);
        } else {
          vnode = new VNode(tag, data, children, void 0, void 0, context);
        }
      } else {
        vnode = createComponent(tag, data, context, children);
      }
      if (Array.isArray(vnode)) {
        return vnode;
      } else if (isDef(vnode)) {
        if (isDef(ns)) {
          applyNS(vnode, ns);
        }
        if (isDef(data)) {
          registerDeepBindings(data);
        }
        return vnode;
      } else {
        return createEmptyVNode();
      }
    }
    function applyNS(vnode, ns, force) {
      vnode.ns = ns;
      if (vnode.tag === "foreignObject") {
        ns = void 0;
        force = true;
      }
      if (isDef(vnode.children)) {
        for (var i = 0, l = vnode.children.length; i < l; i++) {
          var child = vnode.children[i];
          if (isDef(child.tag) && (isUndef(child.ns) || isTrue(force) && child.tag !== "svg")) {
            applyNS(child, ns, force);
          }
        }
      }
    }
    function registerDeepBindings(data) {
      if (isObject(data.style)) {
        traverse(data.style);
      }
      if (isObject(data.class)) {
        traverse(data.class);
      }
    }
    function initRender(vm) {
      vm._vnode = null;
      vm._staticTrees = null;
      var options = vm.$options;
      var parentVnode = vm.$vnode = options._parentVnode;
      var renderContext = parentVnode && parentVnode.context;
      vm.$slots = resolveSlots(options._renderChildren, renderContext);
      vm.$scopedSlots = emptyObject;
      vm._c = function(a, b, c, d) {
        return createElement(vm, a, b, c, d, false);
      };
      vm.$createElement = function(a, b, c, d) {
        return createElement(vm, a, b, c, d, true);
      };
      var parentData = parentVnode && parentVnode.data;
      {
        defineReactive$$1(vm, "$attrs", parentData && parentData.attrs || emptyObject, null, true);
        defineReactive$$1(vm, "$listeners", options._parentListeners || emptyObject, null, true);
      }
    }
    var currentRenderingInstance = null;
    function renderMixin(Vue3) {
      installRenderHelpers(Vue3.prototype);
      Vue3.prototype.$nextTick = function(fn) {
        return nextTick(fn, this);
      };
      Vue3.prototype._render = function() {
        var vm = this;
        var ref2 = vm.$options;
        var render = ref2.render;
        var _parentVnode = ref2._parentVnode;
        if (_parentVnode) {
          vm.$scopedSlots = normalizeScopedSlots(_parentVnode.data.scopedSlots, vm.$slots, vm.$scopedSlots);
        }
        vm.$vnode = _parentVnode;
        var vnode;
        try {
          currentRenderingInstance = vm;
          vnode = render.call(vm._renderProxy, vm.$createElement);
        } catch (e) {
          handleError(e, vm, "render");
          {
            vnode = vm._vnode;
          }
        } finally {
          currentRenderingInstance = null;
        }
        if (Array.isArray(vnode) && vnode.length === 1) {
          vnode = vnode[0];
        }
        if (!(vnode instanceof VNode)) {
          vnode = createEmptyVNode();
        }
        vnode.parent = _parentVnode;
        return vnode;
      };
    }
    function ensureCtor(comp, base) {
      if (comp.__esModule || hasSymbol && comp[Symbol.toStringTag] === "Module") {
        comp = comp.default;
      }
      return isObject(comp) ? base.extend(comp) : comp;
    }
    function createAsyncPlaceholder(factory, data, context, children, tag) {
      var node = createEmptyVNode();
      node.asyncFactory = factory;
      node.asyncMeta = {
        data,
        context,
        children,
        tag
      };
      return node;
    }
    function resolveAsyncComponent(factory, baseCtor) {
      if (isTrue(factory.error) && isDef(factory.errorComp)) {
        return factory.errorComp;
      }
      if (isDef(factory.resolved)) {
        return factory.resolved;
      }
      var owner = currentRenderingInstance;
      if (owner && isDef(factory.owners) && factory.owners.indexOf(owner) === -1) {
        factory.owners.push(owner);
      }
      if (isTrue(factory.loading) && isDef(factory.loadingComp)) {
        return factory.loadingComp;
      }
      if (owner && !isDef(factory.owners)) {
        var owners = factory.owners = [owner];
        var sync = true;
        var timerLoading = null;
        var timerTimeout = null;
        owner.$on("hook:destroyed", function() {
          return remove(owners, owner);
        });
        var forceRender = function(renderCompleted) {
          for (var i = 0, l = owners.length; i < l; i++) {
            owners[i].$forceUpdate();
          }
          if (renderCompleted) {
            owners.length = 0;
            if (timerLoading !== null) {
              clearTimeout(timerLoading);
              timerLoading = null;
            }
            if (timerTimeout !== null) {
              clearTimeout(timerTimeout);
              timerTimeout = null;
            }
          }
        };
        var resolve = once(function(res2) {
          factory.resolved = ensureCtor(res2, baseCtor);
          if (!sync) {
            forceRender(true);
          } else {
            owners.length = 0;
          }
        });
        var reject = once(function(reason) {
          if (isDef(factory.errorComp)) {
            factory.error = true;
            forceRender(true);
          }
        });
        var res = factory(resolve, reject);
        if (isObject(res)) {
          if (isPromise(res)) {
            if (isUndef(factory.resolved)) {
              res.then(resolve, reject);
            }
          } else if (isPromise(res.component)) {
            res.component.then(resolve, reject);
            if (isDef(res.error)) {
              factory.errorComp = ensureCtor(res.error, baseCtor);
            }
            if (isDef(res.loading)) {
              factory.loadingComp = ensureCtor(res.loading, baseCtor);
              if (res.delay === 0) {
                factory.loading = true;
              } else {
                timerLoading = setTimeout(function() {
                  timerLoading = null;
                  if (isUndef(factory.resolved) && isUndef(factory.error)) {
                    factory.loading = true;
                    forceRender(false);
                  }
                }, res.delay || 200);
              }
            }
            if (isDef(res.timeout)) {
              timerTimeout = setTimeout(function() {
                timerTimeout = null;
                if (isUndef(factory.resolved)) {
                  reject(null);
                }
              }, res.timeout);
            }
          }
        }
        sync = false;
        return factory.loading ? factory.loadingComp : factory.resolved;
      }
    }
    function getFirstComponentChild(children) {
      if (Array.isArray(children)) {
        for (var i = 0; i < children.length; i++) {
          var c = children[i];
          if (isDef(c) && (isDef(c.componentOptions) || isAsyncPlaceholder(c))) {
            return c;
          }
        }
      }
    }
    function initEvents(vm) {
      vm._events = Object.create(null);
      vm._hasHookEvent = false;
      var listeners = vm.$options._parentListeners;
      if (listeners) {
        updateComponentListeners(vm, listeners);
      }
    }
    var target;
    function add(event, fn) {
      target.$on(event, fn);
    }
    function remove$1(event, fn) {
      target.$off(event, fn);
    }
    function createOnceHandler(event, fn) {
      var _target = target;
      return function onceHandler() {
        var res = fn.apply(null, arguments);
        if (res !== null) {
          _target.$off(event, onceHandler);
        }
      };
    }
    function updateComponentListeners(vm, listeners, oldListeners) {
      target = vm;
      updateListeners(listeners, oldListeners || {}, add, remove$1, createOnceHandler, vm);
      target = void 0;
    }
    function eventsMixin(Vue3) {
      var hookRE = /^hook:/;
      Vue3.prototype.$on = function(event, fn) {
        var vm = this;
        if (Array.isArray(event)) {
          for (var i = 0, l = event.length; i < l; i++) {
            vm.$on(event[i], fn);
          }
        } else {
          (vm._events[event] || (vm._events[event] = [])).push(fn);
          if (hookRE.test(event)) {
            vm._hasHookEvent = true;
          }
        }
        return vm;
      };
      Vue3.prototype.$once = function(event, fn) {
        var vm = this;
        function on() {
          vm.$off(event, on);
          fn.apply(vm, arguments);
        }
        on.fn = fn;
        vm.$on(event, on);
        return vm;
      };
      Vue3.prototype.$off = function(event, fn) {
        var vm = this;
        if (!arguments.length) {
          vm._events = Object.create(null);
          return vm;
        }
        if (Array.isArray(event)) {
          for (var i$1 = 0, l = event.length; i$1 < l; i$1++) {
            vm.$off(event[i$1], fn);
          }
          return vm;
        }
        var cbs = vm._events[event];
        if (!cbs) {
          return vm;
        }
        if (!fn) {
          vm._events[event] = null;
          return vm;
        }
        var cb;
        var i = cbs.length;
        while (i--) {
          cb = cbs[i];
          if (cb === fn || cb.fn === fn) {
            cbs.splice(i, 1);
            break;
          }
        }
        return vm;
      };
      Vue3.prototype.$emit = function(event) {
        var vm = this;
        var cbs = vm._events[event];
        if (cbs) {
          cbs = cbs.length > 1 ? toArray(cbs) : cbs;
          var args = toArray(arguments, 1);
          var info = 'event handler for "' + event + '"';
          for (var i = 0, l = cbs.length; i < l; i++) {
            invokeWithErrorHandling(cbs[i], vm, args, vm, info);
          }
        }
        return vm;
      };
    }
    var activeInstance = null;
    function setActiveInstance(vm) {
      var prevActiveInstance = activeInstance;
      activeInstance = vm;
      return function() {
        activeInstance = prevActiveInstance;
      };
    }
    function initLifecycle(vm) {
      var options = vm.$options;
      var parent = options.parent;
      if (parent && !options.abstract) {
        while (parent.$options.abstract && parent.$parent) {
          parent = parent.$parent;
        }
        parent.$children.push(vm);
      }
      vm.$parent = parent;
      vm.$root = parent ? parent.$root : vm;
      vm.$children = [];
      vm.$refs = {};
      vm._watcher = null;
      vm._inactive = null;
      vm._directInactive = false;
      vm._isMounted = false;
      vm._isDestroyed = false;
      vm._isBeingDestroyed = false;
    }
    function lifecycleMixin(Vue3) {
      Vue3.prototype._update = function(vnode, hydrating) {
        var vm = this;
        var prevEl = vm.$el;
        var prevVnode = vm._vnode;
        var restoreActiveInstance = setActiveInstance(vm);
        vm._vnode = vnode;
        if (!prevVnode) {
          vm.$el = vm.__patch__(vm.$el, vnode, hydrating, false);
        } else {
          vm.$el = vm.__patch__(prevVnode, vnode);
        }
        restoreActiveInstance();
        if (prevEl) {
          prevEl.__vue__ = null;
        }
        if (vm.$el) {
          vm.$el.__vue__ = vm;
        }
        if (vm.$vnode && vm.$parent && vm.$vnode === vm.$parent._vnode) {
          vm.$parent.$el = vm.$el;
        }
      };
      Vue3.prototype.$forceUpdate = function() {
        var vm = this;
        if (vm._watcher) {
          vm._watcher.update();
        }
      };
      Vue3.prototype.$destroy = function() {
        var vm = this;
        if (vm._isBeingDestroyed) {
          return;
        }
        callHook(vm, "beforeDestroy");
        vm._isBeingDestroyed = true;
        var parent = vm.$parent;
        if (parent && !parent._isBeingDestroyed && !vm.$options.abstract) {
          remove(parent.$children, vm);
        }
        if (vm._watcher) {
          vm._watcher.teardown();
        }
        var i = vm._watchers.length;
        while (i--) {
          vm._watchers[i].teardown();
        }
        if (vm._data.__ob__) {
          vm._data.__ob__.vmCount--;
        }
        vm._isDestroyed = true;
        vm.__patch__(vm._vnode, null);
        callHook(vm, "destroyed");
        vm.$off();
        if (vm.$el) {
          vm.$el.__vue__ = null;
        }
        if (vm.$vnode) {
          vm.$vnode.parent = null;
        }
      };
    }
    function mountComponent(vm, el, hydrating) {
      vm.$el = el;
      if (!vm.$options.render) {
        vm.$options.render = createEmptyVNode;
      }
      callHook(vm, "beforeMount");
      var updateComponent;
      {
        updateComponent = function() {
          vm._update(vm._render(), hydrating);
        };
      }
      new Watcher(vm, updateComponent, noop, {
        before: function before() {
          if (vm._isMounted && !vm._isDestroyed) {
            callHook(vm, "beforeUpdate");
          }
        }
      }, true);
      hydrating = false;
      if (vm.$vnode == null) {
        vm._isMounted = true;
        callHook(vm, "mounted");
      }
      return vm;
    }
    function updateChildComponent(vm, propsData, listeners, parentVnode, renderChildren) {
      var newScopedSlots = parentVnode.data.scopedSlots;
      var oldScopedSlots = vm.$scopedSlots;
      var hasDynamicScopedSlot = !!(newScopedSlots && !newScopedSlots.$stable || oldScopedSlots !== emptyObject && !oldScopedSlots.$stable || newScopedSlots && vm.$scopedSlots.$key !== newScopedSlots.$key || !newScopedSlots && vm.$scopedSlots.$key);
      var needsForceUpdate = !!(renderChildren || vm.$options._renderChildren || hasDynamicScopedSlot);
      vm.$options._parentVnode = parentVnode;
      vm.$vnode = parentVnode;
      if (vm._vnode) {
        vm._vnode.parent = parentVnode;
      }
      vm.$options._renderChildren = renderChildren;
      vm.$attrs = parentVnode.data.attrs || emptyObject;
      vm.$listeners = listeners || emptyObject;
      if (propsData && vm.$options.props) {
        toggleObserving(false);
        var props2 = vm._props;
        var propKeys = vm.$options._propKeys || [];
        for (var i = 0; i < propKeys.length; i++) {
          var key = propKeys[i];
          var propOptions = vm.$options.props;
          props2[key] = validateProp(key, propOptions, propsData, vm);
        }
        toggleObserving(true);
        vm.$options.propsData = propsData;
      }
      listeners = listeners || emptyObject;
      var oldListeners = vm.$options._parentListeners;
      vm.$options._parentListeners = listeners;
      updateComponentListeners(vm, listeners, oldListeners);
      if (needsForceUpdate) {
        vm.$slots = resolveSlots(renderChildren, parentVnode.context);
        vm.$forceUpdate();
      }
    }
    function isInInactiveTree(vm) {
      while (vm && (vm = vm.$parent)) {
        if (vm._inactive) {
          return true;
        }
      }
      return false;
    }
    function activateChildComponent(vm, direct) {
      if (direct) {
        vm._directInactive = false;
        if (isInInactiveTree(vm)) {
          return;
        }
      } else if (vm._directInactive) {
        return;
      }
      if (vm._inactive || vm._inactive === null) {
        vm._inactive = false;
        for (var i = 0; i < vm.$children.length; i++) {
          activateChildComponent(vm.$children[i]);
        }
        callHook(vm, "activated");
      }
    }
    function deactivateChildComponent(vm, direct) {
      if (direct) {
        vm._directInactive = true;
        if (isInInactiveTree(vm)) {
          return;
        }
      }
      if (!vm._inactive) {
        vm._inactive = true;
        for (var i = 0; i < vm.$children.length; i++) {
          deactivateChildComponent(vm.$children[i]);
        }
        callHook(vm, "deactivated");
      }
    }
    function callHook(vm, hook) {
      pushTarget();
      var handlers = vm.$options[hook];
      var info = hook + " hook";
      if (handlers) {
        for (var i = 0, j = handlers.length; i < j; i++) {
          invokeWithErrorHandling(handlers[i], vm, null, vm, info);
        }
      }
      if (vm._hasHookEvent) {
        vm.$emit("hook:" + hook);
      }
      popTarget();
    }
    var queue = [];
    var activatedChildren = [];
    var has = {};
    var waiting = false;
    var flushing = false;
    var index = 0;
    function resetSchedulerState() {
      index = queue.length = activatedChildren.length = 0;
      has = {};
      waiting = flushing = false;
    }
    var currentFlushTimestamp = 0;
    var getNow = Date.now;
    function flushSchedulerQueue() {
      currentFlushTimestamp = getNow();
      flushing = true;
      var watcher, id;
      queue.sort(function(a, b) {
        return a.id - b.id;
      });
      for (index = 0; index < queue.length; index++) {
        watcher = queue[index];
        if (watcher.before) {
          watcher.before();
        }
        id = watcher.id;
        has[id] = null;
        watcher.run();
      }
      var activatedQueue = activatedChildren.slice();
      var updatedQueue = queue.slice();
      resetSchedulerState();
      callActivatedHooks(activatedQueue);
      callUpdatedHooks(updatedQueue);
    }
    function callUpdatedHooks(queue2) {
      var i = queue2.length;
      while (i--) {
        var watcher = queue2[i];
        var vm = watcher.vm;
        if (vm._watcher === watcher && vm._isMounted && !vm._isDestroyed) {
          callHook(vm, "updated");
        }
      }
    }
    function queueActivatedComponent(vm) {
      vm._inactive = false;
      activatedChildren.push(vm);
    }
    function callActivatedHooks(queue2) {
      for (var i = 0; i < queue2.length; i++) {
        queue2[i]._inactive = true;
        activateChildComponent(queue2[i], true);
      }
    }
    function queueWatcher(watcher) {
      var id = watcher.id;
      if (has[id] == null) {
        has[id] = true;
        if (!flushing) {
          queue.push(watcher);
        } else {
          var i = queue.length - 1;
          while (i > index && queue[i].id > watcher.id) {
            i--;
          }
          queue.splice(i + 1, 0, watcher);
        }
        if (!waiting) {
          waiting = true;
          nextTick(flushSchedulerQueue);
        }
      }
    }
    var uid$2 = 0;
    var Watcher = function Watcher2(vm, expOrFn, cb, options, isRenderWatcher) {
      this.vm = vm;
      if (isRenderWatcher) {
        vm._watcher = this;
      }
      vm._watchers.push(this);
      if (options) {
        this.deep = !!options.deep;
        this.user = !!options.user;
        this.lazy = !!options.lazy;
        this.sync = !!options.sync;
        this.before = options.before;
      } else {
        this.deep = this.user = this.lazy = this.sync = false;
      }
      this.cb = cb;
      this.id = ++uid$2;
      this.active = true;
      this.dirty = this.lazy;
      this.deps = [];
      this.newDeps = [];
      this.depIds = new _Set();
      this.newDepIds = new _Set();
      this.expression = "";
      if (typeof expOrFn === "function") {
        this.getter = expOrFn;
      } else {
        this.getter = parsePath(expOrFn);
        if (!this.getter) {
          this.getter = noop;
        }
      }
      this.value = this.lazy ? void 0 : this.get();
    };
    Watcher.prototype.get = function get() {
      pushTarget(this);
      var value;
      var vm = this.vm;
      try {
        value = this.getter.call(vm, vm);
      } catch (e) {
        if (this.user) {
          handleError(e, vm, 'getter for watcher "' + this.expression + '"');
        } else {
          throw e;
        }
      } finally {
        if (this.deep) {
          traverse(value);
        }
        popTarget();
        this.cleanupDeps();
      }
      return value;
    };
    Watcher.prototype.addDep = function addDep(dep) {
      var id = dep.id;
      if (!this.newDepIds.has(id)) {
        this.newDepIds.add(id);
        this.newDeps.push(dep);
        if (!this.depIds.has(id)) {
          dep.addSub(this);
        }
      }
    };
    Watcher.prototype.cleanupDeps = function cleanupDeps() {
      var i = this.deps.length;
      while (i--) {
        var dep = this.deps[i];
        if (!this.newDepIds.has(dep.id)) {
          dep.removeSub(this);
        }
      }
      var tmp = this.depIds;
      this.depIds = this.newDepIds;
      this.newDepIds = tmp;
      this.newDepIds.clear();
      tmp = this.deps;
      this.deps = this.newDeps;
      this.newDeps = tmp;
      this.newDeps.length = 0;
    };
    Watcher.prototype.update = function update() {
      if (this.lazy) {
        this.dirty = true;
      } else if (this.sync) {
        this.run();
      } else {
        queueWatcher(this);
      }
    };
    Watcher.prototype.run = function run() {
      if (this.active) {
        var value = this.get();
        if (value !== this.value || isObject(value) || this.deep) {
          var oldValue = this.value;
          this.value = value;
          if (this.user) {
            var info = 'callback for watcher "' + this.expression + '"';
            invokeWithErrorHandling(this.cb, this.vm, [value, oldValue], this.vm, info);
          } else {
            this.cb.call(this.vm, value, oldValue);
          }
        }
      }
    };
    Watcher.prototype.evaluate = function evaluate() {
      this.value = this.get();
      this.dirty = false;
    };
    Watcher.prototype.depend = function depend() {
      var i = this.deps.length;
      while (i--) {
        this.deps[i].depend();
      }
    };
    Watcher.prototype.teardown = function teardown() {
      if (this.active) {
        if (!this.vm._isBeingDestroyed) {
          remove(this.vm._watchers, this);
        }
        var i = this.deps.length;
        while (i--) {
          this.deps[i].removeSub(this);
        }
        this.active = false;
      }
    };
    var sharedPropertyDefinition = {
      enumerable: true,
      configurable: true,
      get: noop,
      set: noop
    };
    function proxy(target2, sourceKey, key) {
      sharedPropertyDefinition.get = function proxyGetter() {
        return this[sourceKey][key];
      };
      sharedPropertyDefinition.set = function proxySetter(val) {
        this[sourceKey][key] = val;
      };
      Object.defineProperty(target2, key, sharedPropertyDefinition);
    }
    function initState(vm) {
      vm._watchers = [];
      var opts2 = vm.$options;
      if (opts2.props) {
        initProps(vm, opts2.props);
      }
      if (opts2.methods) {
        initMethods(vm, opts2.methods);
      }
      if (opts2.data) {
        initData(vm);
      } else {
        observe(vm._data = {}, true);
      }
      if (opts2.computed) {
        initComputed(vm, opts2.computed);
      }
      if (opts2.watch && opts2.watch !== nativeWatch) {
        initWatch(vm, opts2.watch);
      }
    }
    function initProps(vm, propsOptions) {
      var propsData = vm.$options.propsData || {};
      var props2 = vm._props = {};
      var keys = vm.$options._propKeys = [];
      var isRoot = !vm.$parent;
      if (!isRoot) {
        toggleObserving(false);
      }
      var loop = function(key2) {
        keys.push(key2);
        var value = validateProp(key2, propsOptions, propsData, vm);
        {
          defineReactive$$1(props2, key2, value);
        }
        if (!(key2 in vm)) {
          proxy(vm, "_props", key2);
        }
      };
      for (var key in propsOptions)
        loop(key);
      toggleObserving(true);
    }
    function initData(vm) {
      var data = vm.$options.data;
      data = vm._data = typeof data === "function" ? getData(data, vm) : data || {};
      if (!isPlainObject(data)) {
        data = {};
      }
      var keys = Object.keys(data);
      var props2 = vm.$options.props;
      vm.$options.methods;
      var i = keys.length;
      while (i--) {
        var key = keys[i];
        if (props2 && hasOwn(props2, key)) ; else if (!isReserved(key)) {
          proxy(vm, "_data", key);
        }
      }
      observe(data, true);
    }
    function getData(data, vm) {
      pushTarget();
      try {
        return data.call(vm, vm);
      } catch (e) {
        handleError(e, vm, "data()");
        return {};
      } finally {
        popTarget();
      }
    }
    var computedWatcherOptions = {
      lazy: true
    };
    function initComputed(vm, computed) {
      var watchers = vm._computedWatchers = Object.create(null);
      var isSSR = isServerRendering();
      for (var key in computed) {
        var userDef = computed[key];
        var getter = typeof userDef === "function" ? userDef : userDef.get;
        if (!isSSR) {
          watchers[key] = new Watcher(vm, getter || noop, noop, computedWatcherOptions);
        }
        if (!(key in vm)) {
          defineComputed(vm, key, userDef);
        }
      }
    }
    function defineComputed(target2, key, userDef) {
      var shouldCache = !isServerRendering();
      if (typeof userDef === "function") {
        sharedPropertyDefinition.get = shouldCache ? createComputedGetter(key) : createGetterInvoker(userDef);
        sharedPropertyDefinition.set = noop;
      } else {
        sharedPropertyDefinition.get = userDef.get ? shouldCache && userDef.cache !== false ? createComputedGetter(key) : createGetterInvoker(userDef.get) : noop;
        sharedPropertyDefinition.set = userDef.set || noop;
      }
      Object.defineProperty(target2, key, sharedPropertyDefinition);
    }
    function createComputedGetter(key) {
      return function computedGetter() {
        var watcher = this._computedWatchers && this._computedWatchers[key];
        if (watcher) {
          if (watcher.dirty) {
            watcher.evaluate();
          }
          if (Dep.target) {
            watcher.depend();
          }
          return watcher.value;
        }
      };
    }
    function createGetterInvoker(fn) {
      return function computedGetter() {
        return fn.call(this, this);
      };
    }
    function initMethods(vm, methods) {
      vm.$options.props;
      for (var key in methods) {
        vm[key] = typeof methods[key] !== "function" ? noop : bind(methods[key], vm);
      }
    }
    function initWatch(vm, watch) {
      for (var key in watch) {
        var handler = watch[key];
        if (Array.isArray(handler)) {
          for (var i = 0; i < handler.length; i++) {
            createWatcher(vm, key, handler[i]);
          }
        } else {
          createWatcher(vm, key, handler);
        }
      }
    }
    function createWatcher(vm, expOrFn, handler, options) {
      if (isPlainObject(handler)) {
        options = handler;
        handler = handler.handler;
      }
      if (typeof handler === "string") {
        handler = vm[handler];
      }
      return vm.$watch(expOrFn, handler, options);
    }
    function stateMixin(Vue3) {
      var dataDef = {};
      dataDef.get = function() {
        return this._data;
      };
      var propsDef = {};
      propsDef.get = function() {
        return this._props;
      };
      Object.defineProperty(Vue3.prototype, "$data", dataDef);
      Object.defineProperty(Vue3.prototype, "$props", propsDef);
      Vue3.prototype.$set = set;
      Vue3.prototype.$delete = del;
      Vue3.prototype.$watch = function(expOrFn, cb, options) {
        var vm = this;
        if (isPlainObject(cb)) {
          return createWatcher(vm, expOrFn, cb, options);
        }
        options = options || {};
        options.user = true;
        var watcher = new Watcher(vm, expOrFn, cb, options);
        if (options.immediate) {
          var info = 'callback for immediate watcher "' + watcher.expression + '"';
          pushTarget();
          invokeWithErrorHandling(cb, vm, [watcher.value], vm, info);
          popTarget();
        }
        return function unwatchFn() {
          watcher.teardown();
        };
      };
    }
    var uid$3 = 0;
    function initMixin(Vue3) {
      Vue3.prototype._init = function(options) {
        var vm = this;
        vm._uid = uid$3++;
        vm._isVue = true;
        if (options && options._isComponent) {
          initInternalComponent(vm, options);
        } else {
          vm.$options = mergeOptions(resolveConstructorOptions(vm.constructor), options || {}, vm);
        }
        {
          vm._renderProxy = vm;
        }
        vm._self = vm;
        initLifecycle(vm);
        initEvents(vm);
        initRender(vm);
        callHook(vm, "beforeCreate");
        initInjections(vm);
        initState(vm);
        initProvide(vm);
        callHook(vm, "created");
        if (vm.$options.el) {
          vm.$mount(vm.$options.el);
        }
      };
    }
    function initInternalComponent(vm, options) {
      var opts2 = vm.$options = Object.create(vm.constructor.options);
      var parentVnode = options._parentVnode;
      opts2.parent = options.parent;
      opts2._parentVnode = parentVnode;
      var vnodeComponentOptions = parentVnode.componentOptions;
      opts2.propsData = vnodeComponentOptions.propsData;
      opts2._parentListeners = vnodeComponentOptions.listeners;
      opts2._renderChildren = vnodeComponentOptions.children;
      opts2._componentTag = vnodeComponentOptions.tag;
      if (options.render) {
        opts2.render = options.render;
        opts2.staticRenderFns = options.staticRenderFns;
      }
    }
    function resolveConstructorOptions(Ctor) {
      var options = Ctor.options;
      if (Ctor.super) {
        var superOptions = resolveConstructorOptions(Ctor.super);
        var cachedSuperOptions = Ctor.superOptions;
        if (superOptions !== cachedSuperOptions) {
          Ctor.superOptions = superOptions;
          var modifiedOptions = resolveModifiedOptions(Ctor);
          if (modifiedOptions) {
            extend(Ctor.extendOptions, modifiedOptions);
          }
          options = Ctor.options = mergeOptions(superOptions, Ctor.extendOptions);
          if (options.name) {
            options.components[options.name] = Ctor;
          }
        }
      }
      return options;
    }
    function resolveModifiedOptions(Ctor) {
      var modified;
      var latest = Ctor.options;
      var sealed = Ctor.sealedOptions;
      for (var key in latest) {
        if (latest[key] !== sealed[key]) {
          if (!modified) {
            modified = {};
          }
          modified[key] = latest[key];
        }
      }
      return modified;
    }
    function Vue(options) {
      this._init(options);
    }
    initMixin(Vue);
    stateMixin(Vue);
    eventsMixin(Vue);
    lifecycleMixin(Vue);
    renderMixin(Vue);
    function initUse(Vue3) {
      Vue3.use = function(plugin) {
        var installedPlugins = this._installedPlugins || (this._installedPlugins = []);
        if (installedPlugins.indexOf(plugin) > -1) {
          return this;
        }
        var args = toArray(arguments, 1);
        args.unshift(this);
        if (typeof plugin.install === "function") {
          plugin.install.apply(plugin, args);
        } else if (typeof plugin === "function") {
          plugin.apply(null, args);
        }
        installedPlugins.push(plugin);
        return this;
      };
    }
    function initMixin$1(Vue3) {
      Vue3.mixin = function(mixin) {
        this.options = mergeOptions(this.options, mixin);
        return this;
      };
    }
    function initExtend(Vue3) {
      Vue3.cid = 0;
      var cid = 1;
      Vue3.extend = function(extendOptions) {
        extendOptions = extendOptions || {};
        var Super = this;
        var SuperId = Super.cid;
        var cachedCtors = extendOptions._Ctor || (extendOptions._Ctor = {});
        if (cachedCtors[SuperId]) {
          return cachedCtors[SuperId];
        }
        var name = extendOptions.name || Super.options.name;
        var Sub = function VueComponent(options) {
          this._init(options);
        };
        Sub.prototype = Object.create(Super.prototype);
        Sub.prototype.constructor = Sub;
        Sub.cid = cid++;
        Sub.options = mergeOptions(Super.options, extendOptions);
        Sub["super"] = Super;
        if (Sub.options.props) {
          initProps$1(Sub);
        }
        if (Sub.options.computed) {
          initComputed$1(Sub);
        }
        Sub.extend = Super.extend;
        Sub.mixin = Super.mixin;
        Sub.use = Super.use;
        ASSET_TYPES.forEach(function(type) {
          Sub[type] = Super[type];
        });
        if (name) {
          Sub.options.components[name] = Sub;
        }
        Sub.superOptions = Super.options;
        Sub.extendOptions = extendOptions;
        Sub.sealedOptions = extend({}, Sub.options);
        cachedCtors[SuperId] = Sub;
        return Sub;
      };
    }
    function initProps$1(Comp) {
      var props2 = Comp.options.props;
      for (var key in props2) {
        proxy(Comp.prototype, "_props", key);
      }
    }
    function initComputed$1(Comp) {
      var computed = Comp.options.computed;
      for (var key in computed) {
        defineComputed(Comp.prototype, key, computed[key]);
      }
    }
    function initAssetRegisters(Vue3) {
      ASSET_TYPES.forEach(function(type) {
        Vue3[type] = function(id, definition) {
          if (!definition) {
            return this.options[type + "s"][id];
          } else {
            if (type === "component" && isPlainObject(definition)) {
              definition.name = definition.name || id;
              definition = this.options._base.extend(definition);
            }
            if (type === "directive" && typeof definition === "function") {
              definition = {
                bind: definition,
                update: definition
              };
            }
            this.options[type + "s"][id] = definition;
            return definition;
          }
        };
      });
    }
    function getComponentName(opts2) {
      return opts2 && (opts2.Ctor.options.name || opts2.tag);
    }
    function matches(pattern, name) {
      if (Array.isArray(pattern)) {
        return pattern.indexOf(name) > -1;
      } else if (typeof pattern === "string") {
        return pattern.split(",").indexOf(name) > -1;
      } else if (isRegExp(pattern)) {
        return pattern.test(name);
      }
      return false;
    }
    function pruneCache(keepAliveInstance, filter) {
      var cache = keepAliveInstance.cache;
      var keys = keepAliveInstance.keys;
      var _vnode = keepAliveInstance._vnode;
      for (var key in cache) {
        var entry = cache[key];
        if (entry) {
          var name = entry.name;
          if (name && !filter(name)) {
            pruneCacheEntry(cache, key, keys, _vnode);
          }
        }
      }
    }
    function pruneCacheEntry(cache, key, keys, current) {
      var entry = cache[key];
      if (entry && (!current || entry.tag !== current.tag)) {
        entry.componentInstance.$destroy();
      }
      cache[key] = null;
      remove(keys, key);
    }
    var patternTypes = [String, RegExp, Array];
    var KeepAlive = {
      name: "keep-alive",
      abstract: true,
      props: {
        include: patternTypes,
        exclude: patternTypes,
        max: [String, Number]
      },
      methods: {
        cacheVNode: function cacheVNode() {
          var ref2 = this;
          var cache = ref2.cache;
          var keys = ref2.keys;
          var vnodeToCache = ref2.vnodeToCache;
          var keyToCache = ref2.keyToCache;
          if (vnodeToCache) {
            var tag = vnodeToCache.tag;
            var componentInstance = vnodeToCache.componentInstance;
            var componentOptions = vnodeToCache.componentOptions;
            cache[keyToCache] = {
              name: getComponentName(componentOptions),
              tag,
              componentInstance
            };
            keys.push(keyToCache);
            if (this.max && keys.length > parseInt(this.max)) {
              pruneCacheEntry(cache, keys[0], keys, this._vnode);
            }
            this.vnodeToCache = null;
          }
        }
      },
      created: function created() {
        this.cache = Object.create(null);
        this.keys = [];
      },
      destroyed: function destroyed() {
        for (var key in this.cache) {
          pruneCacheEntry(this.cache, key, this.keys);
        }
      },
      mounted: function mounted() {
        var this$1$1 = this;
        this.cacheVNode();
        this.$watch("include", function(val) {
          pruneCache(this$1$1, function(name) {
            return matches(val, name);
          });
        });
        this.$watch("exclude", function(val) {
          pruneCache(this$1$1, function(name) {
            return !matches(val, name);
          });
        });
      },
      updated: function updated() {
        this.cacheVNode();
      },
      render: function render() {
        var slot = this.$slots.default;
        var vnode = getFirstComponentChild(slot);
        var componentOptions = vnode && vnode.componentOptions;
        if (componentOptions) {
          var name = getComponentName(componentOptions);
          var ref2 = this;
          var include = ref2.include;
          var exclude = ref2.exclude;
          if (include && (!name || !matches(include, name)) || exclude && name && matches(exclude, name)) {
            return vnode;
          }
          var ref$1 = this;
          var cache = ref$1.cache;
          var keys = ref$1.keys;
          var key = vnode.key == null ? componentOptions.Ctor.cid + (componentOptions.tag ? "::" + componentOptions.tag : "") : vnode.key;
          if (cache[key]) {
            vnode.componentInstance = cache[key].componentInstance;
            remove(keys, key);
            keys.push(key);
          } else {
            this.vnodeToCache = vnode;
            this.keyToCache = key;
          }
          vnode.data.keepAlive = true;
        }
        return vnode || slot && slot[0];
      }
    };
    var builtInComponents = {
      KeepAlive
    };
    function initGlobalAPI(Vue3) {
      var configDef = {};
      configDef.get = function() {
        return config;
      };
      Object.defineProperty(Vue3, "config", configDef);
      Vue3.util = {
        warn,
        extend,
        mergeOptions,
        defineReactive: defineReactive$$1
      };
      Vue3.set = set;
      Vue3.delete = del;
      Vue3.nextTick = nextTick;
      Vue3.observable = function(obj) {
        observe(obj);
        return obj;
      };
      Vue3.options = Object.create(null);
      ASSET_TYPES.forEach(function(type) {
        Vue3.options[type + "s"] = Object.create(null);
      });
      Vue3.options._base = Vue3;
      extend(Vue3.options.components, builtInComponents);
      initUse(Vue3);
      initMixin$1(Vue3);
      initExtend(Vue3);
      initAssetRegisters(Vue3);
    }
    initGlobalAPI(Vue);
    Object.defineProperty(Vue.prototype, "$isServer", {
      get: isServerRendering
    });
    Object.defineProperty(Vue.prototype, "$ssrContext", {
      get: function get() {
        return this.$vnode && this.$vnode.ssrContext;
      }
    });
    Object.defineProperty(Vue, "FunctionalRenderContext", {
      value: FunctionalRenderContext
    });
    Vue.version = "2.6.14";
    var isReservedAttr = makeMap("style,class");
    var acceptValue = makeMap("input,textarea,option,select,progress");
    var mustUseProp = function(tag, type, attr) {
      return attr === "value" && acceptValue(tag) && type !== "button" || attr === "selected" && tag === "option" || attr === "checked" && tag === "input" || attr === "muted" && tag === "video";
    };
    var isEnumeratedAttr = makeMap("contenteditable,draggable,spellcheck");
    var isValidContentEditableValue = makeMap("events,caret,typing,plaintext-only");
    var convertEnumeratedValue = function(key, value) {
      return isFalsyAttrValue(value) || value === "false" ? "false" : key === "contenteditable" && isValidContentEditableValue(value) ? value : "true";
    };
    var isBooleanAttr = makeMap("allowfullscreen,async,autofocus,autoplay,checked,compact,controls,declare,default,defaultchecked,defaultmuted,defaultselected,defer,disabled,enabled,formnovalidate,hidden,indeterminate,inert,ismap,itemscope,loop,multiple,muted,nohref,noresize,noshade,novalidate,nowrap,open,pauseonexit,readonly,required,reversed,scoped,seamless,selected,sortable,truespeed,typemustmatch,visible");
    var xlinkNS = "http://www.w3.org/1999/xlink";
    var isXlink = function(name) {
      return name.charAt(5) === ":" && name.slice(0, 5) === "xlink";
    };
    var getXlinkProp = function(name) {
      return isXlink(name) ? name.slice(6, name.length) : "";
    };
    var isFalsyAttrValue = function(val) {
      return val == null || val === false;
    };
    function genClassForVnode(vnode) {
      var data = vnode.data;
      var parentNode2 = vnode;
      var childNode = vnode;
      while (isDef(childNode.componentInstance)) {
        childNode = childNode.componentInstance._vnode;
        if (childNode && childNode.data) {
          data = mergeClassData(childNode.data, data);
        }
      }
      while (isDef(parentNode2 = parentNode2.parent)) {
        if (parentNode2 && parentNode2.data) {
          data = mergeClassData(data, parentNode2.data);
        }
      }
      return renderClass(data.staticClass, data.class);
    }
    function mergeClassData(child, parent) {
      return {
        staticClass: concat(child.staticClass, parent.staticClass),
        class: isDef(child.class) ? [child.class, parent.class] : parent.class
      };
    }
    function renderClass(staticClass, dynamicClass) {
      if (isDef(staticClass) || isDef(dynamicClass)) {
        return concat(staticClass, stringifyClass(dynamicClass));
      }
      return "";
    }
    function concat(a, b) {
      return a ? b ? a + " " + b : a : b || "";
    }
    function stringifyClass(value) {
      if (Array.isArray(value)) {
        return stringifyArray(value);
      }
      if (isObject(value)) {
        return stringifyObject(value);
      }
      if (typeof value === "string") {
        return value;
      }
      return "";
    }
    function stringifyArray(value) {
      var res = "";
      var stringified;
      for (var i = 0, l = value.length; i < l; i++) {
        if (isDef(stringified = stringifyClass(value[i])) && stringified !== "") {
          if (res) {
            res += " ";
          }
          res += stringified;
        }
      }
      return res;
    }
    function stringifyObject(value) {
      var res = "";
      for (var key in value) {
        if (value[key]) {
          if (res) {
            res += " ";
          }
          res += key;
        }
      }
      return res;
    }
    var namespaceMap = {
      svg: "http://www.w3.org/2000/svg",
      math: "http://www.w3.org/1998/Math/MathML"
    };
    var isHTMLTag = makeMap("html,body,base,head,link,meta,style,title,address,article,aside,footer,header,h1,h2,h3,h4,h5,h6,hgroup,nav,section,div,dd,dl,dt,figcaption,figure,picture,hr,img,li,main,ol,p,pre,ul,a,b,abbr,bdi,bdo,br,cite,code,data,dfn,em,i,kbd,mark,q,rp,rt,rtc,ruby,s,samp,small,span,strong,sub,sup,time,u,var,wbr,area,audio,map,track,video,embed,object,param,source,canvas,script,noscript,del,ins,caption,col,colgroup,table,thead,tbody,td,th,tr,button,datalist,fieldset,form,input,label,legend,meter,optgroup,option,output,progress,select,textarea,details,dialog,menu,menuitem,summary,content,element,shadow,template,blockquote,iframe,tfoot");
    var isSVG = makeMap("svg,animate,circle,clippath,cursor,defs,desc,ellipse,filter,font-face,foreignobject,g,glyph,image,line,marker,mask,missing-glyph,path,pattern,polygon,polyline,rect,switch,symbol,text,textpath,tspan,use,view", true);
    var isReservedTag = function(tag) {
      return isHTMLTag(tag) || isSVG(tag);
    };
    function getTagNamespace(tag) {
      if (isSVG(tag)) {
        return "svg";
      }
      if (tag === "math") {
        return "math";
      }
    }
    function isUnknownElement(tag) {
      {
        return true;
      }
    }
    var isTextInputType = makeMap("text,number,password,search,email,tel,url");
    function query(el) {
      if (typeof el === "string") {
        var selected = document.querySelector(el);
        if (!selected) {
          return document.createElement("div");
        }
        return selected;
      } else {
        return el;
      }
    }
    function createElement$1(tagName2, vnode) {
      var elm = document.createElement(tagName2);
      if (tagName2 !== "select") {
        return elm;
      }
      if (vnode.data && vnode.data.attrs && vnode.data.attrs.multiple !== void 0) {
        elm.setAttribute("multiple", "multiple");
      }
      return elm;
    }
    function createElementNS(namespace, tagName2) {
      return document.createElementNS(namespaceMap[namespace], tagName2);
    }
    function createTextNode(text) {
      return document.createTextNode(text);
    }
    function createComment(text) {
      return document.createComment(text);
    }
    function insertBefore(parentNode2, newNode, referenceNode) {
      parentNode2.insertBefore(newNode, referenceNode);
    }
    function removeChild(node, child) {
      node.removeChild(child);
    }
    function appendChild(node, child) {
      node.appendChild(child);
    }
    function parentNode(node) {
      return node.parentNode;
    }
    function nextSibling(node) {
      return node.nextSibling;
    }
    function tagName(node) {
      return node.tagName;
    }
    function setTextContent(node, text) {
      node.textContent = text;
    }
    function setStyleScope(node, scopeId) {
      node.setAttribute(scopeId, "");
    }
    var nodeOps = /* @__PURE__ */ Object.freeze({
      createElement: createElement$1,
      createElementNS,
      createTextNode,
      createComment,
      insertBefore,
      removeChild,
      appendChild,
      parentNode,
      nextSibling,
      tagName,
      setTextContent,
      setStyleScope
    });
    var ref = {
      create: function create(_, vnode) {
        registerRef(vnode);
      },
      update: function update(oldVnode, vnode) {
        if (oldVnode.data.ref !== vnode.data.ref) {
          registerRef(oldVnode, true);
          registerRef(vnode);
        }
      },
      destroy: function destroy(vnode) {
        registerRef(vnode, true);
      }
    };
    function registerRef(vnode, isRemoval) {
      var key = vnode.data.ref;
      if (!isDef(key)) {
        return;
      }
      var vm = vnode.context;
      var ref2 = vnode.componentInstance || vnode.elm;
      var refs = vm.$refs;
      if (isRemoval) {
        if (Array.isArray(refs[key])) {
          remove(refs[key], ref2);
        } else if (refs[key] === ref2) {
          refs[key] = void 0;
        }
      } else {
        if (vnode.data.refInFor) {
          if (!Array.isArray(refs[key])) {
            refs[key] = [ref2];
          } else if (refs[key].indexOf(ref2) < 0) {
            refs[key].push(ref2);
          }
        } else {
          refs[key] = ref2;
        }
      }
    }
    var emptyNode = new VNode("", {}, []);
    var hooks = ["create", "activate", "update", "remove", "destroy"];
    function sameVnode(a, b) {
      return a.key === b.key && a.asyncFactory === b.asyncFactory && (a.tag === b.tag && a.isComment === b.isComment && isDef(a.data) === isDef(b.data) && sameInputType(a, b) || isTrue(a.isAsyncPlaceholder) && isUndef(b.asyncFactory.error));
    }
    function sameInputType(a, b) {
      if (a.tag !== "input") {
        return true;
      }
      var i;
      var typeA = isDef(i = a.data) && isDef(i = i.attrs) && i.type;
      var typeB = isDef(i = b.data) && isDef(i = i.attrs) && i.type;
      return typeA === typeB || isTextInputType(typeA) && isTextInputType(typeB);
    }
    function createKeyToOldIdx(children, beginIdx, endIdx) {
      var i, key;
      var map = {};
      for (i = beginIdx; i <= endIdx; ++i) {
        key = children[i].key;
        if (isDef(key)) {
          map[key] = i;
        }
      }
      return map;
    }
    function createPatchFunction(backend) {
      var i, j;
      var cbs = {};
      var modules2 = backend.modules;
      var nodeOps2 = backend.nodeOps;
      for (i = 0; i < hooks.length; ++i) {
        cbs[hooks[i]] = [];
        for (j = 0; j < modules2.length; ++j) {
          if (isDef(modules2[j][hooks[i]])) {
            cbs[hooks[i]].push(modules2[j][hooks[i]]);
          }
        }
      }
      function emptyNodeAt(elm) {
        return new VNode(nodeOps2.tagName(elm).toLowerCase(), {}, [], void 0, elm);
      }
      function createRmCb(childElm, listeners) {
        function remove$$1() {
          if (--remove$$1.listeners === 0) {
            removeNode(childElm);
          }
        }
        remove$$1.listeners = listeners;
        return remove$$1;
      }
      function removeNode(el) {
        var parent = nodeOps2.parentNode(el);
        if (isDef(parent)) {
          nodeOps2.removeChild(parent, el);
        }
      }
      function createElm(vnode, insertedVnodeQueue, parentElm, refElm, nested, ownerArray, index2) {
        if (isDef(vnode.elm) && isDef(ownerArray)) {
          vnode = ownerArray[index2] = cloneVNode(vnode);
        }
        vnode.isRootInsert = !nested;
        if (createComponent2(vnode, insertedVnodeQueue, parentElm, refElm)) {
          return;
        }
        var data = vnode.data;
        var children = vnode.children;
        var tag = vnode.tag;
        if (isDef(tag)) {
          vnode.elm = vnode.ns ? nodeOps2.createElementNS(vnode.ns, tag) : nodeOps2.createElement(tag, vnode);
          setScope(vnode);
          {
            createChildren(vnode, children, insertedVnodeQueue);
            if (isDef(data)) {
              invokeCreateHooks(vnode, insertedVnodeQueue);
            }
            insert(parentElm, vnode.elm, refElm);
          }
        } else if (isTrue(vnode.isComment)) {
          vnode.elm = nodeOps2.createComment(vnode.text);
          insert(parentElm, vnode.elm, refElm);
        } else {
          vnode.elm = nodeOps2.createTextNode(vnode.text);
          insert(parentElm, vnode.elm, refElm);
        }
      }
      function createComponent2(vnode, insertedVnodeQueue, parentElm, refElm) {
        var i2 = vnode.data;
        if (isDef(i2)) {
          var isReactivated = isDef(vnode.componentInstance) && i2.keepAlive;
          if (isDef(i2 = i2.hook) && isDef(i2 = i2.init)) {
            i2(vnode, false);
          }
          if (isDef(vnode.componentInstance)) {
            initComponent(vnode, insertedVnodeQueue);
            insert(parentElm, vnode.elm, refElm);
            if (isTrue(isReactivated)) {
              reactivateComponent(vnode, insertedVnodeQueue, parentElm, refElm);
            }
            return true;
          }
        }
      }
      function initComponent(vnode, insertedVnodeQueue) {
        if (isDef(vnode.data.pendingInsert)) {
          insertedVnodeQueue.push.apply(insertedVnodeQueue, vnode.data.pendingInsert);
          vnode.data.pendingInsert = null;
        }
        vnode.elm = vnode.componentInstance.$el;
        if (isPatchable(vnode)) {
          invokeCreateHooks(vnode, insertedVnodeQueue);
          setScope(vnode);
        } else {
          registerRef(vnode);
          insertedVnodeQueue.push(vnode);
        }
      }
      function reactivateComponent(vnode, insertedVnodeQueue, parentElm, refElm) {
        var i2;
        var innerNode = vnode;
        while (innerNode.componentInstance) {
          innerNode = innerNode.componentInstance._vnode;
          if (isDef(i2 = innerNode.data) && isDef(i2 = i2.transition)) {
            for (i2 = 0; i2 < cbs.activate.length; ++i2) {
              cbs.activate[i2](emptyNode, innerNode);
            }
            insertedVnodeQueue.push(innerNode);
            break;
          }
        }
        insert(parentElm, vnode.elm, refElm);
      }
      function insert(parent, elm, ref$$1) {
        if (isDef(parent)) {
          if (isDef(ref$$1)) {
            if (nodeOps2.parentNode(ref$$1) === parent) {
              nodeOps2.insertBefore(parent, elm, ref$$1);
            }
          } else {
            nodeOps2.appendChild(parent, elm);
          }
        }
      }
      function createChildren(vnode, children, insertedVnodeQueue) {
        if (Array.isArray(children)) {
          for (var i2 = 0; i2 < children.length; ++i2) {
            createElm(children[i2], insertedVnodeQueue, vnode.elm, null, true, children, i2);
          }
        } else if (isPrimitive(vnode.text)) {
          nodeOps2.appendChild(vnode.elm, nodeOps2.createTextNode(String(vnode.text)));
        }
      }
      function isPatchable(vnode) {
        while (vnode.componentInstance) {
          vnode = vnode.componentInstance._vnode;
        }
        return isDef(vnode.tag);
      }
      function invokeCreateHooks(vnode, insertedVnodeQueue) {
        for (var i$1 = 0; i$1 < cbs.create.length; ++i$1) {
          cbs.create[i$1](emptyNode, vnode);
        }
        i = vnode.data.hook;
        if (isDef(i)) {
          if (isDef(i.create)) {
            i.create(emptyNode, vnode);
          }
          if (isDef(i.insert)) {
            insertedVnodeQueue.push(vnode);
          }
        }
      }
      function setScope(vnode) {
        var i2;
        if (isDef(i2 = vnode.fnScopeId)) {
          nodeOps2.setStyleScope(vnode.elm, i2);
        } else {
          var ancestor = vnode;
          while (ancestor) {
            if (isDef(i2 = ancestor.context) && isDef(i2 = i2.$options._scopeId)) {
              nodeOps2.setStyleScope(vnode.elm, i2);
            }
            ancestor = ancestor.parent;
          }
        }
        if (isDef(i2 = activeInstance) && i2 !== vnode.context && i2 !== vnode.fnContext && isDef(i2 = i2.$options._scopeId)) {
          nodeOps2.setStyleScope(vnode.elm, i2);
        }
      }
      function addVnodes(parentElm, refElm, vnodes, startIdx, endIdx, insertedVnodeQueue) {
        for (; startIdx <= endIdx; ++startIdx) {
          createElm(vnodes[startIdx], insertedVnodeQueue, parentElm, refElm, false, vnodes, startIdx);
        }
      }
      function invokeDestroyHook(vnode) {
        var i2, j2;
        var data = vnode.data;
        if (isDef(data)) {
          if (isDef(i2 = data.hook) && isDef(i2 = i2.destroy)) {
            i2(vnode);
          }
          for (i2 = 0; i2 < cbs.destroy.length; ++i2) {
            cbs.destroy[i2](vnode);
          }
        }
        if (isDef(i2 = vnode.children)) {
          for (j2 = 0; j2 < vnode.children.length; ++j2) {
            invokeDestroyHook(vnode.children[j2]);
          }
        }
      }
      function removeVnodes(vnodes, startIdx, endIdx) {
        for (; startIdx <= endIdx; ++startIdx) {
          var ch = vnodes[startIdx];
          if (isDef(ch)) {
            if (isDef(ch.tag)) {
              removeAndInvokeRemoveHook(ch);
              invokeDestroyHook(ch);
            } else {
              removeNode(ch.elm);
            }
          }
        }
      }
      function removeAndInvokeRemoveHook(vnode, rm) {
        if (isDef(rm) || isDef(vnode.data)) {
          var i2;
          var listeners = cbs.remove.length + 1;
          if (isDef(rm)) {
            rm.listeners += listeners;
          } else {
            rm = createRmCb(vnode.elm, listeners);
          }
          if (isDef(i2 = vnode.componentInstance) && isDef(i2 = i2._vnode) && isDef(i2.data)) {
            removeAndInvokeRemoveHook(i2, rm);
          }
          for (i2 = 0; i2 < cbs.remove.length; ++i2) {
            cbs.remove[i2](vnode, rm);
          }
          if (isDef(i2 = vnode.data.hook) && isDef(i2 = i2.remove)) {
            i2(vnode, rm);
          } else {
            rm();
          }
        } else {
          removeNode(vnode.elm);
        }
      }
      function updateChildren(parentElm, oldCh, newCh, insertedVnodeQueue, removeOnly) {
        var oldStartIdx = 0;
        var newStartIdx = 0;
        var oldEndIdx = oldCh.length - 1;
        var oldStartVnode = oldCh[0];
        var oldEndVnode = oldCh[oldEndIdx];
        var newEndIdx = newCh.length - 1;
        var newStartVnode = newCh[0];
        var newEndVnode = newCh[newEndIdx];
        var oldKeyToIdx, idxInOld, vnodeToMove, refElm;
        var canMove = !removeOnly;
        while (oldStartIdx <= oldEndIdx && newStartIdx <= newEndIdx) {
          if (isUndef(oldStartVnode)) {
            oldStartVnode = oldCh[++oldStartIdx];
          } else if (isUndef(oldEndVnode)) {
            oldEndVnode = oldCh[--oldEndIdx];
          } else if (sameVnode(oldStartVnode, newStartVnode)) {
            patchVnode(oldStartVnode, newStartVnode, insertedVnodeQueue, newCh, newStartIdx);
            oldStartVnode = oldCh[++oldStartIdx];
            newStartVnode = newCh[++newStartIdx];
          } else if (sameVnode(oldEndVnode, newEndVnode)) {
            patchVnode(oldEndVnode, newEndVnode, insertedVnodeQueue, newCh, newEndIdx);
            oldEndVnode = oldCh[--oldEndIdx];
            newEndVnode = newCh[--newEndIdx];
          } else if (sameVnode(oldStartVnode, newEndVnode)) {
            patchVnode(oldStartVnode, newEndVnode, insertedVnodeQueue, newCh, newEndIdx);
            canMove && nodeOps2.insertBefore(parentElm, oldStartVnode.elm, nodeOps2.nextSibling(oldEndVnode.elm));
            oldStartVnode = oldCh[++oldStartIdx];
            newEndVnode = newCh[--newEndIdx];
          } else if (sameVnode(oldEndVnode, newStartVnode)) {
            patchVnode(oldEndVnode, newStartVnode, insertedVnodeQueue, newCh, newStartIdx);
            canMove && nodeOps2.insertBefore(parentElm, oldEndVnode.elm, oldStartVnode.elm);
            oldEndVnode = oldCh[--oldEndIdx];
            newStartVnode = newCh[++newStartIdx];
          } else {
            if (isUndef(oldKeyToIdx)) {
              oldKeyToIdx = createKeyToOldIdx(oldCh, oldStartIdx, oldEndIdx);
            }
            idxInOld = isDef(newStartVnode.key) ? oldKeyToIdx[newStartVnode.key] : findIdxInOld(newStartVnode, oldCh, oldStartIdx, oldEndIdx);
            if (isUndef(idxInOld)) {
              createElm(newStartVnode, insertedVnodeQueue, parentElm, oldStartVnode.elm, false, newCh, newStartIdx);
            } else {
              vnodeToMove = oldCh[idxInOld];
              if (sameVnode(vnodeToMove, newStartVnode)) {
                patchVnode(vnodeToMove, newStartVnode, insertedVnodeQueue, newCh, newStartIdx);
                oldCh[idxInOld] = void 0;
                canMove && nodeOps2.insertBefore(parentElm, vnodeToMove.elm, oldStartVnode.elm);
              } else {
                createElm(newStartVnode, insertedVnodeQueue, parentElm, oldStartVnode.elm, false, newCh, newStartIdx);
              }
            }
            newStartVnode = newCh[++newStartIdx];
          }
        }
        if (oldStartIdx > oldEndIdx) {
          refElm = isUndef(newCh[newEndIdx + 1]) ? null : newCh[newEndIdx + 1].elm;
          addVnodes(parentElm, refElm, newCh, newStartIdx, newEndIdx, insertedVnodeQueue);
        } else if (newStartIdx > newEndIdx) {
          removeVnodes(oldCh, oldStartIdx, oldEndIdx);
        }
      }
      function findIdxInOld(node, oldCh, start, end) {
        for (var i2 = start; i2 < end; i2++) {
          var c = oldCh[i2];
          if (isDef(c) && sameVnode(node, c)) {
            return i2;
          }
        }
      }
      function patchVnode(oldVnode, vnode, insertedVnodeQueue, ownerArray, index2, removeOnly) {
        if (oldVnode === vnode) {
          return;
        }
        if (isDef(vnode.elm) && isDef(ownerArray)) {
          vnode = ownerArray[index2] = cloneVNode(vnode);
        }
        var elm = vnode.elm = oldVnode.elm;
        if (isTrue(oldVnode.isAsyncPlaceholder)) {
          if (isDef(vnode.asyncFactory.resolved)) {
            hydrate(oldVnode.elm, vnode, insertedVnodeQueue);
          } else {
            vnode.isAsyncPlaceholder = true;
          }
          return;
        }
        if (isTrue(vnode.isStatic) && isTrue(oldVnode.isStatic) && vnode.key === oldVnode.key && (isTrue(vnode.isCloned) || isTrue(vnode.isOnce))) {
          vnode.componentInstance = oldVnode.componentInstance;
          return;
        }
        var i2;
        var data = vnode.data;
        if (isDef(data) && isDef(i2 = data.hook) && isDef(i2 = i2.prepatch)) {
          i2(oldVnode, vnode);
        }
        var oldCh = oldVnode.children;
        var ch = vnode.children;
        if (isDef(data) && isPatchable(vnode)) {
          for (i2 = 0; i2 < cbs.update.length; ++i2) {
            cbs.update[i2](oldVnode, vnode);
          }
          if (isDef(i2 = data.hook) && isDef(i2 = i2.update)) {
            i2(oldVnode, vnode);
          }
        }
        if (isUndef(vnode.text)) {
          if (isDef(oldCh) && isDef(ch)) {
            if (oldCh !== ch) {
              updateChildren(elm, oldCh, ch, insertedVnodeQueue, removeOnly);
            }
          } else if (isDef(ch)) {
            if (isDef(oldVnode.text)) {
              nodeOps2.setTextContent(elm, "");
            }
            addVnodes(elm, null, ch, 0, ch.length - 1, insertedVnodeQueue);
          } else if (isDef(oldCh)) {
            removeVnodes(oldCh, 0, oldCh.length - 1);
          } else if (isDef(oldVnode.text)) {
            nodeOps2.setTextContent(elm, "");
          }
        } else if (oldVnode.text !== vnode.text) {
          nodeOps2.setTextContent(elm, vnode.text);
        }
        if (isDef(data)) {
          if (isDef(i2 = data.hook) && isDef(i2 = i2.postpatch)) {
            i2(oldVnode, vnode);
          }
        }
      }
      function invokeInsertHook(vnode, queue2, initial) {
        if (isTrue(initial) && isDef(vnode.parent)) {
          vnode.parent.data.pendingInsert = queue2;
        } else {
          for (var i2 = 0; i2 < queue2.length; ++i2) {
            queue2[i2].data.hook.insert(queue2[i2]);
          }
        }
      }
      var isRenderedModule = makeMap("attrs,class,staticClass,staticStyle,key");
      function hydrate(elm, vnode, insertedVnodeQueue, inVPre) {
        var i2;
        var tag = vnode.tag;
        var data = vnode.data;
        var children = vnode.children;
        inVPre = inVPre || data && data.pre;
        vnode.elm = elm;
        if (isTrue(vnode.isComment) && isDef(vnode.asyncFactory)) {
          vnode.isAsyncPlaceholder = true;
          return true;
        }
        if (isDef(data)) {
          if (isDef(i2 = data.hook) && isDef(i2 = i2.init)) {
            i2(vnode, true);
          }
          if (isDef(i2 = vnode.componentInstance)) {
            initComponent(vnode, insertedVnodeQueue);
            return true;
          }
        }
        if (isDef(tag)) {
          if (isDef(children)) {
            if (!elm.hasChildNodes()) {
              createChildren(vnode, children, insertedVnodeQueue);
            } else {
              if (isDef(i2 = data) && isDef(i2 = i2.domProps) && isDef(i2 = i2.innerHTML)) {
                if (i2 !== elm.innerHTML) {
                  return false;
                }
              } else {
                var childrenMatch = true;
                var childNode = elm.firstChild;
                for (var i$1 = 0; i$1 < children.length; i$1++) {
                  if (!childNode || !hydrate(childNode, children[i$1], insertedVnodeQueue, inVPre)) {
                    childrenMatch = false;
                    break;
                  }
                  childNode = childNode.nextSibling;
                }
                if (!childrenMatch || childNode) {
                  return false;
                }
              }
            }
          }
          if (isDef(data)) {
            var fullInvoke = false;
            for (var key in data) {
              if (!isRenderedModule(key)) {
                fullInvoke = true;
                invokeCreateHooks(vnode, insertedVnodeQueue);
                break;
              }
            }
            if (!fullInvoke && data["class"]) {
              traverse(data["class"]);
            }
          }
        } else if (elm.data !== vnode.text) {
          elm.data = vnode.text;
        }
        return true;
      }
      return function patch2(oldVnode, vnode, hydrating, removeOnly) {
        if (isUndef(vnode)) {
          if (isDef(oldVnode)) {
            invokeDestroyHook(oldVnode);
          }
          return;
        }
        var isInitialPatch = false;
        var insertedVnodeQueue = [];
        if (isUndef(oldVnode)) {
          isInitialPatch = true;
          createElm(vnode, insertedVnodeQueue);
        } else {
          var isRealElement = isDef(oldVnode.nodeType);
          if (!isRealElement && sameVnode(oldVnode, vnode)) {
            patchVnode(oldVnode, vnode, insertedVnodeQueue, null, null, removeOnly);
          } else {
            if (isRealElement) {
              if (oldVnode.nodeType === 1 && oldVnode.hasAttribute(SSR_ATTR)) {
                oldVnode.removeAttribute(SSR_ATTR);
                hydrating = true;
              }
              if (isTrue(hydrating)) {
                if (hydrate(oldVnode, vnode, insertedVnodeQueue)) {
                  invokeInsertHook(vnode, insertedVnodeQueue, true);
                  return oldVnode;
                }
              }
              oldVnode = emptyNodeAt(oldVnode);
            }
            var oldElm = oldVnode.elm;
            var parentElm = nodeOps2.parentNode(oldElm);
            createElm(vnode, insertedVnodeQueue, oldElm._leaveCb ? null : parentElm, nodeOps2.nextSibling(oldElm));
            if (isDef(vnode.parent)) {
              var ancestor = vnode.parent;
              var patchable = isPatchable(vnode);
              while (ancestor) {
                for (var i2 = 0; i2 < cbs.destroy.length; ++i2) {
                  cbs.destroy[i2](ancestor);
                }
                ancestor.elm = vnode.elm;
                if (patchable) {
                  for (var i$1 = 0; i$1 < cbs.create.length; ++i$1) {
                    cbs.create[i$1](emptyNode, ancestor);
                  }
                  var insert2 = ancestor.data.hook.insert;
                  if (insert2.merged) {
                    for (var i$2 = 1; i$2 < insert2.fns.length; i$2++) {
                      insert2.fns[i$2]();
                    }
                  }
                } else {
                  registerRef(ancestor);
                }
                ancestor = ancestor.parent;
              }
            }
            if (isDef(parentElm)) {
              removeVnodes([oldVnode], 0, 0);
            } else if (isDef(oldVnode.tag)) {
              invokeDestroyHook(oldVnode);
            }
          }
        }
        invokeInsertHook(vnode, insertedVnodeQueue, isInitialPatch);
        return vnode.elm;
      };
    }
    var directives = {
      create: updateDirectives,
      update: updateDirectives,
      destroy: function unbindDirectives(vnode) {
        updateDirectives(vnode, emptyNode);
      }
    };
    function updateDirectives(oldVnode, vnode) {
      if (oldVnode.data.directives || vnode.data.directives) {
        _update(oldVnode, vnode);
      }
    }
    function _update(oldVnode, vnode) {
      var isCreate = oldVnode === emptyNode;
      var isDestroy = vnode === emptyNode;
      var oldDirs = normalizeDirectives$1(oldVnode.data.directives, oldVnode.context);
      var newDirs = normalizeDirectives$1(vnode.data.directives, vnode.context);
      var dirsWithInsert = [];
      var dirsWithPostpatch = [];
      var key, oldDir, dir;
      for (key in newDirs) {
        oldDir = oldDirs[key];
        dir = newDirs[key];
        if (!oldDir) {
          callHook$1(dir, "bind", vnode, oldVnode);
          if (dir.def && dir.def.inserted) {
            dirsWithInsert.push(dir);
          }
        } else {
          dir.oldValue = oldDir.value;
          dir.oldArg = oldDir.arg;
          callHook$1(dir, "update", vnode, oldVnode);
          if (dir.def && dir.def.componentUpdated) {
            dirsWithPostpatch.push(dir);
          }
        }
      }
      if (dirsWithInsert.length) {
        var callInsert = function() {
          for (var i = 0; i < dirsWithInsert.length; i++) {
            callHook$1(dirsWithInsert[i], "inserted", vnode, oldVnode);
          }
        };
        if (isCreate) {
          mergeVNodeHook(vnode, "insert", callInsert);
        } else {
          callInsert();
        }
      }
      if (dirsWithPostpatch.length) {
        mergeVNodeHook(vnode, "postpatch", function() {
          for (var i = 0; i < dirsWithPostpatch.length; i++) {
            callHook$1(dirsWithPostpatch[i], "componentUpdated", vnode, oldVnode);
          }
        });
      }
      if (!isCreate) {
        for (key in oldDirs) {
          if (!newDirs[key]) {
            callHook$1(oldDirs[key], "unbind", oldVnode, oldVnode, isDestroy);
          }
        }
      }
    }
    var emptyModifiers = Object.create(null);
    function normalizeDirectives$1(dirs, vm) {
      var res = Object.create(null);
      if (!dirs) {
        return res;
      }
      var i, dir;
      for (i = 0; i < dirs.length; i++) {
        dir = dirs[i];
        if (!dir.modifiers) {
          dir.modifiers = emptyModifiers;
        }
        res[getRawDirName(dir)] = dir;
        dir.def = resolveAsset(vm.$options, "directives", dir.name);
      }
      return res;
    }
    function getRawDirName(dir) {
      return dir.rawName || dir.name + "." + Object.keys(dir.modifiers || {}).join(".");
    }
    function callHook$1(dir, hook, vnode, oldVnode, isDestroy) {
      var fn = dir.def && dir.def[hook];
      if (fn) {
        try {
          fn(vnode.elm, dir, vnode, oldVnode, isDestroy);
        } catch (e) {
          handleError(e, vnode.context, "directive " + dir.name + " " + hook + " hook");
        }
      }
    }
    var baseModules = [ref, directives];
    function updateAttrs(oldVnode, vnode) {
      var opts2 = vnode.componentOptions;
      if (isDef(opts2) && opts2.Ctor.options.inheritAttrs === false) {
        return;
      }
      if (isUndef(oldVnode.data.attrs) && isUndef(vnode.data.attrs)) {
        return;
      }
      var key, cur, old;
      var elm = vnode.elm;
      var oldAttrs = oldVnode.data.attrs || {};
      var attrs2 = vnode.data.attrs || {};
      if (isDef(attrs2.__ob__)) {
        attrs2 = vnode.data.attrs = extend({}, attrs2);
      }
      for (key in attrs2) {
        cur = attrs2[key];
        old = oldAttrs[key];
        if (old !== cur) {
          setAttr(elm, key, cur, vnode.data.pre);
        }
      }
      for (key in oldAttrs) {
        if (isUndef(attrs2[key])) {
          if (isXlink(key)) {
            elm.removeAttributeNS(xlinkNS, getXlinkProp(key));
          } else if (!isEnumeratedAttr(key)) {
            elm.removeAttribute(key);
          }
        }
      }
    }
    function setAttr(el, key, value, isInPre) {
      if (isInPre || el.tagName.indexOf("-") > -1) {
        baseSetAttr(el, key, value);
      } else if (isBooleanAttr(key)) {
        if (isFalsyAttrValue(value)) {
          el.removeAttribute(key);
        } else {
          value = key === "allowfullscreen" && el.tagName === "EMBED" ? "true" : key;
          el.setAttribute(key, value);
        }
      } else if (isEnumeratedAttr(key)) {
        el.setAttribute(key, convertEnumeratedValue(key, value));
      } else if (isXlink(key)) {
        if (isFalsyAttrValue(value)) {
          el.removeAttributeNS(xlinkNS, getXlinkProp(key));
        } else {
          el.setAttributeNS(xlinkNS, key, value);
        }
      } else {
        baseSetAttr(el, key, value);
      }
    }
    function baseSetAttr(el, key, value) {
      if (isFalsyAttrValue(value)) {
        el.removeAttribute(key);
      } else {
        el.setAttribute(key, value);
      }
    }
    var attrs = {
      create: updateAttrs,
      update: updateAttrs
    };
    function updateClass(oldVnode, vnode) {
      var el = vnode.elm;
      var data = vnode.data;
      var oldData = oldVnode.data;
      if (isUndef(data.staticClass) && isUndef(data.class) && (isUndef(oldData) || isUndef(oldData.staticClass) && isUndef(oldData.class))) {
        return;
      }
      var cls = genClassForVnode(vnode);
      var transitionClass = el._transitionClasses;
      if (isDef(transitionClass)) {
        cls = concat(cls, stringifyClass(transitionClass));
      }
      if (cls !== el._prevClass) {
        el.setAttribute("class", cls);
        el._prevClass = cls;
      }
    }
    var klass = {
      create: updateClass,
      update: updateClass
    };
    var RANGE_TOKEN = "__r";
    var CHECKBOX_RADIO_TOKEN = "__c";
    function normalizeEvents(on) {
      if (isDef(on[RANGE_TOKEN])) {
        var event = "input";
        on[event] = [].concat(on[RANGE_TOKEN], on[event] || []);
        delete on[RANGE_TOKEN];
      }
      if (isDef(on[CHECKBOX_RADIO_TOKEN])) {
        on.change = [].concat(on[CHECKBOX_RADIO_TOKEN], on.change || []);
        delete on[CHECKBOX_RADIO_TOKEN];
      }
    }
    var target$1;
    function createOnceHandler$1(event, handler, capture) {
      var _target = target$1;
      return function onceHandler() {
        var res = handler.apply(null, arguments);
        if (res !== null) {
          remove$2(event, onceHandler, capture, _target);
        }
      };
    }
    var useMicrotaskFix = isUsingMicroTask && !(isFF );
    function add$1(name, handler, capture, passive) {
      if (useMicrotaskFix) {
        var attachedTimestamp = currentFlushTimestamp;
        var original = handler;
        handler = original._wrapper = function(e) {
          if (e.target === e.currentTarget || e.timeStamp >= attachedTimestamp || e.timeStamp <= 0 || e.target.ownerDocument !== document) {
            return original.apply(this, arguments);
          }
        };
      }
      target$1.addEventListener(name, handler, capture);
    }
    function remove$2(name, handler, capture, _target) {
      (_target || target$1).removeEventListener(name, handler._wrapper || handler, capture);
    }
    function updateDOMListeners(oldVnode, vnode) {
      if (isUndef(oldVnode.data.on) && isUndef(vnode.data.on)) {
        return;
      }
      var on = vnode.data.on || {};
      var oldOn = oldVnode.data.on || {};
      target$1 = vnode.elm;
      normalizeEvents(on);
      updateListeners(on, oldOn, add$1, remove$2, createOnceHandler$1, vnode.context);
      target$1 = void 0;
    }
    var events = {
      create: updateDOMListeners,
      update: updateDOMListeners
    };
    var svgContainer;
    function updateDOMProps(oldVnode, vnode) {
      if (isUndef(oldVnode.data.domProps) && isUndef(vnode.data.domProps)) {
        return;
      }
      var key, cur;
      var elm = vnode.elm;
      var oldProps = oldVnode.data.domProps || {};
      var props2 = vnode.data.domProps || {};
      if (isDef(props2.__ob__)) {
        props2 = vnode.data.domProps = extend({}, props2);
      }
      for (key in oldProps) {
        if (!(key in props2)) {
          elm[key] = "";
        }
      }
      for (key in props2) {
        cur = props2[key];
        if (key === "textContent" || key === "innerHTML") {
          if (vnode.children) {
            vnode.children.length = 0;
          }
          if (cur === oldProps[key]) {
            continue;
          }
          if (elm.childNodes.length === 1) {
            elm.removeChild(elm.childNodes[0]);
          }
        }
        if (key === "value" && elm.tagName !== "PROGRESS") {
          elm._value = cur;
          var strCur = isUndef(cur) ? "" : String(cur);
          if (shouldUpdateValue(elm, strCur)) {
            elm.value = strCur;
          }
        } else if (key === "innerHTML" && isSVG(elm.tagName) && isUndef(elm.innerHTML)) {
          svgContainer = svgContainer || document.createElement("div");
          svgContainer.innerHTML = "<svg>" + cur + "</svg>";
          var svg = svgContainer.firstChild;
          while (elm.firstChild) {
            elm.removeChild(elm.firstChild);
          }
          while (svg.firstChild) {
            elm.appendChild(svg.firstChild);
          }
        } else if (cur !== oldProps[key]) {
          try {
            elm[key] = cur;
          } catch (e) {
          }
        }
      }
    }
    function shouldUpdateValue(elm, checkVal) {
      return !elm.composing && (elm.tagName === "OPTION" || isNotInFocusAndDirty(elm, checkVal) || isDirtyWithModifiers(elm, checkVal));
    }
    function isNotInFocusAndDirty(elm, checkVal) {
      var notInFocus = true;
      try {
        notInFocus = document.activeElement !== elm;
      } catch (e) {
      }
      return notInFocus && elm.value !== checkVal;
    }
    function isDirtyWithModifiers(elm, newVal) {
      var value = elm.value;
      var modifiers = elm._vModifiers;
      if (isDef(modifiers)) {
        if (modifiers.number) {
          return toNumber(value) !== toNumber(newVal);
        }
        if (modifiers.trim) {
          return value.trim() !== newVal.trim();
        }
      }
      return value !== newVal;
    }
    var domProps = {
      create: updateDOMProps,
      update: updateDOMProps
    };
    var parseStyleText = cached(function(cssText) {
      var res = {};
      var listDelimiter = /;(?![^(]*\))/g;
      var propertyDelimiter = /:(.+)/;
      cssText.split(listDelimiter).forEach(function(item) {
        if (item) {
          var tmp = item.split(propertyDelimiter);
          tmp.length > 1 && (res[tmp[0].trim()] = tmp[1].trim());
        }
      });
      return res;
    });
    function normalizeStyleData(data) {
      var style2 = normalizeStyleBinding(data.style);
      return data.staticStyle ? extend(data.staticStyle, style2) : style2;
    }
    function normalizeStyleBinding(bindingStyle) {
      if (Array.isArray(bindingStyle)) {
        return toObject(bindingStyle);
      }
      if (typeof bindingStyle === "string") {
        return parseStyleText(bindingStyle);
      }
      return bindingStyle;
    }
    function getStyle(vnode, checkChild) {
      var res = {};
      var styleData;
      if (checkChild) {
        var childNode = vnode;
        while (childNode.componentInstance) {
          childNode = childNode.componentInstance._vnode;
          if (childNode && childNode.data && (styleData = normalizeStyleData(childNode.data))) {
            extend(res, styleData);
          }
        }
      }
      if (styleData = normalizeStyleData(vnode.data)) {
        extend(res, styleData);
      }
      var parentNode2 = vnode;
      while (parentNode2 = parentNode2.parent) {
        if (parentNode2.data && (styleData = normalizeStyleData(parentNode2.data))) {
          extend(res, styleData);
        }
      }
      return res;
    }
    var cssVarRE = /^--/;
    var importantRE = /\s*!important$/;
    var setProp = function(el, name, val) {
      if (cssVarRE.test(name)) {
        el.style.setProperty(name, val);
      } else if (importantRE.test(val)) {
        el.style.setProperty(hyphenate(name), val.replace(importantRE, ""), "important");
      } else {
        var normalizedName = normalize(name);
        if (Array.isArray(val)) {
          for (var i = 0, len = val.length; i < len; i++) {
            el.style[normalizedName] = val[i];
          }
        } else {
          el.style[normalizedName] = val;
        }
      }
    };
    var vendorNames = ["Webkit", "Moz", "ms"];
    var emptyStyle;
    var normalize = cached(function(prop) {
      emptyStyle = emptyStyle || document.createElement("div").style;
      prop = camelize(prop);
      if (prop !== "filter" && prop in emptyStyle) {
        return prop;
      }
      var capName = prop.charAt(0).toUpperCase() + prop.slice(1);
      for (var i = 0; i < vendorNames.length; i++) {
        var name = vendorNames[i] + capName;
        if (name in emptyStyle) {
          return name;
        }
      }
    });
    function updateStyle(oldVnode, vnode) {
      var data = vnode.data;
      var oldData = oldVnode.data;
      if (isUndef(data.staticStyle) && isUndef(data.style) && isUndef(oldData.staticStyle) && isUndef(oldData.style)) {
        return;
      }
      var cur, name;
      var el = vnode.elm;
      var oldStaticStyle = oldData.staticStyle;
      var oldStyleBinding = oldData.normalizedStyle || oldData.style || {};
      var oldStyle = oldStaticStyle || oldStyleBinding;
      var style2 = normalizeStyleBinding(vnode.data.style) || {};
      vnode.data.normalizedStyle = isDef(style2.__ob__) ? extend({}, style2) : style2;
      var newStyle = getStyle(vnode, true);
      for (name in oldStyle) {
        if (isUndef(newStyle[name])) {
          setProp(el, name, "");
        }
      }
      for (name in newStyle) {
        cur = newStyle[name];
        if (cur !== oldStyle[name]) {
          setProp(el, name, cur == null ? "" : cur);
        }
      }
    }
    var style = {
      create: updateStyle,
      update: updateStyle
    };
    var whitespaceRE = /\s+/;
    function addClass(el, cls) {
      if (!cls || !(cls = cls.trim())) {
        return;
      }
      if (el.classList) {
        if (cls.indexOf(" ") > -1) {
          cls.split(whitespaceRE).forEach(function(c) {
            return el.classList.add(c);
          });
        } else {
          el.classList.add(cls);
        }
      } else {
        var cur = " " + (el.getAttribute("class") || "") + " ";
        if (cur.indexOf(" " + cls + " ") < 0) {
          el.setAttribute("class", (cur + cls).trim());
        }
      }
    }
    function removeClass(el, cls) {
      if (!cls || !(cls = cls.trim())) {
        return;
      }
      if (el.classList) {
        if (cls.indexOf(" ") > -1) {
          cls.split(whitespaceRE).forEach(function(c) {
            return el.classList.remove(c);
          });
        } else {
          el.classList.remove(cls);
        }
        if (!el.classList.length) {
          el.removeAttribute("class");
        }
      } else {
        var cur = " " + (el.getAttribute("class") || "") + " ";
        var tar = " " + cls + " ";
        while (cur.indexOf(tar) >= 0) {
          cur = cur.replace(tar, " ");
        }
        cur = cur.trim();
        if (cur) {
          el.setAttribute("class", cur);
        } else {
          el.removeAttribute("class");
        }
      }
    }
    function resolveTransition(def$$1) {
      if (!def$$1) {
        return;
      }
      if (typeof def$$1 === "object") {
        var res = {};
        if (def$$1.css !== false) {
          extend(res, autoCssTransition(def$$1.name || "v"));
        }
        extend(res, def$$1);
        return res;
      } else if (typeof def$$1 === "string") {
        return autoCssTransition(def$$1);
      }
    }
    var autoCssTransition = cached(function(name) {
      return {
        enterClass: name + "-enter",
        enterToClass: name + "-enter-to",
        enterActiveClass: name + "-enter-active",
        leaveClass: name + "-leave",
        leaveToClass: name + "-leave-to",
        leaveActiveClass: name + "-leave-active"
      };
    });
    var TRANSITION = "transition";
    var ANIMATION = "animation";
    var transitionProp = "transition";
    var transitionEndEvent = "transitionend";
    var animationProp = "animation";
    var animationEndEvent = "animationend";
    var raf = function(fn) {
      return fn();
    };
    function nextFrame(fn) {
      raf(function() {
        raf(fn);
      });
    }
    function addTransitionClass(el, cls) {
      var transitionClasses = el._transitionClasses || (el._transitionClasses = []);
      if (transitionClasses.indexOf(cls) < 0) {
        transitionClasses.push(cls);
        addClass(el, cls);
      }
    }
    function removeTransitionClass(el, cls) {
      if (el._transitionClasses) {
        remove(el._transitionClasses, cls);
      }
      removeClass(el, cls);
    }
    function whenTransitionEnds(el, expectedType, cb) {
      var ref2 = getTransitionInfo(el, expectedType);
      var type = ref2.type;
      var timeout = ref2.timeout;
      var propCount = ref2.propCount;
      if (!type) {
        return cb();
      }
      var event = type === TRANSITION ? transitionEndEvent : animationEndEvent;
      var ended = 0;
      var end = function() {
        el.removeEventListener(event, onEnd);
        cb();
      };
      var onEnd = function(e) {
        if (e.target === el) {
          if (++ended >= propCount) {
            end();
          }
        }
      };
      setTimeout(function() {
        if (ended < propCount) {
          end();
        }
      }, timeout + 1);
      el.addEventListener(event, onEnd);
    }
    var transformRE = /\b(transform|all)(,|$)/;
    function getTransitionInfo(el, expectedType) {
      var styles = window.getComputedStyle(el);
      var transitionDelays = (styles[transitionProp + "Delay"] || "").split(", ");
      var transitionDurations = (styles[transitionProp + "Duration"] || "").split(", ");
      var transitionTimeout = getTimeout(transitionDelays, transitionDurations);
      var animationDelays = (styles[animationProp + "Delay"] || "").split(", ");
      var animationDurations = (styles[animationProp + "Duration"] || "").split(", ");
      var animationTimeout = getTimeout(animationDelays, animationDurations);
      var type;
      var timeout = 0;
      var propCount = 0;
      if (expectedType === TRANSITION) {
        if (transitionTimeout > 0) {
          type = TRANSITION;
          timeout = transitionTimeout;
          propCount = transitionDurations.length;
        }
      } else if (expectedType === ANIMATION) {
        if (animationTimeout > 0) {
          type = ANIMATION;
          timeout = animationTimeout;
          propCount = animationDurations.length;
        }
      } else {
        timeout = Math.max(transitionTimeout, animationTimeout);
        type = timeout > 0 ? transitionTimeout > animationTimeout ? TRANSITION : ANIMATION : null;
        propCount = type ? type === TRANSITION ? transitionDurations.length : animationDurations.length : 0;
      }
      var hasTransform = type === TRANSITION && transformRE.test(styles[transitionProp + "Property"]);
      return {
        type,
        timeout,
        propCount,
        hasTransform
      };
    }
    function getTimeout(delays, durations) {
      while (delays.length < durations.length) {
        delays = delays.concat(delays);
      }
      return Math.max.apply(null, durations.map(function(d, i) {
        return toMs(d) + toMs(delays[i]);
      }));
    }
    function toMs(s) {
      return Number(s.slice(0, -1).replace(",", ".")) * 1e3;
    }
    function enter(vnode, toggleDisplay) {
      var el = vnode.elm;
      if (isDef(el._leaveCb)) {
        el._leaveCb.cancelled = true;
        el._leaveCb();
      }
      var data = resolveTransition(vnode.data.transition);
      if (isUndef(data)) {
        return;
      }
      if (isDef(el._enterCb) || el.nodeType !== 1) {
        return;
      }
      var css = data.css;
      var type = data.type;
      var enterClass = data.enterClass;
      var enterToClass = data.enterToClass;
      var enterActiveClass = data.enterActiveClass;
      var appearClass = data.appearClass;
      var appearToClass = data.appearToClass;
      var appearActiveClass = data.appearActiveClass;
      var beforeEnter = data.beforeEnter;
      var enter2 = data.enter;
      var afterEnter = data.afterEnter;
      var enterCancelled = data.enterCancelled;
      var beforeAppear = data.beforeAppear;
      var appear = data.appear;
      var afterAppear = data.afterAppear;
      var appearCancelled = data.appearCancelled;
      var duration = data.duration;
      var context = activeInstance;
      var transitionNode = activeInstance.$vnode;
      while (transitionNode && transitionNode.parent) {
        context = transitionNode.context;
        transitionNode = transitionNode.parent;
      }
      var isAppear = !context._isMounted || !vnode.isRootInsert;
      if (isAppear && !appear && appear !== "") {
        return;
      }
      var startClass = isAppear && appearClass ? appearClass : enterClass;
      var activeClass = isAppear && appearActiveClass ? appearActiveClass : enterActiveClass;
      var toClass = isAppear && appearToClass ? appearToClass : enterToClass;
      var beforeEnterHook = isAppear ? beforeAppear || beforeEnter : beforeEnter;
      var enterHook = isAppear ? typeof appear === "function" ? appear : enter2 : enter2;
      var afterEnterHook = isAppear ? afterAppear || afterEnter : afterEnter;
      var enterCancelledHook = isAppear ? appearCancelled || enterCancelled : enterCancelled;
      var explicitEnterDuration = toNumber(isObject(duration) ? duration.enter : duration);
      var expectsCSS = css !== false && !isIE9;
      var userWantsControl = getHookArgumentsLength(enterHook);
      var cb = el._enterCb = once(function() {
        if (expectsCSS) {
          removeTransitionClass(el, toClass);
          removeTransitionClass(el, activeClass);
        }
        if (cb.cancelled) {
          if (expectsCSS) {
            removeTransitionClass(el, startClass);
          }
          enterCancelledHook && enterCancelledHook(el);
        } else {
          afterEnterHook && afterEnterHook(el);
        }
        el._enterCb = null;
      });
      if (!vnode.data.show) {
        mergeVNodeHook(vnode, "insert", function() {
          var parent = el.parentNode;
          var pendingNode = parent && parent._pending && parent._pending[vnode.key];
          if (pendingNode && pendingNode.tag === vnode.tag && pendingNode.elm._leaveCb) {
            pendingNode.elm._leaveCb();
          }
          enterHook && enterHook(el, cb);
        });
      }
      beforeEnterHook && beforeEnterHook(el);
      if (expectsCSS) {
        addTransitionClass(el, startClass);
        addTransitionClass(el, activeClass);
        nextFrame(function() {
          removeTransitionClass(el, startClass);
          if (!cb.cancelled) {
            addTransitionClass(el, toClass);
            if (!userWantsControl) {
              if (isValidDuration(explicitEnterDuration)) {
                setTimeout(cb, explicitEnterDuration);
              } else {
                whenTransitionEnds(el, type, cb);
              }
            }
          }
        });
      }
      if (vnode.data.show) {
        toggleDisplay && toggleDisplay();
        enterHook && enterHook(el, cb);
      }
      if (!expectsCSS && !userWantsControl) {
        cb();
      }
    }
    function leave(vnode, rm) {
      var el = vnode.elm;
      if (isDef(el._enterCb)) {
        el._enterCb.cancelled = true;
        el._enterCb();
      }
      var data = resolveTransition(vnode.data.transition);
      if (isUndef(data) || el.nodeType !== 1) {
        return rm();
      }
      if (isDef(el._leaveCb)) {
        return;
      }
      var css = data.css;
      var type = data.type;
      var leaveClass = data.leaveClass;
      var leaveToClass = data.leaveToClass;
      var leaveActiveClass = data.leaveActiveClass;
      var beforeLeave = data.beforeLeave;
      var leave2 = data.leave;
      var afterLeave = data.afterLeave;
      var leaveCancelled = data.leaveCancelled;
      var delayLeave = data.delayLeave;
      var duration = data.duration;
      var expectsCSS = css !== false && !isIE9;
      var userWantsControl = getHookArgumentsLength(leave2);
      var explicitLeaveDuration = toNumber(isObject(duration) ? duration.leave : duration);
      var cb = el._leaveCb = once(function() {
        if (el.parentNode && el.parentNode._pending) {
          el.parentNode._pending[vnode.key] = null;
        }
        if (expectsCSS) {
          removeTransitionClass(el, leaveToClass);
          removeTransitionClass(el, leaveActiveClass);
        }
        if (cb.cancelled) {
          if (expectsCSS) {
            removeTransitionClass(el, leaveClass);
          }
          leaveCancelled && leaveCancelled(el);
        } else {
          rm();
          afterLeave && afterLeave(el);
        }
        el._leaveCb = null;
      });
      if (delayLeave) {
        delayLeave(performLeave);
      } else {
        performLeave();
      }
      function performLeave() {
        if (cb.cancelled) {
          return;
        }
        if (!vnode.data.show && el.parentNode) {
          (el.parentNode._pending || (el.parentNode._pending = {}))[vnode.key] = vnode;
        }
        beforeLeave && beforeLeave(el);
        if (expectsCSS) {
          addTransitionClass(el, leaveClass);
          addTransitionClass(el, leaveActiveClass);
          nextFrame(function() {
            removeTransitionClass(el, leaveClass);
            if (!cb.cancelled) {
              addTransitionClass(el, leaveToClass);
              if (!userWantsControl) {
                if (isValidDuration(explicitLeaveDuration)) {
                  setTimeout(cb, explicitLeaveDuration);
                } else {
                  whenTransitionEnds(el, type, cb);
                }
              }
            }
          });
        }
        leave2 && leave2(el, cb);
        if (!expectsCSS && !userWantsControl) {
          cb();
        }
      }
    }
    function isValidDuration(val) {
      return typeof val === "number" && !isNaN(val);
    }
    function getHookArgumentsLength(fn) {
      if (isUndef(fn)) {
        return false;
      }
      var invokerFns = fn.fns;
      if (isDef(invokerFns)) {
        return getHookArgumentsLength(Array.isArray(invokerFns) ? invokerFns[0] : invokerFns);
      } else {
        return (fn._length || fn.length) > 1;
      }
    }
    var transition = {};
    var platformModules = [attrs, klass, events, domProps, style, transition];
    var modules = platformModules.concat(baseModules);
    createPatchFunction({
      nodeOps,
      modules
    });
    var directive = {
      inserted: function inserted(el, binding, vnode, oldVnode) {
        if (vnode.tag === "select") {
          if (oldVnode.elm && !oldVnode.elm._vOptions) {
            mergeVNodeHook(vnode, "postpatch", function() {
              directive.componentUpdated(el, binding, vnode);
            });
          } else {
            setSelected(el, binding, vnode.context);
          }
          el._vOptions = [].map.call(el.options, getValue);
        } else if (vnode.tag === "textarea" || isTextInputType(el.type)) {
          el._vModifiers = binding.modifiers;
          if (!binding.modifiers.lazy) {
            el.addEventListener("compositionstart", onCompositionStart);
            el.addEventListener("compositionend", onCompositionEnd);
            el.addEventListener("change", onCompositionEnd);
          }
        }
      },
      componentUpdated: function componentUpdated(el, binding, vnode) {
        if (vnode.tag === "select") {
          setSelected(el, binding, vnode.context);
          var prevOptions = el._vOptions;
          var curOptions = el._vOptions = [].map.call(el.options, getValue);
          if (curOptions.some(function(o, i) {
            return !looseEqual(o, prevOptions[i]);
          })) {
            var needReset = el.multiple ? binding.value.some(function(v) {
              return hasNoMatchingOption(v, curOptions);
            }) : binding.value !== binding.oldValue && hasNoMatchingOption(binding.value, curOptions);
            if (needReset) {
              trigger(el, "change");
            }
          }
        }
      }
    };
    function setSelected(el, binding, vm) {
      actuallySetSelected(el, binding);
    }
    function actuallySetSelected(el, binding, vm) {
      var value = binding.value;
      var isMultiple = el.multiple;
      if (isMultiple && !Array.isArray(value)) {
        return;
      }
      var selected, option;
      for (var i = 0, l = el.options.length; i < l; i++) {
        option = el.options[i];
        if (isMultiple) {
          selected = looseIndexOf(value, getValue(option)) > -1;
          if (option.selected !== selected) {
            option.selected = selected;
          }
        } else {
          if (looseEqual(getValue(option), value)) {
            if (el.selectedIndex !== i) {
              el.selectedIndex = i;
            }
            return;
          }
        }
      }
      if (!isMultiple) {
        el.selectedIndex = -1;
      }
    }
    function hasNoMatchingOption(value, options) {
      return options.every(function(o) {
        return !looseEqual(o, value);
      });
    }
    function getValue(option) {
      return "_value" in option ? option._value : option.value;
    }
    function onCompositionStart(e) {
      e.target.composing = true;
    }
    function onCompositionEnd(e) {
      if (!e.target.composing) {
        return;
      }
      e.target.composing = false;
      trigger(e.target, "input");
    }
    function trigger(el, type) {
      var e = document.createEvent("HTMLEvents");
      e.initEvent(type, true, true);
      el.dispatchEvent(e);
    }
    function locateNode(vnode) {
      return vnode.componentInstance && (!vnode.data || !vnode.data.transition) ? locateNode(vnode.componentInstance._vnode) : vnode;
    }
    var show = {
      bind: function bind2(el, ref2, vnode) {
        var value = ref2.value;
        vnode = locateNode(vnode);
        var transition$$1 = vnode.data && vnode.data.transition;
        var originalDisplay = el.__vOriginalDisplay = el.style.display === "none" ? "" : el.style.display;
        if (value && transition$$1) {
          vnode.data.show = true;
          enter(vnode, function() {
            el.style.display = originalDisplay;
          });
        } else {
          el.style.display = value ? originalDisplay : "none";
        }
      },
      update: function update(el, ref2, vnode) {
        var value = ref2.value;
        var oldValue = ref2.oldValue;
        if (!value === !oldValue) {
          return;
        }
        vnode = locateNode(vnode);
        var transition$$1 = vnode.data && vnode.data.transition;
        if (transition$$1) {
          vnode.data.show = true;
          if (value) {
            enter(vnode, function() {
              el.style.display = el.__vOriginalDisplay;
            });
          } else {
            leave(vnode, function() {
              el.style.display = "none";
            });
          }
        } else {
          el.style.display = value ? el.__vOriginalDisplay : "none";
        }
      },
      unbind: function unbind(el, binding, vnode, oldVnode, isDestroy) {
        if (!isDestroy) {
          el.style.display = el.__vOriginalDisplay;
        }
      }
    };
    var platformDirectives = {
      model: directive,
      show
    };
    var transitionProps = {
      name: String,
      appear: Boolean,
      css: Boolean,
      mode: String,
      type: String,
      enterClass: String,
      leaveClass: String,
      enterToClass: String,
      leaveToClass: String,
      enterActiveClass: String,
      leaveActiveClass: String,
      appearClass: String,
      appearActiveClass: String,
      appearToClass: String,
      duration: [Number, String, Object]
    };
    function getRealChild(vnode) {
      var compOptions = vnode && vnode.componentOptions;
      if (compOptions && compOptions.Ctor.options.abstract) {
        return getRealChild(getFirstComponentChild(compOptions.children));
      } else {
        return vnode;
      }
    }
    function extractTransitionData(comp) {
      var data = {};
      var options = comp.$options;
      for (var key in options.propsData) {
        data[key] = comp[key];
      }
      var listeners = options._parentListeners;
      for (var key$1 in listeners) {
        data[camelize(key$1)] = listeners[key$1];
      }
      return data;
    }
    function placeholder(h, rawChild) {
      if (/\d-keep-alive$/.test(rawChild.tag)) {
        return h("keep-alive", {
          props: rawChild.componentOptions.propsData
        });
      }
    }
    function hasParentTransition(vnode) {
      while (vnode = vnode.parent) {
        if (vnode.data.transition) {
          return true;
        }
      }
    }
    function isSameChild(child, oldChild) {
      return oldChild.key === child.key && oldChild.tag === child.tag;
    }
    var isNotTextNode = function(c) {
      return c.tag || isAsyncPlaceholder(c);
    };
    var isVShowDirective = function(d) {
      return d.name === "show";
    };
    var Transition = {
      name: "transition",
      props: transitionProps,
      abstract: true,
      render: function render(h) {
        var this$1$1 = this;
        var children = this.$slots.default;
        if (!children) {
          return;
        }
        children = children.filter(isNotTextNode);
        if (!children.length) {
          return;
        }
        var mode = this.mode;
        var rawChild = children[0];
        if (hasParentTransition(this.$vnode)) {
          return rawChild;
        }
        var child = getRealChild(rawChild);
        if (!child) {
          return rawChild;
        }
        if (this._leaving) {
          return placeholder(h, rawChild);
        }
        var id = "__transition-" + this._uid + "-";
        child.key = child.key == null ? child.isComment ? id + "comment" : id + child.tag : isPrimitive(child.key) ? String(child.key).indexOf(id) === 0 ? child.key : id + child.key : child.key;
        var data = (child.data || (child.data = {})).transition = extractTransitionData(this);
        var oldRawChild = this._vnode;
        var oldChild = getRealChild(oldRawChild);
        if (child.data.directives && child.data.directives.some(isVShowDirective)) {
          child.data.show = true;
        }
        if (oldChild && oldChild.data && !isSameChild(child, oldChild) && !isAsyncPlaceholder(oldChild) && !(oldChild.componentInstance && oldChild.componentInstance._vnode.isComment)) {
          var oldData = oldChild.data.transition = extend({}, data);
          if (mode === "out-in") {
            this._leaving = true;
            mergeVNodeHook(oldData, "afterLeave", function() {
              this$1$1._leaving = false;
              this$1$1.$forceUpdate();
            });
            return placeholder(h, rawChild);
          } else if (mode === "in-out") {
            if (isAsyncPlaceholder(child)) {
              return oldRawChild;
            }
            var delayedLeave;
            var performLeave = function() {
              delayedLeave();
            };
            mergeVNodeHook(data, "afterEnter", performLeave);
            mergeVNodeHook(data, "enterCancelled", performLeave);
            mergeVNodeHook(oldData, "delayLeave", function(leave2) {
              delayedLeave = leave2;
            });
          }
        }
        return rawChild;
      }
    };
    var props = extend({
      tag: String,
      moveClass: String
    }, transitionProps);
    delete props.mode;
    var TransitionGroup = {
      props,
      beforeMount: function beforeMount() {
        var this$1$1 = this;
        var update = this._update;
        this._update = function(vnode, hydrating) {
          var restoreActiveInstance = setActiveInstance(this$1$1);
          this$1$1.__patch__(this$1$1._vnode, this$1$1.kept, false, true);
          this$1$1._vnode = this$1$1.kept;
          restoreActiveInstance();
          update.call(this$1$1, vnode, hydrating);
        };
      },
      render: function render(h) {
        var tag = this.tag || this.$vnode.data.tag || "span";
        var map = Object.create(null);
        var prevChildren = this.prevChildren = this.children;
        var rawChildren = this.$slots.default || [];
        var children = this.children = [];
        var transitionData = extractTransitionData(this);
        for (var i = 0; i < rawChildren.length; i++) {
          var c = rawChildren[i];
          if (c.tag) {
            if (c.key != null && String(c.key).indexOf("__vlist") !== 0) {
              children.push(c);
              map[c.key] = c;
              (c.data || (c.data = {})).transition = transitionData;
            }
          }
        }
        if (prevChildren) {
          var kept = [];
          var removed = [];
          for (var i$1 = 0; i$1 < prevChildren.length; i$1++) {
            var c$1 = prevChildren[i$1];
            c$1.data.transition = transitionData;
            c$1.data.pos = c$1.elm.getBoundingClientRect();
            if (map[c$1.key]) {
              kept.push(c$1);
            } else {
              removed.push(c$1);
            }
          }
          this.kept = h(tag, null, kept);
          this.removed = removed;
        }
        return h(tag, null, children);
      },
      updated: function updated() {
        var children = this.prevChildren;
        var moveClass = this.moveClass || (this.name || "v") + "-move";
        if (!children.length || !this.hasMove(children[0].elm, moveClass)) {
          return;
        }
        children.forEach(callPendingCbs);
        children.forEach(recordPosition);
        children.forEach(applyTranslation);
        this._reflow = document.body.offsetHeight;
        children.forEach(function(c) {
          if (c.data.moved) {
            var el = c.elm;
            var s = el.style;
            addTransitionClass(el, moveClass);
            s.transform = s.WebkitTransform = s.transitionDuration = "";
            el.addEventListener(transitionEndEvent, el._moveCb = function cb(e) {
              if (e && e.target !== el) {
                return;
              }
              if (!e || /transform$/.test(e.propertyName)) {
                el.removeEventListener(transitionEndEvent, cb);
                el._moveCb = null;
                removeTransitionClass(el, moveClass);
              }
            });
          }
        });
      },
      methods: {
        hasMove: function hasMove(el, moveClass) {
          {
            return false;
          }
        }
      }
    };
    function callPendingCbs(c) {
      if (c.elm._moveCb) {
        c.elm._moveCb();
      }
      if (c.elm._enterCb) {
        c.elm._enterCb();
      }
    }
    function recordPosition(c) {
      c.data.newPos = c.elm.getBoundingClientRect();
    }
    function applyTranslation(c) {
      var oldPos = c.data.pos;
      var newPos = c.data.newPos;
      var dx = oldPos.left - newPos.left;
      var dy = oldPos.top - newPos.top;
      if (dx || dy) {
        c.data.moved = true;
        var s = c.elm.style;
        s.transform = s.WebkitTransform = "translate(" + dx + "px," + dy + "px)";
        s.transitionDuration = "0s";
      }
    }
    var platformComponents = {
      Transition,
      TransitionGroup
    };
    Vue.config.mustUseProp = mustUseProp;
    Vue.config.isReservedTag = isReservedTag;
    Vue.config.isReservedAttr = isReservedAttr;
    Vue.config.getTagNamespace = getTagNamespace;
    Vue.config.isUnknownElement = isUnknownElement;
    extend(Vue.options.directives, platformDirectives);
    extend(Vue.options.components, platformComponents);
    Vue.prototype.__patch__ = noop;
    Vue.prototype.$mount = function(el, hydrating) {
      el = el && inBrowser ? query(el) : void 0;
      return mountComponent(this, el, hydrating);
    };
    var vue_runtime_esm = Vue;
    var vue_composition_api = __webpack_require__(0);
    const isFunction = (fn) => fn instanceof Function;
    const Vue2 = vue_runtime_esm;
    const isVue2 = true;
    const isVue3 = false;
    const install = () => {
    };
    const version = vue_runtime_esm.version;
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.d(__webpack_exports__, "a", function() {
      return normalizeComponent;
    });
    function normalizeComponent(scriptExports, render, staticRenderFns, functionalTemplate, injectStyles, scopeId, moduleIdentifier, shadowMode) {
      var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
      if (render) {
        options.render = render;
        options.staticRenderFns = staticRenderFns;
        options._compiled = true;
      }
      if (functionalTemplate) {
        options.functional = true;
      }
      if (scopeId) {
        options._scopeId = "data-v-" + scopeId;
      }
      var hook;
      if (moduleIdentifier) {
        hook = function(context) {
          context = context || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext;
          if (!context && typeof __VUE_SSR_CONTEXT__ !== "undefined") {
            context = __VUE_SSR_CONTEXT__;
          }
          if (injectStyles) {
            injectStyles.call(this, context);
          }
          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        };
        options._ssrRegister = hook;
      } else if (injectStyles) {
        hook = shadowMode ? function() {
          injectStyles.call(this, (options.functional ? this.parent : this).$root.$options.shadowRoot);
        } : injectStyles;
      }
      if (hook) {
        if (options.functional) {
          options._injectStyles = hook;
          var originalRender = options.render;
          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }
      return {
        exports: scriptExports,
        options
      };
    }
  },
  function(module2, exports) {
    module2.exports = require$$0;
  },
  function(module2, exports, __webpack_require__) {
    module2.exports = function(cssWithMappingToString) {
      var list = [];
      list.toString = function toString() {
        return this.map(function(item) {
          var content = cssWithMappingToString(item);
          if (item[2]) {
            return "@media ".concat(item[2], " {").concat(content, "}");
          }
          return content;
        }).join("");
      };
      list.i = function(modules, mediaQuery, dedupe) {
        if (typeof modules === "string") {
          modules = [[null, modules, ""]];
        }
        var alreadyImportedModules = {};
        if (dedupe) {
          for (var i = 0; i < this.length; i++) {
            var id = this[i][0];
            if (id != null) {
              alreadyImportedModules[id] = true;
            }
          }
        }
        for (var _i = 0; _i < modules.length; _i++) {
          var item = [].concat(modules[_i]);
          if (dedupe && alreadyImportedModules[item[0]]) {
            continue;
          }
          if (mediaQuery) {
            if (!item[2]) {
              item[2] = mediaQuery;
            } else {
              item[2] = "".concat(mediaQuery, " and ").concat(item[2]);
            }
          }
          list.push(item);
        }
      };
      return list;
    };
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    __webpack_require__.d(__webpack_exports__, "default", function() {
      return addStylesServer;
    });
    function listToStyles(parentId, list) {
      var styles = [];
      var newStyles = {};
      for (var i = 0; i < list.length; i++) {
        var item = list[i];
        var id = item[0];
        var css = item[1];
        var media = item[2];
        var sourceMap = item[3];
        var part = {
          id: parentId + ":" + i,
          css,
          media,
          sourceMap
        };
        if (!newStyles[id]) {
          styles.push(newStyles[id] = {
            id,
            parts: [part]
          });
        } else {
          newStyles[id].parts.push(part);
        }
      }
      return styles;
    }
    function addStylesServer(parentId, list, isProduction, context) {
      if (!context && typeof __VUE_SSR_CONTEXT__ !== "undefined") {
        context = __VUE_SSR_CONTEXT__;
      }
      if (context) {
        if (!context.hasOwnProperty("styles")) {
          Object.defineProperty(context, "styles", {
            enumerable: true,
            get: function() {
              return renderStyles(context._styles);
            }
          });
          context._renderStyles = renderStyles;
        }
        var styles = context._styles || (context._styles = {});
        list = listToStyles(parentId, list);
        if (isProduction) {
          addStyleProd(styles, list);
        } else {
          addStyleDev(styles, list);
        }
      }
    }
    function addStyleProd(styles, list) {
      for (var i = 0; i < list.length; i++) {
        var parts = list[i].parts;
        for (var j = 0; j < parts.length; j++) {
          var part = parts[j];
          var id = part.media || "default";
          var style = styles[id];
          if (style) {
            if (style.ids.indexOf(part.id) < 0) {
              style.ids.push(part.id);
              style.css += "\n" + part.css;
            }
          } else {
            styles[id] = {
              ids: [part.id],
              css: part.css,
              media: part.media
            };
          }
        }
      }
    }
    function addStyleDev(styles, list) {
      for (var i = 0; i < list.length; i++) {
        var parts = list[i].parts;
        for (var j = 0; j < parts.length; j++) {
          var part = parts[j];
          styles[part.id] = {
            ids: [part.id],
            css: part.css,
            media: part.media
          };
        }
      }
    }
    function renderStyles(styles) {
      var css = "";
      for (var key in styles) {
        var style = styles[key];
        css += '<style data-vue-ssr-id="' + style.ids.join(" ") + '"' + (style.media ? ' media="' + style.media + '"' : "") + ">" + style.css + "</style>";
      }
      return css;
    }
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.d(__webpack_exports__, "b", function() {
      return setNuxtAppInstance;
    });
    __webpack_require__.d(__webpack_exports__, "a", function() {
      return defineNuxtPlugin;
    });
    __webpack_require__.d(__webpack_exports__, "c", function() {
      return useNuxtApp;
    });
    var vue_composition_api = __webpack_require__(0);
    __webpack_require__(1);
    __webpack_require__(66);
    __webpack_require__(23);
    __webpack_require__(67);
    __webpack_require__(68);
    vue_composition_api["h"];
    let currentNuxtAppInstance;
    const setNuxtAppInstance = (nuxt) => {
      currentNuxtAppInstance = nuxt;
    };
    function defineNuxtPlugin(plugin) {
      return (ctx) => {
        setNuxtAppInstance(ctx.$_nuxtApp);
        plugin(ctx.$_nuxtApp);
        setNuxtAppInstance(null);
      };
    }
    const useNuxtApp = () => {
      const vm = Object(vue_composition_api["k"])();
      if (!vm) {
        if (!currentNuxtAppInstance) {
          throw new Error("nuxt app instance unavailable");
        }
        return currentNuxtAppInstance;
      }
      return vm.proxy.$_nuxtApp;
    };
  },
  function(module2, exports, __webpack_require__) {
    module2.exports = function(url, options) {
      if (!options) {
        options = {};
      }
      url = url && url.__esModule ? url.default : url;
      if (typeof url !== "string") {
        return url;
      }
      if (/^['"].*['"]$/.test(url)) {
        url = url.slice(1, -1);
      }
      if (options.hash) {
        url += options.hash;
      }
      if (/["'() \t\n]/.test(url) || options.needQuotes) {
        return '"'.concat(url.replace(/"/g, '\\"').replace(/\n/g, "\\n"), '"');
      }
      return url;
    };
  },
  function(module2, exports) {
    module2.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjEiIHZpZXdCb3g9IjAgMCAyMCAyMSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0xNi45MjI2IDguMzYzNjJDMTYuOTIyNiAxMi4xMDc2IDEyLjUyMjYgMTcuMDU5NiAxMC45NDU3IDE4LjcyNTNDMTAuNjQ1NyAxOS4wNDA0IDEwLjEzMDMgMTkuMDQwNCA5LjgyMjY1IDE4LjcyNTNDOC4yMzgwMyAxNy4wNjcxIDMuODM4MDIgMTIuMTMwMSAzLjg0NTcxIDguMzYzNjJDMy44NDU3MSA0Ljg2NzIxIDYuNzc2NDggMi4wMzg1NyAxMC4zODQyIDIuMDM4NTdDMTMuOTkxOSAyLjAzODU3IDE2LjkyMjYgNC44NzQ3MSAxNi45MjI2IDguMzYzNjJaIiBzdHJva2U9IiM4MjgyODIiIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+DQo8cGF0aCBkPSJNMTAuMzgzNiAxMS43MDc4QzEyLjA4MjkgMTEuNzA3OCAxMy40NjA1IDEwLjMzMDIgMTMuNDYwNSA4LjYzMDg4QzEzLjQ2MDUgNi45MzE1NCAxMi4wODI5IDUuNTUzOTYgMTAuMzgzNiA1LjU1Mzk2QzguNjg0MjMgNS41NTM5NiA3LjMwNjY0IDYuOTMxNTQgNy4zMDY2NCA4LjYzMDg4QzcuMzA2NjQgMTAuMzMwMiA4LjY4NDIzIDExLjcwNzggMTAuMzgzNiAxMS43MDc4WiIgc3Ryb2tlPSIjODI4MjgyIiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPg0KPC9zdmc+DQo=";
  },
  function(module2, exports, __webpack_require__) {
    module2.exports = __webpack_require__.p + "img/call.5036bc5.svg";
  },
  function(module2, exports) {
    module2.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjEiIHZpZXdCb3g9IjAgMCAyMCAyMSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0xNC41MjE3IDE0LjgyNkgxNy4zMTEzQzE3LjY5MzkgMTQuODI2IDE4IDE0LjQ5OSAxOCAxNC4xMDI1VjguOTgyNDlDMTggOC43MTExOCAxNy45MTY1IDguNDM5ODkgMTcuNzcwNCA4LjIxMDMyTDE2LjYxNTcgNi40NzExOUgzLjM5MTNMMi4yMzY1MiA4LjIxMDMyQzIuMDgzNDggOC40Mzk4OSAyIDguNzA0MjMgMiA4Ljk4MjQ5VjE0LjA5NTZDMiAxNC40OTIxIDIuMzEzMDQgMTQuODE5IDIuNjg4NjkgMTQuODE5SDUuNDc4MjYiIHN0cm9rZT0iIzgyODI4MiIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz4NCjxwYXRoIGQ9Ik0xNC41MjIgM0g1LjQ3ODUyVjYuNDc4MjZIMTQuNTIyVjNaIiBzdHJva2U9IiM4MjgyODIiIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+DQo8cGF0aCBkPSJNMTQuNTIyIDEyLjczOTNINS40Nzg1MlYxOS4wMDAxSDE0LjUyMlYxMi43MzkzWiIgc3Ryb2tlPSIjODI4MjgyIiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPg0KPHBhdGggZD0iTTQuMDg3ODkgMTIuNzM5M0gxNS45MTQiIHN0cm9rZT0iIzgyODI4MiIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz4NCjwvc3ZnPg0K";
  },
  function(module2, exports) {
    module2.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjEiIHZpZXdCb3g9IjAgMCAyMCAyMSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0xNy45OTk3IDUuMTgyMTNWMTUuMzYzOEMxNy45OTk3IDE2LjE2MzggMTcuMzQ1MiAxNi44MTgzIDE2LjU0NTIgMTYuODE4M0gzLjQ1NDUyQzIuNjU0NTMgMTYuODE4MyAyIDE2LjE2MzggMiAxNS4zNjM4VjUuMTgyMTMiIHN0cm9rZT0iIzgyODI4MiIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz4NCjxwYXRoIGQ9Ik0xOC4wMDAzIDUuMTgyMTNMMTAuODU4NiAxMS4xMDJDMTAuMzQ5NSAxMS40NzI5IDkuNjU4NiAxMS40NzI5IDkuMTQ5NTIgMTEuMTAyTDIuMDA3ODEgNS4xODIxM0gxOC4wMDAzWiIgc3Ryb2tlPSIjODI4MjgyIiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPg0KPHBhdGggZD0iTTIgNS4xODIxM0gxNy45OTk3IiBzdHJva2U9IiM4MjgyODIiIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+DQo8L3N2Zz4NCg==";
  },
  function(module2, exports, __webpack_require__) {
    module2.exports = __webpack_require__.p + "img/train.3020f72.svg";
  },
  function(module2, exports, __webpack_require__) {
    module2.exports = __webpack_require__.p + "img/bus.97cd89d.svg";
  },
  function(module2, exports) {
    module2.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0zMS41IDE2QzMxLjUgMjQuNTYwNCAyNC41NjA0IDMxLjUgMTYgMzEuNUM3LjQzOTU5IDMxLjUgMC41IDI0LjU2MDQgMC41IDE2QzAuNSA3LjQzOTU5IDcuNDM5NTkgMC41IDE2IDAuNUMyNC41NjA0IDAuNSAzMS41IDcuNDM5NTkgMzEuNSAxNloiIHN0cm9rZT0id2hpdGUiLz4NCjxwYXRoIGQ9Ik0xOC45Nzc0IDE2LjgxNTVMMTkuMzY0NCAxNC4zMDFIMTYuOTQzN1YxMi42Njk5QzE2Ljk0MzcgMTEuOTgyIDE3LjI4MTkgMTEuMzEwNyAxOC4zNjYxIDExLjMxMDdIMTkuNDY2N1Y5LjE2OTlDMTkuNDY2NyA5LjE2OTkgMTguNDY3OSA5IDE3LjUxMjkgOUMxNS41MTkyIDkgMTQuMjE2MSAxMC4yMDQzIDE0LjIxNjEgMTIuMzg0NVYxNC4zMDFIMTJWMTYuODE1NUgxNC4yMTYxVjIyLjg5NDNDMTUuMTE5OCAyMy4wMzUyIDE2LjA0IDIzLjAzNTIgMTYuOTQzNyAyMi44OTQzVjE2LjgxNTVIMTguOTc3NFoiIGZpbGw9IndoaXRlIi8+DQo8L3N2Zz4NCg==";
  },
  function(module2, exports) {
    module2.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0zMS41IDE2QzMxLjUgMjQuNTYwNCAyNC41NjA0IDMxLjUgMTYgMzEuNUM3LjQzOTU5IDMxLjUgMC41IDI0LjU2MDQgMC41IDE2QzAuNSA3LjQzOTU5IDcuNDM5NTkgMC41IDE2IDAuNUMyNC41NjA0IDAuNSAzMS41IDcuNDM5NTkgMzEuNSAxNloiIHN0cm9rZT0id2hpdGUiLz4NCjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMTMuNTYxOCAxNS4xODZWMjFIMTEuMDE1MVYxMy42NjMySDEzLjU2MThWMTUuMTg2Wk0xMi4yODM0IDEyLjU2OTdDMTEuNTc0OSAxMi41Njk3IDExIDExLjk5NDUgMTEgMTEuMjg0NkMxMSAxMC41NzQ1IDExLjU3NDkgMTAgMTIuMjgzNCAxMEMxMi45OTI5IDEwIDEzLjU2NzIgMTAuNTc0NiAxMy41NjcyIDExLjI4NDZDMTMuNTY3MiAxMS45OTQ1IDEyLjk5MjkgMTIuNTY5NyAxMi4yODM0IDEyLjU2OTdaTTIxLjk4NTYgMTYuOTk4MVYyMUgxOS43OTE1VjE3LjQzNjNDMTkuNzkxNSAxNi41ODI5IDE5LjY5OTIgMTUuNDg1NCAxOC41MzEzIDE1LjQ4NTRDMTcuMzQ1NiAxNS40ODU0IDE3LjE2NjQgMTYuNDE0NCAxNy4xNjY0IDE3LjM3NDdWMjFIMTUuMDUwN1YxMy42NjMySDE3LjA4ODFWMTQuNjQ0MUgxNy4xMDk4QzE3LjQxMzYgMTQuMDk0OCAxOC4xNTgxIDEzLjY2MjUgMTkuMjY2NyAxMy42NjI1QzIxLjEzNDUgMTMuNjYyNSAyMS43NjkyIDE0LjU0NjkgMjEuOTQyOSAxNS45MzA3QzIxLjk4NDEgMTYuMjU1NCAyMiAxNi42MDU4IDIyIDE2Ljk5ODFIMjEuOTg1NloiIGZpbGw9IndoaXRlIi8+DQo8L3N2Zz4NCg==";
  },
  function(module2, exports) {
    module2.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4NCjxwYXRoIGQ9Ik0yLjY2NjAyIDguMDAwMDhDMi42NjYwMiA3LjI2MzcgMy4yNjI5NyA2LjY2Njc1IDMuOTk5MzUgNi42NjY3NUgyNy45OTkzQzI4LjczNTcgNi42NjY3NSAyOS4zMzI3IDcuMjYzNyAyOS4zMzI3IDguMDAwMDhDMjkuMzMyNyA4LjczNjQ2IDI4LjczNTcgOS4zMzM0MiAyNy45OTkzIDkuMzMzNDJIMy45OTkzNUMzLjI2Mjk3IDkuMzMzNDIgMi42NjYwMiA4LjczNjQ2IDIuNjY2MDIgOC4wMDAwOFoiIGZpbGw9IndoaXRlIi8+DQo8cGF0aCBkPSJNMi42NjYwMiAxNi4wNDMxQzIuNjY2MDIgMTUuMzA2NyAzLjI2Mjk3IDE0LjcwOTcgMy45OTkzNSAxNC43MDk3SDI3Ljk5OTNDMjguNzM1NyAxNC43MDk3IDI5LjMzMjcgMTUuMzA2NyAyOS4zMzI3IDE2LjA0MzFDMjkuMzMyNyAxNi43Nzk0IDI4LjczNTcgMTcuMzc2NCAyNy45OTkzIDE3LjM3NjRIMy45OTkzNUMzLjI2Mjk3IDE3LjM3NjQgMi42NjYwMiAxNi43Nzk0IDIuNjY2MDIgMTYuMDQzMVoiIGZpbGw9IndoaXRlIi8+DQo8cGF0aCBkPSJNMy45OTkzNSAyMi43NTI3QzMuMjYyOTcgMjIuNzUyNyAyLjY2NjAyIDIzLjM0OTYgMi42NjYwMiAyNC4wODZDMi42NjYwMiAyNC44MjI0IDMuMjYyOTcgMjUuNDE5NCAzLjk5OTM1IDI1LjQxOTRIMjcuOTk5M0MyOC43MzU3IDI1LjQxOTQgMjkuMzMyNyAyNC44MjI0IDI5LjMzMjcgMjQuMDg2QzI5LjMzMjcgMjMuMzQ5NiAyOC43MzU3IDIyLjc1MjcgMjcuOTk5MyAyMi43NTI3SDMuOTk5MzVaIiBmaWxsPSJ3aGl0ZSIvPg0KPC9zdmc+DQo=";
  },
  function(module2, exports) {
    module2.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjgiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyOCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTAuNjY2MDE2IDIuMDAwMDhDMC42NjYwMTYgMS4yNjM3IDEuMjYyOTcgMC42NjY3NDggMS45OTkzNSAwLjY2Njc0OEgyNS45OTkzQzI2LjczNTcgMC42NjY3NDggMjcuMzMyNyAxLjI2MzcgMjcuMzMyNyAyLjAwMDA4QzI3LjMzMjcgMi43MzY0NiAyNi43MzU3IDMuMzMzNDIgMjUuOTk5MyAzLjMzMzQySDEuOTk5MzVDMS4yNjI5NyAzLjMzMzQyIDAuNjY2MDE2IDIuNzM2NDYgMC42NjYwMTYgMi4wMDAwOFoiIGZpbGw9IiM1NzE5NUMiLz4KPHBhdGggZD0iTTAuNjY2MDE2IDEwLjA0MzFDMC42NjYwMTYgOS4zMDY2NyAxLjI2Mjk3IDguNzA5NzIgMS45OTkzNSA4LjcwOTcySDI1Ljk5OTNDMjYuNzM1NyA4LjcwOTcyIDI3LjMzMjcgOS4zMDY2NyAyNy4zMzI3IDEwLjA0MzFDMjcuMzMyNyAxMC43Nzk0IDI2LjczNTcgMTEuMzc2NCAyNS45OTkzIDExLjM3NjRIMS45OTkzNUMxLjI2Mjk3IDExLjM3NjQgMC42NjYwMTYgMTAuNzc5NCAwLjY2NjAxNiAxMC4wNDMxWiIgZmlsbD0iIzU3MTk1QyIvPgo8cGF0aCBkPSJNMS45OTkzNSAxNi43NTI3QzEuMjYyOTcgMTYuNzUyNyAwLjY2NjAxNiAxNy4zNDk2IDAuNjY2MDE2IDE4LjA4NkMwLjY2NjAxNiAxOC44MjI0IDEuMjYyOTcgMTkuNDE5NCAxLjk5OTM1IDE5LjQxOTRIMjUuOTk5M0MyNi43MzU3IDE5LjQxOTQgMjcuMzMyNyAxOC44MjI0IDI3LjMzMjcgMTguMDg2QzI3LjMzMjcgMTcuMzQ5NiAyNi43MzU3IDE2Ljc1MjcgMjUuOTk5MyAxNi43NTI3SDEuOTk5MzVaIiBmaWxsPSIjNTcxOTVDIi8+Cjwvc3ZnPgo=";
  },
  function(module2, exports) {
    module2.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyMCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTAuNDAwMzkxIDAuMzk5OTAyTDE5LjYwMDQgMTkuNTk5OU0wLjQwMDM5MSAxOS41OTk5TDE5LjYwMDQgMC4zOTk5MDIiIHN0cm9rZT0iYmxhY2siLz4KPC9zdmc+Cg==";
  },
  function(module2, exports) {
    module2.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTMxLjUgMTZDMzEuNSAyNC41NjA0IDI0LjU2MDQgMzEuNSAxNiAzMS41QzcuNDM5NTkgMzEuNSAwLjUgMjQuNTYwNCAwLjUgMTZDMC41IDcuNDM5NTkgNy40Mzk1OSAwLjUgMTYgMC41QzI0LjU2MDQgMC41IDMxLjUgNy40Mzk1OSAzMS41IDE2WiIgc3Ryb2tlPSIjMzMzMzMzIi8+CjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMTMuNTYxOCAxNS4xODZWMjFIMTEuMDE1MVYxMy42NjMySDEzLjU2MThWMTUuMTg2Wk0xMi4yODM0IDEyLjU2OTdDMTEuNTc0OSAxMi41Njk3IDExIDExLjk5NDUgMTEgMTEuMjg0NkMxMSAxMC41NzQ1IDExLjU3NDkgMTAgMTIuMjgzNCAxMEMxMi45OTI5IDEwIDEzLjU2NzIgMTAuNTc0NiAxMy41NjcyIDExLjI4NDZDMTMuNTY3MiAxMS45OTQ1IDEyLjk5MjkgMTIuNTY5NyAxMi4yODM0IDEyLjU2OTdaTTIxLjk4NTYgMTYuOTk4MVYyMUgxOS43OTE1VjE3LjQzNjNDMTkuNzkxNSAxNi41ODI5IDE5LjY5OTIgMTUuNDg1NCAxOC41MzEzIDE1LjQ4NTRDMTcuMzQ1NiAxNS40ODU0IDE3LjE2NjQgMTYuNDE0NCAxNy4xNjY0IDE3LjM3NDdWMjFIMTUuMDUwN1YxMy42NjMySDE3LjA4ODFWMTQuNjQ0MUgxNy4xMDk4QzE3LjQxMzYgMTQuMDk0OCAxOC4xNTgxIDEzLjY2MjUgMTkuMjY2NyAxMy42NjI1QzIxLjEzNDUgMTMuNjYyNSAyMS43NjkyIDE0LjU0NjkgMjEuOTQyOSAxNS45MzA3QzIxLjk4NDEgMTYuMjU1NCAyMiAxNi42MDU4IDIyIDE2Ljk5ODFIMjEuOTg1NloiIGZpbGw9IiMzMzMzMzMiLz4KPC9zdmc+Cg==";
  },
  function(module2, exports) {
    module2.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTMxLjUgMTZDMzEuNSAyNC41NjA0IDI0LjU2MDQgMzEuNSAxNiAzMS41QzcuNDM5NTkgMzEuNSAwLjUgMjQuNTYwNCAwLjUgMTZDMC41IDcuNDM5NTkgNy40Mzk1OSAwLjUgMTYgMC41QzI0LjU2MDQgMC41IDMxLjUgNy40Mzk1OSAzMS41IDE2WiIgc3Ryb2tlPSIjMzMzMzMzIi8+CjxwYXRoIGQ9Ik0xOC45Nzc0IDE2LjgxNTVMMTkuMzY0NCAxNC4zMDFIMTYuOTQzN1YxMi42Njk5QzE2Ljk0MzcgMTEuOTgyIDE3LjI4MTkgMTEuMzEwNyAxOC4zNjYxIDExLjMxMDdIMTkuNDY2N1Y5LjE2OTlDMTkuNDY2NyA5LjE2OTkgMTguNDY3OSA5IDE3LjUxMjkgOUMxNS41MTkyIDkgMTQuMjE2MSAxMC4yMDQzIDE0LjIxNjEgMTIuMzg0NVYxNC4zMDFIMTJWMTYuODE1NUgxNC4yMTYxVjIyLjg5NDNDMTUuMTE5OCAyMy4wMzUyIDE2LjA0IDIzLjAzNTIgMTYuOTQzNyAyMi44OTQzVjE2LjgxNTVIMTguOTc3NFoiIGZpbGw9IiMzMzMzMzMiLz4KPC9zdmc+Cg==";
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    (function(URLSearchParams) {
      __webpack_require__.d(__webpack_exports__, "a", function() {
        return hasProtocol;
      });
      __webpack_require__.d(__webpack_exports__, "b", function() {
        return withTrailingSlash;
      });
      __webpack_require__.d(__webpack_exports__, "c", function() {
        return withoutTrailingSlash;
      });
      function hasProtocol(inputStr, acceptProtocolRelative = false) {
        return /^\w+:\/\/.+/.test(inputStr) || acceptProtocolRelative && /^\/\/[^/]+/.test(inputStr);
      }
      const TRAILING_SLASH_RE = /\/$|\/\?/;
      function hasTrailingSlash(input = "", queryParams = false) {
        if (!queryParams) {
          return input.endsWith("/");
        }
        return TRAILING_SLASH_RE.test(input);
      }
      function withoutTrailingSlash(input = "", queryParams = false) {
        if (!queryParams) {
          return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
        }
        if (!hasTrailingSlash(input, true)) {
          return input || "/";
        }
        const [s0, ...s2] = input.split("?");
        return (s0.slice(0, -1) || "/") + (s2.length ? `?${s2.join("?")}` : "");
      }
      function withTrailingSlash(input = "", queryParams = false) {
        if (!queryParams) {
          return input.endsWith("/") ? input : input + "/";
        }
        if (hasTrailingSlash(input, true)) {
          return input || "/";
        }
        const [s0, ...s2] = input.split("?");
        return s0 + "/" + (s2.length ? `?${s2.join("?")}` : "");
      }
    }).call(this, __webpack_require__(98)["URLSearchParams"]);
  },
  function(module2, exports, __webpack_require__) {
    /**
     * vue-meta v2.4.0
     * (c) 2020
     * - Declan de Wet
     * - Sébastien Chopin (@Atinux)
     * - Pim (@pimlie)
     * - All the amazing contributors
     * @license MIT
     */
    function _interopDefault(ex) {
      return ex && typeof ex === "object" && "default" in ex ? ex["default"] : ex;
    }
    var deepmerge = _interopDefault(__webpack_require__(78));
    var version = "2.4.0";
    function _typeof(obj) {
      "@babel/helpers - typeof";
      if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
        _typeof = function(obj2) {
          return typeof obj2;
        };
      } else {
        _typeof = function(obj2) {
          return obj2 && typeof Symbol === "function" && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
        };
      }
      return _typeof(obj);
    }
    function _defineProperty(obj, key, value) {
      if (key in obj) {
        Object.defineProperty(obj, key, {
          value,
          enumerable: true,
          configurable: true,
          writable: true
        });
      } else {
        obj[key] = value;
      }
      return obj;
    }
    function ownKeys(object, enumerableOnly) {
      var keys = Object.keys(object);
      if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        if (enumerableOnly)
          symbols = symbols.filter(function(sym) {
            return Object.getOwnPropertyDescriptor(object, sym).enumerable;
          });
        keys.push.apply(keys, symbols);
      }
      return keys;
    }
    function _objectSpread2(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i] != null ? arguments[i] : {};
        if (i % 2) {
          ownKeys(Object(source), true).forEach(function(key) {
            _defineProperty(target, key, source[key]);
          });
        } else if (Object.getOwnPropertyDescriptors) {
          Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
        } else {
          ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
          });
        }
      }
      return target;
    }
    function _toConsumableArray(arr) {
      return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
    }
    function _arrayWithoutHoles(arr) {
      if (Array.isArray(arr))
        return _arrayLikeToArray(arr);
    }
    function _iterableToArray(iter) {
      if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter))
        return Array.from(iter);
    }
    function _unsupportedIterableToArray(o, minLen) {
      if (!o)
        return;
      if (typeof o === "string")
        return _arrayLikeToArray(o, minLen);
      var n = Object.prototype.toString.call(o).slice(8, -1);
      if (n === "Object" && o.constructor)
        n = o.constructor.name;
      if (n === "Map" || n === "Set")
        return Array.from(o);
      if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))
        return _arrayLikeToArray(o, minLen);
    }
    function _arrayLikeToArray(arr, len) {
      if (len == null || len > arr.length)
        len = arr.length;
      for (var i = 0, arr2 = new Array(len); i < len; i++)
        arr2[i] = arr[i];
      return arr2;
    }
    function _nonIterableSpread() {
      throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    function _createForOfIteratorHelper(o, allowArrayLike) {
      var it;
      if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) {
        if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
          if (it)
            o = it;
          var i = 0;
          var F = function() {
          };
          return {
            s: F,
            n: function() {
              if (i >= o.length)
                return {
                  done: true
                };
              return {
                done: false,
                value: o[i++]
              };
            },
            e: function(e) {
              throw e;
            },
            f: F
          };
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
      }
      var normalCompletion = true, didErr = false, err;
      return {
        s: function() {
          it = o[Symbol.iterator]();
        },
        n: function() {
          var step = it.next();
          normalCompletion = step.done;
          return step;
        },
        e: function(e) {
          didErr = true;
          err = e;
        },
        f: function() {
          try {
            if (!normalCompletion && it.return != null)
              it.return();
          } finally {
            if (didErr)
              throw err;
          }
        }
      };
    }
    function isArray(arg) {
      return Array.isArray(arg);
    }
    function isUndefined(arg) {
      return typeof arg === "undefined";
    }
    function isObject(arg) {
      return _typeof(arg) === "object";
    }
    function isPureObject(arg) {
      return _typeof(arg) === "object" && arg !== null;
    }
    function isFunction(arg) {
      return typeof arg === "function";
    }
    function isString(arg) {
      return typeof arg === "string";
    }
    function hasGlobalWindowFn() {
      try {
        return !isUndefined(window);
      } catch (e) {
        return false;
      }
    }
    var hasGlobalWindow = hasGlobalWindowFn();
    var _global = hasGlobalWindow ? window : commonjsGlobal;
    var console2 = _global.console || {};
    function warn(str) {
      if (!console2 || !console2.warn) {
        return;
      }
      console2.warn(str);
    }
    var showWarningNotSupported = function showWarningNotSupported2() {
      return warn("This vue app/component has no vue-meta configuration");
    };
    var defaultInfo = {
      title: void 0,
      titleChunk: "",
      titleTemplate: "%s",
      htmlAttrs: {},
      bodyAttrs: {},
      headAttrs: {},
      base: [],
      link: [],
      meta: [],
      style: [],
      script: [],
      noscript: [],
      __dangerouslyDisableSanitizers: [],
      __dangerouslyDisableSanitizersByTagID: {}
    };
    var rootConfigKey = "_vueMeta";
    var keyName = "metaInfo";
    var attribute = "data-vue-meta";
    var ssrAttribute = "data-vue-meta-server-rendered";
    var tagIDKeyName = "vmid";
    var metaTemplateKeyName = "template";
    var contentKeyName = "content";
    var ssrAppId = "ssr";
    var debounceWait = 10;
    var waitOnDestroyed = true;
    var defaultOptions = {
      keyName,
      attribute,
      ssrAttribute,
      tagIDKeyName,
      contentKeyName,
      metaTemplateKeyName,
      waitOnDestroyed,
      debounceWait,
      ssrAppId
    };
    var defaultInfoKeys = Object.keys(defaultInfo);
    var disableOptionKeys = [defaultInfoKeys[12], defaultInfoKeys[13]];
    var metaInfoOptionKeys = [defaultInfoKeys[1], defaultInfoKeys[2], "changed"].concat(disableOptionKeys);
    var metaInfoAttributeKeys = [defaultInfoKeys[3], defaultInfoKeys[4], defaultInfoKeys[5]];
    var tagsSupportingOnload = ["link", "style", "script"];
    var tagsWithoutEndTag = ["base", "meta", "link"];
    var tagsWithInnerContent = ["noscript", "script", "style"];
    var tagAttributeAsInnerContent = ["innerHTML", "cssText", "json"];
    var tagProperties = ["once", "skip", "template"];
    var commonDataAttributes = ["body", "pbody"];
    var booleanHtmlAttributes = ["allowfullscreen", "amp", "amp-boilerplate", "async", "autofocus", "autoplay", "checked", "compact", "controls", "declare", "default", "defaultchecked", "defaultmuted", "defaultselected", "defer", "disabled", "enabled", "formnovalidate", "hidden", "indeterminate", "inert", "ismap", "itemscope", "loop", "multiple", "muted", "nohref", "noresize", "noshade", "novalidate", "nowrap", "open", "pauseonexit", "readonly", "required", "reversed", "scoped", "seamless", "selected", "sortable", "truespeed", "typemustmatch", "visible"];
    var batchId = null;
    function triggerUpdate(_ref, rootVm, hookName) {
      var debounceWait2 = _ref.debounceWait;
      if (!rootVm[rootConfigKey].initialized && (rootVm[rootConfigKey].initializing || hookName === "watcher")) {
        rootVm[rootConfigKey].initialized = null;
      }
      if (rootVm[rootConfigKey].initialized && !rootVm[rootConfigKey].pausing) {
        batchUpdate(function() {
          return void rootVm.$meta().refresh();
        }, debounceWait2);
      }
    }
    function batchUpdate(callback, timeout) {
      timeout = timeout === void 0 ? 10 : timeout;
      if (!timeout) {
        callback();
        return;
      }
      clearTimeout(batchId);
      batchId = setTimeout(function() {
        callback();
      }, timeout);
      return batchId;
    }
    function find(array, predicate, thisArg) {
      if (!Array.prototype.find) {
        for (var idx = 0; idx < array.length; idx++) {
          if (predicate.call(thisArg, array[idx], idx, array)) {
            return array[idx];
          }
        }
        return;
      }
      return array.find(predicate, thisArg);
    }
    function findIndex(array, predicate, thisArg) {
      if (!Array.prototype.findIndex) {
        for (var idx = 0; idx < array.length; idx++) {
          if (predicate.call(thisArg, array[idx], idx, array)) {
            return idx;
          }
        }
        return -1;
      }
      return array.findIndex(predicate, thisArg);
    }
    function toArray(arg) {
      if (!Array.from) {
        return Array.prototype.slice.call(arg);
      }
      return Array.from(arg);
    }
    function includes(array, value) {
      if (!Array.prototype.includes) {
        for (var idx in array) {
          if (array[idx] === value) {
            return true;
          }
        }
        return false;
      }
      return array.includes(value);
    }
    var querySelector = function querySelector2(arg, el) {
      return (el || document).querySelectorAll(arg);
    };
    function getTag(tags, tag) {
      if (!tags[tag]) {
        tags[tag] = document.getElementsByTagName(tag)[0];
      }
      return tags[tag];
    }
    function getElementsKey(_ref) {
      var body = _ref.body, pbody = _ref.pbody;
      return body ? "body" : pbody ? "pbody" : "head";
    }
    function queryElements(parentNode, _ref2, attributes) {
      var appId2 = _ref2.appId, attribute2 = _ref2.attribute, type = _ref2.type, tagIDKeyName2 = _ref2.tagIDKeyName;
      attributes = attributes || {};
      var queries = ["".concat(type, "[").concat(attribute2, '="').concat(appId2, '"]'), "".concat(type, "[data-").concat(tagIDKeyName2, "]")].map(function(query) {
        for (var key in attributes) {
          var val = attributes[key];
          var attributeValue = val && val !== true ? '="'.concat(val, '"') : "";
          query += "[data-".concat(key).concat(attributeValue, "]");
        }
        return query;
      });
      return toArray(querySelector(queries.join(", "), parentNode));
    }
    function removeElementsByAppId(_ref3, appId2) {
      var attribute2 = _ref3.attribute;
      toArray(querySelector("[".concat(attribute2, '="').concat(appId2, '"]'))).map(function(el) {
        return el.remove();
      });
    }
    function removeAttribute(el, attributeName) {
      el.removeAttribute(attributeName);
    }
    function hasMetaInfo(vm) {
      vm = vm || this;
      return vm && (vm[rootConfigKey] === true || isObject(vm[rootConfigKey]));
    }
    function inMetaInfoBranch(vm) {
      vm = vm || this;
      return vm && !isUndefined(vm[rootConfigKey]);
    }
    function pause(rootVm, refresh2) {
      rootVm[rootConfigKey].pausing = true;
      return function() {
        return resume(rootVm, refresh2);
      };
    }
    function resume(rootVm, refresh2) {
      rootVm[rootConfigKey].pausing = false;
      if (refresh2 || refresh2 === void 0) {
        return rootVm.$meta().refresh();
      }
    }
    function addNavGuards(rootVm) {
      var router = rootVm.$router;
      if (rootVm[rootConfigKey].navGuards || !router) {
        return;
      }
      rootVm[rootConfigKey].navGuards = true;
      router.beforeEach(function(to, from, next) {
        pause(rootVm);
        next();
      });
      router.afterEach(function() {
        rootVm.$nextTick(function() {
          var _resume = resume(rootVm), metaInfo = _resume.metaInfo;
          if (metaInfo && isFunction(metaInfo.afterNavigation)) {
            metaInfo.afterNavigation(metaInfo);
          }
        });
      });
    }
    var appId = 1;
    function createMixin(Vue, options) {
      var updateOnLifecycleHook = ["activated", "deactivated", "beforeMount"];
      var wasServerRendered = false;
      return {
        beforeCreate: function beforeCreate() {
          var _this2 = this;
          var rootKey = "$root";
          var $root = this[rootKey];
          var $options = this.$options;
          var devtoolsEnabled = Vue.config.devtools;
          Object.defineProperty(this, "_hasMetaInfo", {
            configurable: true,
            get: function get() {
              if (devtoolsEnabled && !$root[rootConfigKey].deprecationWarningShown) {
                warn("VueMeta DeprecationWarning: _hasMetaInfo has been deprecated and will be removed in a future version. Please use hasMetaInfo(vm) instead");
                $root[rootConfigKey].deprecationWarningShown = true;
              }
              return hasMetaInfo(this);
            }
          });
          if (this === $root) {
            $root.$once("hook:beforeMount", function() {
              wasServerRendered = this.$el && this.$el.nodeType === 1 && this.$el.hasAttribute("data-server-rendered");
              if (!wasServerRendered && $root[rootConfigKey] && $root[rootConfigKey].appId === 1) {
                var htmlTag = getTag({}, "html");
                wasServerRendered = htmlTag && htmlTag.hasAttribute(options.ssrAttribute);
              }
            });
          }
          if (isUndefined($options[options.keyName]) || $options[options.keyName] === null) {
            return;
          }
          if (!$root[rootConfigKey]) {
            $root[rootConfigKey] = {
              appId
            };
            appId++;
            if (devtoolsEnabled && $root.$options[options.keyName]) {
              this.$nextTick(function() {
                var child = find($root.$children, function(c) {
                  return c.$vnode && c.$vnode.fnOptions;
                });
                if (child && child.$vnode.fnOptions[options.keyName]) {
                  warn("VueMeta has detected a possible global mixin which adds a ".concat(options.keyName, " property to all Vue components on the page. This could cause severe performance issues. If possible, use $meta().addApp to add meta information instead"));
                }
              });
            }
          }
          if (!this[rootConfigKey]) {
            this[rootConfigKey] = true;
            var parent = this.$parent;
            while (parent && parent !== $root) {
              if (isUndefined(parent[rootConfigKey])) {
                parent[rootConfigKey] = false;
              }
              parent = parent.$parent;
            }
          }
          if (isFunction($options[options.keyName])) {
            $options.computed = $options.computed || {};
            $options.computed.$metaInfo = $options[options.keyName];
            if (!this.$isServer) {
              this.$on("hook:created", function() {
                this.$watch("$metaInfo", function() {
                  triggerUpdate(options, this[rootKey], "watcher");
                });
              });
            }
          }
          if (isUndefined($root[rootConfigKey].initialized)) {
            $root[rootConfigKey].initialized = this.$isServer;
            if (!$root[rootConfigKey].initialized) {
              if (!$root[rootConfigKey].initializedSsr) {
                $root[rootConfigKey].initializedSsr = true;
                this.$on("hook:beforeMount", function() {
                  var $root2 = this[rootKey];
                  if (wasServerRendered) {
                    $root2[rootConfigKey].appId = options.ssrAppId;
                  }
                });
              }
              this.$on("hook:mounted", function() {
                var $root2 = this[rootKey];
                if ($root2[rootConfigKey].initialized) {
                  return;
                }
                $root2[rootConfigKey].initializing = true;
                this.$nextTick(function() {
                  var _$root$$meta$refresh = $root2.$meta().refresh(), tags = _$root$$meta$refresh.tags, metaInfo = _$root$$meta$refresh.metaInfo;
                  if (tags === false && $root2[rootConfigKey].initialized === null) {
                    this.$nextTick(function() {
                      return triggerUpdate(options, $root2, "init");
                    });
                  }
                  $root2[rootConfigKey].initialized = true;
                  delete $root2[rootConfigKey].initializing;
                  if (!options.refreshOnceOnNavigation && metaInfo.afterNavigation) {
                    addNavGuards($root2);
                  }
                });
              });
              if (options.refreshOnceOnNavigation) {
                addNavGuards($root);
              }
            }
          }
          this.$on("hook:destroyed", function() {
            var _this = this;
            if (!this.$parent || !hasMetaInfo(this)) {
              return;
            }
            delete this._hasMetaInfo;
            this.$nextTick(function() {
              if (!options.waitOnDestroyed || !_this.$el || !_this.$el.offsetParent) {
                triggerUpdate(options, _this.$root, "destroyed");
                return;
              }
              var interval = setInterval(function() {
                if (_this.$el && _this.$el.offsetParent !== null) {
                  return;
                }
                clearInterval(interval);
                triggerUpdate(options, _this.$root, "destroyed");
              }, 50);
            });
          });
          if (this.$isServer) {
            return;
          }
          updateOnLifecycleHook.forEach(function(lifecycleHook) {
            _this2.$on("hook:".concat(lifecycleHook), function() {
              triggerUpdate(options, this[rootKey], lifecycleHook);
            });
          });
        }
      };
    }
    function setOptions(options) {
      options = isObject(options) ? options : {};
      return {
        keyName: options["keyName"] || defaultOptions.keyName,
        attribute: options["attribute"] || defaultOptions.attribute,
        ssrAttribute: options["ssrAttribute"] || defaultOptions.ssrAttribute,
        tagIDKeyName: options["tagIDKeyName"] || defaultOptions.tagIDKeyName,
        contentKeyName: options["contentKeyName"] || defaultOptions.contentKeyName,
        metaTemplateKeyName: options["metaTemplateKeyName"] || defaultOptions.metaTemplateKeyName,
        debounceWait: isUndefined(options["debounceWait"]) ? defaultOptions.debounceWait : options["debounceWait"],
        waitOnDestroyed: isUndefined(options["waitOnDestroyed"]) ? defaultOptions.waitOnDestroyed : options["waitOnDestroyed"],
        ssrAppId: options["ssrAppId"] || defaultOptions.ssrAppId,
        refreshOnceOnNavigation: !!options["refreshOnceOnNavigation"]
      };
    }
    function getOptions(options) {
      var optionsCopy = {};
      for (var key in options) {
        optionsCopy[key] = options[key];
      }
      return optionsCopy;
    }
    function ensureIsArray(arg, key) {
      if (!key || !isObject(arg)) {
        return isArray(arg) ? arg : [];
      }
      if (!isArray(arg[key])) {
        arg[key] = [];
      }
      return arg;
    }
    var serverSequences = [[/&/g, "&amp;"], [/</g, "&lt;"], [/>/g, "&gt;"], [/"/g, "&quot;"], [/'/g, "&#x27;"]];
    var clientSequences = [[/&/g, "&"], [/</g, "<"], [/>/g, ">"], [/"/g, '"'], [/'/g, "'"]];
    function escape(info, options, escapeOptions, escapeKeys) {
      var tagIDKeyName2 = options.tagIDKeyName;
      var _escapeOptions$doEsca = escapeOptions.doEscape, doEscape = _escapeOptions$doEsca === void 0 ? function(v) {
        return v;
      } : _escapeOptions$doEsca;
      var escaped = {};
      for (var key in info) {
        var value = info[key];
        if (includes(metaInfoOptionKeys, key)) {
          escaped[key] = value;
          continue;
        }
        var disableKey = disableOptionKeys[0];
        if (escapeOptions[disableKey] && includes(escapeOptions[disableKey], key)) {
          escaped[key] = value;
          continue;
        }
        var tagId = info[tagIDKeyName2];
        if (tagId) {
          disableKey = disableOptionKeys[1];
          if (escapeOptions[disableKey] && escapeOptions[disableKey][tagId] && includes(escapeOptions[disableKey][tagId], key)) {
            escaped[key] = value;
            continue;
          }
        }
        if (isString(value)) {
          escaped[key] = doEscape(value);
        } else if (isArray(value)) {
          escaped[key] = value.map(function(v) {
            if (isPureObject(v)) {
              return escape(v, options, escapeOptions, true);
            }
            return doEscape(v);
          });
        } else if (isPureObject(value)) {
          escaped[key] = escape(value, options, escapeOptions, true);
        } else {
          escaped[key] = value;
        }
        if (escapeKeys) {
          var escapedKey = doEscape(key);
          if (key !== escapedKey) {
            escaped[escapedKey] = escaped[key];
            delete escaped[key];
          }
        }
      }
      return escaped;
    }
    function escapeMetaInfo(options, info, escapeSequences) {
      escapeSequences = escapeSequences || [];
      var escapeOptions = {
        doEscape: function doEscape(value) {
          return escapeSequences.reduce(function(val, seq) {
            return val.replace(seq[0], seq[1]);
          }, value);
        }
      };
      disableOptionKeys.forEach(function(disableKey, index2) {
        if (index2 === 0) {
          ensureIsArray(info, disableKey);
        } else if (index2 === 1) {
          for (var key in info[disableKey]) {
            ensureIsArray(info[disableKey], key);
          }
        }
        escapeOptions[disableKey] = info[disableKey];
      });
      return escape(info, options, escapeOptions);
    }
    function applyTemplate(_ref, headObject, template, chunk) {
      var component = _ref.component, metaTemplateKeyName2 = _ref.metaTemplateKeyName, contentKeyName2 = _ref.contentKeyName;
      if (template === true || headObject[metaTemplateKeyName2] === true) {
        return false;
      }
      if (isUndefined(template) && headObject[metaTemplateKeyName2]) {
        template = headObject[metaTemplateKeyName2];
        headObject[metaTemplateKeyName2] = true;
      }
      if (!template) {
        delete headObject[metaTemplateKeyName2];
        return false;
      }
      if (isUndefined(chunk)) {
        chunk = headObject[contentKeyName2];
      }
      headObject[contentKeyName2] = isFunction(template) ? template.call(component, chunk) : template.replace(/%s/g, chunk);
      return true;
    }
    function _arrayMerge(_ref, target, source) {
      var component = _ref.component, tagIDKeyName2 = _ref.tagIDKeyName, metaTemplateKeyName2 = _ref.metaTemplateKeyName, contentKeyName2 = _ref.contentKeyName;
      var destination = [];
      if (!target.length && !source.length) {
        return destination;
      }
      target.forEach(function(targetItem, targetIndex) {
        if (!targetItem[tagIDKeyName2]) {
          destination.push(targetItem);
          return;
        }
        var sourceIndex = findIndex(source, function(item) {
          return item[tagIDKeyName2] === targetItem[tagIDKeyName2];
        });
        var sourceItem = source[sourceIndex];
        if (sourceIndex === -1) {
          destination.push(targetItem);
          return;
        }
        if (contentKeyName2 in sourceItem && sourceItem[contentKeyName2] === void 0 || "innerHTML" in sourceItem && sourceItem.innerHTML === void 0) {
          destination.push(targetItem);
          source.splice(sourceIndex, 1);
          return;
        }
        if (sourceItem[contentKeyName2] === null || sourceItem.innerHTML === null) {
          source.splice(sourceIndex, 1);
          return;
        }
        var targetTemplate = targetItem[metaTemplateKeyName2];
        if (!targetTemplate) {
          return;
        }
        var sourceTemplate = sourceItem[metaTemplateKeyName2];
        if (!sourceTemplate) {
          applyTemplate({
            component,
            metaTemplateKeyName: metaTemplateKeyName2,
            contentKeyName: contentKeyName2
          }, sourceItem, targetTemplate);
          sourceItem.template = true;
          return;
        }
        if (!sourceItem[contentKeyName2]) {
          applyTemplate({
            component,
            metaTemplateKeyName: metaTemplateKeyName2,
            contentKeyName: contentKeyName2
          }, sourceItem, void 0, targetItem[contentKeyName2]);
        }
      });
      return destination.concat(source);
    }
    var warningShown = false;
    function merge(target, source, options) {
      options = options || {};
      if (source.title === void 0) {
        delete source.title;
      }
      metaInfoAttributeKeys.forEach(function(attrKey) {
        if (!source[attrKey]) {
          return;
        }
        for (var key in source[attrKey]) {
          if (key in source[attrKey] && source[attrKey][key] === void 0) {
            if (includes(booleanHtmlAttributes, key) && !warningShown) {
              warn("VueMeta: Please note that since v2 the value undefined is not used to indicate boolean attributes anymore, see migration guide for details");
              warningShown = true;
            }
            delete source[attrKey][key];
          }
        }
      });
      return deepmerge(target, source, {
        arrayMerge: function arrayMerge(t, s) {
          return _arrayMerge(options, t, s);
        }
      });
    }
    function getComponentMetaInfo(options, component) {
      return getComponentOption(options || {}, component, defaultInfo);
    }
    function getComponentOption(options, component, result) {
      result = result || {};
      if (component._inactive) {
        return result;
      }
      options = options || {};
      var _options = options, keyName2 = _options.keyName;
      var $metaInfo = component.$metaInfo, $options = component.$options, $children = component.$children;
      if ($options[keyName2]) {
        var data = $metaInfo || $options[keyName2];
        if (isObject(data)) {
          result = merge(result, data, options);
        }
      }
      if ($children.length) {
        $children.forEach(function(childComponent) {
          if (!inMetaInfoBranch(childComponent)) {
            return;
          }
          result = getComponentOption(options, childComponent, result);
        });
      }
      return result;
    }
    var callbacks = [];
    function isDOMComplete(d) {
      return (d || document).readyState === "complete";
    }
    function addCallback(query, callback) {
      if (arguments.length === 1) {
        callback = query;
        query = "";
      }
      callbacks.push([query, callback]);
    }
    function addCallbacks(_ref, type, tags, autoAddListeners) {
      var tagIDKeyName2 = _ref.tagIDKeyName;
      var hasAsyncCallback = false;
      tags.forEach(function(tag) {
        if (!tag[tagIDKeyName2] || !tag.callback) {
          return;
        }
        hasAsyncCallback = true;
        addCallback("".concat(type, "[data-").concat(tagIDKeyName2, '="').concat(tag[tagIDKeyName2], '"]'), tag.callback);
      });
      if (!autoAddListeners || !hasAsyncCallback) {
        return hasAsyncCallback;
      }
      return addListeners();
    }
    function addListeners() {
      if (isDOMComplete()) {
        applyCallbacks();
        return;
      }
      document.onreadystatechange = function() {
        applyCallbacks();
      };
    }
    function applyCallbacks(matchElement) {
      callbacks.forEach(function(args) {
        var query = args[0];
        var callback = args[1];
        var selector = "".concat(query, '[onload="this.__vm_l=1"]');
        var elements = [];
        if (!matchElement) {
          elements = toArray(querySelector(selector));
        }
        if (matchElement && matchElement.matches(selector)) {
          elements = [matchElement];
        }
        elements.forEach(function(element) {
          if (element.__vm_cb) {
            return;
          }
          var onload = function onload2() {
            element.__vm_cb = true;
            removeAttribute(element, "onload");
            callback(element);
          };
          if (element.__vm_l) {
            onload();
            return;
          }
          if (!element.__vm_ev) {
            element.__vm_ev = true;
            element.addEventListener("load", onload);
          }
        });
      });
    }
    var attributeMap = {};
    function updateAttribute(appId2, options, type, attrs, tag) {
      var _ref = options || {}, attribute2 = _ref.attribute;
      var vueMetaAttrString = tag.getAttribute(attribute2);
      if (vueMetaAttrString) {
        attributeMap[type] = JSON.parse(decodeURI(vueMetaAttrString));
        removeAttribute(tag, attribute2);
      }
      var data = attributeMap[type] || {};
      var toUpdate = [];
      for (var attr in data) {
        if (data[attr] !== void 0 && appId2 in data[attr]) {
          toUpdate.push(attr);
          if (!attrs[attr]) {
            delete data[attr][appId2];
          }
        }
      }
      for (var _attr in attrs) {
        var attrData = data[_attr];
        if (!attrData || attrData[appId2] !== attrs[_attr]) {
          toUpdate.push(_attr);
          if (attrs[_attr] !== void 0) {
            data[_attr] = data[_attr] || {};
            data[_attr][appId2] = attrs[_attr];
          }
        }
      }
      for (var _i = 0, _toUpdate = toUpdate; _i < _toUpdate.length; _i++) {
        var _attr2 = _toUpdate[_i];
        var _attrData = data[_attr2];
        var attrValues = [];
        for (var _appId in _attrData) {
          Array.prototype.push.apply(attrValues, [].concat(_attrData[_appId]));
        }
        if (attrValues.length) {
          var attrValue = includes(booleanHtmlAttributes, _attr2) && attrValues.some(Boolean) ? "" : attrValues.filter(function(v) {
            return v !== void 0;
          }).join(" ");
          tag.setAttribute(_attr2, attrValue);
        } else {
          removeAttribute(tag, _attr2);
        }
      }
      attributeMap[type] = data;
    }
    function updateTitle(title) {
      if (!title && title !== "") {
        return;
      }
      document.title = title;
    }
    function updateTag(appId2, options, type, tags, head, body) {
      var _ref = options || {}, attribute2 = _ref.attribute, tagIDKeyName2 = _ref.tagIDKeyName;
      var dataAttributes = commonDataAttributes.slice();
      dataAttributes.push(tagIDKeyName2);
      var newElements = [];
      var queryOptions = {
        appId: appId2,
        attribute: attribute2,
        type,
        tagIDKeyName: tagIDKeyName2
      };
      var currentElements = {
        head: queryElements(head, queryOptions),
        pbody: queryElements(body, queryOptions, {
          pbody: true
        }),
        body: queryElements(body, queryOptions, {
          body: true
        })
      };
      if (tags.length > 1) {
        var found = [];
        tags = tags.filter(function(x) {
          var k = JSON.stringify(x);
          var res = !includes(found, k);
          found.push(k);
          return res;
        });
      }
      tags.forEach(function(tag) {
        if (tag.skip) {
          return;
        }
        var newElement = document.createElement(type);
        if (!tag.once) {
          newElement.setAttribute(attribute2, appId2);
        }
        Object.keys(tag).forEach(function(attr) {
          if (includes(tagProperties, attr)) {
            return;
          }
          if (attr === "innerHTML") {
            newElement.innerHTML = tag.innerHTML;
            return;
          }
          if (attr === "json") {
            newElement.innerHTML = JSON.stringify(tag.json);
            return;
          }
          if (attr === "cssText") {
            if (newElement.styleSheet) {
              newElement.styleSheet.cssText = tag.cssText;
            } else {
              newElement.appendChild(document.createTextNode(tag.cssText));
            }
            return;
          }
          if (attr === "callback") {
            newElement.onload = function() {
              return tag[attr](newElement);
            };
            return;
          }
          var _attr = includes(dataAttributes, attr) ? "data-".concat(attr) : attr;
          var isBooleanAttribute = includes(booleanHtmlAttributes, attr);
          if (isBooleanAttribute && !tag[attr]) {
            return;
          }
          var value = isBooleanAttribute ? "" : tag[attr];
          newElement.setAttribute(_attr, value);
        });
        var oldElements2 = currentElements[getElementsKey(tag)];
        var indexToDelete;
        var hasEqualElement = oldElements2.some(function(existingTag, index2) {
          indexToDelete = index2;
          return newElement.isEqualNode(existingTag);
        });
        if (hasEqualElement && (indexToDelete || indexToDelete === 0)) {
          oldElements2.splice(indexToDelete, 1);
        } else {
          newElements.push(newElement);
        }
      });
      var oldElements = [];
      for (var _type in currentElements) {
        Array.prototype.push.apply(oldElements, currentElements[_type]);
      }
      oldElements.forEach(function(element) {
        element.parentNode.removeChild(element);
      });
      newElements.forEach(function(element) {
        if (element.hasAttribute("data-body")) {
          body.appendChild(element);
          return;
        }
        if (element.hasAttribute("data-pbody")) {
          body.insertBefore(element, body.firstChild);
          return;
        }
        head.appendChild(element);
      });
      return {
        oldTags: oldElements,
        newTags: newElements
      };
    }
    function updateClientMetaInfo(appId2, options, newInfo) {
      options = options || {};
      var _options = options, ssrAttribute2 = _options.ssrAttribute, ssrAppId2 = _options.ssrAppId;
      var tags = {};
      var htmlTag = getTag(tags, "html");
      if (appId2 === ssrAppId2 && htmlTag.hasAttribute(ssrAttribute2)) {
        removeAttribute(htmlTag, ssrAttribute2);
        var addLoadListeners = false;
        tagsSupportingOnload.forEach(function(type2) {
          if (newInfo[type2] && addCallbacks(options, type2, newInfo[type2])) {
            addLoadListeners = true;
          }
        });
        if (addLoadListeners) {
          addListeners();
        }
        return false;
      }
      var tagsAdded = {};
      var tagsRemoved = {};
      for (var type in newInfo) {
        if (includes(metaInfoOptionKeys, type)) {
          continue;
        }
        if (type === "title") {
          updateTitle(newInfo.title);
          continue;
        }
        if (includes(metaInfoAttributeKeys, type)) {
          var tagName = type.substr(0, 4);
          updateAttribute(appId2, options, type, newInfo[type], getTag(tags, tagName));
          continue;
        }
        if (!isArray(newInfo[type])) {
          continue;
        }
        var _updateTag = updateTag(appId2, options, type, newInfo[type], getTag(tags, "head"), getTag(tags, "body")), oldTags = _updateTag.oldTags, newTags = _updateTag.newTags;
        if (newTags.length) {
          tagsAdded[type] = newTags;
          tagsRemoved[type] = oldTags;
        }
      }
      return {
        tagsAdded,
        tagsRemoved
      };
    }
    var appsMetaInfo;
    function addApp(rootVm, appId2, options) {
      return {
        set: function set(metaInfo) {
          return setMetaInfo(rootVm, appId2, options, metaInfo);
        },
        remove: function remove() {
          return removeMetaInfo(rootVm, appId2, options);
        }
      };
    }
    function setMetaInfo(rootVm, appId2, options, metaInfo) {
      if (rootVm && rootVm.$el) {
        return updateClientMetaInfo(appId2, options, metaInfo);
      }
      appsMetaInfo = appsMetaInfo || {};
      appsMetaInfo[appId2] = metaInfo;
    }
    function removeMetaInfo(rootVm, appId2, options) {
      if (rootVm && rootVm.$el) {
        var tags = {};
        var _iterator = _createForOfIteratorHelper(metaInfoAttributeKeys), _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done; ) {
            var type = _step.value;
            var tagName = type.substr(0, 4);
            updateAttribute(appId2, options, type, {}, getTag(tags, tagName));
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
        return removeElementsByAppId(options, appId2);
      }
      if (appsMetaInfo[appId2]) {
        delete appsMetaInfo[appId2];
        clearAppsMetaInfo();
      }
    }
    function getAppsMetaInfo() {
      return appsMetaInfo;
    }
    function clearAppsMetaInfo(force) {
      if (force || !Object.keys(appsMetaInfo).length) {
        appsMetaInfo = void 0;
      }
    }
    function getMetaInfo(options, info, escapeSequences, component) {
      options = options || {};
      escapeSequences = escapeSequences || [];
      var _options = options, tagIDKeyName2 = _options.tagIDKeyName;
      if (info.title) {
        info.titleChunk = info.title;
      }
      if (info.titleTemplate && info.titleTemplate !== "%s") {
        applyTemplate({
          component,
          contentKeyName: "title"
        }, info, info.titleTemplate, info.titleChunk || "");
      }
      if (info.base) {
        info.base = Object.keys(info.base).length ? [info.base] : [];
      }
      if (info.meta) {
        info.meta = info.meta.filter(function(metaItem, index2, arr) {
          var hasVmid = !!metaItem[tagIDKeyName2];
          if (!hasVmid) {
            return true;
          }
          var isFirstItemForVmid = index2 === findIndex(arr, function(item) {
            return item[tagIDKeyName2] === metaItem[tagIDKeyName2];
          });
          return isFirstItemForVmid;
        });
        info.meta.forEach(function(metaObject) {
          return applyTemplate(options, metaObject);
        });
      }
      return escapeMetaInfo(options, info, escapeSequences);
    }
    function refresh(rootVm, options) {
      options = options || {};
      if (!rootVm[rootConfigKey]) {
        showWarningNotSupported();
        return {};
      }
      var rawInfo = getComponentMetaInfo(options, rootVm);
      var metaInfo = getMetaInfo(options, rawInfo, clientSequences, rootVm);
      var appId2 = rootVm[rootConfigKey].appId;
      var tags = updateClientMetaInfo(appId2, options, metaInfo);
      if (tags && isFunction(metaInfo.changed)) {
        metaInfo.changed(metaInfo, tags.tagsAdded, tags.tagsRemoved);
        tags = {
          addedTags: tags.tagsAdded,
          removedTags: tags.tagsRemoved
        };
      }
      var appsMetaInfo2 = getAppsMetaInfo();
      if (appsMetaInfo2) {
        for (var additionalAppId in appsMetaInfo2) {
          updateClientMetaInfo(additionalAppId, options, appsMetaInfo2[additionalAppId]);
          delete appsMetaInfo2[additionalAppId];
        }
        clearAppsMetaInfo(true);
      }
      return {
        vm: rootVm,
        metaInfo,
        tags
      };
    }
    function attributeGenerator(options, type, data, _ref) {
      var addSsrAttribute = _ref.addSsrAttribute;
      var _ref2 = options || {}, attribute2 = _ref2.attribute, ssrAttribute2 = _ref2.ssrAttribute;
      var attributeStr = "";
      for (var attr in data) {
        var attrData = data[attr];
        var attrValues = [];
        for (var appId2 in attrData) {
          attrValues.push.apply(attrValues, _toConsumableArray([].concat(attrData[appId2])));
        }
        if (attrValues.length) {
          attributeStr += booleanHtmlAttributes.includes(attr) && attrValues.some(Boolean) ? "".concat(attr) : "".concat(attr, '="').concat(attrValues.join(" "), '"');
          attributeStr += " ";
        }
      }
      if (attributeStr) {
        attributeStr += "".concat(attribute2, '="').concat(encodeURI(JSON.stringify(data)), '"');
      }
      if (type === "htmlAttrs" && addSsrAttribute) {
        return "".concat(ssrAttribute2).concat(attributeStr ? " " : "").concat(attributeStr);
      }
      return attributeStr;
    }
    function titleGenerator(options, type, data, generatorOptions) {
      var _ref = generatorOptions || {}, ln = _ref.ln;
      if (!data) {
        return "";
      }
      return "<".concat(type, ">").concat(data, "</").concat(type, ">").concat(ln ? "\n" : "");
    }
    function tagGenerator(options, type, tags, generatorOptions) {
      var _ref = options || {}, ssrAppId2 = _ref.ssrAppId, attribute2 = _ref.attribute, tagIDKeyName2 = _ref.tagIDKeyName;
      var _ref2 = generatorOptions || {}, appId2 = _ref2.appId, _ref2$isSSR = _ref2.isSSR, isSSR = _ref2$isSSR === void 0 ? true : _ref2$isSSR, _ref2$body = _ref2.body, body = _ref2$body === void 0 ? false : _ref2$body, _ref2$pbody = _ref2.pbody, pbody = _ref2$pbody === void 0 ? false : _ref2$pbody, _ref2$ln = _ref2.ln, ln = _ref2$ln === void 0 ? false : _ref2$ln;
      var dataAttributes = [tagIDKeyName2].concat(_toConsumableArray(commonDataAttributes));
      if (!tags || !tags.length) {
        return "";
      }
      return tags.reduce(function(tagsStr, tag) {
        if (tag.skip) {
          return tagsStr;
        }
        var tagKeys = Object.keys(tag);
        if (tagKeys.length === 0) {
          return tagsStr;
        }
        if (Boolean(tag.body) !== body || Boolean(tag.pbody) !== pbody) {
          return tagsStr;
        }
        var attrs = tag.once ? "" : " ".concat(attribute2, '="').concat(appId2 || (isSSR === false ? "1" : ssrAppId2), '"');
        for (var attr in tag) {
          if (tagAttributeAsInnerContent.includes(attr) || tagProperties.includes(attr)) {
            continue;
          }
          if (attr === "callback") {
            attrs += ' onload="this.__vm_l=1"';
            continue;
          }
          var prefix = "";
          if (dataAttributes.includes(attr)) {
            prefix = "data-";
          }
          var isBooleanAttr = !prefix && booleanHtmlAttributes.includes(attr);
          if (isBooleanAttr && !tag[attr]) {
            continue;
          }
          attrs += " ".concat(prefix).concat(attr) + (isBooleanAttr ? "" : '="'.concat(tag[attr], '"'));
        }
        var json = "";
        if (tag.json) {
          json = JSON.stringify(tag.json);
        }
        var content = tag.innerHTML || tag.cssText || json;
        var hasEndTag = !tagsWithoutEndTag.includes(type);
        var hasContent = hasEndTag && tagsWithInnerContent.includes(type);
        return "".concat(tagsStr, "<").concat(type).concat(attrs).concat(!hasContent && hasEndTag ? "/" : "", ">") + (hasContent ? "".concat(content, "</").concat(type, ">") : "") + (ln ? "\n" : "");
      }, "");
    }
    function generateServerInjector(options, metaInfo, globalInjectOptions) {
      var serverInjector = {
        data: metaInfo,
        extraData: void 0,
        addInfo: function addInfo(appId2, metaInfo2) {
          this.extraData = this.extraData || {};
          this.extraData[appId2] = metaInfo2;
        },
        callInjectors: function callInjectors(opts) {
          var m = this.injectors;
          return (opts.body || opts.pbody ? "" : m.title.text(opts)) + m.meta.text(opts) + m.base.text(opts) + m.link.text(opts) + m.style.text(opts) + m.script.text(opts) + m.noscript.text(opts);
        },
        injectors: {
          head: function head(ln) {
            return serverInjector.callInjectors(_objectSpread2(_objectSpread2({}, globalInjectOptions), {}, {
              ln
            }));
          },
          bodyPrepend: function bodyPrepend(ln) {
            return serverInjector.callInjectors(_objectSpread2(_objectSpread2({}, globalInjectOptions), {}, {
              ln,
              pbody: true
            }));
          },
          bodyAppend: function bodyAppend(ln) {
            return serverInjector.callInjectors(_objectSpread2(_objectSpread2({}, globalInjectOptions), {}, {
              ln,
              body: true
            }));
          }
        }
      };
      var _loop = function _loop2(type2) {
        if (metaInfoOptionKeys.includes(type2)) {
          return "continue";
        }
        serverInjector.injectors[type2] = {
          text: function text(injectOptions) {
            var addSsrAttribute = injectOptions === true;
            injectOptions = _objectSpread2(_objectSpread2({
              addSsrAttribute
            }, globalInjectOptions), injectOptions);
            if (type2 === "title") {
              return titleGenerator(options, type2, serverInjector.data[type2], injectOptions);
            }
            if (metaInfoAttributeKeys.includes(type2)) {
              var attributeData = {};
              var data = serverInjector.data[type2];
              if (data) {
                var appId2 = injectOptions.isSSR === false ? "1" : options.ssrAppId;
                for (var attr in data) {
                  attributeData[attr] = _defineProperty({}, appId2, data[attr]);
                }
              }
              if (serverInjector.extraData) {
                for (var _appId in serverInjector.extraData) {
                  var _data = serverInjector.extraData[_appId][type2];
                  if (_data) {
                    for (var _attr in _data) {
                      attributeData[_attr] = _objectSpread2(_objectSpread2({}, attributeData[_attr]), {}, _defineProperty({}, _appId, _data[_attr]));
                    }
                  }
                }
              }
              return attributeGenerator(options, type2, attributeData, injectOptions);
            }
            var str = tagGenerator(options, type2, serverInjector.data[type2], injectOptions);
            if (serverInjector.extraData) {
              for (var _appId2 in serverInjector.extraData) {
                var _data2 = serverInjector.extraData[_appId2][type2];
                var extraStr = tagGenerator(options, type2, _data2, _objectSpread2({
                  appId: _appId2
                }, injectOptions));
                str = "".concat(str).concat(extraStr);
              }
            }
            return str;
          }
        };
      };
      for (var type in defaultInfo) {
        var _ret = _loop(type);
        if (_ret === "continue")
          continue;
      }
      return serverInjector;
    }
    function inject(rootVm, options, injectOptions) {
      if (!rootVm[rootConfigKey]) {
        showWarningNotSupported();
        return {};
      }
      var rawInfo = getComponentMetaInfo(options, rootVm);
      var metaInfo = getMetaInfo(options, rawInfo, serverSequences, rootVm);
      var serverInjector = generateServerInjector(options, metaInfo, injectOptions);
      var appsMetaInfo2 = getAppsMetaInfo();
      if (appsMetaInfo2) {
        for (var additionalAppId in appsMetaInfo2) {
          serverInjector.addInfo(additionalAppId, appsMetaInfo2[additionalAppId]);
          delete appsMetaInfo2[additionalAppId];
        }
        clearAppsMetaInfo(true);
      }
      return serverInjector.injectors;
    }
    function $meta(options) {
      options = options || {};
      var $root = this.$root;
      return {
        getOptions: function getOptions$1() {
          return getOptions(options);
        },
        setOptions: function setOptions2(newOptions) {
          var refreshNavKey = "refreshOnceOnNavigation";
          if (newOptions && newOptions[refreshNavKey]) {
            options.refreshOnceOnNavigation = !!newOptions[refreshNavKey];
            addNavGuards($root);
          }
          var debounceWaitKey = "debounceWait";
          if (newOptions && debounceWaitKey in newOptions) {
            var debounceWait2 = parseInt(newOptions[debounceWaitKey]);
            if (!isNaN(debounceWait2)) {
              options.debounceWait = debounceWait2;
            }
          }
          var waitOnDestroyedKey = "waitOnDestroyed";
          if (newOptions && waitOnDestroyedKey in newOptions) {
            options.waitOnDestroyed = !!newOptions[waitOnDestroyedKey];
          }
        },
        refresh: function refresh$1() {
          return refresh($root, options);
        },
        inject: function inject$1(injectOptions) {
          return inject($root, options, injectOptions);
        },
        pause: function pause$1() {
          return pause($root);
        },
        resume: function resume$1() {
          return resume($root);
        },
        addApp: function addApp$1(appId2) {
          return addApp($root, appId2, options);
        }
      };
    }
    function generate(rawInfo, options) {
      options = setOptions(options);
      var metaInfo = getMetaInfo(options, rawInfo, serverSequences);
      var serverInjector = generateServerInjector(options, metaInfo);
      return serverInjector.injectors;
    }
    function install(Vue, options) {
      if (Vue.__vuemeta_installed) {
        return;
      }
      Vue.__vuemeta_installed = true;
      options = setOptions(options);
      Vue.prototype.$meta = function() {
        return $meta.call(this, options);
      };
      Vue.mixin(createMixin(Vue, options));
    }
    var index = {
      version,
      install,
      generate: function generate$1(metaInfo, options) {
        return generate(metaInfo, options);
      },
      hasMetaInfo
    };
    module2.exports = index;
  },
  function(module2, exports) {
    module2.exports = require$$1;
  },
  function(module2, exports, __webpack_require__) {
    /*!
     * vue-no-ssr v1.1.1
     * (c) 2018-present egoist <0x142857@gmail.com>
     * Released under the MIT License.
     */
    var index = {
      name: "NoSsr",
      functional: true,
      props: {
        placeholder: String,
        placeholderTag: {
          type: String,
          default: "div"
        }
      },
      render: function render(h, ref) {
        var parent = ref.parent;
        var slots = ref.slots;
        var props = ref.props;
        var ref$1 = slots();
        var defaultSlot = ref$1.default;
        if (defaultSlot === void 0)
          defaultSlot = [];
        var placeholderSlot = ref$1.placeholder;
        if (parent._isMounted) {
          return defaultSlot;
        }
        parent.$once("hook:mounted", function() {
          parent.$forceUpdate();
        });
        if (props.placeholderTag && (props.placeholder || placeholderSlot)) {
          return h(props.placeholderTag, {
            class: ["no-ssr-placeholder"]
          }, props.placeholder || placeholderSlot);
        }
        return defaultSlot.length > 0 ? defaultSlot.map(function() {
          return h(false);
        }) : h(false);
      }
    };
    module2.exports = index;
  },
  function(module2, exports) {
    module2.exports = require$$2;
  },
  function(module2, exports) {
    module2.exports = require$$3;
  },
  function(module2, exports) {
    module2.exports = require$$4;
  },
  function(module2, exports) {
    module2.exports = require$$5;
  },
  function(module2, exports) {
    module2.exports = require$$6;
  },
  function(module2, exports) {
    module2.exports = require$$7;
  },
  function(module2, exports) {
    module2.exports = require$$8;
  },
  function(module2, exports) {
    module2.exports = require$$9;
  },
  function(module2, exports) {
    module2.exports = require$$10;
  },
  function(module2, exports) {
    module2.exports = require$$11;
  },
  function(module2, exports) {
    module2.exports = require$$12;
  },
  function(module2, exports) {
    module2.exports = require$$13;
  },
  function(module2, exports) {
    module2.exports = require$$14;
  },
  function(module2, exports) {
    module2.exports = require$$15;
  },
  function(module2, exports) {
    module2.exports = require$$16;
  },
  function(module2, exports) {
    module2.exports = require$$17;
  },
  function(module2, exports, __webpack_require__) {
    /*!
     * vue-client-only v0.0.0-semantic-release
     * (c) 2021-present egoist <0x142857@gmail.com>
     * Released under the MIT License.
     */
    var index = {
      name: "ClientOnly",
      functional: true,
      props: {
        placeholder: String,
        placeholderTag: {
          type: String,
          default: "div"
        }
      },
      render: function render(h, ref) {
        var parent = ref.parent;
        var slots = ref.slots;
        var props = ref.props;
        var ref$1 = slots();
        var defaultSlot = ref$1.default;
        if (defaultSlot === void 0)
          defaultSlot = [];
        var placeholderSlot = ref$1.placeholder;
        if (parent._isMounted) {
          return defaultSlot;
        }
        parent.$once("hook:mounted", function() {
          parent.$forceUpdate();
        });
        if (props.placeholderTag && (props.placeholder || placeholderSlot)) {
          return h(props.placeholderTag, {
            class: ["client-only-placeholder"]
          }, props.placeholder || placeholderSlot);
        }
        return defaultSlot.length > 0 ? defaultSlot.map(function() {
          return h(false);
        }) : h(false);
      }
    };
    module2.exports = index;
  },
  function(module2, exports) {
    module2.exports = require$$18;
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var render = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", { class: "header " + _vm.bgClass }, [_vm._ssrNode('<div class="container" data-v-a0106514>', "</div>", [_vm._ssrNode('<div class="header-wrap" data-v-a0106514>', "</div>", [_vm._ssrNode('<div class="left-panel" data-v-a0106514>', "</div>", [_vm.bgClass === "bg-transparent" ? _c("router-link", { attrs: { "to": "/" } }, [_c("img", { staticClass: "logo", attrs: { "src": __webpack_require__(71), "alt": "Logo" } })]) : _c("router-link", { attrs: { "to": "/" } }, [_c("img", { staticClass: "logo", attrs: { "src": __webpack_require__(72), "alt": "Logo" } })])], 1), _vm._ssrNode(" "), _vm._ssrNode('<div class="right-panel" data-v-a0106514>', "</div>", [_vm._ssrNode((_vm.mobileView ? '<div data-v-a0106514><button type="button" data-v-a0106514><i' + _vm._ssrClass(null, _vm.bgClass === "bg-transparent" ? "icon-menu" : "icon-menu-violet-bg") + " data-v-a0106514></i></button></div>" : "<!---->") + " "), !_vm.mobileView ? _vm._ssrNode('<div class="flex jc-center" data-v-a0106514>', "</div>", [_vm._ssrNode('<ul class="nav-wrap" data-v-a0106514>', "</ul>", _vm._l(_vm.menu, function(item, i) {
        return _vm._ssrNode('<li class="nav-item" data-v-a0106514>', "</li>", [_c("NuxtLink", { staticClass: "nav-link", attrs: { "to": item.to } }, [_vm._v("\n                " + _vm._s(item.label) + "\n              ")])], 1);
      }), 0), _vm._ssrNode(" "), _c("LanguageInput")], 2) : _vm._e()], 2)], 2)]), _vm._ssrNode(" "), _vm.mobileMenu ? _vm._ssrNode('<div class="Mobile-dropdown" data-v-a0106514>', "</div>", [_vm._ssrNode('<div class="text-right p-5" data-v-a0106514><button type="button" data-v-a0106514><i class="icon-cross" data-v-a0106514></i></button></div> '), _vm._ssrNode("<ul data-v-a0106514>", "</ul>", _vm._l(_vm.menu, function(item, i) {
        return _vm._ssrNode("<li data-v-a0106514>", "</li>", [_c("NuxtLink", { staticClass: "nav-link", attrs: { "to": item.to } }, [_vm._v("\n          " + _vm._s(item.label) + "\n        ")])], 1);
      }), 0), _vm._ssrNode(' <div class="lang-select" data-v-a0106514><div class="elements" data-v-a0106514><span class="active" data-v-a0106514>KO</span> <span data-v-a0106514>EN</span></div></div>')], 2) : _vm._e()], 2);
    };
    var staticRenderFns = [];
    var Headervue_type_script_lang_js_ = {
      name: "NuxtHeader",
      props: {
        bgClass: String
      },
      data() {
        return {
          menu: [{
            label: "Our Founders",
            to: "/founders"
          }, {
            label: "Our Team",
            to: "/team"
          }, {
            label: "Philosophy",
            to: "/philosophy"
          }, {
            label: "Contents",
            to: "/contents"
          }, {
            label: "Contact",
            to: "/contact"
          }],
          mobileView: false,
          mobileMenu: false
        };
      },
      created() {
        this.getDimensions();
      },
      mounted() {
        window.addEventListener("resize", this.getDimensions);
      },
      unmounted() {
        window.removeEventListener("resize", this.getDimensions);
      },
      methods: {
        getDimensions() {
          this.mobileView = window.innerWidth <= 990;
        },
        mobileToggle() {
          this.mobileMenu = !this.mobileMenu;
        },
        closeMenu() {
          this.mobileMenu = false;
        }
      }
    };
    var components_Headervue_type_script_lang_js_ = Headervue_type_script_lang_js_;
    var componentNormalizer = __webpack_require__(2);
    function injectStyles(context) {
      var style0 = __webpack_require__(89);
      if (style0.__inject__)
        style0.__inject__(context);
    }
    var component = Object(componentNormalizer["a"])(components_Headervue_type_script_lang_js_, render, staticRenderFns, false, injectStyles, "a0106514", "54d13bf8");
    __webpack_exports__["default"] = component.exports;
    installComponents(component, { LanguageInput: __webpack_require__(73).default });
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var render = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", { staticClass: "footer" }, [_vm._ssrNode('<div class="container" data-v-fa9d665e><p data-v-fa9d665e>\xA9 Copyright 2018. All Rights Reserved, Murexpartners.</p></div>')]);
    };
    var staticRenderFns = [];
    var Footervue_type_script_lang_js_ = {
      name: "Footer"
    };
    var components_Footervue_type_script_lang_js_ = Footervue_type_script_lang_js_;
    var componentNormalizer = __webpack_require__(2);
    function injectStyles(context) {
      var style0 = __webpack_require__(93);
      if (style0.__inject__)
        style0.__inject__(context);
    }
    var component = Object(componentNormalizer["a"])(components_Footervue_type_script_lang_js_, render, staticRenderFns, false, injectStyles, "fa9d665e", "339ed806");
    __webpack_exports__["default"] = component.exports;
  },
  function(module2, exports) {
    module2.exports = require$$19;
  },
  function(module2, exports) {
    module2.exports = require$$20;
  },
  function(module2, exports) {
    module2.exports = require$$21;
  },
  function(module2, exports) {
    module2.exports = require$$22;
  },
  function(module2, exports) {
    module2.exports = require$$23;
  },
  function(module2, exports) {
    module2.exports = require$$24;
  },
  function(module2, exports) {
    module2.exports = require$$25;
  },
  function(module2, exports) {
    module2.exports = require$$26;
  },
  function(module2, exports) {
    module2.exports = require$$27;
  },
  function(module2, exports) {
    module2.exports = require$$28;
  },
  function(module2, exports) {
    module2.exports = require$$29;
  },
  function(module2, exports) {
    module2.exports = require$$30;
  },
  function(module2, exports) {
    module2.exports = require$$31;
  },
  function(module2, exports, __webpack_require__) {
    var content = __webpack_require__(80);
    if (content.__esModule)
      content = content.default;
    if (typeof content === "string")
      content = [[module2.i, content, ""]];
    if (content.locals)
      module2.exports = content.locals;
    var add = __webpack_require__(5).default;
    module2.exports.__inject__ = function(context) {
      add("ef28f648", content, true, context);
    };
  },
  function(module2, exports, __webpack_require__) {
    var content = __webpack_require__(82);
    if (content.__esModule)
      content = content.default;
    if (typeof content === "string")
      content = [[module2.i, content, ""]];
    if (content.locals)
      module2.exports = content.locals;
    var add = __webpack_require__(5).default;
    module2.exports.__inject__ = function(context) {
      add("78bce61d", content, true, context);
    };
  },
  function(module2, exports, __webpack_require__) {
    var content = __webpack_require__(88);
    if (content.__esModule)
      content = content.default;
    if (typeof content === "string")
      content = [[module2.i, content, ""]];
    if (content.locals)
      module2.exports = content.locals;
    var add = __webpack_require__(5).default;
    module2.exports.__inject__ = function(context) {
      add("0ec3b52c", content, true, context);
    };
  },
  function(module2, exports, __webpack_require__) {
    var content = __webpack_require__(90);
    if (content.__esModule)
      content = content.default;
    if (typeof content === "string")
      content = [[module2.i, content, ""]];
    if (content.locals)
      module2.exports = content.locals;
    var add = __webpack_require__(5).default;
    module2.exports.__inject__ = function(context) {
      add("60196300", content, true, context);
    };
  },
  function(module2, exports, __webpack_require__) {
    var content = __webpack_require__(92);
    if (content.__esModule)
      content = content.default;
    if (typeof content === "string")
      content = [[module2.i, content, ""]];
    if (content.locals)
      module2.exports = content.locals;
    var add = __webpack_require__(5).default;
    module2.exports.__inject__ = function(context) {
      add("17b2e9ce", content, true, context);
    };
  },
  function(module2, exports, __webpack_require__) {
    var content = __webpack_require__(94);
    if (content.__esModule)
      content = content.default;
    if (typeof content === "string")
      content = [[module2.i, content, ""]];
    if (content.locals)
      module2.exports = content.locals;
    var add = __webpack_require__(5).default;
    module2.exports.__inject__ = function(context) {
      add("05c7d2f6", content, true, context);
    };
  },
  function(module2, exports, __webpack_require__) {
    var content = __webpack_require__(96);
    if (content.__esModule)
      content = content.default;
    if (typeof content === "string")
      content = [[module2.i, content, ""]];
    if (content.locals)
      module2.exports = content.locals;
    var add = __webpack_require__(5).default;
    module2.exports.__inject__ = function(context) {
      add("18280970", content, true, context);
    };
  },
  function(module2, exports) {
  },
  function(module2, exports) {
    module2.exports = require$$32;
  },
  function(module2, exports) {
    module2.exports = require$$33;
  },
  function(module2, exports) {
    module2.exports = require$$34;
  },
  function(module2, exports) {
    module2.exports = require$$35;
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var render = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _vm.loading ? _c("div", { staticClass: "loading-page" }, [_vm._ssrNode("<p data-v-fcf1beee>Loading...</p>")]) : _vm._e();
    };
    var staticRenderFns = [];
    var LoadingBarvue_type_script_lang_js_ = {
      data: () => ({
        loading: false
      }),
      methods: {
        start() {
          this.loading = true;
        },
        finish() {
          this.loading = false;
        }
      }
    };
    var components_LoadingBarvue_type_script_lang_js_ = LoadingBarvue_type_script_lang_js_;
    var componentNormalizer = __webpack_require__(2);
    function injectStyles(context) {
      var style0 = __webpack_require__(81);
      if (style0.__inject__)
        style0.__inject__(context);
    }
    var component = Object(componentNormalizer["a"])(components_LoadingBarvue_type_script_lang_js_, render, staticRenderFns, false, injectStyles, "fcf1beee", "6b17dc22");
    __webpack_exports__["default"] = component.exports;
  },
  function(module2, exports, __webpack_require__) {
    module2.exports = __webpack_require__.p + "img/site-logo-white.e4d9897.svg";
  },
  function(module2, exports, __webpack_require__) {
    module2.exports = __webpack_require__.p + "img/site-logo.4909022.svg";
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var render = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", { staticClass: "lang-dropdown" }, [_c("select", { directives: [{ name: "model", rawName: "v-model", value: _vm.$i18n.locale, expression: "$i18n.locale" }], on: { "change": function($event) {
        var $$selectedVal = Array.prototype.filter.call($event.target.options, function(o) {
          return o.selected;
        }).map(function(o) {
          var val = "_value" in o ? o._value : o.value;
          return val;
        });
        _vm.$set(_vm.$i18n, "locale", $event.target.multiple ? $$selectedVal : $$selectedVal[0]);
      } } }, _vm._l(_vm.$i18n.locales, function(lang) {
        return _c("option", { key: lang.code, domProps: { "value": lang.code } }, [_vm._v(_vm._s(lang.name))]);
      }), 0)]);
    };
    var staticRenderFns = [];
    var LanguageInputvue_type_script_lang_js_ = {};
    var components_LanguageInputvue_type_script_lang_js_ = LanguageInputvue_type_script_lang_js_;
    var componentNormalizer = __webpack_require__(2);
    function injectStyles(context) {
      var style0 = __webpack_require__(91);
      if (style0.__inject__)
        style0.__inject__(context);
    }
    var component = Object(componentNormalizer["a"])(components_LanguageInputvue_type_script_lang_js_, render, staticRenderFns, false, injectStyles, "b8c0ea24", "8dcdc792");
    __webpack_exports__["default"] = component.exports;
  },
  function(module2, exports, __webpack_require__) {
    __webpack_require__(75);
    __webpack_require__(76);
    module2.exports = __webpack_require__(99);
  },
  function(module2, exports) {
    globalThis.installComponents = function(component, components) {
      var options = typeof component.exports === "function" ? component.exports.extendOptions : component.options;
      if (typeof component.exports === "function") {
        options.components = component.exports.options.components;
      }
      options.components = options.components || {};
      for (var i in components) {
        options.components[i] = options.components[i] || components[i];
      }
      if (options.functional) {
        provideFunctionalComponents(component, options.components);
      }
    };
    var functionalPatchKey = "_functionalComponents";
    function provideFunctionalComponents(component, components) {
      if (component.exports[functionalPatchKey]) {
        return;
      }
      component.exports[functionalPatchKey] = true;
      var render = component.exports.render;
      component.exports.render = function(h, vm) {
        return render(h, Object.assign({}, vm, {
          _c: function(n, a, b) {
            return vm._c(components[n] || n, a, b);
          }
        }));
      };
    }
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
    var _vue_composition_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(0);
    var _app__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6);
    vue__WEBPACK_IMPORTED_MODULE_0__["default"].use(_vue_composition_api__WEBPACK_IMPORTED_MODULE_1__["f"].default || _vue_composition_api__WEBPACK_IMPORTED_MODULE_1__["f"]);
    __webpack_exports__["default"] = Object(_app__WEBPACK_IMPORTED_MODULE_2__["a"])((nuxtApp) => {
      const _originalSetup = nuxtApp.nuxt2Context.app.setup;
      nuxtApp.nuxt2Context.app.setup = function(...args) {
        const result = _originalSetup instanceof Function ? _originalSetup(...args) : {};
        nuxtApp.hooks.callHookWith((hooks) => hooks.map((hook) => hook()), "vue:setup");
        return result;
      };
    });
  },
  function(module2, exports) {
    module2.exports = require$$36;
  },
  function(module2, exports) {
    module2.exports = require$$37;
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_error_vue_vue_type_style_index_0_id_38fb106c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(58);
    for (var __WEBPACK_IMPORT_KEY__ in _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_error_vue_vue_type_style_index_0_id_38fb106c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__)
      if (["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0)
        (function(key) {
          __webpack_require__.d(__webpack_exports__, key, function() {
            return _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_error_vue_vue_type_style_index_0_id_38fb106c_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key];
          });
        })(__WEBPACK_IMPORT_KEY__);
  },
  function(module2, exports, __webpack_require__) {
    var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
    var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(7);
    var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(8);
    var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(9);
    var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(10);
    var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(11);
    var ___CSS_LOADER_URL_IMPORT_4___ = __webpack_require__(12);
    var ___CSS_LOADER_URL_IMPORT_5___ = __webpack_require__(13);
    var ___CSS_LOADER_URL_IMPORT_6___ = __webpack_require__(14);
    var ___CSS_LOADER_URL_IMPORT_7___ = __webpack_require__(15);
    var ___CSS_LOADER_URL_IMPORT_8___ = __webpack_require__(16);
    var ___CSS_LOADER_URL_IMPORT_9___ = __webpack_require__(17);
    var ___CSS_LOADER_URL_IMPORT_10___ = __webpack_require__(18);
    var ___CSS_LOADER_URL_IMPORT_11___ = __webpack_require__(19);
    var ___CSS_LOADER_URL_IMPORT_12___ = __webpack_require__(20);
    var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i) {
      return i[1];
    });
    var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
    var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
    var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
    var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
    var ___CSS_LOADER_URL_REPLACEMENT_4___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_4___);
    var ___CSS_LOADER_URL_REPLACEMENT_5___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_5___);
    var ___CSS_LOADER_URL_REPLACEMENT_6___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_6___);
    var ___CSS_LOADER_URL_REPLACEMENT_7___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_7___);
    var ___CSS_LOADER_URL_REPLACEMENT_8___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_8___);
    var ___CSS_LOADER_URL_REPLACEMENT_9___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_9___);
    var ___CSS_LOADER_URL_REPLACEMENT_10___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_10___);
    var ___CSS_LOADER_URL_REPLACEMENT_11___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_11___);
    var ___CSS_LOADER_URL_REPLACEMENT_12___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_12___);
    ___CSS_LOADER_EXPORT___.push([module2.i, '/*purgecss start ignore*/\nbody[data-v-38fb106c],html[data-v-38fb106c]{\n  font-family:"Poppins","Pretendard",sans-serif\n}\n.container[data-v-38fb106c]{\n  width:100%;\n  margin:0 auto\n}\n.divider-1[data-v-38fb106c]{\n  display:block;\n  width:100%;\n  height:1px;\n  background-color:#cfcfcf\n}\n.heading-1[data-v-38fb106c]{\n  font-size:52px;\n  letter-spacing:-.02em\n}\n.heading-1[data-v-38fb106c],.heading-2[data-v-38fb106c]{\n  font-family:"Poppins","Pretendard",sans-serif;\n  font-style:normal;\n  font-weight:500;\n  line-height:100%;\n  color:#181818\n}\n.heading-2[data-v-38fb106c]{\n  font-size:32px\n}\n.fluidContainer[data-v-38fb106c]{\n  padding:0 36px\n}\n@media screen and (max-width:767px){\n.fluidContainer[data-v-38fb106c]{\n    padding:0\n}\n}\n.custom-checkbox[data-v-38fb106c]{\n  display:block;\n  position:relative;\n  padding-left:30px;\n  margin-bottom:12px;\n  cursor:pointer;\n  font-size:22px;\n  -webkit-user-select:none;\n  -moz-user-select:none;\n  -ms-user-select:none;\n  user-select:none\n}\n.custom-checkbox input[data-v-38fb106c]{\n  position:absolute;\n  opacity:0;\n  cursor:pointer;\n  height:0;\n  width:0\n}\n.checkmark[data-v-38fb106c]{\n  position:absolute;\n  top:0;\n  left:0;\n  height:16px;\n  width:16px;\n  background-color:#fff;\n  border:1px solid #bdbdbd\n}\n.custom-checkbox:hover input~.checkmark[data-v-38fb106c]{\n  background-color:#ececec\n}\n.custom-checkbox input:checked~.checkmark[data-v-38fb106c]{\n  background-color:#57195c;\n  border:1px solid #57195c\n}\n.checkmark[data-v-38fb106c]:after{\n  content:"";\n  position:absolute;\n  display:block\n}\n.custom-checkbox input:checked~.checkmark[data-v-38fb106c]:after{\n  display:block\n}\n.custom-checkbox .checkmark[data-v-38fb106c]:after{\n  left:5px;\n  top:1px;\n  width:5px;\n  height:10px;\n  border:solid #bdbdbd;\n  border-width:0 1px 1px 0;\n  transform:rotate(45deg)\n}\n.icon-location-pin[data-v-38fb106c]{\n  background:url(' + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-call[data-v-38fb106c],.icon-location-pin[data-v-38fb106c]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-call[data-v-38fb106c]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax[data-v-38fb106c]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax[data-v-38fb106c],.icon-mail[data-v-38fb106c]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-mail[data-v-38fb106c]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-train[data-v-38fb106c]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-bus[data-v-38fb106c],.icon-train[data-v-38fb106c]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-bus[data-v-38fb106c]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb[data-v-38fb106c]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb[data-v-38fb106c],.icon-ln[data-v-38fb106c]{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-ln[data-v-38fb106c]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu[data-v-38fb106c]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_8___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu[data-v-38fb106c],.icon-menu-violet-bg[data-v-38fb106c]{\n  height:18px;\n  width:26px;\n  display:inline-block\n}\n.icon-menu-violet-bg[data-v-38fb106c]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_9___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-cross[data-v-38fb106c]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_10___ + ") no-repeat 50%;\n  background-size:100%;\n  height:19px;\n  width:19px;\n  display:inline-block\n}\n.icon-linkedin-dark[data-v-38fb106c]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_11___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-facebook-dark[data-v-38fb106c],.icon-linkedin-dark[data-v-38fb106c]{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-facebook-dark[data-v-38fb106c]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_12___ + ") no-repeat 50%;\n  background-size:100%\n}\n.error-page[data-v-38fb106c]{\n  position:fixed;\n  top:0;\n  left:0;\n  width:100%;\n  height:100%;\n  background:#d53535;\n  text-align:center;\n  padding-top:200px;\n  font-size:30px;\n  font-family:sans-serif\n}\n\n/*purgecss end ignore*/", ""]);
    ___CSS_LOADER_EXPORT___.locals = {};
    module2.exports = ___CSS_LOADER_EXPORT___;
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_5_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_5_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_5_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_LoadingBar_vue_vue_type_style_index_0_id_fcf1beee_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59);
    for (var __WEBPACK_IMPORT_KEY__ in _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_5_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_5_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_5_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_LoadingBar_vue_vue_type_style_index_0_id_fcf1beee_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__)
      if (["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0)
        (function(key) {
          __webpack_require__.d(__webpack_exports__, key, function() {
            return _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_5_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_5_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_5_oneOf_1_2_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_LoadingBar_vue_vue_type_style_index_0_id_fcf1beee_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key];
          });
        })(__WEBPACK_IMPORT_KEY__);
  },
  function(module2, exports, __webpack_require__) {
    var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
    var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i) {
      return i[1];
    });
    ___CSS_LOADER_EXPORT___.push([module2.i, "/*purgecss start ignore*/\n.loading-page[data-v-fcf1beee]{\n  position:fixed;\n  top:0;\n  left:0;\n  width:100%;\n  height:100%;\n  background:rgba(213,53,53,.8);\n  text-align:center;\n  padding-top:200px;\n  font-size:30px;\n  font-family:sans-serif\n}\n\n/*purgecss end ignore*/", ""]);
    ___CSS_LOADER_EXPORT___.locals = {};
    module2.exports = ___CSS_LOADER_EXPORT___;
  },
  function(module2, exports, __webpack_require__) {
    var content = __webpack_require__(84);
    if (content.__esModule)
      content = content.default;
    if (typeof content === "string")
      content = [[module2.i, content, ""]];
    if (content.locals)
      module2.exports = content.locals;
    __webpack_require__(5).default("52dd2c64", content, true);
  },
  function(module2, exports, __webpack_require__) {
    var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
    var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i) {
      return i[1];
    });
    ___CSS_LOADER_EXPORT___.push([module2.i, "/*! tailwindcss v2.2.19 | MIT License | https://tailwindcss.com*/\n\n/*! modern-normalize v1.1.0 | MIT License | https://github.com/sindresorhus/modern-normalize */\n\n/*\nDocument\n========\n*/\n\n/**\nUse a better box model (opinionated).\n*/\n\n*,\n::before,\n::after {\n  box-sizing: border-box;\n}\n\n/**\nUse a more readable tab size (opinionated).\n*/\n\nhtml {\n  -moz-tab-size: 4;\n  -o-tab-size: 4;\n     tab-size: 4;\n}\n\n/**\n1. Correct the line height in all browsers.\n2. Prevent adjustments of font size after orientation changes in iOS.\n*/\n\nhtml {\n  line-height: 1.15; /* 1 */\n  -webkit-text-size-adjust: 100%; /* 2 */\n}\n\n/*\nSections\n========\n*/\n\n/**\nRemove the margin in all browsers.\n*/\n\nbody {\n  margin: 0;\n}\n\n/**\nImprove consistency of default fonts in all browsers. (https://github.com/sindresorhus/modern-normalize/issues/3)\n*/\n\nbody {\n  font-family:\n		system-ui,\n		-apple-system, /* Firefox supports this but not yet `system-ui` */\n		'Segoe UI',\n		Roboto,\n		Helvetica,\n		Arial,\n		sans-serif,\n		'Apple Color Emoji',\n		'Segoe UI Emoji';\n}\n\n/*\nGrouping content\n================\n*/\n\n/**\n1. Add the correct height in Firefox.\n2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)\n*/\n\nhr {\n  height: 0; /* 1 */\n  color: inherit; /* 2 */\n}\n\n/*\nText-level semantics\n====================\n*/\n\n/**\nAdd the correct text decoration in Chrome, Edge, and Safari.\n*/\n\nabbr[title] {\n  -webkit-text-decoration: underline dotted;\n          text-decoration: underline dotted;\n}\n\n/**\nAdd the correct font weight in Edge and Safari.\n*/\n\nb,\nstrong {\n  font-weight: bolder;\n}\n\n/**\n1. Improve consistency of default fonts in all browsers. (https://github.com/sindresorhus/modern-normalize/issues/3)\n2. Correct the odd 'em' font sizing in all browsers.\n*/\n\ncode,\nkbd,\nsamp,\npre {\n  font-family:\n		ui-monospace,\n		SFMono-Regular,\n		Consolas,\n		'Liberation Mono',\n		Menlo,\n		monospace; /* 1 */\n  font-size: 1em; /* 2 */\n}\n\n/**\nAdd the correct font size in all browsers.\n*/\n\nsmall {\n  font-size: 80%;\n}\n\n/**\nPrevent 'sub' and 'sup' elements from affecting the line height in all browsers.\n*/\n\nsub,\nsup {\n  font-size: 75%;\n  line-height: 0;\n  position: relative;\n  vertical-align: baseline;\n}\n\nsub {\n  bottom: -0.25em;\n}\n\nsup {\n  top: -0.5em;\n}\n\n/*\nTabular data\n============\n*/\n\n/**\n1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)\n2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)\n*/\n\ntable {\n  text-indent: 0; /* 1 */\n  border-color: inherit; /* 2 */\n}\n\n/*\nForms\n=====\n*/\n\n/**\n1. Change the font styles in all browsers.\n2. Remove the margin in Firefox and Safari.\n*/\n\nbutton,\ninput,\noptgroup,\nselect,\ntextarea {\n  font-family: inherit; /* 1 */\n  font-size: 100%; /* 1 */\n  line-height: 1.15; /* 1 */\n  margin: 0; /* 2 */\n}\n\n/**\nRemove the inheritance of text transform in Edge and Firefox.\n1. Remove the inheritance of text transform in Firefox.\n*/\n\nbutton,\nselect { /* 1 */\n  text-transform: none;\n}\n\n/**\nCorrect the inability to style clickable types in iOS and Safari.\n*/\n\nbutton,\n[type='button'] {\n  -webkit-appearance: button;\n}\n\n/**\nRemove the inner border and padding in Firefox.\n*/\n\n::-moz-focus-inner {\n  border-style: none;\n  padding: 0;\n}\n\n/**\nRestore the focus styles unset by the previous rule.\n*/\n\n/**\nRemove the additional ':invalid' styles in Firefox.\nSee: https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737\n*/\n\n/**\nRemove the padding so developers are not caught out when they zero out 'fieldset' elements in all browsers.\n*/\n\nlegend {\n  padding: 0;\n}\n\n/**\nAdd the correct vertical alignment in Chrome and Firefox.\n*/\n\nprogress {\n  vertical-align: baseline;\n}\n\n/**\nCorrect the cursor style of increment and decrement buttons in Safari.\n*/\n\n::-webkit-inner-spin-button,\n::-webkit-outer-spin-button {\n  height: auto;\n}\n\n/**\n1. Correct the odd appearance in Chrome and Safari.\n2. Correct the outline style in Safari.\n*/\n\n/**\nRemove the inner padding in Chrome and Safari on macOS.\n*/\n\n::-webkit-search-decoration {\n  -webkit-appearance: none;\n}\n\n/**\n1. Correct the inability to style clickable types in iOS and Safari.\n2. Change font properties to 'inherit' in Safari.\n*/\n\n::-webkit-file-upload-button {\n  -webkit-appearance: button; /* 1 */\n  font: inherit; /* 2 */\n}\n\n/*\nInteractive\n===========\n*/\n\n/*\nAdd the correct display in Chrome and Safari.\n*/\n\nsummary {\n  display: list-item;\n}\n\n/**\n * Manually forked from SUIT CSS Base: https://github.com/suitcss/base\n * A thin layer on top of normalize.css that provides a starting point more\n * suitable for web applications.\n */\n\n/**\n * Removes the default spacing and border for appropriate elements.\n */\n\nblockquote,\ndl,\ndd,\nh1,\nh2,\nh3,\nh4,\nh5,\nh6,\nhr,\nfigure,\np,\npre {\n  margin: 0;\n}\n\nbutton {\n  background-color: transparent;\n  background-image: none;\n}\n\nfieldset {\n  margin: 0;\n  padding: 0;\n}\n\nol,\nul {\n  list-style: none;\n  margin: 0;\n  padding: 0;\n}\n\n/**\n * Tailwind custom reset styles\n */\n\n/**\n * 1. Use the user's configured `sans` font-family (with Tailwind's default\n *    sans-serif font stack as a fallback) as a sane default.\n * 2. Use Tailwind's default \"normal\" line-height so the user isn't forced\n *    to override it to ensure consistency even when using the default theme.\n */\n\nhtml {\n  font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, \"Noto Sans\", sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\"; /* 1 */\n  line-height: 1.5; /* 2 */\n}\n\n/**\n * Inherit font-family and line-height from `html` so users can set them as\n * a class directly on the `html` element.\n */\n\nbody {\n  font-family: inherit;\n  line-height: inherit;\n}\n\n/**\n * 1. Prevent padding and border from affecting element width.\n *\n *    We used to set this in the html element and inherit from\n *    the parent element for everything else. This caused issues\n *    in shadow-dom-enhanced elements like <details> where the content\n *    is wrapped by a div with box-sizing set to `content-box`.\n *\n *    https://github.com/mozdevs/cssremedy/issues/4\n *\n *\n * 2. Allow adding a border to an element by just adding a border-width.\n *\n *    By default, the way the browser specifies that an element should have no\n *    border is by setting it's border-style to `none` in the user-agent\n *    stylesheet.\n *\n *    In order to easily add borders to elements by just setting the `border-width`\n *    property, we change the default border-style for all elements to `solid`, and\n *    use border-width to hide them instead. This way our `border` utilities only\n *    need to set the `border-width` property instead of the entire `border`\n *    shorthand, making our border utilities much more straightforward to compose.\n *\n *    https://github.com/tailwindcss/tailwindcss/pull/116\n */\n\n*,\n::before,\n::after {\n  box-sizing: border-box; /* 1 */\n  border-width: 0; /* 2 */\n  border-style: solid; /* 2 */\n  border-color: currentColor; /* 2 */\n}\n\n/*\n * Ensure horizontal rules are visible by default\n */\n\nhr {\n  border-top-width: 1px;\n}\n\n/**\n * Undo the `border-style: none` reset that Normalize applies to images so that\n * our `border-{width}` utilities have the expected effect.\n *\n * The Normalize reset is unnecessary for us since we default the border-width\n * to 0 on all elements.\n *\n * https://github.com/tailwindcss/tailwindcss/issues/362\n */\n\nimg {\n  border-style: solid;\n}\n\ntextarea {\n  resize: vertical;\n}\n\ninput::-moz-placeholder, textarea::-moz-placeholder {\n  opacity: 1;\n  color: #a1a1aa;\n}\n\ninput:-ms-input-placeholder, textarea:-ms-input-placeholder {\n  opacity: 1;\n  color: #a1a1aa;\n}\n\ninput::placeholder,\ntextarea::placeholder {\n  opacity: 1;\n  color: #a1a1aa;\n}\n\nbutton,\n[role=\"button\"] {\n  cursor: pointer;\n}\n\n/**\n * Override legacy focus reset from Normalize with modern Firefox focus styles.\n *\n * This is actually an improvement over the new defaults in Firefox in our testing,\n * as it triggers the better focus styles even for links, which still use a dotted\n * outline in Firefox by default.\n */\n\ntable {\n  border-collapse: collapse;\n}\n\nh1,\nh2,\nh3,\nh4,\nh5,\nh6 {\n  font-size: inherit;\n  font-weight: inherit;\n}\n\n/**\n * Reset links to optimize for opt-in styling instead of\n * opt-out.\n */\n\na {\n  color: inherit;\n  text-decoration: inherit;\n}\n\n/**\n * Reset form element properties that are easy to forget to\n * style explicitly so you don't inadvertently introduce\n * styles that deviate from your design system. These styles\n * supplement a partial reset that is already applied by\n * normalize.css.\n */\n\nbutton,\ninput,\noptgroup,\nselect,\ntextarea {\n  padding: 0;\n  line-height: inherit;\n  color: inherit;\n}\n\n/**\n * Use the configured 'mono' font family for elements that\n * are expected to be rendered with a monospace font, falling\n * back to the system monospace stack if there is no configured\n * 'mono' font family.\n */\n\npre,\ncode,\nkbd,\nsamp {\n  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace;\n}\n\n/**\n * 1. Make replaced elements `display: block` by default as that's\n *    the behavior you want almost all of the time. Inspired by\n *    CSS Remedy, with `svg` added as well.\n *\n *    https://github.com/mozdevs/cssremedy/issues/14\n * \n * 2. Add `vertical-align: middle` to align replaced elements more\n *    sensibly by default when overriding `display` by adding a\n *    utility like `inline`.\n *\n *    This can trigger a poorly considered linting error in some\n *    tools but is included by design.\n * \n *    https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210\n */\n\nimg,\nsvg,\nvideo,\ncanvas,\naudio,\niframe,\nembed,\nobject {\n  display: block; /* 1 */\n  vertical-align: middle; /* 2 */\n}\n\n/**\n * Constrain images and videos to the parent width and preserve\n * their intrinsic aspect ratio.\n *\n * https://github.com/mozdevs/cssremedy/issues/14\n */\n\nimg,\nvideo {\n  max-width: 100%;\n  height: auto;\n}\n\n/**\n * Ensure the default browser behavior of the `hidden` attribute.\n */\n\n*, ::before, ::after{\n  border-color:currentColor;\n}\n\n.container{\n  width:100%;\n  padding-right:48px;\n  padding-left:48px;\n}\n\n@media (min-width: 640px){\n  .container{\n    max-width:640px;\n    padding-right:15px;\n    padding-left:15px;\n  }\n}\n\n@media (min-width: 768px){\n  .container{\n    max-width:768px;\n  }\n}\n\n@media (min-width: 1024px){\n  .container{\n    max-width:1024px;\n    padding-right:20px;\n    padding-left:20px;\n  }\n}\n\n@media (min-width: 1280px){\n  .container{\n    max-width:1280px;\n    padding-right:48px;\n    padding-left:48px;\n  }\n}\n\n@media (min-width: 1536px){\n  .container{\n    max-width:1536px;\n    padding-right:48px;\n    padding-left:48px;\n  }\n}\n\n@media (min-width: 1824px){\n  .container{\n    max-width:1824px;\n    padding-right:48px;\n    padding-left:48px;\n  }\n}\n\n.relative{\n  position:relative;\n}\n\n.col-auto{\n  grid-column:auto;\n}\n\n.mx-auto{\n  margin-left:auto;\n  margin-right:auto;\n}\n\n.mt-3{\n  margin-top:0.75rem;\n}\n\n.mt-4{\n  margin-top:1rem;\n}\n\n.mt-8{\n  margin-top:2rem;\n}\n\n.mb-10{\n  margin-bottom:2.5rem;\n}\n\n.flex{\n  display:flex;\n}\n\n.table{\n  display:table;\n}\n\n.grid{\n  display:grid;\n}\n\n.contents{\n  display:contents;\n}\n\n.h-4{\n  height:1rem;\n}\n\n.h-6{\n  height:1.5rem;\n}\n\n.min-h-screen{\n  min-height:100vh;\n}\n\n.w-4{\n  width:1rem;\n}\n\n.w-6{\n  width:1.5rem;\n}\n\n.w-1\\/2{\n  width:50%;\n}\n\n.w-full{\n  width:100%;\n}\n\n.max-w-4xl{\n  max-width:56rem;\n}\n\n.transform{\n  --tw-translate-x:0;\n  --tw-translate-y:0;\n  --tw-rotate:0;\n  --tw-skew-x:0;\n  --tw-skew-y:0;\n  --tw-scale-x:1;\n  --tw-scale-y:1;\n  transform:translateX(var(--tw-translate-x)) translateY(var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));\n}\n\n@-webkit-keyframes spin{\n  to{\n    transform:rotate(360deg);\n  }\n}\n\n@keyframes spin{\n  to{\n    transform:rotate(360deg);\n  }\n}\n\n@-webkit-keyframes ping{\n  75%, 100%{\n    transform:scale(2);\n    opacity:0;\n  }\n}\n\n@keyframes ping{\n  75%, 100%{\n    transform:scale(2);\n    opacity:0;\n  }\n}\n\n@-webkit-keyframes pulse{\n  50%{\n    opacity:.5;\n  }\n}\n\n@keyframes pulse{\n  50%{\n    opacity:.5;\n  }\n}\n\n@-webkit-keyframes bounce{\n  0%, 100%{\n    transform:translateY(-25%);\n    -webkit-animation-timing-function:cubic-bezier(0.8,0,1,1);\n            animation-timing-function:cubic-bezier(0.8,0,1,1);\n  }\n\n  50%{\n    transform:none;\n    -webkit-animation-timing-function:cubic-bezier(0,0,0.2,1);\n            animation-timing-function:cubic-bezier(0,0,0.2,1);\n  }\n}\n\n@keyframes bounce{\n  0%, 100%{\n    transform:translateY(-25%);\n    -webkit-animation-timing-function:cubic-bezier(0.8,0,1,1);\n            animation-timing-function:cubic-bezier(0.8,0,1,1);\n  }\n\n  50%{\n    transform:none;\n    -webkit-animation-timing-function:cubic-bezier(0,0,0.2,1);\n            animation-timing-function:cubic-bezier(0,0,0.2,1);\n  }\n}\n\n.resize{\n  resize:both;\n}\n\n.appearance-none{\n  -webkit-appearance:none;\n     -moz-appearance:none;\n          appearance:none;\n}\n\n.grid-flow-col{\n  grid-auto-flow:column;\n}\n\n.grid-cols-1{\n  grid-template-columns:repeat(1, minmax(0, 1fr));\n}\n\n.grid-cols-2{\n  grid-template-columns:repeat(2, minmax(0, 1fr));\n}\n\n.grid-rows-1{\n  grid-template-rows:repeat(1, minmax(0, 1fr));\n}\n\n.items-center{\n  align-items:center;\n}\n\n.justify-center{\n  justify-content:center;\n}\n\n.justify-around{\n  justify-content:space-around;\n}\n\n.gap-10{\n  gap:2.5rem;\n}\n\n.space-x-2 > :not([hidden]) ~ :not([hidden]){\n  --tw-space-x-reverse:0;\n  margin-right:calc(0.5rem * var(--tw-space-x-reverse));\n  margin-left:calc(0.5rem * calc(1 - var(--tw-space-x-reverse)));\n}\n\n.overflow-hidden{\n  overflow:hidden;\n}\n\n.rounded-sm{\n  border-radius:0.125rem;\n}\n\n.rounded{\n  border-radius:0.25rem;\n}\n\n.border{\n  border-width:1px;\n}\n\n.border-t{\n  border-top-width:1px;\n}\n\n.border-dashed{\n  border-style:dashed;\n}\n\n.border-grey-1{\n  --tw-border-opacity:1;\n  border-color:rgba(189, 189, 189, var(--tw-border-opacity));\n}\n\n.bg-transparent{\n  background-color:transparent;\n}\n\n.bg-white{\n  --tw-bg-opacity:1;\n  background-color:rgba(255, 255, 255, var(--tw-bg-opacity));\n}\n\n.p-1{\n  padding:0.25rem;\n}\n\n.p-5{\n  padding:1.25rem;\n}\n\n.p-6{\n  padding:1.5rem;\n}\n\n.px-4{\n  padding-left:1rem;\n  padding-right:1rem;\n}\n\n.pt-4{\n  padding-top:1rem;\n}\n\n.pt-8{\n  padding-top:2rem;\n}\n\n.pb-2{\n  padding-bottom:0.5rem;\n}\n\n.text-right{\n  text-align:right;\n}\n\n.text-sm{\n  font-size:0.875rem;\n  line-height:1.25rem;\n}\n\n.text-2xl{\n  font-size:1.5rem;\n  line-height:2rem;\n}\n\n.font-semibold{\n  font-weight:600;\n}\n\n.leading-7{\n  line-height:1.75rem;\n}\n\n.hover\\:underline:hover{\n  text-decoration:underline;\n}\n\n*, ::before, ::after{\n  --tw-shadow:0 0 #0000;\n}\n\n.shadow{\n  --tw-shadow:0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);\n  box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);\n}\n\n*, ::before, ::after{\n  --tw-ring-inset:var(--tw-empty,/*!*/ /*!*/);\n  --tw-ring-offset-width:0px;\n  --tw-ring-offset-color:#fff;\n  --tw-ring-color:rgba(59, 130, 246, 0.5);\n  --tw-ring-offset-shadow:0 0 #0000;\n  --tw-ring-shadow:0 0 #0000;\n}\n\n.blur{\n  --tw-blur:blur(8px);\n}\n\n.backdrop-filter{\n  --tw-backdrop-blur:var(--tw-empty,/*!*/ /*!*/);\n  --tw-backdrop-brightness:var(--tw-empty,/*!*/ /*!*/);\n  --tw-backdrop-contrast:var(--tw-empty,/*!*/ /*!*/);\n  --tw-backdrop-grayscale:var(--tw-empty,/*!*/ /*!*/);\n  --tw-backdrop-hue-rotate:var(--tw-empty,/*!*/ /*!*/);\n  --tw-backdrop-invert:var(--tw-empty,/*!*/ /*!*/);\n  --tw-backdrop-opacity:var(--tw-empty,/*!*/ /*!*/);\n  --tw-backdrop-saturate:var(--tw-empty,/*!*/ /*!*/);\n  --tw-backdrop-sepia:var(--tw-empty,/*!*/ /*!*/);\n  -webkit-backdrop-filter:var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);\n          backdrop-filter:var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);\n}\n\n.transition{\n  transition-property:background-color, border-color, color, fill, stroke, opacity, box-shadow, transform, filter, -webkit-backdrop-filter;\n  transition-property:background-color, border-color, color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;\n  transition-property:background-color, border-color, color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter, -webkit-backdrop-filter;\n  transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);\n  transition-duration:150ms;\n}\n\n.ease-in-out{\n  transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);\n}\n\n@media (min-width: 640px){\n  .sm\\:items-center{\n    align-items:center;\n  }\n\n  .sm\\:rounded-lg{\n    border-radius:0.5rem;\n  }\n\n  .sm\\:px-6{\n    padding-left:1.5rem;\n    padding-right:1.5rem;\n  }\n\n  .sm\\:pt-0{\n    padding-top:0px;\n  }\n}\n\n@media (min-width: 768px){\n  .md\\:grid-cols-2{\n    grid-template-columns:repeat(2, minmax(0, 1fr));\n  }\n\n  .md\\:gap-4{\n    gap:1rem;\n  }\n\n  .md\\:gap-20{\n    gap:5rem;\n  }\n}\n\n@media (min-width: 1024px){\n  .lg\\:grid-cols-4{\n    grid-template-columns:repeat(4, minmax(0, 1fr));\n  }\n\n  .lg\\:gap-8{\n    gap:2rem;\n  }\n\n  .lg\\:px-8{\n    padding-left:2rem;\n    padding-right:2rem;\n  }\n}\n\n@media (min-width: 1280px){\n}\n\n@media (min-width: 1536px){\n}\n\n@media (min-width: 1824px){\n}", ""]);
    ___CSS_LOADER_EXPORT___.locals = {};
    module2.exports = ___CSS_LOADER_EXPORT___;
  },
  function(module2, exports, __webpack_require__) {
    var content = __webpack_require__(86);
    if (content.__esModule)
      content = content.default;
    if (typeof content === "string")
      content = [[module2.i, content, ""]];
    if (content.locals)
      module2.exports = content.locals;
    __webpack_require__(5).default("3d645bd0", content, true);
  },
  function(module2, exports, __webpack_require__) {
    var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
    var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i) {
      return i[1];
    });
    ___CSS_LOADER_EXPORT___.push([module2.i, "/*purgecss start ignore*/\n\n/*purgecss end ignore*/", ""]);
    ___CSS_LOADER_EXPORT___.locals = {};
    module2.exports = ___CSS_LOADER_EXPORT___;
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_default_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(60);
    for (var __WEBPACK_IMPORT_KEY__ in _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_default_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__)
      if (["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0)
        (function(key) {
          __webpack_require__.d(__webpack_exports__, key, function() {
            return _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_default_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key];
          });
        })(__WEBPACK_IMPORT_KEY__);
  },
  function(module2, exports, __webpack_require__) {
    var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
    var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(7);
    var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(8);
    var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(9);
    var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(10);
    var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(11);
    var ___CSS_LOADER_URL_IMPORT_4___ = __webpack_require__(12);
    var ___CSS_LOADER_URL_IMPORT_5___ = __webpack_require__(13);
    var ___CSS_LOADER_URL_IMPORT_6___ = __webpack_require__(14);
    var ___CSS_LOADER_URL_IMPORT_7___ = __webpack_require__(15);
    var ___CSS_LOADER_URL_IMPORT_8___ = __webpack_require__(16);
    var ___CSS_LOADER_URL_IMPORT_9___ = __webpack_require__(17);
    var ___CSS_LOADER_URL_IMPORT_10___ = __webpack_require__(18);
    var ___CSS_LOADER_URL_IMPORT_11___ = __webpack_require__(19);
    var ___CSS_LOADER_URL_IMPORT_12___ = __webpack_require__(20);
    var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i) {
      return i[1];
    });
    var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
    var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
    var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
    var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
    var ___CSS_LOADER_URL_REPLACEMENT_4___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_4___);
    var ___CSS_LOADER_URL_REPLACEMENT_5___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_5___);
    var ___CSS_LOADER_URL_REPLACEMENT_6___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_6___);
    var ___CSS_LOADER_URL_REPLACEMENT_7___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_7___);
    var ___CSS_LOADER_URL_REPLACEMENT_8___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_8___);
    var ___CSS_LOADER_URL_REPLACEMENT_9___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_9___);
    var ___CSS_LOADER_URL_REPLACEMENT_10___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_10___);
    var ___CSS_LOADER_URL_REPLACEMENT_11___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_11___);
    var ___CSS_LOADER_URL_REPLACEMENT_12___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_12___);
    ___CSS_LOADER_EXPORT___.push([module2.i, '/*purgecss start ignore*/\nbody,html{\n  font-family:"Poppins","Pretendard",sans-serif\n}\n.container{\n  width:100%;\n  margin:0 auto\n}\n.divider-1{\n  display:block;\n  width:100%;\n  height:1px;\n  background-color:#cfcfcf\n}\n.heading-1{\n  font-size:52px;\n  letter-spacing:-.02em\n}\n.heading-1,.heading-2{\n  font-family:"Poppins","Pretendard",sans-serif;\n  font-style:normal;\n  font-weight:500;\n  line-height:100%;\n  color:#181818\n}\n.heading-2{\n  font-size:32px\n}\n.fluidContainer{\n  padding:0 36px\n}\n@media screen and (max-width:767px){\n.fluidContainer{\n    padding:0\n}\n}\n.custom-checkbox{\n  display:block;\n  position:relative;\n  padding-left:30px;\n  margin-bottom:12px;\n  cursor:pointer;\n  font-size:22px;\n  -webkit-user-select:none;\n  -moz-user-select:none;\n  -ms-user-select:none;\n  user-select:none\n}\n.custom-checkbox input{\n  position:absolute;\n  opacity:0;\n  cursor:pointer;\n  height:0;\n  width:0\n}\n.checkmark{\n  position:absolute;\n  top:0;\n  left:0;\n  height:16px;\n  width:16px;\n  background-color:#fff;\n  border:1px solid #bdbdbd\n}\n.custom-checkbox:hover input~.checkmark{\n  background-color:#ececec\n}\n.custom-checkbox input:checked~.checkmark{\n  background-color:#57195c;\n  border:1px solid #57195c\n}\n.checkmark:after{\n  content:"";\n  position:absolute;\n  display:block\n}\n.custom-checkbox input:checked~.checkmark:after{\n  display:block\n}\n.custom-checkbox .checkmark:after{\n  left:5px;\n  top:1px;\n  width:5px;\n  height:10px;\n  border:solid #bdbdbd;\n  border-width:0 1px 1px 0;\n  transform:rotate(45deg)\n}\n.icon-location-pin{\n  background:url(' + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-call,.icon-location-pin{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-call{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax,.icon-mail{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-mail{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-train{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-bus,.icon-train{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-bus{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb,.icon-ln{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-ln{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_8___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu,.icon-menu-violet-bg{\n  height:18px;\n  width:26px;\n  display:inline-block\n}\n.icon-menu-violet-bg{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_9___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-cross{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_10___ + ") no-repeat 50%;\n  background-size:100%;\n  height:19px;\n  width:19px;\n  display:inline-block\n}\n.icon-linkedin-dark{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_11___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-facebook-dark,.icon-linkedin-dark{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-facebook-dark{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_12___ + ") no-repeat 50%;\n  background-size:100%\n}\n.main-body{\n  min-height:calc(100vh - 140px)\n}\n\n/*purgecss end ignore*/", ""]);
    ___CSS_LOADER_EXPORT___.locals = {};
    module2.exports = ___CSS_LOADER_EXPORT___;
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_Header_vue_vue_type_style_index_0_id_a0106514_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61);
    for (var __WEBPACK_IMPORT_KEY__ in _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_Header_vue_vue_type_style_index_0_id_a0106514_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__)
      if (["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0)
        (function(key) {
          __webpack_require__.d(__webpack_exports__, key, function() {
            return _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_Header_vue_vue_type_style_index_0_id_a0106514_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key];
          });
        })(__WEBPACK_IMPORT_KEY__);
  },
  function(module2, exports, __webpack_require__) {
    var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
    var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(7);
    var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(8);
    var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(9);
    var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(10);
    var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(11);
    var ___CSS_LOADER_URL_IMPORT_4___ = __webpack_require__(12);
    var ___CSS_LOADER_URL_IMPORT_5___ = __webpack_require__(13);
    var ___CSS_LOADER_URL_IMPORT_6___ = __webpack_require__(14);
    var ___CSS_LOADER_URL_IMPORT_7___ = __webpack_require__(15);
    var ___CSS_LOADER_URL_IMPORT_8___ = __webpack_require__(16);
    var ___CSS_LOADER_URL_IMPORT_9___ = __webpack_require__(17);
    var ___CSS_LOADER_URL_IMPORT_10___ = __webpack_require__(18);
    var ___CSS_LOADER_URL_IMPORT_11___ = __webpack_require__(19);
    var ___CSS_LOADER_URL_IMPORT_12___ = __webpack_require__(20);
    var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i) {
      return i[1];
    });
    var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
    var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
    var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
    var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
    var ___CSS_LOADER_URL_REPLACEMENT_4___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_4___);
    var ___CSS_LOADER_URL_REPLACEMENT_5___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_5___);
    var ___CSS_LOADER_URL_REPLACEMENT_6___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_6___);
    var ___CSS_LOADER_URL_REPLACEMENT_7___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_7___);
    var ___CSS_LOADER_URL_REPLACEMENT_8___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_8___);
    var ___CSS_LOADER_URL_REPLACEMENT_9___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_9___);
    var ___CSS_LOADER_URL_REPLACEMENT_10___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_10___);
    var ___CSS_LOADER_URL_REPLACEMENT_11___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_11___);
    var ___CSS_LOADER_URL_REPLACEMENT_12___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_12___);
    ___CSS_LOADER_EXPORT___.push([module2.i, '/*purgecss start ignore*/\nbody[data-v-a0106514],html[data-v-a0106514]{\n  font-family:"Poppins","Pretendard",sans-serif\n}\n.container[data-v-a0106514]{\n  width:100%;\n  margin:0 auto\n}\n.divider-1[data-v-a0106514]{\n  display:block;\n  width:100%;\n  height:1px;\n  background-color:#cfcfcf\n}\n.heading-1[data-v-a0106514]{\n  font-size:52px;\n  letter-spacing:-.02em\n}\n.heading-1[data-v-a0106514],.heading-2[data-v-a0106514]{\n  font-family:"Poppins","Pretendard",sans-serif;\n  font-style:normal;\n  font-weight:500;\n  line-height:100%;\n  color:#181818\n}\n.heading-2[data-v-a0106514]{\n  font-size:32px\n}\n.fluidContainer[data-v-a0106514]{\n  padding:0 36px\n}\n@media screen and (max-width:767px){\n.fluidContainer[data-v-a0106514]{\n    padding:0\n}\n}\n.custom-checkbox[data-v-a0106514]{\n  display:block;\n  position:relative;\n  padding-left:30px;\n  margin-bottom:12px;\n  cursor:pointer;\n  font-size:22px;\n  -webkit-user-select:none;\n  -moz-user-select:none;\n  -ms-user-select:none;\n  user-select:none\n}\n.custom-checkbox input[data-v-a0106514]{\n  position:absolute;\n  opacity:0;\n  cursor:pointer;\n  height:0;\n  width:0\n}\n.checkmark[data-v-a0106514]{\n  position:absolute;\n  top:0;\n  left:0;\n  height:16px;\n  width:16px;\n  background-color:#fff;\n  border:1px solid #bdbdbd\n}\n.custom-checkbox:hover input~.checkmark[data-v-a0106514]{\n  background-color:#ececec\n}\n.custom-checkbox input:checked~.checkmark[data-v-a0106514]{\n  background-color:#57195c;\n  border:1px solid #57195c\n}\n.checkmark[data-v-a0106514]:after{\n  content:"";\n  position:absolute;\n  display:block\n}\n.custom-checkbox input:checked~.checkmark[data-v-a0106514]:after{\n  display:block\n}\n.custom-checkbox .checkmark[data-v-a0106514]:after{\n  left:5px;\n  top:1px;\n  width:5px;\n  height:10px;\n  border:solid #bdbdbd;\n  border-width:0 1px 1px 0;\n  transform:rotate(45deg)\n}\n.icon-location-pin[data-v-a0106514]{\n  background:url(' + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-call[data-v-a0106514],.icon-location-pin[data-v-a0106514]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-call[data-v-a0106514]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax[data-v-a0106514]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax[data-v-a0106514],.icon-mail[data-v-a0106514]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-mail[data-v-a0106514]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-train[data-v-a0106514]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-bus[data-v-a0106514],.icon-train[data-v-a0106514]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-bus[data-v-a0106514]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb[data-v-a0106514]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb[data-v-a0106514],.icon-ln[data-v-a0106514]{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-ln[data-v-a0106514]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu[data-v-a0106514]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_8___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu[data-v-a0106514],.icon-menu-violet-bg[data-v-a0106514]{\n  height:18px;\n  width:26px;\n  display:inline-block\n}\n.icon-menu-violet-bg[data-v-a0106514]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_9___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-cross[data-v-a0106514]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_10___ + ") no-repeat 50%;\n  background-size:100%;\n  height:19px;\n  width:19px;\n  display:inline-block\n}\n.icon-linkedin-dark[data-v-a0106514]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_11___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-facebook-dark[data-v-a0106514],.icon-linkedin-dark[data-v-a0106514]{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-facebook-dark[data-v-a0106514]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_12___ + ') no-repeat 50%;\n  background-size:100%\n}\n.header .logo[data-v-a0106514]{\n  width:calc(100px + 3vw);\n  height:auto\n}\n.header .header-wrap[data-v-a0106514]{\n  justify-content:space-between;\n  height:80px\n}\n.header .header-wrap[data-v-a0106514],.header .header-wrap .right-panel[data-v-a0106514],.header .header-wrap .right-panel .nav-wrap[data-v-a0106514]{\n  display:flex;\n  align-items:center\n}\n.header .header-wrap .right-panel .nav-wrap .nav-item .nav-link[data-v-a0106514]{\n  font-family:"Poppins","Pretendard",sans-serif;\n  font-style:normal;\n  font-weight:500;\n  font-size:16px;\n  line-height:24px;\n  color:#181818;\n  padding:0 30px\n}\n@media screen and (max-width:1024px){\n.header .header-wrap .right-panel .nav-wrap .nav-item .nav-link[data-v-a0106514]{\n    padding:0 12px\n}\n}\n.header.bg-white[data-v-a0106514]{\n  box-shadow:0 0 10px rgba(0,0,0,.1)\n}\n.header.bg-transparent[data-v-a0106514]{\n  position:absolute;\n  top:0;\n  left:0;\n  width:100%;\n  z-index:9\n}\n.header.bg-transparent .right-panel .lang-dropdown select[data-v-a0106514],.header.bg-transparent .right-panel .nav-wrap .nav-item .nav-link[data-v-a0106514]{\n  color:#fff\n}\n.header .Mobile-dropdown[data-v-a0106514]{\n  position:absolute;\n  top:0;\n  left:0;\n  width:100%;\n  height:100vh;\n  background-color:#fff\n}\n.header .Mobile-dropdown ul[data-v-a0106514]{\n  padding:30px;\n  margin-bottom:10px\n}\n.header .Mobile-dropdown ul li[data-v-a0106514]{\n  margin-bottom:30px;\n  font-weight:500;\n  font-size:16px;\n  color:#181818\n}\n.header .Mobile-dropdown ul li[data-v-a0106514]:last-child{\n  margin-bottom:0\n}\n.header .Mobile-dropdown .lang-select[data-v-a0106514]{\n  padding:0 30px 30px\n}\n.header .Mobile-dropdown .lang-select .elements[data-v-a0106514]{\n  padding:40px 0 0;\n  border-top:1px solid #e0e0e0\n}\n.header .Mobile-dropdown .lang-select .elements span[data-v-a0106514]{\n  font-weight:400;\n  font-size:16px;\n  display:inline-block;\n  margin-right:16px;\n  color:#a4a4a4;\n  cursor:pointer\n}\n.header .Mobile-dropdown .lang-select .elements span.active[data-v-a0106514]{\n  color:#181818\n}\n\n/*purgecss end ignore*/', ""]);
    ___CSS_LOADER_EXPORT___.locals = {};
    module2.exports = ___CSS_LOADER_EXPORT___;
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_LanguageInput_vue_vue_type_style_index_0_id_b8c0ea24_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(62);
    for (var __WEBPACK_IMPORT_KEY__ in _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_LanguageInput_vue_vue_type_style_index_0_id_b8c0ea24_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__)
      if (["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0)
        (function(key) {
          __webpack_require__.d(__webpack_exports__, key, function() {
            return _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_LanguageInput_vue_vue_type_style_index_0_id_b8c0ea24_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key];
          });
        })(__WEBPACK_IMPORT_KEY__);
  },
  function(module2, exports, __webpack_require__) {
    var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
    var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(7);
    var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(8);
    var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(9);
    var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(10);
    var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(11);
    var ___CSS_LOADER_URL_IMPORT_4___ = __webpack_require__(12);
    var ___CSS_LOADER_URL_IMPORT_5___ = __webpack_require__(13);
    var ___CSS_LOADER_URL_IMPORT_6___ = __webpack_require__(14);
    var ___CSS_LOADER_URL_IMPORT_7___ = __webpack_require__(15);
    var ___CSS_LOADER_URL_IMPORT_8___ = __webpack_require__(16);
    var ___CSS_LOADER_URL_IMPORT_9___ = __webpack_require__(17);
    var ___CSS_LOADER_URL_IMPORT_10___ = __webpack_require__(18);
    var ___CSS_LOADER_URL_IMPORT_11___ = __webpack_require__(19);
    var ___CSS_LOADER_URL_IMPORT_12___ = __webpack_require__(20);
    var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i) {
      return i[1];
    });
    var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
    var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
    var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
    var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
    var ___CSS_LOADER_URL_REPLACEMENT_4___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_4___);
    var ___CSS_LOADER_URL_REPLACEMENT_5___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_5___);
    var ___CSS_LOADER_URL_REPLACEMENT_6___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_6___);
    var ___CSS_LOADER_URL_REPLACEMENT_7___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_7___);
    var ___CSS_LOADER_URL_REPLACEMENT_8___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_8___);
    var ___CSS_LOADER_URL_REPLACEMENT_9___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_9___);
    var ___CSS_LOADER_URL_REPLACEMENT_10___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_10___);
    var ___CSS_LOADER_URL_REPLACEMENT_11___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_11___);
    var ___CSS_LOADER_URL_REPLACEMENT_12___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_12___);
    ___CSS_LOADER_EXPORT___.push([module2.i, '/*purgecss start ignore*/\nbody[data-v-b8c0ea24],html[data-v-b8c0ea24]{\n  font-family:"Poppins","Pretendard",sans-serif\n}\n.container[data-v-b8c0ea24]{\n  width:100%;\n  margin:0 auto\n}\n.divider-1[data-v-b8c0ea24]{\n  display:block;\n  width:100%;\n  height:1px;\n  background-color:#cfcfcf\n}\n.heading-1[data-v-b8c0ea24]{\n  font-size:52px;\n  letter-spacing:-.02em\n}\n.heading-1[data-v-b8c0ea24],.heading-2[data-v-b8c0ea24]{\n  font-family:"Poppins","Pretendard",sans-serif;\n  font-style:normal;\n  font-weight:500;\n  line-height:100%;\n  color:#181818\n}\n.heading-2[data-v-b8c0ea24]{\n  font-size:32px\n}\n.fluidContainer[data-v-b8c0ea24]{\n  padding:0 36px\n}\n@media screen and (max-width:767px){\n.fluidContainer[data-v-b8c0ea24]{\n    padding:0\n}\n}\n.custom-checkbox[data-v-b8c0ea24]{\n  display:block;\n  position:relative;\n  padding-left:30px;\n  margin-bottom:12px;\n  cursor:pointer;\n  font-size:22px;\n  -webkit-user-select:none;\n  -moz-user-select:none;\n  -ms-user-select:none;\n  user-select:none\n}\n.custom-checkbox input[data-v-b8c0ea24]{\n  position:absolute;\n  opacity:0;\n  cursor:pointer;\n  height:0;\n  width:0\n}\n.checkmark[data-v-b8c0ea24]{\n  position:absolute;\n  top:0;\n  left:0;\n  height:16px;\n  width:16px;\n  background-color:#fff;\n  border:1px solid #bdbdbd\n}\n.custom-checkbox:hover input~.checkmark[data-v-b8c0ea24]{\n  background-color:#ececec\n}\n.custom-checkbox input:checked~.checkmark[data-v-b8c0ea24]{\n  background-color:#57195c;\n  border:1px solid #57195c\n}\n.checkmark[data-v-b8c0ea24]:after{\n  content:"";\n  position:absolute;\n  display:block\n}\n.custom-checkbox input:checked~.checkmark[data-v-b8c0ea24]:after{\n  display:block\n}\n.custom-checkbox .checkmark[data-v-b8c0ea24]:after{\n  left:5px;\n  top:1px;\n  width:5px;\n  height:10px;\n  border:solid #bdbdbd;\n  border-width:0 1px 1px 0;\n  transform:rotate(45deg)\n}\n.icon-location-pin[data-v-b8c0ea24]{\n  background:url(' + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-call[data-v-b8c0ea24],.icon-location-pin[data-v-b8c0ea24]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-call[data-v-b8c0ea24]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax[data-v-b8c0ea24]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax[data-v-b8c0ea24],.icon-mail[data-v-b8c0ea24]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-mail[data-v-b8c0ea24]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-train[data-v-b8c0ea24]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-bus[data-v-b8c0ea24],.icon-train[data-v-b8c0ea24]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-bus[data-v-b8c0ea24]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb[data-v-b8c0ea24]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb[data-v-b8c0ea24],.icon-ln[data-v-b8c0ea24]{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-ln[data-v-b8c0ea24]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu[data-v-b8c0ea24]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_8___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu[data-v-b8c0ea24],.icon-menu-violet-bg[data-v-b8c0ea24]{\n  height:18px;\n  width:26px;\n  display:inline-block\n}\n.icon-menu-violet-bg[data-v-b8c0ea24]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_9___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-cross[data-v-b8c0ea24]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_10___ + ") no-repeat 50%;\n  background-size:100%;\n  height:19px;\n  width:19px;\n  display:inline-block\n}\n.icon-linkedin-dark[data-v-b8c0ea24]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_11___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-facebook-dark[data-v-b8c0ea24],.icon-linkedin-dark[data-v-b8c0ea24]{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-facebook-dark[data-v-b8c0ea24]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_12___ + ') no-repeat 50%;\n  background-size:100%\n}\n.lang-dropdown select[data-v-b8c0ea24]{\n  font-family:"Poppins","Pretendard",sans-serif;\n  font-style:normal;\n  font-weight:400;\n  font-size:14px;\n  line-height:21px;\n  color:#828282;\n  background-color:transparent\n}\n\n/*purgecss end ignore*/', ""]);
    ___CSS_LOADER_EXPORT___.locals = {};
    module2.exports = ___CSS_LOADER_EXPORT___;
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_Footer_vue_vue_type_style_index_0_id_fa9d665e_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(63);
    for (var __WEBPACK_IMPORT_KEY__ in _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_Footer_vue_vue_type_style_index_0_id_fa9d665e_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__)
      if (["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0)
        (function(key) {
          __webpack_require__.d(__webpack_exports__, key, function() {
            return _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_Footer_vue_vue_type_style_index_0_id_fa9d665e_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key];
          });
        })(__WEBPACK_IMPORT_KEY__);
  },
  function(module2, exports, __webpack_require__) {
    var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
    var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(7);
    var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(8);
    var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(9);
    var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(10);
    var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(11);
    var ___CSS_LOADER_URL_IMPORT_4___ = __webpack_require__(12);
    var ___CSS_LOADER_URL_IMPORT_5___ = __webpack_require__(13);
    var ___CSS_LOADER_URL_IMPORT_6___ = __webpack_require__(14);
    var ___CSS_LOADER_URL_IMPORT_7___ = __webpack_require__(15);
    var ___CSS_LOADER_URL_IMPORT_8___ = __webpack_require__(16);
    var ___CSS_LOADER_URL_IMPORT_9___ = __webpack_require__(17);
    var ___CSS_LOADER_URL_IMPORT_10___ = __webpack_require__(18);
    var ___CSS_LOADER_URL_IMPORT_11___ = __webpack_require__(19);
    var ___CSS_LOADER_URL_IMPORT_12___ = __webpack_require__(20);
    var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i) {
      return i[1];
    });
    var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
    var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
    var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
    var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
    var ___CSS_LOADER_URL_REPLACEMENT_4___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_4___);
    var ___CSS_LOADER_URL_REPLACEMENT_5___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_5___);
    var ___CSS_LOADER_URL_REPLACEMENT_6___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_6___);
    var ___CSS_LOADER_URL_REPLACEMENT_7___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_7___);
    var ___CSS_LOADER_URL_REPLACEMENT_8___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_8___);
    var ___CSS_LOADER_URL_REPLACEMENT_9___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_9___);
    var ___CSS_LOADER_URL_REPLACEMENT_10___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_10___);
    var ___CSS_LOADER_URL_REPLACEMENT_11___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_11___);
    var ___CSS_LOADER_URL_REPLACEMENT_12___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_12___);
    ___CSS_LOADER_EXPORT___.push([module2.i, '/*purgecss start ignore*/\nbody[data-v-fa9d665e],html[data-v-fa9d665e]{\n  font-family:"Poppins","Pretendard",sans-serif\n}\n.container[data-v-fa9d665e]{\n  width:100%;\n  margin:0 auto\n}\n.divider-1[data-v-fa9d665e]{\n  display:block;\n  width:100%;\n  height:1px;\n  background-color:#cfcfcf\n}\n.heading-1[data-v-fa9d665e]{\n  font-size:52px;\n  letter-spacing:-.02em\n}\n.heading-1[data-v-fa9d665e],.heading-2[data-v-fa9d665e]{\n  font-family:"Poppins","Pretendard",sans-serif;\n  font-style:normal;\n  font-weight:500;\n  line-height:100%;\n  color:#181818\n}\n.heading-2[data-v-fa9d665e]{\n  font-size:32px\n}\n.fluidContainer[data-v-fa9d665e]{\n  padding:0 36px\n}\n@media screen and (max-width:767px){\n.fluidContainer[data-v-fa9d665e]{\n    padding:0\n}\n}\n.custom-checkbox[data-v-fa9d665e]{\n  display:block;\n  position:relative;\n  padding-left:30px;\n  margin-bottom:12px;\n  cursor:pointer;\n  font-size:22px;\n  -webkit-user-select:none;\n  -moz-user-select:none;\n  -ms-user-select:none;\n  user-select:none\n}\n.custom-checkbox input[data-v-fa9d665e]{\n  position:absolute;\n  opacity:0;\n  cursor:pointer;\n  height:0;\n  width:0\n}\n.checkmark[data-v-fa9d665e]{\n  position:absolute;\n  top:0;\n  left:0;\n  height:16px;\n  width:16px;\n  background-color:#fff;\n  border:1px solid #bdbdbd\n}\n.custom-checkbox:hover input~.checkmark[data-v-fa9d665e]{\n  background-color:#ececec\n}\n.custom-checkbox input:checked~.checkmark[data-v-fa9d665e]{\n  background-color:#57195c;\n  border:1px solid #57195c\n}\n.checkmark[data-v-fa9d665e]:after{\n  content:"";\n  position:absolute;\n  display:block\n}\n.custom-checkbox input:checked~.checkmark[data-v-fa9d665e]:after{\n  display:block\n}\n.custom-checkbox .checkmark[data-v-fa9d665e]:after{\n  left:5px;\n  top:1px;\n  width:5px;\n  height:10px;\n  border:solid #bdbdbd;\n  border-width:0 1px 1px 0;\n  transform:rotate(45deg)\n}\n.icon-location-pin[data-v-fa9d665e]{\n  background:url(' + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-call[data-v-fa9d665e],.icon-location-pin[data-v-fa9d665e]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-call[data-v-fa9d665e]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax[data-v-fa9d665e]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax[data-v-fa9d665e],.icon-mail[data-v-fa9d665e]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-mail[data-v-fa9d665e]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-train[data-v-fa9d665e]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-bus[data-v-fa9d665e],.icon-train[data-v-fa9d665e]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-bus[data-v-fa9d665e]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb[data-v-fa9d665e]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb[data-v-fa9d665e],.icon-ln[data-v-fa9d665e]{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-ln[data-v-fa9d665e]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu[data-v-fa9d665e]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_8___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu[data-v-fa9d665e],.icon-menu-violet-bg[data-v-fa9d665e]{\n  height:18px;\n  width:26px;\n  display:inline-block\n}\n.icon-menu-violet-bg[data-v-fa9d665e]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_9___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-cross[data-v-fa9d665e]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_10___ + ") no-repeat 50%;\n  background-size:100%;\n  height:19px;\n  width:19px;\n  display:inline-block\n}\n.icon-linkedin-dark[data-v-fa9d665e]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_11___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-facebook-dark[data-v-fa9d665e],.icon-linkedin-dark[data-v-fa9d665e]{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-facebook-dark[data-v-fa9d665e]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_12___ + ') no-repeat 50%;\n  background-size:100%\n}\n.footer[data-v-fa9d665e]{\n  display:flex;\n  align-items:center;\n  justify-content:center;\n  border:1px solid #cfcfcf;\n  height:60px;\n  overflow:hidden\n}\n.footer p[data-v-fa9d665e]{\n  font-family:"Poppins","Pretendard",sans-serif;\n  font-style:normal;\n  font-weight:300;\n  font-size:12px;\n  line-height:18px;\n  text-align:center;\n  color:#828282\n}\n\n/*purgecss end ignore*/', ""]);
    ___CSS_LOADER_EXPORT___.locals = {};
    module2.exports = ___CSS_LOADER_EXPORT___;
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_home_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(64);
    for (var __WEBPACK_IMPORT_KEY__ in _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_home_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__)
      if (["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0)
        (function(key) {
          __webpack_require__.d(__webpack_exports__, key, function() {
            return _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_home_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key];
          });
        })(__WEBPACK_IMPORT_KEY__);
  },
  function(module2, exports, __webpack_require__) {
    var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
    var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(7);
    var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(8);
    var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(9);
    var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(10);
    var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(11);
    var ___CSS_LOADER_URL_IMPORT_4___ = __webpack_require__(12);
    var ___CSS_LOADER_URL_IMPORT_5___ = __webpack_require__(13);
    var ___CSS_LOADER_URL_IMPORT_6___ = __webpack_require__(14);
    var ___CSS_LOADER_URL_IMPORT_7___ = __webpack_require__(15);
    var ___CSS_LOADER_URL_IMPORT_8___ = __webpack_require__(16);
    var ___CSS_LOADER_URL_IMPORT_9___ = __webpack_require__(17);
    var ___CSS_LOADER_URL_IMPORT_10___ = __webpack_require__(18);
    var ___CSS_LOADER_URL_IMPORT_11___ = __webpack_require__(19);
    var ___CSS_LOADER_URL_IMPORT_12___ = __webpack_require__(20);
    var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i) {
      return i[1];
    });
    var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
    var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
    var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
    var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
    var ___CSS_LOADER_URL_REPLACEMENT_4___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_4___);
    var ___CSS_LOADER_URL_REPLACEMENT_5___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_5___);
    var ___CSS_LOADER_URL_REPLACEMENT_6___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_6___);
    var ___CSS_LOADER_URL_REPLACEMENT_7___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_7___);
    var ___CSS_LOADER_URL_REPLACEMENT_8___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_8___);
    var ___CSS_LOADER_URL_REPLACEMENT_9___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_9___);
    var ___CSS_LOADER_URL_REPLACEMENT_10___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_10___);
    var ___CSS_LOADER_URL_REPLACEMENT_11___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_11___);
    var ___CSS_LOADER_URL_REPLACEMENT_12___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_12___);
    ___CSS_LOADER_EXPORT___.push([module2.i, '/*purgecss start ignore*/\nbody,html{\n  font-family:"Poppins","Pretendard",sans-serif\n}\n.container{\n  width:100%;\n  margin:0 auto\n}\n.divider-1{\n  display:block;\n  width:100%;\n  height:1px;\n  background-color:#cfcfcf\n}\n.heading-1{\n  font-size:52px;\n  letter-spacing:-.02em\n}\n.heading-1,.heading-2{\n  font-family:"Poppins","Pretendard",sans-serif;\n  font-style:normal;\n  font-weight:500;\n  line-height:100%;\n  color:#181818\n}\n.heading-2{\n  font-size:32px\n}\n.fluidContainer{\n  padding:0 36px\n}\n@media screen and (max-width:767px){\n.fluidContainer{\n    padding:0\n}\n}\n.custom-checkbox{\n  display:block;\n  position:relative;\n  padding-left:30px;\n  margin-bottom:12px;\n  cursor:pointer;\n  font-size:22px;\n  -webkit-user-select:none;\n  -moz-user-select:none;\n  -ms-user-select:none;\n  user-select:none\n}\n.custom-checkbox input{\n  position:absolute;\n  opacity:0;\n  cursor:pointer;\n  height:0;\n  width:0\n}\n.checkmark{\n  position:absolute;\n  top:0;\n  left:0;\n  height:16px;\n  width:16px;\n  background-color:#fff;\n  border:1px solid #bdbdbd\n}\n.custom-checkbox:hover input~.checkmark{\n  background-color:#ececec\n}\n.custom-checkbox input:checked~.checkmark{\n  background-color:#57195c;\n  border:1px solid #57195c\n}\n.checkmark:after{\n  content:"";\n  position:absolute;\n  display:block\n}\n.custom-checkbox input:checked~.checkmark:after{\n  display:block\n}\n.custom-checkbox .checkmark:after{\n  left:5px;\n  top:1px;\n  width:5px;\n  height:10px;\n  border:solid #bdbdbd;\n  border-width:0 1px 1px 0;\n  transform:rotate(45deg)\n}\n.icon-location-pin{\n  background:url(' + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-call,.icon-location-pin{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-call{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax,.icon-mail{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-mail{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-train{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-bus,.icon-train{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-bus{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb,.icon-ln{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-ln{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_8___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu,.icon-menu-violet-bg{\n  height:18px;\n  width:26px;\n  display:inline-block\n}\n.icon-menu-violet-bg{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_9___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-cross{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_10___ + ") no-repeat 50%;\n  background-size:100%;\n  height:19px;\n  width:19px;\n  display:inline-block\n}\n.icon-linkedin-dark{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_11___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-facebook-dark,.icon-linkedin-dark{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-facebook-dark{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_12___ + ") no-repeat 50%;\n  background-size:100%\n}\n.main-body{\n  min-height:calc(100vh - 140px)\n}\n\n/*purgecss end ignore*/", ""]);
    ___CSS_LOADER_EXPORT___.locals = {};
    module2.exports = ___CSS_LOADER_EXPORT___;
  },
  function(module2, exports) {
    module2.exports = require$$38;
  },
  function(module2, exports) {
    module2.exports = require$$39;
  },
  function(module2, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var components_namespaceObject = {};
    __webpack_require__.r(components_namespaceObject);
    __webpack_require__.d(components_namespaceObject, "AdvisoryCards", function() {
      return AdvisoryCards;
    });
    __webpack_require__.d(components_namespaceObject, "Banner", function() {
      return Banner;
    });
    __webpack_require__.d(components_namespaceObject, "BannerState", function() {
      return BannerState;
    });
    __webpack_require__.d(components_namespaceObject, "ContactInfoItem", function() {
      return ContactInfoItem;
    });
    __webpack_require__.d(components_namespaceObject, "Filters", function() {
      return Filters;
    });
    __webpack_require__.d(components_namespaceObject, "Footer", function() {
      return Footer;
    });
    __webpack_require__.d(components_namespaceObject, "FounderCards", function() {
      return FounderCards;
    });
    __webpack_require__.d(components_namespaceObject, "Header", function() {
      return Header;
    });
    __webpack_require__.d(components_namespaceObject, "LanguageInput", function() {
      return LanguageInput;
    });
    __webpack_require__.d(components_namespaceObject, "LoadingBar", function() {
      return components_LoadingBar;
    });
    __webpack_require__.d(components_namespaceObject, "Modal", function() {
      return Modal;
    });
    __webpack_require__.d(components_namespaceObject, "NuxtLogo", function() {
      return NuxtLogo;
    });
    __webpack_require__.d(components_namespaceObject, "TeamCard", function() {
      return TeamCard;
    });
    __webpack_require__.d(components_namespaceObject, "TeamCards", function() {
      return TeamCards;
    });
    __webpack_require__.d(components_namespaceObject, "TopHeading", function() {
      return TopHeading;
    });
    __webpack_require__.d(components_namespaceObject, "Tutorial", function() {
      return Tutorial;
    });
    var vue_composition_api = __webpack_require__(0);
    var vue2_bridge = __webpack_require__(1);
    var external_ufo_ = __webpack_require__(3);
    const middleware = {};
    var _nuxt_middleware = middleware;
    function createGetCounter(counterObject, defaultKey = "") {
      return function getCounter(id = defaultKey) {
        if (counterObject[id] === void 0) {
          counterObject[id] = 0;
        }
        return counterObject[id]++;
      };
    }
    function globalHandleError(error) {
      if (vue2_bridge["default"].config.errorHandler) {
        vue2_bridge["default"].config.errorHandler(error);
      }
    }
    function interopDefault(promise) {
      return promise.then((m) => m.default || m);
    }
    function hasFetch(vm) {
      return vm.$options && typeof vm.$options.fetch === "function" && !vm.$options.fetch.length;
    }
    function purifyData(data) {
      {
        return data;
      }
    }
    function getChildrenComponentInstancesUsingFetch(vm, instances = []) {
      const children = vm.$children || [];
      for (const child of children) {
        if (child.$fetch) {
          instances.push(child);
          continue;
        }
        if (child.$children) {
          getChildrenComponentInstancesUsingFetch(child, instances);
        }
      }
      return instances;
    }
    function applyAsyncData(Component, asyncData) {
      if (!asyncData && Component.options.__hasNuxtData) {
        return;
      }
      const ComponentData = Component.options._originDataFn || Component.options.data || function() {
        return {};
      };
      Component.options._originDataFn = ComponentData;
      Component.options.data = function() {
        const data = ComponentData.call(this, this);
        if (this.$ssrContext) {
          asyncData = this.$ssrContext.asyncData[Component.cid];
        }
        return {
          ...data,
          ...asyncData
        };
      };
      Component.options.__hasNuxtData = true;
      if (Component._Ctor && Component._Ctor.options) {
        Component._Ctor.options.data = Component.options.data;
      }
    }
    function sanitizeComponent(Component) {
      if (Component.options && Component._Ctor === Component) {
        return Component;
      }
      if (!Component.options) {
        Component = vue2_bridge["default"].extend(Component);
        Component._Ctor = Component;
      } else {
        Component._Ctor = Component;
        Component.extendOptions = Component.options;
      }
      if (!Component.options.name && Component.options.__file) {
        Component.options.name = Component.options.__file;
      }
      return Component;
    }
    function getMatchedComponents(route, matches = false, prop = "components") {
      return Array.prototype.concat.apply([], route.matched.map((m, index) => {
        return Object.keys(m[prop]).map((key) => {
          matches && matches.push(index);
          return m[prop][key];
        });
      }));
    }
    function getMatchedComponentsInstances(route, matches = false) {
      return getMatchedComponents(route, matches, "instances");
    }
    function flatMapComponents(route, fn) {
      return Array.prototype.concat.apply([], route.matched.map((m, index) => {
        return Object.keys(m.components).reduce((promises, key) => {
          if (m.components[key]) {
            promises.push(fn(m.components[key], m.instances[key], m, key, index));
          } else {
            delete m.components[key];
          }
          return promises;
        }, []);
      }));
    }
    function resolveRouteComponents(route, fn) {
      return Promise.all(flatMapComponents(route, async (Component, instance, match, key) => {
        if (typeof Component === "function" && !Component.options) {
          try {
            Component = await Component();
          } catch (error) {
            if (error && error.name === "ChunkLoadError" && false) {
              const timeNow = Date.now();
              const previousReloadTime = parseInt(window.sessionStorage.getItem("nuxt-reload"));
              if (!previousReloadTime || previousReloadTime + 6e4 < timeNow) {
                window.sessionStorage.setItem("nuxt-reload", timeNow);
                window.location.reload(true);
              }
            }
            throw error;
          }
        }
        match.components[key] = Component = sanitizeComponent(Component);
        return typeof fn === "function" ? fn(Component, instance, match, key) : Component;
      }));
    }
    async function getRouteData(route) {
      if (!route) {
        return;
      }
      await resolveRouteComponents(route);
      return {
        ...route,
        meta: getMatchedComponents(route).map((Component, index) => {
          return {
            ...Component.options.meta,
            ...(route.matched[index] || {}).meta
          };
        })
      };
    }
    async function setContext(app, context) {
      if (!app.context) {
        app.context = {
          isStatic: false,
          isDev: false,
          isHMR: false,
          app,
          payload: context.payload,
          error: context.error,
          base: app.router.options.base,
          env: {
            "NITRO_PRESET": "server"
          }
        };
        if (context.req) {
          app.context.req = context.req;
        }
        if (context.res) {
          app.context.res = context.res;
        }
        if (context.ssrContext) {
          app.context.ssrContext = context.ssrContext;
        }
        app.context.redirect = (status, path, query) => {
          if (!status) {
            return;
          }
          app.context._redirected = true;
          let pathType = typeof path;
          if (typeof status !== "number" && (pathType === "undefined" || pathType === "object")) {
            query = path || {};
            path = status;
            pathType = typeof path;
            status = 302;
          }
          if (pathType === "object") {
            path = app.router.resolve(path).route.fullPath;
          }
          if (/(^[.]{1,2}\/)|(^\/(?!\/))/.test(path)) {
            app.context.next({
              path,
              query,
              status
            });
          } else {
            path = Object(external_ufo_["withQuery"])(path, query);
            {
              app.context.next({
                path,
                status
              });
            }
          }
        };
        {
          app.context.beforeNuxtRender = (fn) => context.beforeRenderFns.push(fn);
          app.context.beforeSerialize = (fn) => context.beforeSerializeFns.push(fn);
        }
      }
      const [currentRouteData, fromRouteData] = await Promise.all([getRouteData(context.route), getRouteData(context.from)]);
      if (context.route) {
        app.context.route = currentRouteData;
      }
      if (context.from) {
        app.context.from = fromRouteData;
      }
      app.context.next = context.next;
      app.context._redirected = false;
      app.context._errored = false;
      app.context.isHMR = false;
      app.context.params = app.context.route.params || {};
      app.context.query = app.context.route.query || {};
    }
    function middlewareSeries(promises, appContext) {
      if (!promises.length || appContext._redirected || appContext._errored) {
        return Promise.resolve();
      }
      return promisify(promises[0], appContext).then(() => {
        return middlewareSeries(promises.slice(1), appContext);
      });
    }
    function promisify(fn, context) {
      let promise;
      if (fn.length === 2) {
        promise = new Promise((resolve) => {
          fn(context, function(err, data) {
            if (err) {
              context.error(err);
            }
            data = data || {};
            resolve(data);
          });
        });
      } else {
        promise = fn(context);
      }
      if (promise && promise instanceof Promise && typeof promise.then === "function") {
        return promise;
      }
      return Promise.resolve(promise);
    }
    function getLocation(base, mode) {
      if (mode === "hash") {
        return window.location.hash.replace(/^#\//, "");
      }
      base = decodeURI(base).slice(0, -1);
      let path = decodeURI(window.location.pathname);
      if (base && path.startsWith(base)) {
        path = path.slice(base.length);
      }
      const fullPath = (path || "/") + window.location.search + window.location.hash;
      return Object(external_ufo_["normalizeURL"])(fullPath);
    }
    function compile(str, options2) {
      return tokensToFunction(parse(str, options2), options2);
    }
    function normalizeError(err) {
      let message;
      if (!(err.message || typeof err === "string")) {
        try {
          message = JSON.stringify(err, null, 2);
        } catch (e) {
          message = `[${err.constructor.name}]`;
        }
      } else {
        message = err.message || err;
      }
      return {
        ...err,
        message,
        statusCode: err.statusCode || err.status || err.response && err.response.status || 500
      };
    }
    const PATH_REGEXP = new RegExp([
      "(\\\\.)",
      "([\\/.])?(?:(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?|(\\*))"
    ].join("|"), "g");
    function parse(str, options2) {
      const tokens = [];
      let key = 0;
      let index = 0;
      let path = "";
      const defaultDelimiter = options2 && options2.delimiter || "/";
      let res;
      while ((res = PATH_REGEXP.exec(str)) != null) {
        const m = res[0];
        const escaped = res[1];
        const offset = res.index;
        path += str.slice(index, offset);
        index = offset + m.length;
        if (escaped) {
          path += escaped[1];
          continue;
        }
        const next = str[index];
        const prefix = res[2];
        const name = res[3];
        const capture = res[4];
        const group = res[5];
        const modifier = res[6];
        const asterisk = res[7];
        if (path) {
          tokens.push(path);
          path = "";
        }
        const partial = prefix != null && next != null && next !== prefix;
        const repeat = modifier === "+" || modifier === "*";
        const optional = modifier === "?" || modifier === "*";
        const delimiter = res[2] || defaultDelimiter;
        const pattern = capture || group;
        tokens.push({
          name: name || key++,
          prefix: prefix || "",
          delimiter,
          optional,
          repeat,
          partial,
          asterisk: Boolean(asterisk),
          pattern: pattern ? escapeGroup(pattern) : asterisk ? ".*" : "[^" + escapeString(delimiter) + "]+?"
        });
      }
      if (index < str.length) {
        path += str.substr(index);
      }
      if (path) {
        tokens.push(path);
      }
      return tokens;
    }
    function encodeURIComponentPretty(str, slashAllowed) {
      const re = slashAllowed ? /[?#]/g : /[/?#]/g;
      return encodeURI(str).replace(re, (c) => {
        return "%" + c.charCodeAt(0).toString(16).toUpperCase();
      });
    }
    function encodeAsterisk(str) {
      return encodeURIComponentPretty(str, true);
    }
    function escapeString(str) {
      return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
    }
    function escapeGroup(group) {
      return group.replace(/([=!:$/()])/g, "\\$1");
    }
    function tokensToFunction(tokens, options2) {
      const matches = new Array(tokens.length);
      for (let i = 0; i < tokens.length; i++) {
        if (typeof tokens[i] === "object") {
          matches[i] = new RegExp("^(?:" + tokens[i].pattern + ")$", flags(options2));
        }
      }
      return function(obj, opts) {
        let path = "";
        const data = obj || {};
        const options3 = opts || {};
        const encode2 = options3.pretty ? encodeURIComponentPretty : encodeURIComponent;
        for (let i = 0; i < tokens.length; i++) {
          const token = tokens[i];
          if (typeof token === "string") {
            path += token;
            continue;
          }
          const value = data[token.name || "pathMatch"];
          let segment;
          if (value == null) {
            if (token.optional) {
              if (token.partial) {
                path += token.prefix;
              }
              continue;
            } else {
              throw new TypeError('Expected "' + token.name + '" to be defined');
            }
          }
          if (Array.isArray(value)) {
            if (!token.repeat) {
              throw new TypeError('Expected "' + token.name + '" to not repeat, but received `' + JSON.stringify(value) + "`");
            }
            if (value.length === 0) {
              if (token.optional) {
                continue;
              } else {
                throw new TypeError('Expected "' + token.name + '" to not be empty');
              }
            }
            for (let j = 0; j < value.length; j++) {
              segment = encode2(value[j]);
              if (!matches[i].test(segment)) {
                throw new TypeError('Expected all "' + token.name + '" to match "' + token.pattern + '", but received `' + JSON.stringify(segment) + "`");
              }
              path += (j === 0 ? token.prefix : token.delimiter) + segment;
            }
            continue;
          }
          segment = token.asterisk ? encodeAsterisk(value) : encode2(value);
          if (!matches[i].test(segment)) {
            throw new TypeError('Expected "' + token.name + '" to match "' + token.pattern + '", but received "' + segment + '"');
          }
          path += token.prefix + segment;
        }
        return path;
      };
    }
    function flags(options2) {
      return options2 && options2.sensitive ? "" : "i";
    }
    function addLifecycleHook(vm, hook, fn) {
      if (!vm.$options[hook]) {
        vm.$options[hook] = [];
      }
      if (!vm.$options[hook].includes(fn)) {
        vm.$options[hook].push(fn);
      }
    }
    external_ufo_["joinURL"];
    external_ufo_["withoutTrailingSlash"];
    external_ufo_["isSamePath"];
    async function serverPrefetch() {
      if (!this._fetchOnServer) {
        return;
      }
      try {
        await this.$options.fetch.call(this);
      } catch (err) {
        this.$fetchState.error = normalizeError(err);
      }
      this.$fetchState.pending = false;
      this._fetchKey = this._fetchKey || this.$ssrContext.fetchCounters[""]++;
      const attrs = this.$vnode.data.attrs = this.$vnode.data.attrs || {};
      attrs["data-fetch-key"] = this._fetchKey;
      this.$ssrContext.nuxt.fetch[this._fetchKey] = this.$fetchState.error ? {
        _error: this.$fetchState.error
      } : purifyData(this._data);
    }
    var fetch_server = {
      created() {
        if (!hasFetch(this)) {
          return;
        }
        if (typeof this.$options.fetchOnServer === "function") {
          this._fetchOnServer = this.$options.fetchOnServer.call(this) !== false;
        } else {
          this._fetchOnServer = this.$options.fetchOnServer !== false;
        }
        const defaultKey = this.$options._scopeId || this.$options.name || "";
        const getCounter = createGetCounter(this.$ssrContext.fetchCounters, defaultKey);
        if (typeof this.$options.fetchKey === "function") {
          this._fetchKey = this.$options.fetchKey.call(this, getCounter);
        } else {
          const key = typeof this.$options.fetchKey === "string" ? this.$options.fetchKey : defaultKey;
          this._fetchKey = key ? key + ":" + getCounter(key) : String(getCounter(key));
        }
        this.$fetch = () => {
        };
        vue2_bridge["default"].util.defineReactive(this, "$fetchState", {
          pending: true,
          error: null,
          timestamp: Date.now()
        });
        addLifecycleHook(this, "serverPrefetch", serverPrefetch);
      }
    };
    var vue_meta_common = __webpack_require__(22);
    var vue_meta_common_default = /* @__PURE__ */ __webpack_require__.n(vue_meta_common);
    var vue_client_only_common = __webpack_require__(41);
    var vue_client_only_common_default = /* @__PURE__ */ __webpack_require__.n(vue_client_only_common);
    var vue_no_ssr_common = __webpack_require__(24);
    var vue_no_ssr_common_default = /* @__PURE__ */ __webpack_require__.n(vue_no_ssr_common);
    function extend(a, b) {
      for (var key in b) {
        a[key] = b[key];
      }
      return a;
    }
    var encodeReserveRE = /[!'()*]/g;
    var encodeReserveReplacer = function(c) {
      return "%" + c.charCodeAt(0).toString(16);
    };
    var commaRE = /%2C/g;
    var encode = function(str) {
      return encodeURIComponent(str).replace(encodeReserveRE, encodeReserveReplacer).replace(commaRE, ",");
    };
    function decode(str) {
      try {
        return decodeURIComponent(str);
      } catch (err) {
      }
      return str;
    }
    function resolveQuery(query, extraQuery, _parseQuery) {
      if (extraQuery === void 0)
        extraQuery = {};
      var parse2 = _parseQuery || parseQuery;
      var parsedQuery;
      try {
        parsedQuery = parse2(query || "");
      } catch (e) {
        parsedQuery = {};
      }
      for (var key in extraQuery) {
        var value = extraQuery[key];
        parsedQuery[key] = Array.isArray(value) ? value.map(castQueryParamValue) : castQueryParamValue(value);
      }
      return parsedQuery;
    }
    var castQueryParamValue = function(value) {
      return value == null || typeof value === "object" ? value : String(value);
    };
    function parseQuery(query) {
      var res = {};
      query = query.trim().replace(/^(\?|#|&)/, "");
      if (!query) {
        return res;
      }
      query.split("&").forEach(function(param) {
        var parts = param.replace(/\+/g, " ").split("=");
        var key = decode(parts.shift());
        var val = parts.length > 0 ? decode(parts.join("=")) : null;
        if (res[key] === void 0) {
          res[key] = val;
        } else if (Array.isArray(res[key])) {
          res[key].push(val);
        } else {
          res[key] = [res[key], val];
        }
      });
      return res;
    }
    function stringifyQuery(obj) {
      var res = obj ? Object.keys(obj).map(function(key) {
        var val = obj[key];
        if (val === void 0) {
          return "";
        }
        if (val === null) {
          return encode(key);
        }
        if (Array.isArray(val)) {
          var result = [];
          val.forEach(function(val2) {
            if (val2 === void 0) {
              return;
            }
            if (val2 === null) {
              result.push(encode(key));
            } else {
              result.push(encode(key) + "=" + encode(val2));
            }
          });
          return result.join("&");
        }
        return encode(key) + "=" + encode(val);
      }).filter(function(x) {
        return x.length > 0;
      }).join("&") : null;
      return res ? "?" + res : "";
    }
    var trailingSlashRE = /\/?$/;
    function createRoute(record, location, redirectedFrom, router) {
      var stringifyQuery2 = router && router.options.stringifyQuery;
      var query = location.query || {};
      try {
        query = clone(query);
      } catch (e) {
      }
      var route = {
        name: location.name || record && record.name,
        meta: record && record.meta || {},
        path: location.path || "/",
        hash: location.hash || "",
        query,
        params: location.params || {},
        fullPath: getFullPath(location, stringifyQuery2),
        matched: record ? formatMatch(record) : []
      };
      if (redirectedFrom) {
        route.redirectedFrom = getFullPath(redirectedFrom, stringifyQuery2);
      }
      return Object.freeze(route);
    }
    function clone(value) {
      if (Array.isArray(value)) {
        return value.map(clone);
      } else if (value && typeof value === "object") {
        var res = {};
        for (var key in value) {
          res[key] = clone(value[key]);
        }
        return res;
      } else {
        return value;
      }
    }
    var START = createRoute(null, {
      path: "/"
    });
    function formatMatch(record) {
      var res = [];
      while (record) {
        res.unshift(record);
        record = record.parent;
      }
      return res;
    }
    function getFullPath(ref, _stringifyQuery) {
      var path = ref.path;
      var query = ref.query;
      if (query === void 0)
        query = {};
      var hash = ref.hash;
      if (hash === void 0)
        hash = "";
      var stringify = _stringifyQuery || stringifyQuery;
      return (path || "/") + stringify(query) + hash;
    }
    function isSameRoute(a, b, onlyPath) {
      if (b === START) {
        return a === b;
      } else if (!b) {
        return false;
      } else if (a.path && b.path) {
        return a.path.replace(trailingSlashRE, "") === b.path.replace(trailingSlashRE, "") && (onlyPath || a.hash === b.hash && isObjectEqual(a.query, b.query));
      } else if (a.name && b.name) {
        return a.name === b.name && (onlyPath || a.hash === b.hash && isObjectEqual(a.query, b.query) && isObjectEqual(a.params, b.params));
      } else {
        return false;
      }
    }
    function isObjectEqual(a, b) {
      if (a === void 0)
        a = {};
      if (b === void 0)
        b = {};
      if (!a || !b) {
        return a === b;
      }
      var aKeys = Object.keys(a).sort();
      var bKeys = Object.keys(b).sort();
      if (aKeys.length !== bKeys.length) {
        return false;
      }
      return aKeys.every(function(key, i) {
        var aVal = a[key];
        var bKey = bKeys[i];
        if (bKey !== key) {
          return false;
        }
        var bVal = b[key];
        if (aVal == null || bVal == null) {
          return aVal === bVal;
        }
        if (typeof aVal === "object" && typeof bVal === "object") {
          return isObjectEqual(aVal, bVal);
        }
        return String(aVal) === String(bVal);
      });
    }
    function isIncludedRoute(current, target) {
      return current.path.replace(trailingSlashRE, "/").indexOf(target.path.replace(trailingSlashRE, "/")) === 0 && (!target.hash || current.hash === target.hash) && queryIncludes(current.query, target.query);
    }
    function queryIncludes(current, target) {
      for (var key in target) {
        if (!(key in current)) {
          return false;
        }
      }
      return true;
    }
    function handleRouteEntered(route) {
      for (var i = 0; i < route.matched.length; i++) {
        var record = route.matched[i];
        for (var name in record.instances) {
          var instance = record.instances[name];
          var cbs = record.enteredCbs[name];
          if (!instance || !cbs) {
            continue;
          }
          delete record.enteredCbs[name];
          for (var i$1 = 0; i$1 < cbs.length; i$1++) {
            if (!instance._isBeingDestroyed) {
              cbs[i$1](instance);
            }
          }
        }
      }
    }
    var View = {
      name: "RouterView",
      functional: true,
      props: {
        name: {
          type: String,
          default: "default"
        }
      },
      render: function render2(_, ref) {
        var props = ref.props;
        var children = ref.children;
        var parent = ref.parent;
        var data = ref.data;
        data.routerView = true;
        var h = parent.$createElement;
        var name = props.name;
        var route = parent.$route;
        var cache = parent._routerViewCache || (parent._routerViewCache = {});
        var depth = 0;
        var inactive = false;
        while (parent && parent._routerRoot !== parent) {
          var vnodeData = parent.$vnode ? parent.$vnode.data : {};
          if (vnodeData.routerView) {
            depth++;
          }
          if (vnodeData.keepAlive && parent._directInactive && parent._inactive) {
            inactive = true;
          }
          parent = parent.$parent;
        }
        data.routerViewDepth = depth;
        if (inactive) {
          var cachedData = cache[name];
          var cachedComponent = cachedData && cachedData.component;
          if (cachedComponent) {
            if (cachedData.configProps) {
              fillPropsinData(cachedComponent, data, cachedData.route, cachedData.configProps);
            }
            return h(cachedComponent, data, children);
          } else {
            return h();
          }
        }
        var matched = route.matched[depth];
        var component = matched && matched.components[name];
        if (!matched || !component) {
          cache[name] = null;
          return h();
        }
        cache[name] = {
          component
        };
        data.registerRouteInstance = function(vm, val) {
          var current = matched.instances[name];
          if (val && current !== vm || !val && current === vm) {
            matched.instances[name] = val;
          }
        };
        (data.hook || (data.hook = {})).prepatch = function(_2, vnode) {
          matched.instances[name] = vnode.componentInstance;
        };
        data.hook.init = function(vnode) {
          if (vnode.data.keepAlive && vnode.componentInstance && vnode.componentInstance !== matched.instances[name]) {
            matched.instances[name] = vnode.componentInstance;
          }
          handleRouteEntered(route);
        };
        var configProps = matched.props && matched.props[name];
        if (configProps) {
          extend(cache[name], {
            route,
            configProps
          });
          fillPropsinData(component, data, route, configProps);
        }
        return h(component, data, children);
      }
    };
    function fillPropsinData(component, data, route, configProps) {
      var propsToPass = data.props = resolveProps(route, configProps);
      if (propsToPass) {
        propsToPass = data.props = extend({}, propsToPass);
        var attrs = data.attrs = data.attrs || {};
        for (var key in propsToPass) {
          if (!component.props || !(key in component.props)) {
            attrs[key] = propsToPass[key];
            delete propsToPass[key];
          }
        }
      }
    }
    function resolveProps(route, config) {
      switch (typeof config) {
        case "undefined":
          return;
        case "object":
          return config;
        case "function":
          return config(route);
        case "boolean":
          return config ? route.params : void 0;
      }
    }
    function resolvePath(relative, base, append) {
      var firstChar = relative.charAt(0);
      if (firstChar === "/") {
        return relative;
      }
      if (firstChar === "?" || firstChar === "#") {
        return base + relative;
      }
      var stack = base.split("/");
      if (!append || !stack[stack.length - 1]) {
        stack.pop();
      }
      var segments = relative.replace(/^\//, "").split("/");
      for (var i = 0; i < segments.length; i++) {
        var segment = segments[i];
        if (segment === "..") {
          stack.pop();
        } else if (segment !== ".") {
          stack.push(segment);
        }
      }
      if (stack[0] !== "") {
        stack.unshift("");
      }
      return stack.join("/");
    }
    function parsePath(path) {
      var hash = "";
      var query = "";
      var hashIndex = path.indexOf("#");
      if (hashIndex >= 0) {
        hash = path.slice(hashIndex);
        path = path.slice(0, hashIndex);
      }
      var queryIndex = path.indexOf("?");
      if (queryIndex >= 0) {
        query = path.slice(queryIndex + 1);
        path = path.slice(0, queryIndex);
      }
      return {
        path,
        query,
        hash
      };
    }
    function cleanPath(path) {
      return path.replace(/\/+/g, "/");
    }
    var isarray = Array.isArray || function(arr) {
      return Object.prototype.toString.call(arr) == "[object Array]";
    };
    var pathToRegexp_1 = pathToRegexp;
    var parse_1 = vue_router_esm_parse;
    var compile_1 = vue_router_esm_compile;
    var tokensToFunction_1 = vue_router_esm_tokensToFunction;
    var tokensToRegExp_1 = tokensToRegExp;
    var vue_router_esm_PATH_REGEXP = new RegExp([
      "(\\\\.)",
      "([\\/.])?(?:(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?|(\\*))"
    ].join("|"), "g");
    function vue_router_esm_parse(str, options2) {
      var tokens = [];
      var key = 0;
      var index = 0;
      var path = "";
      var defaultDelimiter = options2 && options2.delimiter || "/";
      var res;
      while ((res = vue_router_esm_PATH_REGEXP.exec(str)) != null) {
        var m = res[0];
        var escaped = res[1];
        var offset = res.index;
        path += str.slice(index, offset);
        index = offset + m.length;
        if (escaped) {
          path += escaped[1];
          continue;
        }
        var next = str[index];
        var prefix = res[2];
        var name = res[3];
        var capture = res[4];
        var group = res[5];
        var modifier = res[6];
        var asterisk = res[7];
        if (path) {
          tokens.push(path);
          path = "";
        }
        var partial = prefix != null && next != null && next !== prefix;
        var repeat = modifier === "+" || modifier === "*";
        var optional = modifier === "?" || modifier === "*";
        var delimiter = res[2] || defaultDelimiter;
        var pattern = capture || group;
        tokens.push({
          name: name || key++,
          prefix: prefix || "",
          delimiter,
          optional,
          repeat,
          partial,
          asterisk: !!asterisk,
          pattern: pattern ? vue_router_esm_escapeGroup(pattern) : asterisk ? ".*" : "[^" + vue_router_esm_escapeString(delimiter) + "]+?"
        });
      }
      if (index < str.length) {
        path += str.substr(index);
      }
      if (path) {
        tokens.push(path);
      }
      return tokens;
    }
    function vue_router_esm_compile(str, options2) {
      return vue_router_esm_tokensToFunction(vue_router_esm_parse(str, options2), options2);
    }
    function vue_router_esm_encodeURIComponentPretty(str) {
      return encodeURI(str).replace(/[\/?#]/g, function(c) {
        return "%" + c.charCodeAt(0).toString(16).toUpperCase();
      });
    }
    function vue_router_esm_encodeAsterisk(str) {
      return encodeURI(str).replace(/[?#]/g, function(c) {
        return "%" + c.charCodeAt(0).toString(16).toUpperCase();
      });
    }
    function vue_router_esm_tokensToFunction(tokens, options2) {
      var matches = new Array(tokens.length);
      for (var i = 0; i < tokens.length; i++) {
        if (typeof tokens[i] === "object") {
          matches[i] = new RegExp("^(?:" + tokens[i].pattern + ")$", vue_router_esm_flags(options2));
        }
      }
      return function(obj, opts) {
        var path = "";
        var data = obj || {};
        var options3 = opts || {};
        var encode2 = options3.pretty ? vue_router_esm_encodeURIComponentPretty : encodeURIComponent;
        for (var i2 = 0; i2 < tokens.length; i2++) {
          var token = tokens[i2];
          if (typeof token === "string") {
            path += token;
            continue;
          }
          var value = data[token.name];
          var segment;
          if (value == null) {
            if (token.optional) {
              if (token.partial) {
                path += token.prefix;
              }
              continue;
            } else {
              throw new TypeError('Expected "' + token.name + '" to be defined');
            }
          }
          if (isarray(value)) {
            if (!token.repeat) {
              throw new TypeError('Expected "' + token.name + '" to not repeat, but received `' + JSON.stringify(value) + "`");
            }
            if (value.length === 0) {
              if (token.optional) {
                continue;
              } else {
                throw new TypeError('Expected "' + token.name + '" to not be empty');
              }
            }
            for (var j = 0; j < value.length; j++) {
              segment = encode2(value[j]);
              if (!matches[i2].test(segment)) {
                throw new TypeError('Expected all "' + token.name + '" to match "' + token.pattern + '", but received `' + JSON.stringify(segment) + "`");
              }
              path += (j === 0 ? token.prefix : token.delimiter) + segment;
            }
            continue;
          }
          segment = token.asterisk ? vue_router_esm_encodeAsterisk(value) : encode2(value);
          if (!matches[i2].test(segment)) {
            throw new TypeError('Expected "' + token.name + '" to match "' + token.pattern + '", but received "' + segment + '"');
          }
          path += token.prefix + segment;
        }
        return path;
      };
    }
    function vue_router_esm_escapeString(str) {
      return str.replace(/([.+*?=^!:${}()[\]|\/\\])/g, "\\$1");
    }
    function vue_router_esm_escapeGroup(group) {
      return group.replace(/([=!:$\/()])/g, "\\$1");
    }
    function attachKeys(re, keys) {
      re.keys = keys;
      return re;
    }
    function vue_router_esm_flags(options2) {
      return options2 && options2.sensitive ? "" : "i";
    }
    function regexpToRegexp(path, keys) {
      var groups = path.source.match(/\((?!\?)/g);
      if (groups) {
        for (var i = 0; i < groups.length; i++) {
          keys.push({
            name: i,
            prefix: null,
            delimiter: null,
            optional: false,
            repeat: false,
            partial: false,
            asterisk: false,
            pattern: null
          });
        }
      }
      return attachKeys(path, keys);
    }
    function arrayToRegexp(path, keys, options2) {
      var parts = [];
      for (var i = 0; i < path.length; i++) {
        parts.push(pathToRegexp(path[i], keys, options2).source);
      }
      var regexp = new RegExp("(?:" + parts.join("|") + ")", vue_router_esm_flags(options2));
      return attachKeys(regexp, keys);
    }
    function stringToRegexp(path, keys, options2) {
      return tokensToRegExp(vue_router_esm_parse(path, options2), keys, options2);
    }
    function tokensToRegExp(tokens, keys, options2) {
      if (!isarray(keys)) {
        options2 = keys || options2;
        keys = [];
      }
      options2 = options2 || {};
      var strict = options2.strict;
      var end = options2.end !== false;
      var route = "";
      for (var i = 0; i < tokens.length; i++) {
        var token = tokens[i];
        if (typeof token === "string") {
          route += vue_router_esm_escapeString(token);
        } else {
          var prefix = vue_router_esm_escapeString(token.prefix);
          var capture = "(?:" + token.pattern + ")";
          keys.push(token);
          if (token.repeat) {
            capture += "(?:" + prefix + capture + ")*";
          }
          if (token.optional) {
            if (!token.partial) {
              capture = "(?:" + prefix + "(" + capture + "))?";
            } else {
              capture = prefix + "(" + capture + ")?";
            }
          } else {
            capture = prefix + "(" + capture + ")";
          }
          route += capture;
        }
      }
      var delimiter = vue_router_esm_escapeString(options2.delimiter || "/");
      var endsWithDelimiter = route.slice(-delimiter.length) === delimiter;
      if (!strict) {
        route = (endsWithDelimiter ? route.slice(0, -delimiter.length) : route) + "(?:" + delimiter + "(?=$))?";
      }
      if (end) {
        route += "$";
      } else {
        route += strict && endsWithDelimiter ? "" : "(?=" + delimiter + "|$)";
      }
      return attachKeys(new RegExp("^" + route, vue_router_esm_flags(options2)), keys);
    }
    function pathToRegexp(path, keys, options2) {
      if (!isarray(keys)) {
        options2 = keys || options2;
        keys = [];
      }
      options2 = options2 || {};
      if (path instanceof RegExp) {
        return regexpToRegexp(path, keys);
      }
      if (isarray(path)) {
        return arrayToRegexp(path, keys, options2);
      }
      return stringToRegexp(path, keys, options2);
    }
    pathToRegexp_1.parse = parse_1;
    pathToRegexp_1.compile = compile_1;
    pathToRegexp_1.tokensToFunction = tokensToFunction_1;
    pathToRegexp_1.tokensToRegExp = tokensToRegExp_1;
    var regexpCompileCache = Object.create(null);
    function fillParams(path, params, routeMsg) {
      params = params || {};
      try {
        var filler = regexpCompileCache[path] || (regexpCompileCache[path] = pathToRegexp_1.compile(path));
        if (typeof params.pathMatch === "string") {
          params[0] = params.pathMatch;
        }
        return filler(params, {
          pretty: true
        });
      } catch (e) {
        return "";
      } finally {
        delete params[0];
      }
    }
    function normalizeLocation(raw, current, append, router) {
      var next = typeof raw === "string" ? {
        path: raw
      } : raw;
      if (next._normalized) {
        return next;
      } else if (next.name) {
        next = extend({}, raw);
        var params = next.params;
        if (params && typeof params === "object") {
          next.params = extend({}, params);
        }
        return next;
      }
      if (!next.path && next.params && current) {
        next = extend({}, next);
        next._normalized = true;
        var params$1 = extend(extend({}, current.params), next.params);
        if (current.name) {
          next.name = current.name;
          next.params = params$1;
        } else if (current.matched.length) {
          var rawPath = current.matched[current.matched.length - 1].path;
          next.path = fillParams(rawPath, params$1, "path " + current.path);
        } else ;
        return next;
      }
      var parsedPath = parsePath(next.path || "");
      var basePath = current && current.path || "/";
      var path = parsedPath.path ? resolvePath(parsedPath.path, basePath, append || next.append) : basePath;
      var query = resolveQuery(parsedPath.query, next.query, router && router.options.parseQuery);
      var hash = next.hash || parsedPath.hash;
      if (hash && hash.charAt(0) !== "#") {
        hash = "#" + hash;
      }
      return {
        _normalized: true,
        path,
        query,
        hash
      };
    }
    var toTypes = [String, Object];
    var eventTypes = [String, Array];
    var noop = function() {
    };
    var Link = {
      name: "RouterLink",
      props: {
        to: {
          type: toTypes,
          required: true
        },
        tag: {
          type: String,
          default: "a"
        },
        custom: Boolean,
        exact: Boolean,
        exactPath: Boolean,
        append: Boolean,
        replace: Boolean,
        activeClass: String,
        exactActiveClass: String,
        ariaCurrentValue: {
          type: String,
          default: "page"
        },
        event: {
          type: eventTypes,
          default: "click"
        }
      },
      render: function render2(h) {
        var this$1$1 = this;
        var router = this.$router;
        var current = this.$route;
        var ref = router.resolve(this.to, current, this.append);
        var location = ref.location;
        var route = ref.route;
        var href = ref.href;
        var classes = {};
        var globalActiveClass = router.options.linkActiveClass;
        var globalExactActiveClass = router.options.linkExactActiveClass;
        var activeClassFallback = globalActiveClass == null ? "router-link-active" : globalActiveClass;
        var exactActiveClassFallback = globalExactActiveClass == null ? "router-link-exact-active" : globalExactActiveClass;
        var activeClass = this.activeClass == null ? activeClassFallback : this.activeClass;
        var exactActiveClass = this.exactActiveClass == null ? exactActiveClassFallback : this.exactActiveClass;
        var compareTarget = route.redirectedFrom ? createRoute(null, normalizeLocation(route.redirectedFrom), null, router) : route;
        classes[exactActiveClass] = isSameRoute(current, compareTarget, this.exactPath);
        classes[activeClass] = this.exact || this.exactPath ? classes[exactActiveClass] : isIncludedRoute(current, compareTarget);
        var ariaCurrentValue = classes[exactActiveClass] ? this.ariaCurrentValue : null;
        var handler = function(e) {
          if (guardEvent(e)) {
            if (this$1$1.replace) {
              router.replace(location, noop);
            } else {
              router.push(location, noop);
            }
          }
        };
        var on = {
          click: guardEvent
        };
        if (Array.isArray(this.event)) {
          this.event.forEach(function(e) {
            on[e] = handler;
          });
        } else {
          on[this.event] = handler;
        }
        var data = {
          class: classes
        };
        var scopedSlot = !this.$scopedSlots.$hasNormal && this.$scopedSlots.default && this.$scopedSlots.default({
          href,
          route,
          navigate: handler,
          isActive: classes[activeClass],
          isExactActive: classes[exactActiveClass]
        });
        if (scopedSlot) {
          if (scopedSlot.length === 1) {
            return scopedSlot[0];
          } else if (scopedSlot.length > 1 || !scopedSlot.length) {
            return scopedSlot.length === 0 ? h() : h("span", {}, scopedSlot);
          }
        }
        if (this.tag === "a") {
          data.on = on;
          data.attrs = {
            href,
            "aria-current": ariaCurrentValue
          };
        } else {
          var a = findAnchor(this.$slots.default);
          if (a) {
            a.isStatic = false;
            var aData = a.data = extend({}, a.data);
            aData.on = aData.on || {};
            for (var event in aData.on) {
              var handler$1 = aData.on[event];
              if (event in on) {
                aData.on[event] = Array.isArray(handler$1) ? handler$1 : [handler$1];
              }
            }
            for (var event$1 in on) {
              if (event$1 in aData.on) {
                aData.on[event$1].push(on[event$1]);
              } else {
                aData.on[event$1] = handler;
              }
            }
            var aAttrs = a.data.attrs = extend({}, a.data.attrs);
            aAttrs.href = href;
            aAttrs["aria-current"] = ariaCurrentValue;
          } else {
            data.on = on;
          }
        }
        return h(this.tag, data, this.$slots.default);
      }
    };
    function guardEvent(e) {
      if (e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) {
        return;
      }
      if (e.defaultPrevented) {
        return;
      }
      if (e.button !== void 0 && e.button !== 0) {
        return;
      }
      if (e.currentTarget && e.currentTarget.getAttribute) {
        var target = e.currentTarget.getAttribute("target");
        if (/\b_blank\b/i.test(target)) {
          return;
        }
      }
      if (e.preventDefault) {
        e.preventDefault();
      }
      return true;
    }
    function findAnchor(children) {
      if (children) {
        var child;
        for (var i = 0; i < children.length; i++) {
          child = children[i];
          if (child.tag === "a") {
            return child;
          }
          if (child.children && (child = findAnchor(child.children))) {
            return child;
          }
        }
      }
    }
    var _Vue;
    function install(Vue2) {
      if (install.installed && _Vue === Vue2) {
        return;
      }
      install.installed = true;
      _Vue = Vue2;
      var isDef = function(v) {
        return v !== void 0;
      };
      var registerInstance = function(vm, callVal) {
        var i = vm.$options._parentVnode;
        if (isDef(i) && isDef(i = i.data) && isDef(i = i.registerRouteInstance)) {
          i(vm, callVal);
        }
      };
      Vue2.mixin({
        beforeCreate: function beforeCreate() {
          if (isDef(this.$options.router)) {
            this._routerRoot = this;
            this._router = this.$options.router;
            this._router.init(this);
            Vue2.util.defineReactive(this, "_route", this._router.history.current);
          } else {
            this._routerRoot = this.$parent && this.$parent._routerRoot || this;
          }
          registerInstance(this, this);
        },
        destroyed: function destroyed() {
          registerInstance(this);
        }
      });
      Object.defineProperty(Vue2.prototype, "$router", {
        get: function get() {
          return this._routerRoot._router;
        }
      });
      Object.defineProperty(Vue2.prototype, "$route", {
        get: function get() {
          return this._routerRoot._route;
        }
      });
      Vue2.component("RouterView", View);
      Vue2.component("RouterLink", Link);
      var strats = Vue2.config.optionMergeStrategies;
      strats.beforeRouteEnter = strats.beforeRouteLeave = strats.beforeRouteUpdate = strats.created;
    }
    var inBrowser = false;
    function createRouteMap(routes, oldPathList, oldPathMap, oldNameMap, parentRoute) {
      var pathList = oldPathList || [];
      var pathMap = oldPathMap || Object.create(null);
      var nameMap = oldNameMap || Object.create(null);
      routes.forEach(function(route) {
        addRouteRecord(pathList, pathMap, nameMap, route, parentRoute);
      });
      for (var i = 0, l = pathList.length; i < l; i++) {
        if (pathList[i] === "*") {
          pathList.push(pathList.splice(i, 1)[0]);
          l--;
          i--;
        }
      }
      return {
        pathList,
        pathMap,
        nameMap
      };
    }
    function addRouteRecord(pathList, pathMap, nameMap, route, parent, matchAs) {
      var path = route.path;
      var name = route.name;
      var pathToRegexpOptions = route.pathToRegexpOptions || {};
      var normalizedPath = normalizePath(path, parent, pathToRegexpOptions.strict);
      if (typeof route.caseSensitive === "boolean") {
        pathToRegexpOptions.sensitive = route.caseSensitive;
      }
      var record = {
        path: normalizedPath,
        regex: compileRouteRegex(normalizedPath, pathToRegexpOptions),
        components: route.components || {
          default: route.component
        },
        alias: route.alias ? typeof route.alias === "string" ? [route.alias] : route.alias : [],
        instances: {},
        enteredCbs: {},
        name,
        parent,
        matchAs,
        redirect: route.redirect,
        beforeEnter: route.beforeEnter,
        meta: route.meta || {},
        props: route.props == null ? {} : route.components ? route.props : {
          default: route.props
        }
      };
      if (route.children) {
        route.children.forEach(function(child) {
          var childMatchAs = matchAs ? cleanPath(matchAs + "/" + child.path) : void 0;
          addRouteRecord(pathList, pathMap, nameMap, child, record, childMatchAs);
        });
      }
      if (!pathMap[record.path]) {
        pathList.push(record.path);
        pathMap[record.path] = record;
      }
      if (route.alias !== void 0) {
        var aliases = Array.isArray(route.alias) ? route.alias : [route.alias];
        for (var i = 0; i < aliases.length; ++i) {
          var alias = aliases[i];
          var aliasRoute = {
            path: alias,
            children: route.children
          };
          addRouteRecord(pathList, pathMap, nameMap, aliasRoute, parent, record.path || "/");
        }
      }
      if (name) {
        if (!nameMap[name]) {
          nameMap[name] = record;
        }
      }
    }
    function compileRouteRegex(path, pathToRegexpOptions) {
      var regex = pathToRegexp_1(path, [], pathToRegexpOptions);
      return regex;
    }
    function normalizePath(path, parent, strict) {
      if (!strict) {
        path = path.replace(/\/$/, "");
      }
      if (path[0] === "/") {
        return path;
      }
      if (parent == null) {
        return path;
      }
      return cleanPath(parent.path + "/" + path);
    }
    function createMatcher(routes, router) {
      var ref = createRouteMap(routes);
      var pathList = ref.pathList;
      var pathMap = ref.pathMap;
      var nameMap = ref.nameMap;
      function addRoutes(routes2) {
        createRouteMap(routes2, pathList, pathMap, nameMap);
      }
      function addRoute(parentOrRoute, route) {
        var parent = typeof parentOrRoute !== "object" ? nameMap[parentOrRoute] : void 0;
        createRouteMap([route || parentOrRoute], pathList, pathMap, nameMap, parent);
        if (parent && parent.alias.length) {
          createRouteMap(parent.alias.map(function(alias2) {
            return {
              path: alias2,
              children: [route]
            };
          }), pathList, pathMap, nameMap, parent);
        }
      }
      function getRoutes() {
        return pathList.map(function(path) {
          return pathMap[path];
        });
      }
      function match(raw, currentRoute, redirectedFrom) {
        var location = normalizeLocation(raw, currentRoute, false, router);
        var name = location.name;
        if (name) {
          var record = nameMap[name];
          if (!record) {
            return _createRoute(null, location);
          }
          var paramNames = record.regex.keys.filter(function(key2) {
            return !key2.optional;
          }).map(function(key2) {
            return key2.name;
          });
          if (typeof location.params !== "object") {
            location.params = {};
          }
          if (currentRoute && typeof currentRoute.params === "object") {
            for (var key in currentRoute.params) {
              if (!(key in location.params) && paramNames.indexOf(key) > -1) {
                location.params[key] = currentRoute.params[key];
              }
            }
          }
          location.path = fillParams(record.path, location.params);
          return _createRoute(record, location, redirectedFrom);
        } else if (location.path) {
          location.params = {};
          for (var i = 0; i < pathList.length; i++) {
            var path = pathList[i];
            var record$1 = pathMap[path];
            if (matchRoute(record$1.regex, location.path, location.params)) {
              return _createRoute(record$1, location, redirectedFrom);
            }
          }
        }
        return _createRoute(null, location);
      }
      function redirect(record, location) {
        var originalRedirect = record.redirect;
        var redirect2 = typeof originalRedirect === "function" ? originalRedirect(createRoute(record, location, null, router)) : originalRedirect;
        if (typeof redirect2 === "string") {
          redirect2 = {
            path: redirect2
          };
        }
        if (!redirect2 || typeof redirect2 !== "object") {
          return _createRoute(null, location);
        }
        var re = redirect2;
        var name = re.name;
        var path = re.path;
        var query = location.query;
        var hash = location.hash;
        var params = location.params;
        query = re.hasOwnProperty("query") ? re.query : query;
        hash = re.hasOwnProperty("hash") ? re.hash : hash;
        params = re.hasOwnProperty("params") ? re.params : params;
        if (name) {
          nameMap[name];
          return match({
            _normalized: true,
            name,
            query,
            hash,
            params
          }, void 0, location);
        } else if (path) {
          var rawPath = resolveRecordPath(path, record);
          var resolvedPath = fillParams(rawPath, params);
          return match({
            _normalized: true,
            path: resolvedPath,
            query,
            hash
          }, void 0, location);
        } else {
          return _createRoute(null, location);
        }
      }
      function alias(record, location, matchAs) {
        var aliasedPath = fillParams(matchAs, location.params);
        var aliasedMatch = match({
          _normalized: true,
          path: aliasedPath
        });
        if (aliasedMatch) {
          var matched = aliasedMatch.matched;
          var aliasedRecord = matched[matched.length - 1];
          location.params = aliasedMatch.params;
          return _createRoute(aliasedRecord, location);
        }
        return _createRoute(null, location);
      }
      function _createRoute(record, location, redirectedFrom) {
        if (record && record.redirect) {
          return redirect(record, redirectedFrom || location);
        }
        if (record && record.matchAs) {
          return alias(record, location, record.matchAs);
        }
        return createRoute(record, location, redirectedFrom, router);
      }
      return {
        match,
        addRoute,
        getRoutes,
        addRoutes
      };
    }
    function matchRoute(regex, path, params) {
      var m = path.match(regex);
      if (!m) {
        return false;
      } else if (!params) {
        return true;
      }
      for (var i = 1, len = m.length; i < len; ++i) {
        var key = regex.keys[i - 1];
        if (key) {
          params[key.name || "pathMatch"] = typeof m[i] === "string" ? decode(m[i]) : m[i];
        }
      }
      return true;
    }
    function resolveRecordPath(path, record) {
      return resolvePath(path, record.parent ? record.parent.path : "/", true);
    }
    var Time = Date;
    function genStateKey() {
      return Time.now().toFixed(3);
    }
    var _key = genStateKey();
    function getStateKey() {
      return _key;
    }
    function setStateKey(key) {
      return _key = key;
    }
    var positionStore = Object.create(null);
    function handleScroll(router, to, from, isPop) {
      if (!router.app) {
        return;
      }
      var behavior = router.options.scrollBehavior;
      if (!behavior) {
        return;
      }
      router.app.$nextTick(function() {
        var position = getScrollPosition();
        var shouldScroll = behavior.call(router, to, from, isPop ? position : null);
        if (!shouldScroll) {
          return;
        }
        if (typeof shouldScroll.then === "function") {
          shouldScroll.then(function(shouldScroll2) {
            scrollToPosition(shouldScroll2, position);
          }).catch(function(err) {
          });
        } else {
          scrollToPosition(shouldScroll, position);
        }
      });
    }
    function saveScrollPosition() {
      var key = getStateKey();
      if (key) {
        positionStore[key] = {
          x: window.pageXOffset,
          y: window.pageYOffset
        };
      }
    }
    function getScrollPosition() {
      var key = getStateKey();
      if (key) {
        return positionStore[key];
      }
    }
    function getElementPosition(el, offset) {
      var docEl = document.documentElement;
      var docRect = docEl.getBoundingClientRect();
      var elRect = el.getBoundingClientRect();
      return {
        x: elRect.left - docRect.left - offset.x,
        y: elRect.top - docRect.top - offset.y
      };
    }
    function isValidPosition(obj) {
      return isNumber(obj.x) || isNumber(obj.y);
    }
    function normalizePosition(obj) {
      return {
        x: isNumber(obj.x) ? obj.x : window.pageXOffset,
        y: isNumber(obj.y) ? obj.y : window.pageYOffset
      };
    }
    function normalizeOffset(obj) {
      return {
        x: isNumber(obj.x) ? obj.x : 0,
        y: isNumber(obj.y) ? obj.y : 0
      };
    }
    function isNumber(v) {
      return typeof v === "number";
    }
    var hashStartsWithNumberRE = /^#\d/;
    function scrollToPosition(shouldScroll, position) {
      var isObject2 = typeof shouldScroll === "object";
      if (isObject2 && typeof shouldScroll.selector === "string") {
        var el = hashStartsWithNumberRE.test(shouldScroll.selector) ? document.getElementById(shouldScroll.selector.slice(1)) : document.querySelector(shouldScroll.selector);
        if (el) {
          var offset = shouldScroll.offset && typeof shouldScroll.offset === "object" ? shouldScroll.offset : {};
          offset = normalizeOffset(offset);
          position = getElementPosition(el, offset);
        } else if (isValidPosition(shouldScroll)) {
          position = normalizePosition(shouldScroll);
        }
      } else if (isObject2 && isValidPosition(shouldScroll)) {
        position = normalizePosition(shouldScroll);
      }
      if (position) {
        if ("scrollBehavior" in document.documentElement.style) {
          window.scrollTo({
            left: position.x,
            top: position.y,
            behavior: shouldScroll.behavior
          });
        } else {
          window.scrollTo(position.x, position.y);
        }
      }
    }
    var supportsPushState = inBrowser ;
    function pushState(url, replace) {
      saveScrollPosition();
      var history = window.history;
      try {
        if (replace) {
          var stateCopy = extend({}, history.state);
          stateCopy.key = getStateKey();
          history.replaceState(stateCopy, "", url);
        } else {
          history.pushState({
            key: setStateKey(genStateKey())
          }, "", url);
        }
      } catch (e) {
        window.location[replace ? "replace" : "assign"](url);
      }
    }
    function replaceState(url) {
      pushState(url, true);
    }
    function runQueue(queue, fn, cb) {
      var step = function(index) {
        if (index >= queue.length) {
          cb();
        } else {
          if (queue[index]) {
            fn(queue[index], function() {
              step(index + 1);
            });
          } else {
            step(index + 1);
          }
        }
      };
      step(0);
    }
    var NavigationFailureType = {
      redirected: 2,
      aborted: 4,
      cancelled: 8,
      duplicated: 16
    };
    function createNavigationRedirectedError(from, to) {
      return createRouterError(from, to, NavigationFailureType.redirected, 'Redirected when going from "' + from.fullPath + '" to "' + stringifyRoute(to) + '" via a navigation guard.');
    }
    function createNavigationDuplicatedError(from, to) {
      var error = createRouterError(from, to, NavigationFailureType.duplicated, 'Avoided redundant navigation to current location: "' + from.fullPath + '".');
      error.name = "NavigationDuplicated";
      return error;
    }
    function createNavigationCancelledError(from, to) {
      return createRouterError(from, to, NavigationFailureType.cancelled, 'Navigation cancelled from "' + from.fullPath + '" to "' + to.fullPath + '" with a new navigation.');
    }
    function createNavigationAbortedError(from, to) {
      return createRouterError(from, to, NavigationFailureType.aborted, 'Navigation aborted from "' + from.fullPath + '" to "' + to.fullPath + '" via a navigation guard.');
    }
    function createRouterError(from, to, type, message) {
      var error = new Error(message);
      error._isRouter = true;
      error.from = from;
      error.to = to;
      error.type = type;
      return error;
    }
    var propertiesToLog = ["params", "query", "hash"];
    function stringifyRoute(to) {
      if (typeof to === "string") {
        return to;
      }
      if ("path" in to) {
        return to.path;
      }
      var location = {};
      propertiesToLog.forEach(function(key) {
        if (key in to) {
          location[key] = to[key];
        }
      });
      return JSON.stringify(location, null, 2);
    }
    function isError(err) {
      return Object.prototype.toString.call(err).indexOf("Error") > -1;
    }
    function isNavigationFailure(err, errorType) {
      return isError(err) && err._isRouter && (errorType == null || err.type === errorType);
    }
    function resolveAsyncComponents(matched) {
      return function(to, from, next) {
        var hasAsync = false;
        var pending = 0;
        var error = null;
        vue_router_esm_flatMapComponents(matched, function(def, _, match, key) {
          if (typeof def === "function" && def.cid === void 0) {
            hasAsync = true;
            pending++;
            var resolve = once(function(resolvedDef) {
              if (isESModule(resolvedDef)) {
                resolvedDef = resolvedDef.default;
              }
              def.resolved = typeof resolvedDef === "function" ? resolvedDef : _Vue.extend(resolvedDef);
              match.components[key] = resolvedDef;
              pending--;
              if (pending <= 0) {
                next();
              }
            });
            var reject = once(function(reason) {
              var msg = "Failed to resolve async component " + key + ": " + reason;
              if (!error) {
                error = isError(reason) ? reason : new Error(msg);
                next(error);
              }
            });
            var res;
            try {
              res = def(resolve, reject);
            } catch (e) {
              reject(e);
            }
            if (res) {
              if (typeof res.then === "function") {
                res.then(resolve, reject);
              } else {
                var comp = res.component;
                if (comp && typeof comp.then === "function") {
                  comp.then(resolve, reject);
                }
              }
            }
          }
        });
        if (!hasAsync) {
          next();
        }
      };
    }
    function vue_router_esm_flatMapComponents(matched, fn) {
      return flatten(matched.map(function(m) {
        return Object.keys(m.components).map(function(key) {
          return fn(m.components[key], m.instances[key], m, key);
        });
      }));
    }
    function flatten(arr) {
      return Array.prototype.concat.apply([], arr);
    }
    var hasSymbol = typeof Symbol === "function" && typeof Symbol.toStringTag === "symbol";
    function isESModule(obj) {
      return obj.__esModule || hasSymbol && obj[Symbol.toStringTag] === "Module";
    }
    function once(fn) {
      var called = false;
      return function() {
        var args = [], len = arguments.length;
        while (len--)
          args[len] = arguments[len];
        if (called) {
          return;
        }
        called = true;
        return fn.apply(this, args);
      };
    }
    var History = function History2(router, base) {
      this.router = router;
      this.base = normalizeBase(base);
      this.current = START;
      this.pending = null;
      this.ready = false;
      this.readyCbs = [];
      this.readyErrorCbs = [];
      this.errorCbs = [];
      this.listeners = [];
    };
    History.prototype.listen = function listen(cb) {
      this.cb = cb;
    };
    History.prototype.onReady = function onReady(cb, errorCb) {
      if (this.ready) {
        cb();
      } else {
        this.readyCbs.push(cb);
        if (errorCb) {
          this.readyErrorCbs.push(errorCb);
        }
      }
    };
    History.prototype.onError = function onError(errorCb) {
      this.errorCbs.push(errorCb);
    };
    History.prototype.transitionTo = function transitionTo(location, onComplete, onAbort) {
      var this$1$1 = this;
      var route;
      try {
        route = this.router.match(location, this.current);
      } catch (e) {
        this.errorCbs.forEach(function(cb) {
          cb(e);
        });
        throw e;
      }
      var prev = this.current;
      this.confirmTransition(route, function() {
        this$1$1.updateRoute(route);
        onComplete && onComplete(route);
        this$1$1.ensureURL();
        this$1$1.router.afterHooks.forEach(function(hook) {
          hook && hook(route, prev);
        });
        if (!this$1$1.ready) {
          this$1$1.ready = true;
          this$1$1.readyCbs.forEach(function(cb) {
            cb(route);
          });
        }
      }, function(err) {
        if (onAbort) {
          onAbort(err);
        }
        if (err && !this$1$1.ready) {
          if (!isNavigationFailure(err, NavigationFailureType.redirected) || prev !== START) {
            this$1$1.ready = true;
            this$1$1.readyErrorCbs.forEach(function(cb) {
              cb(err);
            });
          }
        }
      });
    };
    History.prototype.confirmTransition = function confirmTransition(route, onComplete, onAbort) {
      var this$1$1 = this;
      var current = this.current;
      this.pending = route;
      var abort = function(err) {
        if (!isNavigationFailure(err) && isError(err)) {
          if (this$1$1.errorCbs.length) {
            this$1$1.errorCbs.forEach(function(cb) {
              cb(err);
            });
          } else {
            console.error(err);
          }
        }
        onAbort && onAbort(err);
      };
      var lastRouteIndex = route.matched.length - 1;
      var lastCurrentIndex = current.matched.length - 1;
      if (isSameRoute(route, current) && lastRouteIndex === lastCurrentIndex && route.matched[lastRouteIndex] === current.matched[lastCurrentIndex]) {
        this.ensureURL();
        if (route.hash) {
          handleScroll(this.router, current, route, false);
        }
        return abort(createNavigationDuplicatedError(current, route));
      }
      var ref = resolveQueue(this.current.matched, route.matched);
      var updated = ref.updated;
      var deactivated = ref.deactivated;
      var activated = ref.activated;
      var queue = [].concat(extractLeaveGuards(deactivated), this.router.beforeHooks, extractUpdateHooks(updated), activated.map(function(m) {
        return m.beforeEnter;
      }), resolveAsyncComponents(activated));
      var iterator = function(hook, next) {
        if (this$1$1.pending !== route) {
          return abort(createNavigationCancelledError(current, route));
        }
        try {
          hook(route, current, function(to) {
            if (to === false) {
              this$1$1.ensureURL(true);
              abort(createNavigationAbortedError(current, route));
            } else if (isError(to)) {
              this$1$1.ensureURL(true);
              abort(to);
            } else if (typeof to === "string" || typeof to === "object" && (typeof to.path === "string" || typeof to.name === "string")) {
              abort(createNavigationRedirectedError(current, route));
              if (typeof to === "object" && to.replace) {
                this$1$1.replace(to);
              } else {
                this$1$1.push(to);
              }
            } else {
              next(to);
            }
          });
        } catch (e) {
          abort(e);
        }
      };
      runQueue(queue, iterator, function() {
        var enterGuards = extractEnterGuards(activated);
        var queue2 = enterGuards.concat(this$1$1.router.resolveHooks);
        runQueue(queue2, iterator, function() {
          if (this$1$1.pending !== route) {
            return abort(createNavigationCancelledError(current, route));
          }
          this$1$1.pending = null;
          onComplete(route);
          if (this$1$1.router.app) {
            this$1$1.router.app.$nextTick(function() {
              handleRouteEntered(route);
            });
          }
        });
      });
    };
    History.prototype.updateRoute = function updateRoute(route) {
      this.current = route;
      this.cb && this.cb(route);
    };
    History.prototype.setupListeners = function setupListeners() {
    };
    History.prototype.teardown = function teardown() {
      this.listeners.forEach(function(cleanupListener) {
        cleanupListener();
      });
      this.listeners = [];
      this.current = START;
      this.pending = null;
    };
    function normalizeBase(base) {
      if (!base) {
        {
          base = "/";
        }
      }
      if (base.charAt(0) !== "/") {
        base = "/" + base;
      }
      return base.replace(/\/$/, "");
    }
    function resolveQueue(current, next) {
      var i;
      var max = Math.max(current.length, next.length);
      for (i = 0; i < max; i++) {
        if (current[i] !== next[i]) {
          break;
        }
      }
      return {
        updated: next.slice(0, i),
        activated: next.slice(i),
        deactivated: current.slice(i)
      };
    }
    function extractGuards(records, name, bind2, reverse) {
      var guards = vue_router_esm_flatMapComponents(records, function(def, instance, match, key) {
        var guard = extractGuard(def, name);
        if (guard) {
          return Array.isArray(guard) ? guard.map(function(guard2) {
            return bind2(guard2, instance, match, key);
          }) : bind2(guard, instance, match, key);
        }
      });
      return flatten(reverse ? guards.reverse() : guards);
    }
    function extractGuard(def, key) {
      if (typeof def !== "function") {
        def = _Vue.extend(def);
      }
      return def.options[key];
    }
    function extractLeaveGuards(deactivated) {
      return extractGuards(deactivated, "beforeRouteLeave", bindGuard, true);
    }
    function extractUpdateHooks(updated) {
      return extractGuards(updated, "beforeRouteUpdate", bindGuard);
    }
    function bindGuard(guard, instance) {
      if (instance) {
        return function boundRouteGuard() {
          return guard.apply(instance, arguments);
        };
      }
    }
    function extractEnterGuards(activated) {
      return extractGuards(activated, "beforeRouteEnter", function(guard, _, match, key) {
        return bindEnterGuard(guard, match, key);
      });
    }
    function bindEnterGuard(guard, match, key) {
      return function routeEnterGuard(to, from, next) {
        return guard(to, from, function(cb) {
          if (typeof cb === "function") {
            if (!match.enteredCbs[key]) {
              match.enteredCbs[key] = [];
            }
            match.enteredCbs[key].push(cb);
          }
          next(cb);
        });
      };
    }
    var HTML5History = /* @__PURE__ */ function(History2) {
      function HTML5History2(router, base) {
        History2.call(this, router, base);
        this._startLocation = vue_router_esm_getLocation(this.base);
      }
      if (History2)
        HTML5History2.__proto__ = History2;
      HTML5History2.prototype = Object.create(History2 && History2.prototype);
      HTML5History2.prototype.constructor = HTML5History2;
      HTML5History2.prototype.setupListeners = function setupListeners() {
        var this$1$1 = this;
        if (this.listeners.length > 0) {
          return;
        }
        var router = this.router;
        router.options.scrollBehavior;
        var handleRoutingEvent = function() {
          this$1$1.current;
          var location = vue_router_esm_getLocation(this$1$1.base);
          if (this$1$1.current === START && location === this$1$1._startLocation) {
            return;
          }
          this$1$1.transitionTo(location, function(route) {
          });
        };
        window.addEventListener("popstate", handleRoutingEvent);
        this.listeners.push(function() {
          window.removeEventListener("popstate", handleRoutingEvent);
        });
      };
      HTML5History2.prototype.go = function go(n) {
        window.history.go(n);
      };
      HTML5History2.prototype.push = function push(location, onComplete, onAbort) {
        var this$1$1 = this;
        var ref = this;
        var fromRoute = ref.current;
        this.transitionTo(location, function(route) {
          pushState(cleanPath(this$1$1.base + route.fullPath));
          handleScroll(this$1$1.router, route, fromRoute, false);
          onComplete && onComplete(route);
        }, onAbort);
      };
      HTML5History2.prototype.replace = function replace(location, onComplete, onAbort) {
        var this$1$1 = this;
        var ref = this;
        var fromRoute = ref.current;
        this.transitionTo(location, function(route) {
          replaceState(cleanPath(this$1$1.base + route.fullPath));
          handleScroll(this$1$1.router, route, fromRoute, false);
          onComplete && onComplete(route);
        }, onAbort);
      };
      HTML5History2.prototype.ensureURL = function ensureURL(push) {
        if (vue_router_esm_getLocation(this.base) !== this.current.fullPath) {
          var current = cleanPath(this.base + this.current.fullPath);
          push ? pushState(current) : replaceState(current);
        }
      };
      HTML5History2.prototype.getCurrentLocation = function getCurrentLocation() {
        return vue_router_esm_getLocation(this.base);
      };
      return HTML5History2;
    }(History);
    function vue_router_esm_getLocation(base) {
      var path = window.location.pathname;
      var pathLowerCase = path.toLowerCase();
      var baseLowerCase = base.toLowerCase();
      if (base && (pathLowerCase === baseLowerCase || pathLowerCase.indexOf(cleanPath(baseLowerCase + "/")) === 0)) {
        path = path.slice(base.length);
      }
      return (path || "/") + window.location.search + window.location.hash;
    }
    var HashHistory = /* @__PURE__ */ function(History2) {
      function HashHistory2(router, base, fallback) {
        History2.call(this, router, base);
        if (fallback && checkFallback(this.base)) {
          return;
        }
        ensureSlash();
      }
      if (History2)
        HashHistory2.__proto__ = History2;
      HashHistory2.prototype = Object.create(History2 && History2.prototype);
      HashHistory2.prototype.constructor = HashHistory2;
      HashHistory2.prototype.setupListeners = function setupListeners() {
        var this$1$1 = this;
        if (this.listeners.length > 0) {
          return;
        }
        var router = this.router;
        router.options.scrollBehavior;
        var handleRoutingEvent = function() {
          this$1$1.current;
          if (!ensureSlash()) {
            return;
          }
          this$1$1.transitionTo(getHash(), function(route) {
            {
              replaceHash(route.fullPath);
            }
          });
        };
        var eventType = "hashchange";
        window.addEventListener(eventType, handleRoutingEvent);
        this.listeners.push(function() {
          window.removeEventListener(eventType, handleRoutingEvent);
        });
      };
      HashHistory2.prototype.push = function push(location, onComplete, onAbort) {
        var this$1$1 = this;
        var ref = this;
        var fromRoute = ref.current;
        this.transitionTo(location, function(route) {
          pushHash(route.fullPath);
          handleScroll(this$1$1.router, route, fromRoute, false);
          onComplete && onComplete(route);
        }, onAbort);
      };
      HashHistory2.prototype.replace = function replace(location, onComplete, onAbort) {
        var this$1$1 = this;
        var ref = this;
        var fromRoute = ref.current;
        this.transitionTo(location, function(route) {
          replaceHash(route.fullPath);
          handleScroll(this$1$1.router, route, fromRoute, false);
          onComplete && onComplete(route);
        }, onAbort);
      };
      HashHistory2.prototype.go = function go(n) {
        window.history.go(n);
      };
      HashHistory2.prototype.ensureURL = function ensureURL(push) {
        var current = this.current.fullPath;
        if (getHash() !== current) {
          push ? pushHash(current) : replaceHash(current);
        }
      };
      HashHistory2.prototype.getCurrentLocation = function getCurrentLocation() {
        return getHash();
      };
      return HashHistory2;
    }(History);
    function checkFallback(base) {
      var location = vue_router_esm_getLocation(base);
      if (!/^\/#/.test(location)) {
        window.location.replace(cleanPath(base + "/#" + location));
        return true;
      }
    }
    function ensureSlash() {
      var path = getHash();
      if (path.charAt(0) === "/") {
        return true;
      }
      replaceHash("/" + path);
      return false;
    }
    function getHash() {
      var href = window.location.href;
      var index = href.indexOf("#");
      if (index < 0) {
        return "";
      }
      href = href.slice(index + 1);
      return href;
    }
    function getUrl(path) {
      var href = window.location.href;
      var i = href.indexOf("#");
      var base = i >= 0 ? href.slice(0, i) : href;
      return base + "#" + path;
    }
    function pushHash(path) {
      {
        window.location.hash = path;
      }
    }
    function replaceHash(path) {
      {
        window.location.replace(getUrl(path));
      }
    }
    var AbstractHistory = /* @__PURE__ */ function(History2) {
      function AbstractHistory2(router, base) {
        History2.call(this, router, base);
        this.stack = [];
        this.index = -1;
      }
      if (History2)
        AbstractHistory2.__proto__ = History2;
      AbstractHistory2.prototype = Object.create(History2 && History2.prototype);
      AbstractHistory2.prototype.constructor = AbstractHistory2;
      AbstractHistory2.prototype.push = function push(location, onComplete, onAbort) {
        var this$1$1 = this;
        this.transitionTo(location, function(route) {
          this$1$1.stack = this$1$1.stack.slice(0, this$1$1.index + 1).concat(route);
          this$1$1.index++;
          onComplete && onComplete(route);
        }, onAbort);
      };
      AbstractHistory2.prototype.replace = function replace(location, onComplete, onAbort) {
        var this$1$1 = this;
        this.transitionTo(location, function(route) {
          this$1$1.stack = this$1$1.stack.slice(0, this$1$1.index).concat(route);
          onComplete && onComplete(route);
        }, onAbort);
      };
      AbstractHistory2.prototype.go = function go(n) {
        var this$1$1 = this;
        var targetIndex = this.index + n;
        if (targetIndex < 0 || targetIndex >= this.stack.length) {
          return;
        }
        var route = this.stack[targetIndex];
        this.confirmTransition(route, function() {
          var prev = this$1$1.current;
          this$1$1.index = targetIndex;
          this$1$1.updateRoute(route);
          this$1$1.router.afterHooks.forEach(function(hook) {
            hook && hook(route, prev);
          });
        }, function(err) {
          if (isNavigationFailure(err, NavigationFailureType.duplicated)) {
            this$1$1.index = targetIndex;
          }
        });
      };
      AbstractHistory2.prototype.getCurrentLocation = function getCurrentLocation() {
        var current = this.stack[this.stack.length - 1];
        return current ? current.fullPath : "/";
      };
      AbstractHistory2.prototype.ensureURL = function ensureURL() {
      };
      return AbstractHistory2;
    }(History);
    var VueRouter = function VueRouter2(options2) {
      if (options2 === void 0)
        options2 = {};
      this.app = null;
      this.apps = [];
      this.options = options2;
      this.beforeHooks = [];
      this.resolveHooks = [];
      this.afterHooks = [];
      this.matcher = createMatcher(options2.routes || [], this);
      var mode = options2.mode || "hash";
      this.fallback = mode === "history" && !supportsPushState && options2.fallback !== false;
      if (this.fallback) {
        mode = "hash";
      }
      {
        mode = "abstract";
      }
      this.mode = mode;
      switch (mode) {
        case "history":
          this.history = new HTML5History(this, options2.base);
          break;
        case "hash":
          this.history = new HashHistory(this, options2.base, this.fallback);
          break;
        case "abstract":
          this.history = new AbstractHistory(this, options2.base);
          break;
      }
    };
    var prototypeAccessors = {
      currentRoute: {
        configurable: true
      }
    };
    VueRouter.prototype.match = function match(raw, current, redirectedFrom) {
      return this.matcher.match(raw, current, redirectedFrom);
    };
    prototypeAccessors.currentRoute.get = function() {
      return this.history && this.history.current;
    };
    VueRouter.prototype.init = function init(app) {
      var this$1$1 = this;
      this.apps.push(app);
      app.$once("hook:destroyed", function() {
        var index = this$1$1.apps.indexOf(app);
        if (index > -1) {
          this$1$1.apps.splice(index, 1);
        }
        if (this$1$1.app === app) {
          this$1$1.app = this$1$1.apps[0] || null;
        }
        if (!this$1$1.app) {
          this$1$1.history.teardown();
        }
      });
      if (this.app) {
        return;
      }
      this.app = app;
      var history = this.history;
      if (history instanceof HTML5History || history instanceof HashHistory) {
        var handleInitialScroll = function(routeOrError) {
          history.current;
          this$1$1.options.scrollBehavior;
        };
        var setupListeners = function(routeOrError) {
          history.setupListeners();
          handleInitialScroll(routeOrError);
        };
        history.transitionTo(history.getCurrentLocation(), setupListeners, setupListeners);
      }
      history.listen(function(route) {
        this$1$1.apps.forEach(function(app2) {
          app2._route = route;
        });
      });
    };
    VueRouter.prototype.beforeEach = function beforeEach(fn) {
      return registerHook(this.beforeHooks, fn);
    };
    VueRouter.prototype.beforeResolve = function beforeResolve(fn) {
      return registerHook(this.resolveHooks, fn);
    };
    VueRouter.prototype.afterEach = function afterEach(fn) {
      return registerHook(this.afterHooks, fn);
    };
    VueRouter.prototype.onReady = function onReady(cb, errorCb) {
      this.history.onReady(cb, errorCb);
    };
    VueRouter.prototype.onError = function onError(errorCb) {
      this.history.onError(errorCb);
    };
    VueRouter.prototype.push = function push(location, onComplete, onAbort) {
      var this$1$1 = this;
      if (!onComplete && !onAbort && typeof Promise !== "undefined") {
        return new Promise(function(resolve, reject) {
          this$1$1.history.push(location, resolve, reject);
        });
      } else {
        this.history.push(location, onComplete, onAbort);
      }
    };
    VueRouter.prototype.replace = function replace(location, onComplete, onAbort) {
      var this$1$1 = this;
      if (!onComplete && !onAbort && typeof Promise !== "undefined") {
        return new Promise(function(resolve, reject) {
          this$1$1.history.replace(location, resolve, reject);
        });
      } else {
        this.history.replace(location, onComplete, onAbort);
      }
    };
    VueRouter.prototype.go = function go(n) {
      this.history.go(n);
    };
    VueRouter.prototype.back = function back() {
      this.go(-1);
    };
    VueRouter.prototype.forward = function forward() {
      this.go(1);
    };
    VueRouter.prototype.getMatchedComponents = function getMatchedComponents2(to) {
      var route = to ? to.matched ? to : this.resolve(to).route : this.currentRoute;
      if (!route) {
        return [];
      }
      return [].concat.apply([], route.matched.map(function(m) {
        return Object.keys(m.components).map(function(key) {
          return m.components[key];
        });
      }));
    };
    VueRouter.prototype.resolve = function resolve(to, current, append) {
      current = current || this.history.current;
      var location = normalizeLocation(to, current, append, this);
      var route = this.match(location, current);
      var fullPath = route.redirectedFrom || route.fullPath;
      var base = this.history.base;
      var href = createHref(base, fullPath, this.mode);
      return {
        location,
        route,
        href,
        normalizedTo: location,
        resolved: route
      };
    };
    VueRouter.prototype.getRoutes = function getRoutes() {
      return this.matcher.getRoutes();
    };
    VueRouter.prototype.addRoute = function addRoute(parentOrRoute, route) {
      this.matcher.addRoute(parentOrRoute, route);
      if (this.history.current !== START) {
        this.history.transitionTo(this.history.getCurrentLocation());
      }
    };
    VueRouter.prototype.addRoutes = function addRoutes(routes) {
      this.matcher.addRoutes(routes);
      if (this.history.current !== START) {
        this.history.transitionTo(this.history.getCurrentLocation());
      }
    };
    Object.defineProperties(VueRouter.prototype, prototypeAccessors);
    function registerHook(list, fn) {
      list.push(fn);
      return function() {
        var i = list.indexOf(fn);
        if (i > -1) {
          list.splice(i, 1);
        }
      };
    }
    function createHref(base, fullPath, mode) {
      var path = mode === "hash" ? "#" + fullPath : fullPath;
      return base ? cleanPath(base + "/" + path) : path;
    }
    VueRouter.install = install;
    VueRouter.version = "3.5.3";
    VueRouter.isNavigationFailure = isNavigationFailure;
    VueRouter.NavigationFailureType = NavigationFailureType;
    VueRouter.START_LOCATION = START;
    var vue_router_esm = VueRouter;
    function shouldScrollToTop(route) {
      const Pages = getMatchedComponents(route);
      if (Pages.length === 1) {
        const {
          options: options2 = {}
        } = Pages[0];
        return options2.scrollToTop !== false;
      }
      return Pages.some(({
        options: options2
      }) => options2 && options2.scrollToTop);
    }
    var router_scrollBehavior = function(to, from, savedPosition) {
      let position = false;
      const isRouteChanged = to !== from;
      if (savedPosition) {
        position = savedPosition;
      } else if (isRouteChanged && shouldScrollToTop(to)) {
        position = {
          x: 0,
          y: 0
        };
      }
      const nuxt = window.$nuxt;
      if (!isRouteChanged || to.path === from.path && to.hash !== from.hash) {
        nuxt.$nextTick(() => nuxt.$emit("triggerScroll"));
      }
      return new Promise((resolve) => {
        nuxt.$once("triggerScroll", () => {
          if (to.hash) {
            let hash = to.hash;
            if (typeof window.CSS !== "undefined" && typeof window.CSS.escape !== "undefined") {
              hash = "#" + window.CSS.escape(hash.substr(1));
            }
            try {
              const el = document.querySelector(hash);
              if (el) {
                var _getComputedStyle$scr;
                position = {
                  selector: hash
                };
                const y = Number((_getComputedStyle$scr = getComputedStyle(el)["scroll-margin-top"]) === null || _getComputedStyle$scr === void 0 ? void 0 : _getComputedStyle$scr.replace("px", ""));
                if (y) {
                  position.offset = {
                    y
                  };
                }
              }
            } catch (e) {
              console.warn("Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).");
            }
          }
          resolve(position);
        });
      });
    };
    const _2649ed6f = () => interopDefault(__webpack_require__.e(13).then(__webpack_require__.bind(null, 171)));
    const _83fdbbfc = () => interopDefault(__webpack_require__.e(14).then(__webpack_require__.bind(null, 172)));
    const _299002b0 = () => interopDefault(__webpack_require__.e(15).then(__webpack_require__.bind(null, 173)));
    const _215d0d9c = () => interopDefault(__webpack_require__.e(16).then(__webpack_require__.bind(null, 174)));
    const _4f6299ff = () => interopDefault(__webpack_require__.e(18).then(__webpack_require__.bind(null, 175)));
    const _6cd6112a = () => interopDefault(__webpack_require__.e(19).then(__webpack_require__.bind(null, 176)));
    const _e928bb2c = () => interopDefault(__webpack_require__.e(20).then(__webpack_require__.bind(null, 179)));
    const _4601c834 = () => interopDefault(__webpack_require__.e(17).then(__webpack_require__.bind(null, 177)));
    const emptyFn = () => {
    };
    vue2_bridge["default"].use(vue_router_esm);
    const routerOptions = {
      mode: "history",
      base: "/",
      linkActiveClass: "nuxt-link-active",
      linkExactActiveClass: "nuxt-link-exact-active",
      scrollBehavior: router_scrollBehavior,
      routes: [{
        path: "/about",
        component: _2649ed6f,
        name: "about___en"
      }, {
        path: "/fr/about",
        component: _2649ed6f,
        name: "about___fr"
      }, {
        path: "/kr/about",
        component: _2649ed6f,
        name: "about___kr"
      }, {
        path: "/contact",
        component: _83fdbbfc,
        name: "contact___en"
      }, {
        path: "/fr/contact",
        component: _83fdbbfc,
        name: "contact___fr"
      }, {
        path: "/kr/contact",
        component: _83fdbbfc,
        name: "contact___kr"
      }, {
        path: "/contents",
        component: _299002b0,
        name: "contents___en"
      }, {
        path: "/fr/contents",
        component: _299002b0,
        name: "contents___fr"
      }, {
        path: "/kr/contents",
        component: _299002b0,
        name: "contents___kr"
      }, {
        path: "/founders",
        component: _215d0d9c,
        name: "founders___en"
      }, {
        path: "/fr/founders",
        component: _215d0d9c,
        name: "founders___fr"
      }, {
        path: "/kr/founders",
        component: _215d0d9c,
        name: "founders___kr"
      }, {
        path: "/philosophy",
        component: _4f6299ff,
        name: "philosophy___en"
      }, {
        path: "/fr/philosophy",
        component: _4f6299ff,
        name: "philosophy___fr"
      }, {
        path: "/kr/philosophy",
        component: _4f6299ff,
        name: "philosophy___kr"
      }, {
        path: "/team",
        component: _6cd6112a,
        name: "team___en"
      }, {
        path: "/fr/team",
        component: _6cd6112a,
        name: "team___fr"
      }, {
        path: "/kr/team",
        component: _6cd6112a,
        name: "team___kr"
      }, {
        path: "/users",
        component: _e928bb2c,
        name: "users___en"
      }, {
        path: "/fr/users",
        component: _e928bb2c,
        name: "users___fr"
      }, {
        path: "/kr/users",
        component: _e928bb2c,
        name: "users___kr"
      }, {
        path: "/",
        component: _4601c834,
        name: "index___en"
      }, {
        path: "/fr",
        component: _4601c834,
        name: "index___fr"
      }, {
        path: "/kr",
        component: _4601c834,
        name: "index___kr"
      }],
      fallback: false
    };
    function createRouter(ssrContext, config) {
      const base = config._app && config._app.basePath || routerOptions.base;
      const router = new vue_router_esm({
        ...routerOptions,
        base
      });
      const originalPush = router.push;
      router.push = function push(location, onComplete = emptyFn, onAbort) {
        return originalPush.call(this, location, onComplete, onAbort);
      };
      const resolve = router.resolve.bind(router);
      router.resolve = (to, current, append) => {
        if (typeof to === "string") {
          to = Object(external_ufo_["normalizeURL"])(to);
        }
        return resolve(to, current, append);
      };
      return router;
    }
    var nuxt_child = {
      name: "NuxtChild",
      functional: true,
      props: {
        nuxtChildKey: {
          type: String,
          default: ""
        },
        keepAlive: Boolean,
        keepAliveProps: {
          type: Object,
          default: void 0
        }
      },
      render(_, {
        parent,
        data,
        props
      }) {
        const h = parent.$createElement;
        data.nuxtChild = true;
        const _parent = parent;
        const transitions = parent.$nuxt.nuxt.transitions;
        const defaultTransition2 = parent.$nuxt.nuxt.defaultTransition;
        let depth = 0;
        while (parent) {
          if (parent.$vnode && parent.$vnode.data.nuxtChild) {
            depth++;
          }
          parent = parent.$parent;
        }
        data.nuxtChildDepth = depth;
        const transition = transitions[depth] || defaultTransition2;
        const transitionProps = {};
        transitionsKeys.forEach((key) => {
          if (typeof transition[key] !== "undefined") {
            transitionProps[key] = transition[key];
          }
        });
        const listeners = {};
        listenersKeys.forEach((key) => {
          if (typeof transition[key] === "function") {
            listeners[key] = transition[key].bind(_parent);
          }
        });
        if (transition.css === false) {
          const leave = listeners.leave;
          if (!leave || leave.length < 2) {
            listeners.leave = (el, done) => {
              if (leave) {
                leave.call(_parent, el);
              }
              _parent.$nextTick(done);
            };
          }
        }
        let routerView = h("routerView", data);
        if (props.keepAlive) {
          routerView = h("keep-alive", {
            props: props.keepAliveProps
          }, [routerView]);
        }
        return h("transition", {
          props: transitionProps,
          on: listeners
        }, [routerView]);
      }
    };
    const transitionsKeys = ["name", "mode", "appear", "css", "type", "duration", "enterClass", "leaveClass", "appearClass", "enterActiveClass", "enterActiveClass", "leaveActiveClass", "appearActiveClass", "enterToClass", "leaveToClass", "appearToClass"];
    const listenersKeys = ["beforeEnter", "enter", "afterEnter", "enterCancelled", "beforeLeave", "leave", "afterLeave", "leaveCancelled", "beforeAppear", "appear", "afterAppear", "appearCancelled"];
    var render = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", { staticClass: "error-page" }, [_vm._ssrNode((_vm.error.statusCode === 404 ? "<h1 data-v-38fb106c>404 Page not found</h1>" : "<h1 data-v-38fb106c>An error occurred</h1>") + " "), _c("NuxtLink", { attrs: { "to": "/" } }, [_vm._v("Home page")])], 2);
    };
    var staticRenderFns = [];
    var errorvue_type_script_lang_js_ = {
      props: ["error"],
      layout: "error"
    };
    var layouts_errorvue_type_script_lang_js_ = errorvue_type_script_lang_js_;
    var componentNormalizer = __webpack_require__(2);
    function injectStyles(context) {
      var style0 = __webpack_require__(79);
      if (style0.__inject__)
        style0.__inject__(context);
    }
    var error_component = Object(componentNormalizer["a"])(layouts_errorvue_type_script_lang_js_, render, staticRenderFns, false, injectStyles, "38fb106c", "0172bb8c");
    var layouts_error = error_component.exports;
    var components_nuxt = {
      name: "Nuxt",
      components: {
        NuxtChild: nuxt_child,
        NuxtError: layouts_error
      },
      props: {
        nuxtChildKey: {
          type: String,
          default: void 0
        },
        keepAlive: Boolean,
        keepAliveProps: {
          type: Object,
          default: void 0
        },
        name: {
          type: String,
          default: "default"
        }
      },
      errorCaptured(error) {
        if (this.displayingNuxtError) {
          this.errorFromNuxtError = error;
          this.$forceUpdate();
        }
      },
      computed: {
        routerViewKey() {
          if (typeof this.nuxtChildKey !== "undefined" || this.$route.matched.length > 1) {
            return this.nuxtChildKey || compile(this.$route.matched[0].path)(this.$route.params);
          }
          const [matchedRoute] = this.$route.matched;
          if (!matchedRoute) {
            return this.$route.path;
          }
          const Component = matchedRoute.components.default;
          if (Component && Component.options) {
            const {
              options: options2
            } = Component;
            if (options2.key) {
              return typeof options2.key === "function" ? options2.key(this.$route) : options2.key;
            }
          }
          const strict = /\/$/.test(matchedRoute.path);
          return strict ? this.$route.path : this.$route.path.replace(/\/$/, "");
        }
      },
      beforeCreate() {
        vue2_bridge["default"].util.defineReactive(this, "nuxt", this.$root.$options.nuxt);
      },
      render(h) {
        if (!this.nuxt.err) {
          return h("NuxtChild", {
            key: this.routerViewKey,
            props: this.$props
          });
        }
        if (this.errorFromNuxtError) {
          this.$nextTick(() => this.errorFromNuxtError = false);
          return h("div", {}, [h("h2", "An error occurred while showing the error page"), h("p", "Unfortunately an error occurred and while showing the error page another error occurred"), h("p", `Error details: ${this.errorFromNuxtError.toString()}`), h("nuxt-link", {
            props: {
              to: "/"
            }
          }, "Go back to home")]);
        }
        this.displayingNuxtError = true;
        this.$nextTick(() => this.displayingNuxtError = false);
        return h(layouts_error, {
          props: {
            error: this.nuxt.err
          }
        });
      }
    };
    var LoadingBar = __webpack_require__(70);
    __webpack_require__(83);
    __webpack_require__(85);
    var defaultvue_type_template_id_e0dd8552_render = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", { staticClass: "default-layout" }, [_c("client-only", { attrs: { "placeholder": "loading..." } }, [_c("Header", { attrs: { "bgClass": "bg-white" } })], 1), _vm._ssrNode(" "), _vm._ssrNode('<div class="main-body">', "</div>", [_c("Nuxt")], 1), _vm._ssrNode(" "), _c("Footer")], 2);
    };
    var defaultvue_type_template_id_e0dd8552_staticRenderFns = [];
    var script = {};
    function default_injectStyles(context) {
      var style0 = __webpack_require__(87);
      if (style0.__inject__)
        style0.__inject__(context);
    }
    var default_component = Object(componentNormalizer["a"])(script, defaultvue_type_template_id_e0dd8552_render, defaultvue_type_template_id_e0dd8552_staticRenderFns, false, default_injectStyles, null, "9b76391a");
    var layouts_default = default_component.exports;
    installComponents(default_component, { Header: __webpack_require__(43).default, Footer: __webpack_require__(44).default });
    var homevue_type_template_id_2db82fb3_render = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", { staticClass: "home-layout" }, [_c("client-only", { attrs: { "placeholder": "loading..." } }, [_c("Header", { attrs: { "bgClass": "bg-transparent" } })], 1), _vm._ssrNode(" "), _vm._ssrNode('<div class="main-body">', "</div>", [_c("Nuxt")], 1), _vm._ssrNode(" "), _c("Footer")], 2);
    };
    var homevue_type_template_id_2db82fb3_staticRenderFns = [];
    var homevue_type_script_lang_js_ = {
      name: "Home-Layout"
    };
    var layouts_homevue_type_script_lang_js_ = homevue_type_script_lang_js_;
    function home_injectStyles(context) {
      var style0 = __webpack_require__(95);
      if (style0.__inject__)
        style0.__inject__(context);
    }
    var home_component = Object(componentNormalizer["a"])(layouts_homevue_type_script_lang_js_, homevue_type_template_id_2db82fb3_render, homevue_type_template_id_2db82fb3_staticRenderFns, false, home_injectStyles, null, "34e1231d");
    var home = home_component.exports;
    installComponents(home_component, { Header: __webpack_require__(43).default, Footer: __webpack_require__(44).default });
    const layouts = {
      "_default": sanitizeComponent(layouts_default),
      "_home": sanitizeComponent(home)
    };
    var App = {
      render(h, props) {
        const loadingEl = h("NuxtLoading", {
          ref: "loading"
        });
        const layoutEl = h(this.layout || "nuxt");
        const templateEl = h("div", {
          domProps: {
            id: "__layout"
          },
          key: this.layoutName
        }, [layoutEl]);
        const transitionEl = h("transition", {
          props: {
            name: "layout",
            mode: "out-in"
          },
          on: {
            beforeEnter(el) {
              window.$nuxt.$nextTick(() => {
                window.$nuxt.$emit("triggerScroll");
              });
            }
          }
        }, [templateEl]);
        return h("div", {
          domProps: {
            id: "__nuxt"
          }
        }, [loadingEl, transitionEl]);
      },
      data: () => ({
        isOnline: true,
        layout: null,
        layoutName: "",
        nbFetching: 0
      }),
      beforeCreate() {
        vue2_bridge["default"].util.defineReactive(this, "nuxt", this.$options.nuxt);
      },
      created() {
        this.$root.$options.$nuxt = this;
        this.error = this.nuxt.error;
        this.context = this.$options.context;
      },
      async mounted() {
        this.$loading = this.$refs.loading;
      },
      watch: {
        "nuxt.err": "errorChanged"
      },
      computed: {
        isOffline() {
          return !this.isOnline;
        },
        isFetching() {
          return this.nbFetching > 0;
        }
      },
      methods: {
        refreshOnlineStatus() {
        },
        async refresh() {
          const pages = getMatchedComponentsInstances(this.$route);
          if (!pages.length) {
            return;
          }
          this.$loading.start();
          const promises = pages.map((page) => {
            const p = [];
            if (page.$options.fetch && page.$options.fetch.length) {
              p.push(promisify(page.$options.fetch, this.context));
            }
            if (page.$fetch) {
              p.push(page.$fetch());
            } else {
              for (const component of getChildrenComponentInstancesUsingFetch(page.$vnode.componentInstance)) {
                p.push(component.$fetch());
              }
            }
            if (page.$options.asyncData) {
              p.push(promisify(page.$options.asyncData, this.context).then((newData) => {
                for (const key in newData) {
                  vue2_bridge["default"].set(page.$data, key, newData[key]);
                }
              }));
            }
            return Promise.all(p);
          });
          try {
            await Promise.all(promises);
          } catch (error) {
            this.$loading.fail(error);
            globalHandleError(error);
            this.error(error);
          }
          this.$loading.finish();
        },
        errorChanged() {
          if (this.nuxt.err) {
            if (this.$loading) {
              if (this.$loading.fail) {
                this.$loading.fail(this.nuxt.err);
              }
              if (this.$loading.finish) {
                this.$loading.finish();
              }
            }
            let errorLayout = (layouts_error.options || layouts_error).layout;
            if (typeof errorLayout === "function") {
              errorLayout = errorLayout(this.context);
            }
            this.setLayout(errorLayout);
          }
        },
        setLayout(layout) {
          if (!layout || !layouts["_" + layout]) {
            layout = "default";
          }
          this.layoutName = layout;
          this.layout = layouts["_" + layout];
          return this.layout;
        },
        loadLayout(layout) {
          if (!layout || !layouts["_" + layout]) {
            layout = "default";
          }
          return Promise.resolve(layouts["_" + layout]);
        }
      },
      components: {
        NuxtLoading: LoadingBar["default"]
      }
    };
    const AdvisoryCards = () => __webpack_require__.e(1).then(__webpack_require__.bind(null, 153)).then((c) => wrapFunctional(c.default || c));
    const Banner = () => __webpack_require__.e(2).then(__webpack_require__.bind(null, 155)).then((c) => wrapFunctional(c.default || c));
    const BannerState = () => __webpack_require__.e(3).then(__webpack_require__.bind(null, 130)).then((c) => wrapFunctional(c.default || c));
    const ContactInfoItem = () => __webpack_require__.e(4).then(__webpack_require__.bind(null, 149)).then((c) => wrapFunctional(c.default || c));
    const Filters = () => __webpack_require__.e(5).then(__webpack_require__.bind(null, 150)).then((c) => wrapFunctional(c.default || c));
    const Footer = () => Promise.resolve().then(__webpack_require__.bind(null, 44)).then((c) => wrapFunctional(c.default || c));
    const FounderCards = () => __webpack_require__.e(6).then(__webpack_require__.bind(null, 151)).then((c) => wrapFunctional(c.default || c));
    const Header = () => Promise.resolve().then(__webpack_require__.bind(null, 43)).then((c) => wrapFunctional(c.default || c));
    const LanguageInput = () => Promise.resolve().then(__webpack_require__.bind(null, 73)).then((c) => wrapFunctional(c.default || c));
    const components_LoadingBar = () => Promise.resolve().then(__webpack_require__.bind(null, 70)).then((c) => wrapFunctional(c.default || c));
    const Modal = () => __webpack_require__.e(7).then(__webpack_require__.bind(null, 154)).then((c) => wrapFunctional(c.default || c));
    const NuxtLogo = () => __webpack_require__.e(8).then(__webpack_require__.bind(null, 180)).then((c) => wrapFunctional(c.default || c));
    const TeamCard = () => __webpack_require__.e(9).then(__webpack_require__.bind(null, 103)).then((c) => wrapFunctional(c.default || c));
    const TeamCards = () => __webpack_require__.e(10).then(__webpack_require__.bind(null, 152)).then((c) => wrapFunctional(c.default || c));
    const TopHeading = () => __webpack_require__.e(11).then(__webpack_require__.bind(null, 127)).then((c) => wrapFunctional(c.default || c));
    const Tutorial = () => __webpack_require__.e(12).then(__webpack_require__.bind(null, 178)).then((c) => wrapFunctional(c.default || c));
    function wrapFunctional(options2) {
      if (!options2 || !options2.functional) {
        return options2;
      }
      const propKeys = Array.isArray(options2.props) ? options2.props : Object.keys(options2.props || {});
      return {
        render(h) {
          const attrs = {};
          const props = {};
          for (const key in this.$attrs) {
            if (propKeys.includes(key)) {
              props[key] = this.$attrs[key];
            } else {
              attrs[key] = this.$attrs[key];
            }
          }
          return h(options2, {
            on: this.$listeners,
            attrs,
            props,
            scopedSlots: this.$scopedSlots
          }, this.$slots.default);
        }
      };
    }
    for (const name in components_namespaceObject) {
      vue2_bridge["default"].component(name, components_namespaceObject[name]);
      vue2_bridge["default"].component("Lazy" + name, components_namespaceObject[name]);
    }
    var external_hookable_ = __webpack_require__(69);
    var runtime = __webpack_require__(6);
    function proxiedState(state) {
      state._asyncData = state._asyncData || {};
      state._errors = state._errors || {};
      return new Proxy(state, {
        get(target, prop) {
          if (prop === "data") {
            return target._asyncData;
          }
          if (prop === "_data") {
            return target.state;
          }
          return Reflect.get(target, prop);
        }
      });
    }
    var runtime_app_plugin_e394a3b6 = (ctx, inject) => {
      const nuxtApp = {
        vueApp: {
          component: vue2_bridge["default"].component.bind(vue2_bridge["default"]),
          config: {
            globalProperties: {}
          },
          directive: vue2_bridge["default"].directive.bind(vue2_bridge["default"]),
          mixin: vue2_bridge["default"].mixin.bind(vue2_bridge["default"]),
          mount: () => {
          },
          provide: inject,
          unmount: () => {
          },
          use(vuePlugin) {
            vuePlugin.install(this);
          },
          version: vue2_bridge["default"].version
        },
        provide: inject,
        globalName: "nuxt",
        payload: proxiedState(ctx.ssrContext.nuxt),
        _asyncDataPromises: [],
        isHydrating: true,
        nuxt2Context: ctx
      };
      nuxtApp.hooks = Object(external_hookable_["createHooks"])();
      nuxtApp.hook = nuxtApp.hooks.hook;
      nuxtApp.callHook = nuxtApp.hooks.callHook;
      if (!Array.isArray(ctx.app.created)) {
        ctx.app.created = [ctx.app.created].filter(Boolean);
      }
      if (!Array.isArray(ctx.app.mounted)) {
        ctx.app.mounted = [ctx.app.mounted].filter(Boolean);
      }
      {
        nuxtApp.ssrContext = ctx.ssrContext;
      }
      ctx.app.created.push(function() {
        nuxtApp.vue2App = this;
      });
      ctx.app.mounted.push(() => {
        nuxtApp.isHydrating = false;
      });
      const proxiedApp = new Proxy(nuxtApp, {
        get(target, prop) {
          if (prop[0] === "$") {
            var _target$vue2App;
            return target.nuxt2Context[prop] || ((_target$vue2App = target.vue2App) === null || _target$vue2App === void 0 ? void 0 : _target$vue2App[prop]);
          }
          return Reflect.get(target, prop);
        }
      });
      Object(runtime["b"])(proxiedApp);
      inject("_nuxtApp", proxiedApp);
    };
    function isHTTPS(req, trustProxy = true) {
      const _xForwardedProto = trustProxy && req.headers ? req.headers["x-forwarded-proto"] : void 0;
      const protoCheck = typeof _xForwardedProto === "string" ? _xForwardedProto.includes("https") : void 0;
      if (protoCheck) {
        return true;
      }
      const _encrypted = req.connection ? req.connection.encrypted : void 0;
      const encryptedCheck = _encrypted !== void 0 ? _encrypted === true : void 0;
      if (encryptedCheck) {
        return true;
      }
      if (protoCheck === void 0 && encryptedCheck === void 0) {
        return void 0;
      }
      return false;
    }
    var dist = isHTTPS;
    const Constants = {
      COMPONENT_OPTIONS_KEY: "nuxtI18n",
      STRATEGIES: {
        "PREFIX": "prefix",
        "PREFIX_EXCEPT_DEFAULT": "prefix_except_default",
        "PREFIX_AND_DEFAULT": "prefix_and_default",
        "NO_PREFIX": "no_prefix"
      }
    };
    const options = {
      vueI18n: {
        "locale": "en",
        "fallbackLocale": "en",
        "messages": {
          "en": {
            "message": "Hello!"
          },
          "fr": {
            "message": "Bonjour"
          },
          "kr": {
            "message": "\uC548\uB155\uD558\uC138\uC694!"
          }
        }
      },
      vueI18nLoader: true,
      locales: [{
        "code": "en",
        "name": "EN"
      }, {
        "code": "fr",
        "name": "FR"
      }, {
        "code": "kr",
        "name": "KO"
      }],
      defaultLocale: "en",
      defaultDirection: "ltr",
      routesNameSeparator: "___",
      defaultLocaleRouteNameSuffix: "default",
      sortRoutes: true,
      strategy: "prefix_except_default",
      lazy: false,
      langDir: null,
      rootRedirect: null,
      detectBrowserLanguage: {
        "alwaysRedirect": false,
        "cookieCrossOrigin": false,
        "cookieDomain": null,
        "cookieKey": "i18n_redirected",
        "cookieSecure": false,
        "fallbackLocale": "",
        "onlyOnNoPrefix": false,
        "onlyOnRoot": false,
        "useCookie": true
      },
      differentDomains: false,
      seo: false,
      baseUrl: "",
      vuex: {
        "moduleName": "i18n",
        "syncLocale": false,
        "syncMessages": false,
        "syncRouteParams": true
      },
      parsePages: true,
      pages: {},
      skipSettingLocaleOnNavigate: false,
      beforeLanguageSwitch: () => null,
      onBeforeLanguageSwitch: () => {
      },
      onLanguageSwitched: () => null,
      normalizedLocales: [{
        "code": "en",
        "name": "EN"
      }, {
        "code": "fr",
        "name": "FR"
      }, {
        "code": "kr",
        "name": "KO"
      }],
      localeCodes: ["en", "fr", "kr"]
    };
    var external_cookie_ = __webpack_require__(42);
    var external_cookie_default = /* @__PURE__ */ __webpack_require__.n(external_cookie_);
    __webpack_require__(97);
    function formatMessage(text) {
      return `[nuxt-i18n] ${text}`;
    }
    function parseAcceptLanguage(input) {
      return input.split(",").map((tag) => tag.split(";")[0]);
    }
    function matchBrowserLocale(appLocales, browserLocales) {
      const matchedLocales = [];
      const normalizedAppLocales = [];
      for (const appLocale of appLocales) {
        const {
          code
        } = appLocale;
        const iso = appLocale.iso || code;
        normalizedAppLocales.push({
          code,
          iso
        });
      }
      for (const [index, browserCode] of browserLocales.entries()) {
        const matchedLocale = normalizedAppLocales.find((appLocale) => appLocale.iso.toLowerCase() === browserCode.toLowerCase());
        if (matchedLocale) {
          matchedLocales.push({
            code: matchedLocale.code,
            score: 1 - index / browserLocales.length
          });
          break;
        }
      }
      for (const [index, browserCode] of browserLocales.entries()) {
        const languageCode = browserCode.split("-")[0].toLowerCase();
        const matchedLocale = normalizedAppLocales.find((appLocale) => appLocale.iso.split("-")[0].toLowerCase() === languageCode);
        if (matchedLocale) {
          matchedLocales.push({
            code: matchedLocale.code,
            score: 0.999 - index / browserLocales.length
          });
          break;
        }
      }
      if (matchedLocales.length > 1) {
        matchedLocales.sort((localeA, localeB) => {
          if (localeA.score === localeB.score) {
            return localeB.code.length - localeA.code.length;
          }
          return localeB.score - localeA.score;
        });
      }
      return matchedLocales.length ? matchedLocales[0].code : void 0;
    }
    function getLocaleDomain(locales, req) {
      let host;
      if (req) {
        const detectedHost = req.headers["x-forwarded-host"] || req.headers.host;
        host = Array.isArray(detectedHost) ? detectedHost[0] : detectedHost;
      }
      if (host) {
        const matchingLocale = locales.find((l) => l.domain === host);
        if (matchingLocale) {
          return matchingLocale.code;
        }
      }
      return "";
    }
    function getLocalesRegex(localeCodes) {
      return new RegExp(`^/(${localeCodes.join("|")})(?:/|$)`, "i");
    }
    function createLocaleFromRouteGetter(localeCodes, {
      routesNameSeparator,
      defaultLocaleRouteNameSuffix
    }) {
      const localesPattern = `(${localeCodes.join("|")})`;
      const defaultSuffixPattern = `(?:${routesNameSeparator}${defaultLocaleRouteNameSuffix})?`;
      const regexpName = new RegExp(`${routesNameSeparator}${localesPattern}${defaultSuffixPattern}$`, "i");
      const regexpPath = getLocalesRegex(localeCodes);
      const getLocaleFromRoute = (route) => {
        if (route.name) {
          const matches = route.name.match(regexpName);
          if (matches && matches.length > 1) {
            return matches[1];
          }
        } else if (route.path) {
          const matches = route.path.match(regexpPath);
          if (matches && matches.length > 1) {
            return matches[1];
          }
        }
        return "";
      };
      return getLocaleFromRoute;
    }
    function getLocaleCookie(req, {
      useCookie,
      cookieKey,
      localeCodes
    }) {
      if (useCookie) {
        let localeCode;
        if (req && typeof req.headers.cookie !== "undefined") {
          const cookies = req.headers && req.headers.cookie ? external_cookie_default.a.parse(req.headers.cookie) : {};
          localeCode = cookies[cookieKey];
        }
        if (localeCode && localeCodes.includes(localeCode)) {
          return localeCode;
        }
      }
    }
    function setLocaleCookie(locale, res, {
      useCookie,
      cookieDomain,
      cookieKey,
      cookieSecure,
      cookieCrossOrigin
    }) {
      if (!useCookie) {
        return;
      }
      const date = new Date();
      const cookieOptions = {
        expires: new Date(date.setDate(date.getDate() + 365)),
        path: "/",
        sameSite: cookieCrossOrigin ? "none" : "lax",
        secure: cookieCrossOrigin || cookieSecure
      };
      if (cookieDomain) {
        cookieOptions.domain = cookieDomain;
      }
      if (res) {
        let headers = res.getHeader("Set-Cookie") || [];
        if (!Array.isArray(headers)) {
          headers = [String(headers)];
        }
        const redirectCookie = external_cookie_default.a.serialize(cookieKey, locale, cookieOptions);
        headers.push(redirectCookie);
        res.setHeader("Set-Cookie", headers);
      }
    }
    var ufo_dist = __webpack_require__(21);
    async function loadLanguageAsync(context, locale) {
      const {
        app
      } = context;
      const {
        i18n
      } = app;
      if (!i18n.loadedLanguages) {
        i18n.loadedLanguages = [];
      }
      if (!i18n.loadedLanguages.includes(locale)) {
        const localeObject = options.normalizedLocales.find((l) => l.code === locale);
        if (localeObject) {
          const {
            file
          } = localeObject;
          if (file) ; else {
            console.warn(formatMessage(`Could not find lang file for locale ${locale}`));
          }
        } else {
          console.warn(formatMessage(`Attempted to load messages for non-existant locale code "${locale}"`));
        }
      }
    }
    function resolveBaseUrl(baseUrl, context, localeCode, {
      differentDomains,
      normalizedLocales
    }) {
      if (typeof baseUrl === "function") {
        return baseUrl(context);
      }
      if (differentDomains && localeCode) {
        const domain = getDomainFromLocale(localeCode, context.req, {
          normalizedLocales
        });
        if (domain) {
          return domain;
        }
      }
      return baseUrl;
    }
    function getDomainFromLocale(localeCode, req, {
      normalizedLocales
    }) {
      const lang = normalizedLocales.find((locale) => locale.code === localeCode);
      if (lang && lang.domain) {
        if (Object(ufo_dist["a"])(lang.domain)) {
          return lang.domain;
        }
        let protocol;
        {
          protocol = req && dist(req) ? "https" : "http";
        }
        return `${protocol}://${lang.domain}`;
      }
      console.warn(formatMessage(`Could not find domain name for locale ${localeCode}`));
    }
    function registerStore(store, vuex, localeCodes) {
      const storeModule = {
        namespaced: true,
        state: () => ({
          ...vuex.syncLocale ? {
            locale: ""
          } : {},
          ...vuex.syncMessages ? {
            messages: {}
          } : {},
          ...vuex.syncRouteParams ? {
            routeParams: {}
          } : {}
        }),
        actions: {
          ...vuex.syncLocale ? {
            setLocale({
              commit
            }, locale) {
              commit("setLocale", locale);
            }
          } : {},
          ...vuex.syncMessages ? {
            setMessages({
              commit
            }, messages) {
              commit("setMessages", messages);
            }
          } : {},
          ...vuex.syncRouteParams ? {
            setRouteParams({
              commit
            }, params) {
              commit("setRouteParams", params);
            }
          } : {}
        },
        mutations: {
          ...vuex.syncLocale ? {
            setLocale(state, locale) {
              state.locale = locale;
            }
          } : {},
          ...vuex.syncMessages ? {
            setMessages(state, messages) {
              state.messages = messages;
            }
          } : {},
          ...vuex.syncRouteParams ? {
            setRouteParams(state, params) {
              state.routeParams = params;
            }
          } : {}
        },
        getters: {
          ...vuex.syncRouteParams ? {
            localeRouteParams: ({
              routeParams
            }) => {
              const paramsGetter = (locale) => routeParams && routeParams[locale] || {};
              return paramsGetter;
            }
          } : {}
        }
      };
      store.registerModule(vuex.moduleName, storeModule, {
        preserveState: !!store.state[vuex.moduleName]
      });
    }
    async function syncVuex(store, locale = null, messages = null, vuex) {
      if (vuex && store) {
        if (locale !== null && vuex.syncLocale) {
          await store.dispatch(vuex.moduleName + "/setLocale", locale);
        }
        if (messages !== null && vuex.syncMessages) {
          await store.dispatch(vuex.moduleName + "/setMessages", messages);
        }
      }
    }
    const i18nMiddleware = async (context) => {
      const {
        app,
        isHMR
      } = context;
      if (isHMR) {
        return;
      }
      const [status, redirectPath, preserveQuery] = await app.i18n.__onNavigate(context.route);
      if (status && redirectPath) {
        const query = preserveQuery ? context.route.query : void 0;
        context.redirect(status, redirectPath, query);
      }
    };
    _nuxt_middleware.nuxti18n = i18nMiddleware;
    function plugin_routing_localePath(route, locale) {
      const localizedRoute = resolveRoute.call(this, route, locale);
      return localizedRoute ? localizedRoute.route.fullPath : "";
    }
    function localeRoute(route, locale) {
      const resolved = resolveRoute.call(this, route, locale);
      return resolved ? resolved.route : void 0;
    }
    function localeLocation(route, locale) {
      const resolved = resolveRoute.call(this, route, locale);
      return resolved ? resolved.location : void 0;
    }
    function resolveRoute(route, locale) {
      if (!route) {
        return;
      }
      const {
        i18n
      } = this;
      locale = locale || i18n.locale;
      if (!locale) {
        return;
      }
      if (typeof route === "string") {
        if (route[0] === "/") {
          route = {
            path: route
          };
        } else {
          route = {
            name: route
          };
        }
      }
      let localizedRoute = Object.assign({}, route);
      if (localizedRoute.path && !localizedRoute.name) {
        const resolvedRoute2 = this.router.resolve(localizedRoute).route;
        const resolvedRouteName = this.getRouteBaseName(resolvedRoute2);
        if (resolvedRouteName) {
          localizedRoute = {
            name: getLocaleRouteName(resolvedRouteName, locale),
            params: resolvedRoute2.params,
            query: resolvedRoute2.query,
            hash: resolvedRoute2.hash
          };
        } else {
          const isDefaultLocale = locale === options.defaultLocale;
          const isPrefixed = !(isDefaultLocale && [Constants.STRATEGIES.PREFIX_EXCEPT_DEFAULT, Constants.STRATEGIES.PREFIX_AND_DEFAULT].includes(options.strategy)) && !(options.strategy === Constants.STRATEGIES.NO_PREFIX) && !i18n.differentDomains;
          if (isPrefixed) {
            localizedRoute.path = `/${locale}${localizedRoute.path}`;
          }
          localizedRoute.path = Object(ufo_dist["c"])(localizedRoute.path, true);
        }
      } else {
        if (!localizedRoute.name && !localizedRoute.path) {
          localizedRoute.name = this.getRouteBaseName();
        }
        localizedRoute.name = getLocaleRouteName(localizedRoute.name, locale);
        const {
          params
        } = localizedRoute;
        if (params && params["0"] === void 0 && params.pathMatch) {
          params["0"] = params.pathMatch;
        }
      }
      const resolvedRoute = this.router.resolve(localizedRoute);
      if (resolvedRoute.route.name) {
        return resolvedRoute;
      }
      return this.router.resolve(route);
    }
    function switchLocalePath(locale) {
      const name = this.getRouteBaseName();
      if (!name) {
        return "";
      }
      const {
        i18n,
        route,
        store
      } = this;
      const {
        params,
        ...routeCopy
      } = route;
      let langSwitchParams = {};
      if (options.vuex && options.vuex.syncRouteParams && store) {
        langSwitchParams = store.getters[`${options.vuex.moduleName}/localeRouteParams`](locale);
      }
      const baseRoute = Object.assign({}, routeCopy, {
        name,
        params: {
          ...params,
          ...langSwitchParams,
          0: params.pathMatch
        }
      });
      let path = this.localePath(baseRoute, locale);
      if (i18n.differentDomains) {
        const getDomainOptions = {
          differentDomains: i18n.differentDomains,
          normalizedLocales: options.normalizedLocales
        };
        const domain = getDomainFromLocale(locale, this.req, getDomainOptions);
        if (domain) {
          path = domain + path;
        }
      }
      return path;
    }
    function getRouteBaseName(givenRoute) {
      const route = givenRoute !== void 0 ? givenRoute : this.route;
      if (!route || !route.name) {
        return;
      }
      return route.name.split(options.routesNameSeparator)[0];
    }
    function getLocaleRouteName(routeName, locale) {
      let name = routeName + (options.strategy === Constants.STRATEGIES.NO_PREFIX ? "" : options.routesNameSeparator + locale);
      if (locale === options.defaultLocale && options.strategy === Constants.STRATEGIES.PREFIX_AND_DEFAULT) {
        name += options.routesNameSeparator + options.defaultLocaleRouteNameSuffix;
      }
      return name;
    }
    const VueInstanceProxy = function(targetFunction) {
      return function() {
        const proxy = {
          getRouteBaseName: this.getRouteBaseName,
          i18n: this.$i18n,
          localePath: this.localePath,
          localeRoute: this.localeRoute,
          localeLocation: this.localeLocation,
          req: this.$ssrContext.req ,
          route: this.$route,
          router: this.$router,
          store: this.$store
        };
        return targetFunction.call(proxy, ...arguments);
      };
    };
    const NuxtContextProxy = function(context, targetFunction) {
      return function() {
        const {
          app,
          req,
          route,
          store
        } = context;
        const proxy = {
          getRouteBaseName: app.getRouteBaseName,
          i18n: app.i18n,
          localePath: app.localePath,
          localeLocation: app.localeLocation,
          localeRoute: app.localeRoute,
          req: req ,
          route,
          router: app.router,
          store
        };
        return targetFunction.call(proxy, ...arguments);
      };
    };
    const plugin_routing_plugin = {
      install(Vue2) {
        Vue2.mixin({
          methods: {
            localePath: VueInstanceProxy(plugin_routing_localePath),
            localeRoute: VueInstanceProxy(localeRoute),
            localeLocation: VueInstanceProxy(localeLocation),
            switchLocalePath: VueInstanceProxy(switchLocalePath),
            getRouteBaseName: VueInstanceProxy(getRouteBaseName)
          }
        });
      }
    };
    var plugin_routing = (context) => {
      vue2_bridge["default"].use(plugin_routing_plugin);
      const {
        app,
        store
      } = context;
      app.localePath = context.localePath = NuxtContextProxy(context, plugin_routing_localePath);
      app.localeRoute = context.localeRoute = NuxtContextProxy(context, localeRoute);
      app.localeLocation = context.localeLocation = NuxtContextProxy(context, localeLocation);
      app.switchLocalePath = context.switchLocalePath = NuxtContextProxy(context, switchLocalePath);
      app.getRouteBaseName = context.getRouteBaseName = NuxtContextProxy(context, getRouteBaseName);
      if (store) {
        store.localePath = app.localePath;
        store.localeRoute = app.localeRoute;
        store.localeLocation = app.localeLocation;
        store.switchLocalePath = app.switchLocalePath;
        store.getRouteBaseName = app.getRouteBaseName;
      }
    };
    __webpack_require__(25);
    __webpack_require__(26);
    __webpack_require__(27);
    __webpack_require__(28);
    __webpack_require__(29);
    __webpack_require__(30);
    __webpack_require__(31);
    __webpack_require__(32);
    __webpack_require__(33);
    __webpack_require__(34);
    __webpack_require__(35);
    __webpack_require__(36);
    __webpack_require__(37);
    __webpack_require__(38);
    __webpack_require__(39);
    __webpack_require__(40);
    /*!
     * vue-i18n v8.26.7 
     * (c) 2021 kazuya kawaguchi
     * Released under the MIT License.
     */
    var numberFormatKeys = ["compactDisplay", "currency", "currencyDisplay", "currencySign", "localeMatcher", "notation", "numberingSystem", "signDisplay", "style", "unit", "unitDisplay", "useGrouping", "minimumIntegerDigits", "minimumFractionDigits", "maximumFractionDigits", "minimumSignificantDigits", "maximumSignificantDigits"];
    function vue_i18n_esm_warn(msg, err) {
      if (typeof console !== "undefined") {
        console.warn("[vue-i18n] " + msg);
        if (err) {
          console.warn(err.stack);
        }
      }
    }
    function vue_i18n_esm_error(msg, err) {
      if (typeof console !== "undefined") {
        console.error("[vue-i18n] " + msg);
        if (err) {
          console.error(err.stack);
        }
      }
    }
    var isArray = Array.isArray;
    function vue_i18n_esm_isObject(obj) {
      return obj !== null && typeof obj === "object";
    }
    function isBoolean(val) {
      return typeof val === "boolean";
    }
    function isString(val) {
      return typeof val === "string";
    }
    var vue_i18n_esm_toString = Object.prototype.toString;
    var OBJECT_STRING = "[object Object]";
    function isPlainObject(obj) {
      return vue_i18n_esm_toString.call(obj) === OBJECT_STRING;
    }
    function isNull(val) {
      return val === null || val === void 0;
    }
    function isFunction(val) {
      return typeof val === "function";
    }
    function parseArgs() {
      var args = [], len = arguments.length;
      while (len--)
        args[len] = arguments[len];
      var locale = null;
      var params = null;
      if (args.length === 1) {
        if (vue_i18n_esm_isObject(args[0]) || isArray(args[0])) {
          params = args[0];
        } else if (typeof args[0] === "string") {
          locale = args[0];
        }
      } else if (args.length === 2) {
        if (typeof args[0] === "string") {
          locale = args[0];
        }
        if (vue_i18n_esm_isObject(args[1]) || isArray(args[1])) {
          params = args[1];
        }
      }
      return {
        locale,
        params
      };
    }
    function looseClone(obj) {
      return JSON.parse(JSON.stringify(obj));
    }
    function remove(arr, item) {
      if (arr.delete(item)) {
        return arr;
      }
    }
    function arrayFrom(arr) {
      var ret = [];
      arr.forEach(function(a) {
        return ret.push(a);
      });
      return ret;
    }
    function includes(arr, item) {
      return !!~arr.indexOf(item);
    }
    var vue_i18n_esm_hasOwnProperty = Object.prototype.hasOwnProperty;
    function hasOwn(obj, key) {
      return vue_i18n_esm_hasOwnProperty.call(obj, key);
    }
    function merge(target) {
      var arguments$1 = arguments;
      var output = Object(target);
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments$1[i];
        if (source !== void 0 && source !== null) {
          var key = void 0;
          for (key in source) {
            if (hasOwn(source, key)) {
              if (vue_i18n_esm_isObject(source[key])) {
                output[key] = merge(output[key], source[key]);
              } else {
                output[key] = source[key];
              }
            }
          }
        }
      }
      return output;
    }
    function looseEqual(a, b) {
      if (a === b) {
        return true;
      }
      var isObjectA = vue_i18n_esm_isObject(a);
      var isObjectB = vue_i18n_esm_isObject(b);
      if (isObjectA && isObjectB) {
        try {
          var isArrayA = isArray(a);
          var isArrayB = isArray(b);
          if (isArrayA && isArrayB) {
            return a.length === b.length && a.every(function(e, i) {
              return looseEqual(e, b[i]);
            });
          } else if (!isArrayA && !isArrayB) {
            var keysA = Object.keys(a);
            var keysB = Object.keys(b);
            return keysA.length === keysB.length && keysA.every(function(key) {
              return looseEqual(a[key], b[key]);
            });
          } else {
            return false;
          }
        } catch (e) {
          return false;
        }
      } else if (!isObjectA && !isObjectB) {
        return String(a) === String(b);
      } else {
        return false;
      }
    }
    function escapeHtml(rawText) {
      return rawText.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
    }
    function escapeParams(params) {
      if (params != null) {
        Object.keys(params).forEach(function(key) {
          if (typeof params[key] == "string") {
            params[key] = escapeHtml(params[key]);
          }
        });
      }
      return params;
    }
    function vue_i18n_esm_extend(Vue2) {
      if (!Vue2.prototype.hasOwnProperty("$i18n")) {
        Object.defineProperty(Vue2.prototype, "$i18n", {
          get: function get() {
            return this._i18n;
          }
        });
      }
      Vue2.prototype.$t = function(key) {
        var values = [], len = arguments.length - 1;
        while (len-- > 0)
          values[len] = arguments[len + 1];
        var i18n = this.$i18n;
        return i18n._t.apply(i18n, [key, i18n.locale, i18n._getMessages(), this].concat(values));
      };
      Vue2.prototype.$tc = function(key, choice) {
        var values = [], len = arguments.length - 2;
        while (len-- > 0)
          values[len] = arguments[len + 2];
        var i18n = this.$i18n;
        return i18n._tc.apply(i18n, [key, i18n.locale, i18n._getMessages(), this, choice].concat(values));
      };
      Vue2.prototype.$te = function(key, locale) {
        var i18n = this.$i18n;
        return i18n._te(key, i18n.locale, i18n._getMessages(), locale);
      };
      Vue2.prototype.$d = function(value) {
        var ref;
        var args = [], len = arguments.length - 1;
        while (len-- > 0)
          args[len] = arguments[len + 1];
        return (ref = this.$i18n).d.apply(ref, [value].concat(args));
      };
      Vue2.prototype.$n = function(value) {
        var ref;
        var args = [], len = arguments.length - 1;
        while (len-- > 0)
          args[len] = arguments[len + 1];
        return (ref = this.$i18n).n.apply(ref, [value].concat(args));
      };
    }
    function defineMixin(bridge) {
      if (bridge === void 0)
        bridge = false;
      function mounted() {
        if (this !== this.$root && this.$options.__INTLIFY_META__ && this.$el) {
          this.$el.setAttribute("data-intlify", this.$options.__INTLIFY_META__);
        }
      }
      return bridge ? {
        mounted
      } : {
        beforeCreate: function beforeCreate() {
          var options2 = this.$options;
          options2.i18n = options2.i18n || (options2.__i18nBridge || options2.__i18n ? {} : null);
          if (options2.i18n) {
            if (options2.i18n instanceof VueI18n) {
              if (options2.__i18nBridge || options2.__i18n) {
                try {
                  var localeMessages2 = options2.i18n && options2.i18n.messages ? options2.i18n.messages : {};
                  var _i18n = options2.__i18nBridge || options2.__i18n;
                  _i18n.forEach(function(resource) {
                    localeMessages2 = merge(localeMessages2, JSON.parse(resource));
                  });
                  Object.keys(localeMessages2).forEach(function(locale) {
                    options2.i18n.mergeLocaleMessage(locale, localeMessages2[locale]);
                  });
                } catch (e) {
                }
              }
              this._i18n = options2.i18n;
              this._i18nWatcher = this._i18n.watchI18nData();
            } else if (isPlainObject(options2.i18n)) {
              var rootI18n = this.$root && this.$root.$i18n && this.$root.$i18n instanceof VueI18n ? this.$root.$i18n : null;
              if (rootI18n) {
                options2.i18n.root = this.$root;
                options2.i18n.formatter = rootI18n.formatter;
                options2.i18n.fallbackLocale = rootI18n.fallbackLocale;
                options2.i18n.formatFallbackMessages = rootI18n.formatFallbackMessages;
                options2.i18n.silentTranslationWarn = rootI18n.silentTranslationWarn;
                options2.i18n.silentFallbackWarn = rootI18n.silentFallbackWarn;
                options2.i18n.pluralizationRules = rootI18n.pluralizationRules;
                options2.i18n.preserveDirectiveContent = rootI18n.preserveDirectiveContent;
              }
              if (options2.__i18nBridge || options2.__i18n) {
                try {
                  var localeMessages$1 = options2.i18n && options2.i18n.messages ? options2.i18n.messages : {};
                  var _i18n$1 = options2.__i18nBridge || options2.__i18n;
                  _i18n$1.forEach(function(resource) {
                    localeMessages$1 = merge(localeMessages$1, JSON.parse(resource));
                  });
                  options2.i18n.messages = localeMessages$1;
                } catch (e) {
                }
              }
              var ref = options2.i18n;
              var sharedMessages = ref.sharedMessages;
              if (sharedMessages && isPlainObject(sharedMessages)) {
                options2.i18n.messages = merge(options2.i18n.messages, sharedMessages);
              }
              this._i18n = new VueI18n(options2.i18n);
              this._i18nWatcher = this._i18n.watchI18nData();
              if (options2.i18n.sync === void 0 || !!options2.i18n.sync) {
                this._localeWatcher = this.$i18n.watchLocale();
              }
              if (rootI18n) {
                rootI18n.onComponentInstanceCreated(this._i18n);
              }
            } else ;
          } else if (this.$root && this.$root.$i18n && this.$root.$i18n instanceof VueI18n) {
            this._i18n = this.$root.$i18n;
          } else if (options2.parent && options2.parent.$i18n && options2.parent.$i18n instanceof VueI18n) {
            this._i18n = options2.parent.$i18n;
          }
        },
        beforeMount: function beforeMount() {
          var options2 = this.$options;
          options2.i18n = options2.i18n || (options2.__i18nBridge || options2.__i18n ? {} : null);
          if (options2.i18n) {
            if (options2.i18n instanceof VueI18n) {
              this._i18n.subscribeDataChanging(this);
              this._subscribing = true;
            } else if (isPlainObject(options2.i18n)) {
              this._i18n.subscribeDataChanging(this);
              this._subscribing = true;
            } else ;
          } else if (this.$root && this.$root.$i18n && this.$root.$i18n instanceof VueI18n) {
            this._i18n.subscribeDataChanging(this);
            this._subscribing = true;
          } else if (options2.parent && options2.parent.$i18n && options2.parent.$i18n instanceof VueI18n) {
            this._i18n.subscribeDataChanging(this);
            this._subscribing = true;
          }
        },
        mounted,
        beforeDestroy: function beforeDestroy() {
          if (!this._i18n) {
            return;
          }
          var self = this;
          this.$nextTick(function() {
            if (self._subscribing) {
              self._i18n.unsubscribeDataChanging(self);
              delete self._subscribing;
            }
            if (self._i18nWatcher) {
              self._i18nWatcher();
              self._i18n.destroyVM();
              delete self._i18nWatcher;
            }
            if (self._localeWatcher) {
              self._localeWatcher();
              delete self._localeWatcher;
            }
          });
        }
      };
    }
    var interpolationComponent = {
      name: "i18n",
      functional: true,
      props: {
        tag: {
          type: [String, Boolean, Object],
          default: "span"
        },
        path: {
          type: String,
          required: true
        },
        locale: {
          type: String
        },
        places: {
          type: [Array, Object]
        }
      },
      render: function render2(h, ref) {
        var data = ref.data;
        var parent = ref.parent;
        var props = ref.props;
        var slots = ref.slots;
        var $i18n = parent.$i18n;
        if (!$i18n) {
          return;
        }
        var path = props.path;
        var locale = props.locale;
        var places = props.places;
        var params = slots();
        var children = $i18n.i(path, locale, onlyHasDefaultPlace(params) || places ? useLegacyPlaces(params.default, places) : params);
        var tag = !!props.tag && props.tag !== true || props.tag === false ? props.tag : "span";
        return tag ? h(tag, data, children) : children;
      }
    };
    function onlyHasDefaultPlace(params) {
      var prop;
      for (prop in params) {
        if (prop !== "default") {
          return false;
        }
      }
      return Boolean(prop);
    }
    function useLegacyPlaces(children, places) {
      var params = places ? createParamsFromPlaces(places) : {};
      if (!children) {
        return params;
      }
      children = children.filter(function(child) {
        return child.tag || child.text.trim() !== "";
      });
      var everyPlace = children.every(vnodeHasPlaceAttribute);
      return children.reduce(everyPlace ? assignChildPlace : assignChildIndex, params);
    }
    function createParamsFromPlaces(places) {
      return Array.isArray(places) ? places.reduce(assignChildIndex, {}) : Object.assign({}, places);
    }
    function assignChildPlace(params, child) {
      if (child.data && child.data.attrs && child.data.attrs.place) {
        params[child.data.attrs.place] = child;
      }
      return params;
    }
    function assignChildIndex(params, child, index) {
      params[index] = child;
      return params;
    }
    function vnodeHasPlaceAttribute(vnode) {
      return Boolean(vnode.data && vnode.data.attrs && vnode.data.attrs.place);
    }
    var numberComponent = {
      name: "i18n-n",
      functional: true,
      props: {
        tag: {
          type: [String, Boolean, Object],
          default: "span"
        },
        value: {
          type: Number,
          required: true
        },
        format: {
          type: [String, Object]
        },
        locale: {
          type: String
        }
      },
      render: function render2(h, ref) {
        var props = ref.props;
        var parent = ref.parent;
        var data = ref.data;
        var i18n = parent.$i18n;
        if (!i18n) {
          return null;
        }
        var key = null;
        var options2 = null;
        if (isString(props.format)) {
          key = props.format;
        } else if (vue_i18n_esm_isObject(props.format)) {
          if (props.format.key) {
            key = props.format.key;
          }
          options2 = Object.keys(props.format).reduce(function(acc, prop) {
            var obj;
            if (includes(numberFormatKeys, prop)) {
              return Object.assign({}, acc, (obj = {}, obj[prop] = props.format[prop], obj));
            }
            return acc;
          }, null);
        }
        var locale = props.locale || i18n.locale;
        var parts = i18n._ntp(props.value, locale, key, options2);
        var values = parts.map(function(part, index) {
          var obj;
          var slot = data.scopedSlots && data.scopedSlots[part.type];
          return slot ? slot((obj = {}, obj[part.type] = part.value, obj.index = index, obj.parts = parts, obj)) : part.value;
        });
        var tag = !!props.tag && props.tag !== true || props.tag === false ? props.tag : "span";
        return tag ? h(tag, {
          attrs: data.attrs,
          "class": data["class"],
          staticClass: data.staticClass
        }, values) : values;
      }
    };
    function bind(el, binding, vnode) {
      if (!vue_i18n_esm_assert(el, vnode)) {
        return;
      }
      t(el, binding, vnode);
    }
    function update(el, binding, vnode, oldVNode) {
      if (!vue_i18n_esm_assert(el, vnode)) {
        return;
      }
      var i18n = vnode.context.$i18n;
      if (localeEqual(el, vnode) && looseEqual(binding.value, binding.oldValue) && looseEqual(el._localeMessage, i18n.getLocaleMessage(i18n.locale))) {
        return;
      }
      t(el, binding, vnode);
    }
    function unbind(el, binding, vnode, oldVNode) {
      var vm = vnode.context;
      if (!vm) {
        vue_i18n_esm_warn("Vue instance does not exists in VNode context");
        return;
      }
      var i18n = vnode.context.$i18n || {};
      if (!binding.modifiers.preserve && !i18n.preserveDirectiveContent) {
        el.textContent = "";
      }
      el._vt = void 0;
      delete el["_vt"];
      el._locale = void 0;
      delete el["_locale"];
      el._localeMessage = void 0;
      delete el["_localeMessage"];
    }
    function vue_i18n_esm_assert(el, vnode) {
      var vm = vnode.context;
      if (!vm) {
        vue_i18n_esm_warn("Vue instance does not exists in VNode context");
        return false;
      }
      if (!vm.$i18n) {
        vue_i18n_esm_warn("VueI18n instance does not exists in Vue instance");
        return false;
      }
      return true;
    }
    function localeEqual(el, vnode) {
      var vm = vnode.context;
      return el._locale === vm.$i18n.locale;
    }
    function t(el, binding, vnode) {
      var ref$1, ref$2;
      var value = binding.value;
      var ref = parseValue(value);
      var path = ref.path;
      var locale = ref.locale;
      var args = ref.args;
      var choice = ref.choice;
      if (!path && !locale && !args) {
        vue_i18n_esm_warn("value type not supported");
        return;
      }
      if (!path) {
        vue_i18n_esm_warn("`path` is required in v-t directive");
        return;
      }
      var vm = vnode.context;
      if (choice != null) {
        el._vt = el.textContent = (ref$1 = vm.$i18n).tc.apply(ref$1, [path, choice].concat(makeParams(locale, args)));
      } else {
        el._vt = el.textContent = (ref$2 = vm.$i18n).t.apply(ref$2, [path].concat(makeParams(locale, args)));
      }
      el._locale = vm.$i18n.locale;
      el._localeMessage = vm.$i18n.getLocaleMessage(vm.$i18n.locale);
    }
    function parseValue(value) {
      var path;
      var locale;
      var args;
      var choice;
      if (isString(value)) {
        path = value;
      } else if (isPlainObject(value)) {
        path = value.path;
        locale = value.locale;
        args = value.args;
        choice = value.choice;
      }
      return {
        path,
        locale,
        args,
        choice
      };
    }
    function makeParams(locale, args) {
      var params = [];
      locale && params.push(locale);
      if (args && (Array.isArray(args) || isPlainObject(args))) {
        params.push(args);
      }
      return params;
    }
    var Vue;
    function vue_i18n_esm_install(_Vue2, options2) {
      if (options2 === void 0)
        options2 = {
          bridge: false
        };
      vue_i18n_esm_install.installed = true;
      Vue = _Vue2;
      Vue.version && Number(Vue.version.split(".")[0]) || -1;
      vue_i18n_esm_extend(Vue);
      Vue.mixin(defineMixin(options2.bridge));
      Vue.directive("t", {
        bind,
        update,
        unbind
      });
      Vue.component(interpolationComponent.name, interpolationComponent);
      Vue.component(numberComponent.name, numberComponent);
      var strats = Vue.config.optionMergeStrategies;
      strats.i18n = function(parentVal, childVal) {
        return childVal === void 0 ? parentVal : childVal;
      };
    }
    var BaseFormatter = function BaseFormatter2() {
      this._caches = Object.create(null);
    };
    BaseFormatter.prototype.interpolate = function interpolate(message, values) {
      if (!values) {
        return [message];
      }
      var tokens = this._caches[message];
      if (!tokens) {
        tokens = vue_i18n_esm_parse(message);
        this._caches[message] = tokens;
      }
      return vue_i18n_esm_compile(tokens, values);
    };
    var RE_TOKEN_LIST_VALUE = /^(?:\d)+/;
    var RE_TOKEN_NAMED_VALUE = /^(?:\w)+/;
    function vue_i18n_esm_parse(format) {
      var tokens = [];
      var position = 0;
      var text = "";
      while (position < format.length) {
        var char = format[position++];
        if (char === "{") {
          if (text) {
            tokens.push({
              type: "text",
              value: text
            });
          }
          text = "";
          var sub = "";
          char = format[position++];
          while (char !== void 0 && char !== "}") {
            sub += char;
            char = format[position++];
          }
          var isClosed = char === "}";
          var type = RE_TOKEN_LIST_VALUE.test(sub) ? "list" : isClosed && RE_TOKEN_NAMED_VALUE.test(sub) ? "named" : "unknown";
          tokens.push({
            value: sub,
            type
          });
        } else if (char === "%") {
          if (format[position] !== "{") {
            text += char;
          }
        } else {
          text += char;
        }
      }
      text && tokens.push({
        type: "text",
        value: text
      });
      return tokens;
    }
    function vue_i18n_esm_compile(tokens, values) {
      var compiled = [];
      var index = 0;
      var mode = Array.isArray(values) ? "list" : vue_i18n_esm_isObject(values) ? "named" : "unknown";
      if (mode === "unknown") {
        return compiled;
      }
      while (index < tokens.length) {
        var token = tokens[index];
        switch (token.type) {
          case "text":
            compiled.push(token.value);
            break;
          case "list":
            compiled.push(values[parseInt(token.value, 10)]);
            break;
          case "named":
            if (mode === "named") {
              compiled.push(values[token.value]);
            }
            break;
        }
        index++;
      }
      return compiled;
    }
    var APPEND = 0;
    var PUSH = 1;
    var INC_SUB_PATH_DEPTH = 2;
    var PUSH_SUB_PATH = 3;
    var BEFORE_PATH = 0;
    var IN_PATH = 1;
    var BEFORE_IDENT = 2;
    var IN_IDENT = 3;
    var IN_SUB_PATH = 4;
    var IN_SINGLE_QUOTE = 5;
    var IN_DOUBLE_QUOTE = 6;
    var AFTER_PATH = 7;
    var ERROR = 8;
    var pathStateMachine = [];
    pathStateMachine[BEFORE_PATH] = {
      "ws": [BEFORE_PATH],
      "ident": [IN_IDENT, APPEND],
      "[": [IN_SUB_PATH],
      "eof": [AFTER_PATH]
    };
    pathStateMachine[IN_PATH] = {
      "ws": [IN_PATH],
      ".": [BEFORE_IDENT],
      "[": [IN_SUB_PATH],
      "eof": [AFTER_PATH]
    };
    pathStateMachine[BEFORE_IDENT] = {
      "ws": [BEFORE_IDENT],
      "ident": [IN_IDENT, APPEND],
      "0": [IN_IDENT, APPEND],
      "number": [IN_IDENT, APPEND]
    };
    pathStateMachine[IN_IDENT] = {
      "ident": [IN_IDENT, APPEND],
      "0": [IN_IDENT, APPEND],
      "number": [IN_IDENT, APPEND],
      "ws": [IN_PATH, PUSH],
      ".": [BEFORE_IDENT, PUSH],
      "[": [IN_SUB_PATH, PUSH],
      "eof": [AFTER_PATH, PUSH]
    };
    pathStateMachine[IN_SUB_PATH] = {
      "'": [IN_SINGLE_QUOTE, APPEND],
      '"': [IN_DOUBLE_QUOTE, APPEND],
      "[": [IN_SUB_PATH, INC_SUB_PATH_DEPTH],
      "]": [IN_PATH, PUSH_SUB_PATH],
      "eof": ERROR,
      "else": [IN_SUB_PATH, APPEND]
    };
    pathStateMachine[IN_SINGLE_QUOTE] = {
      "'": [IN_SUB_PATH, APPEND],
      "eof": ERROR,
      "else": [IN_SINGLE_QUOTE, APPEND]
    };
    pathStateMachine[IN_DOUBLE_QUOTE] = {
      '"': [IN_SUB_PATH, APPEND],
      "eof": ERROR,
      "else": [IN_DOUBLE_QUOTE, APPEND]
    };
    var literalValueRE = /^\s?(?:true|false|-?[\d.]+|'[^']*'|"[^"]*")\s?$/;
    function isLiteral(exp) {
      return literalValueRE.test(exp);
    }
    function stripQuotes(str) {
      var a = str.charCodeAt(0);
      var b = str.charCodeAt(str.length - 1);
      return a === b && (a === 34 || a === 39) ? str.slice(1, -1) : str;
    }
    function getPathCharType(ch) {
      if (ch === void 0 || ch === null) {
        return "eof";
      }
      var code = ch.charCodeAt(0);
      switch (code) {
        case 91:
        case 93:
        case 46:
        case 34:
        case 39:
          return ch;
        case 95:
        case 36:
        case 45:
          return "ident";
        case 9:
        case 10:
        case 13:
        case 160:
        case 65279:
        case 8232:
        case 8233:
          return "ws";
      }
      return "ident";
    }
    function formatSubPath(path) {
      var trimmed = path.trim();
      if (path.charAt(0) === "0" && isNaN(path)) {
        return false;
      }
      return isLiteral(trimmed) ? stripQuotes(trimmed) : "*" + trimmed;
    }
    function parse$1(path) {
      var keys = [];
      var index = -1;
      var mode = BEFORE_PATH;
      var subPathDepth = 0;
      var c;
      var key;
      var newChar;
      var type;
      var transition;
      var action;
      var typeMap;
      var actions = [];
      actions[PUSH] = function() {
        if (key !== void 0) {
          keys.push(key);
          key = void 0;
        }
      };
      actions[APPEND] = function() {
        if (key === void 0) {
          key = newChar;
        } else {
          key += newChar;
        }
      };
      actions[INC_SUB_PATH_DEPTH] = function() {
        actions[APPEND]();
        subPathDepth++;
      };
      actions[PUSH_SUB_PATH] = function() {
        if (subPathDepth > 0) {
          subPathDepth--;
          mode = IN_SUB_PATH;
          actions[APPEND]();
        } else {
          subPathDepth = 0;
          if (key === void 0) {
            return false;
          }
          key = formatSubPath(key);
          if (key === false) {
            return false;
          } else {
            actions[PUSH]();
          }
        }
      };
      function maybeUnescapeQuote() {
        var nextChar = path[index + 1];
        if (mode === IN_SINGLE_QUOTE && nextChar === "'" || mode === IN_DOUBLE_QUOTE && nextChar === '"') {
          index++;
          newChar = "\\" + nextChar;
          actions[APPEND]();
          return true;
        }
      }
      while (mode !== null) {
        index++;
        c = path[index];
        if (c === "\\" && maybeUnescapeQuote()) {
          continue;
        }
        type = getPathCharType(c);
        typeMap = pathStateMachine[mode];
        transition = typeMap[type] || typeMap["else"] || ERROR;
        if (transition === ERROR) {
          return;
        }
        mode = transition[0];
        action = actions[transition[1]];
        if (action) {
          newChar = transition[2];
          newChar = newChar === void 0 ? c : newChar;
          if (action() === false) {
            return;
          }
        }
        if (mode === AFTER_PATH) {
          return keys;
        }
      }
    }
    var I18nPath = function I18nPath2() {
      this._cache = Object.create(null);
    };
    I18nPath.prototype.parsePath = function parsePath2(path) {
      var hit = this._cache[path];
      if (!hit) {
        hit = parse$1(path);
        if (hit) {
          this._cache[path] = hit;
        }
      }
      return hit || [];
    };
    I18nPath.prototype.getPathValue = function getPathValue(obj, path) {
      if (!vue_i18n_esm_isObject(obj)) {
        return null;
      }
      var paths = this.parsePath(path);
      if (paths.length === 0) {
        return null;
      } else {
        var length = paths.length;
        var last = obj;
        var i = 0;
        while (i < length) {
          var value = last[paths[i]];
          if (value === void 0 || value === null) {
            return null;
          }
          last = value;
          i++;
        }
        return last;
      }
    };
    var htmlTagMatcher = /<\/?[\w\s="/.':;#-\/]+>/;
    var linkKeyMatcher = /(?:@(?:\.[a-z]+)?:(?:[\w\-_|./]+|\([\w\-_|./]+\)))/g;
    var linkKeyPrefixMatcher = /^@(?:\.([a-z]+))?:/;
    var bracketsMatcher = /[()]/g;
    var defaultModifiers = {
      "upper": function(str) {
        return str.toLocaleUpperCase();
      },
      "lower": function(str) {
        return str.toLocaleLowerCase();
      },
      "capitalize": function(str) {
        return "" + str.charAt(0).toLocaleUpperCase() + str.substr(1);
      }
    };
    var defaultFormatter = new BaseFormatter();
    var VueI18n = function VueI18n2(options2) {
      var this$1$1 = this;
      if (options2 === void 0)
        options2 = {};
      if (!Vue && false) {
        vue_i18n_esm_install(window.Vue);
      }
      var locale = options2.locale || "en-US";
      var fallbackLocale = options2.fallbackLocale === false ? false : options2.fallbackLocale || "en-US";
      var messages = options2.messages || {};
      var dateTimeFormats = options2.dateTimeFormats || options2.datetimeFormats || {};
      var numberFormats = options2.numberFormats || {};
      this._vm = null;
      this._formatter = options2.formatter || defaultFormatter;
      this._modifiers = options2.modifiers || {};
      this._missing = options2.missing || null;
      this._root = options2.root || null;
      this._sync = options2.sync === void 0 ? true : !!options2.sync;
      this._fallbackRoot = options2.fallbackRoot === void 0 ? true : !!options2.fallbackRoot;
      this._formatFallbackMessages = options2.formatFallbackMessages === void 0 ? false : !!options2.formatFallbackMessages;
      this._silentTranslationWarn = options2.silentTranslationWarn === void 0 ? false : options2.silentTranslationWarn;
      this._silentFallbackWarn = options2.silentFallbackWarn === void 0 ? false : !!options2.silentFallbackWarn;
      this._dateTimeFormatters = {};
      this._numberFormatters = {};
      this._path = new I18nPath();
      this._dataListeners = /* @__PURE__ */ new Set();
      this._componentInstanceCreatedListener = options2.componentInstanceCreatedListener || null;
      this._preserveDirectiveContent = options2.preserveDirectiveContent === void 0 ? false : !!options2.preserveDirectiveContent;
      this.pluralizationRules = options2.pluralizationRules || {};
      this._warnHtmlInMessage = options2.warnHtmlInMessage || "off";
      this._postTranslation = options2.postTranslation || null;
      this._escapeParameterHtml = options2.escapeParameterHtml || false;
      if ("__VUE_I18N_BRIDGE__" in options2) {
        this.__VUE_I18N_BRIDGE__ = options2.__VUE_I18N_BRIDGE__;
      }
      this.getChoiceIndex = function(choice, choicesLength) {
        var thisPrototype = Object.getPrototypeOf(this$1$1);
        if (thisPrototype && thisPrototype.getChoiceIndex) {
          var prototypeGetChoiceIndex = thisPrototype.getChoiceIndex;
          return prototypeGetChoiceIndex.call(this$1$1, choice, choicesLength);
        }
        var defaultImpl = function(_choice, _choicesLength) {
          _choice = Math.abs(_choice);
          if (_choicesLength === 2) {
            return _choice ? _choice > 1 ? 1 : 0 : 1;
          }
          return _choice ? Math.min(_choice, 2) : 0;
        };
        if (this$1$1.locale in this$1$1.pluralizationRules) {
          return this$1$1.pluralizationRules[this$1$1.locale].apply(this$1$1, [choice, choicesLength]);
        } else {
          return defaultImpl(choice, choicesLength);
        }
      };
      this._exist = function(message, key) {
        if (!message || !key) {
          return false;
        }
        if (!isNull(this$1$1._path.getPathValue(message, key))) {
          return true;
        }
        if (message[key]) {
          return true;
        }
        return false;
      };
      if (this._warnHtmlInMessage === "warn" || this._warnHtmlInMessage === "error") {
        Object.keys(messages).forEach(function(locale2) {
          this$1$1._checkLocaleMessage(locale2, this$1$1._warnHtmlInMessage, messages[locale2]);
        });
      }
      this._initVM({
        locale,
        fallbackLocale,
        messages,
        dateTimeFormats,
        numberFormats
      });
    };
    var vue_i18n_esm_prototypeAccessors = {
      vm: {
        configurable: true
      },
      messages: {
        configurable: true
      },
      dateTimeFormats: {
        configurable: true
      },
      numberFormats: {
        configurable: true
      },
      availableLocales: {
        configurable: true
      },
      locale: {
        configurable: true
      },
      fallbackLocale: {
        configurable: true
      },
      formatFallbackMessages: {
        configurable: true
      },
      missing: {
        configurable: true
      },
      formatter: {
        configurable: true
      },
      silentTranslationWarn: {
        configurable: true
      },
      silentFallbackWarn: {
        configurable: true
      },
      preserveDirectiveContent: {
        configurable: true
      },
      warnHtmlInMessage: {
        configurable: true
      },
      postTranslation: {
        configurable: true
      },
      sync: {
        configurable: true
      }
    };
    VueI18n.prototype._checkLocaleMessage = function _checkLocaleMessage(locale, level, message) {
      var paths = [];
      var fn = function(level2, locale2, message2, paths2) {
        if (isPlainObject(message2)) {
          Object.keys(message2).forEach(function(key) {
            var val = message2[key];
            if (isPlainObject(val)) {
              paths2.push(key);
              paths2.push(".");
              fn(level2, locale2, val, paths2);
              paths2.pop();
              paths2.pop();
            } else {
              paths2.push(key);
              fn(level2, locale2, val, paths2);
              paths2.pop();
            }
          });
        } else if (isArray(message2)) {
          message2.forEach(function(item, index) {
            if (isPlainObject(item)) {
              paths2.push("[" + index + "]");
              paths2.push(".");
              fn(level2, locale2, item, paths2);
              paths2.pop();
              paths2.pop();
            } else {
              paths2.push("[" + index + "]");
              fn(level2, locale2, item, paths2);
              paths2.pop();
            }
          });
        } else if (isString(message2)) {
          var ret = htmlTagMatcher.test(message2);
          if (ret) {
            var msg = "Detected HTML in message '" + message2 + "' of keypath '" + paths2.join("") + "' at '" + locale2 + "'. Consider component interpolation with '<i18n>' to avoid XSS. See https://bit.ly/2ZqJzkp";
            if (level2 === "warn") {
              vue_i18n_esm_warn(msg);
            } else if (level2 === "error") {
              vue_i18n_esm_error(msg);
            }
          }
        }
      };
      fn(level, locale, message, paths);
    };
    VueI18n.prototype._initVM = function _initVM(data) {
      var silent = Vue.config.silent;
      Vue.config.silent = true;
      this._vm = new Vue({
        data,
        __VUE18N__INSTANCE__: true
      });
      Vue.config.silent = silent;
    };
    VueI18n.prototype.destroyVM = function destroyVM() {
      this._vm.$destroy();
    };
    VueI18n.prototype.subscribeDataChanging = function subscribeDataChanging(vm) {
      this._dataListeners.add(vm);
    };
    VueI18n.prototype.unsubscribeDataChanging = function unsubscribeDataChanging(vm) {
      remove(this._dataListeners, vm);
    };
    VueI18n.prototype.watchI18nData = function watchI18nData() {
      var this$1$1 = this;
      return this._vm.$watch("$data", function() {
        var listeners = arrayFrom(this$1$1._dataListeners);
        var i = listeners.length;
        while (i--) {
          Vue.nextTick(function() {
            listeners[i] && listeners[i].$forceUpdate();
          });
        }
      }, {
        deep: true
      });
    };
    VueI18n.prototype.watchLocale = function watchLocale(composer) {
      if (!composer) {
        if (!this._sync || !this._root) {
          return null;
        }
        var target = this._vm;
        return this._root.$i18n.vm.$watch("locale", function(val) {
          target.$set(target, "locale", val);
          target.$forceUpdate();
        }, {
          immediate: true
        });
      } else {
        if (!this.__VUE_I18N_BRIDGE__) {
          return null;
        }
        var self = this;
        var target$1 = this._vm;
        return this.vm.$watch("locale", function(val) {
          target$1.$set(target$1, "locale", val);
          if (self.__VUE_I18N_BRIDGE__ && composer) {
            composer.locale.value = val;
          }
          target$1.$forceUpdate();
        }, {
          immediate: true
        });
      }
    };
    VueI18n.prototype.onComponentInstanceCreated = function onComponentInstanceCreated(newI18n) {
      if (this._componentInstanceCreatedListener) {
        this._componentInstanceCreatedListener(newI18n, this);
      }
    };
    vue_i18n_esm_prototypeAccessors.vm.get = function() {
      return this._vm;
    };
    vue_i18n_esm_prototypeAccessors.messages.get = function() {
      return looseClone(this._getMessages());
    };
    vue_i18n_esm_prototypeAccessors.dateTimeFormats.get = function() {
      return looseClone(this._getDateTimeFormats());
    };
    vue_i18n_esm_prototypeAccessors.numberFormats.get = function() {
      return looseClone(this._getNumberFormats());
    };
    vue_i18n_esm_prototypeAccessors.availableLocales.get = function() {
      return Object.keys(this.messages).sort();
    };
    vue_i18n_esm_prototypeAccessors.locale.get = function() {
      return this._vm.locale;
    };
    vue_i18n_esm_prototypeAccessors.locale.set = function(locale) {
      this._vm.$set(this._vm, "locale", locale);
    };
    vue_i18n_esm_prototypeAccessors.fallbackLocale.get = function() {
      return this._vm.fallbackLocale;
    };
    vue_i18n_esm_prototypeAccessors.fallbackLocale.set = function(locale) {
      this._localeChainCache = {};
      this._vm.$set(this._vm, "fallbackLocale", locale);
    };
    vue_i18n_esm_prototypeAccessors.formatFallbackMessages.get = function() {
      return this._formatFallbackMessages;
    };
    vue_i18n_esm_prototypeAccessors.formatFallbackMessages.set = function(fallback) {
      this._formatFallbackMessages = fallback;
    };
    vue_i18n_esm_prototypeAccessors.missing.get = function() {
      return this._missing;
    };
    vue_i18n_esm_prototypeAccessors.missing.set = function(handler) {
      this._missing = handler;
    };
    vue_i18n_esm_prototypeAccessors.formatter.get = function() {
      return this._formatter;
    };
    vue_i18n_esm_prototypeAccessors.formatter.set = function(formatter) {
      this._formatter = formatter;
    };
    vue_i18n_esm_prototypeAccessors.silentTranslationWarn.get = function() {
      return this._silentTranslationWarn;
    };
    vue_i18n_esm_prototypeAccessors.silentTranslationWarn.set = function(silent) {
      this._silentTranslationWarn = silent;
    };
    vue_i18n_esm_prototypeAccessors.silentFallbackWarn.get = function() {
      return this._silentFallbackWarn;
    };
    vue_i18n_esm_prototypeAccessors.silentFallbackWarn.set = function(silent) {
      this._silentFallbackWarn = silent;
    };
    vue_i18n_esm_prototypeAccessors.preserveDirectiveContent.get = function() {
      return this._preserveDirectiveContent;
    };
    vue_i18n_esm_prototypeAccessors.preserveDirectiveContent.set = function(preserve) {
      this._preserveDirectiveContent = preserve;
    };
    vue_i18n_esm_prototypeAccessors.warnHtmlInMessage.get = function() {
      return this._warnHtmlInMessage;
    };
    vue_i18n_esm_prototypeAccessors.warnHtmlInMessage.set = function(level) {
      var this$1$1 = this;
      var orgLevel = this._warnHtmlInMessage;
      this._warnHtmlInMessage = level;
      if (orgLevel !== level && (level === "warn" || level === "error")) {
        var messages = this._getMessages();
        Object.keys(messages).forEach(function(locale) {
          this$1$1._checkLocaleMessage(locale, this$1$1._warnHtmlInMessage, messages[locale]);
        });
      }
    };
    vue_i18n_esm_prototypeAccessors.postTranslation.get = function() {
      return this._postTranslation;
    };
    vue_i18n_esm_prototypeAccessors.postTranslation.set = function(handler) {
      this._postTranslation = handler;
    };
    vue_i18n_esm_prototypeAccessors.sync.get = function() {
      return this._sync;
    };
    vue_i18n_esm_prototypeAccessors.sync.set = function(val) {
      this._sync = val;
    };
    VueI18n.prototype._getMessages = function _getMessages() {
      return this._vm.messages;
    };
    VueI18n.prototype._getDateTimeFormats = function _getDateTimeFormats() {
      return this._vm.dateTimeFormats;
    };
    VueI18n.prototype._getNumberFormats = function _getNumberFormats() {
      return this._vm.numberFormats;
    };
    VueI18n.prototype._warnDefault = function _warnDefault(locale, key, result, vm, values, interpolateMode) {
      if (!isNull(result)) {
        return result;
      }
      if (this._missing) {
        var missingRet = this._missing.apply(null, [locale, key, vm, values]);
        if (isString(missingRet)) {
          return missingRet;
        }
      }
      if (this._formatFallbackMessages) {
        var parsedArgs = parseArgs.apply(void 0, values);
        return this._render(key, interpolateMode, parsedArgs.params, key);
      } else {
        return key;
      }
    };
    VueI18n.prototype._isFallbackRoot = function _isFallbackRoot(val) {
      return !val && !isNull(this._root) && this._fallbackRoot;
    };
    VueI18n.prototype._isSilentFallbackWarn = function _isSilentFallbackWarn(key) {
      return this._silentFallbackWarn instanceof RegExp ? this._silentFallbackWarn.test(key) : this._silentFallbackWarn;
    };
    VueI18n.prototype._isSilentFallback = function _isSilentFallback(locale, key) {
      return this._isSilentFallbackWarn(key) && (this._isFallbackRoot() || locale !== this.fallbackLocale);
    };
    VueI18n.prototype._isSilentTranslationWarn = function _isSilentTranslationWarn(key) {
      return this._silentTranslationWarn instanceof RegExp ? this._silentTranslationWarn.test(key) : this._silentTranslationWarn;
    };
    VueI18n.prototype._interpolate = function _interpolate(locale, message, key, host, interpolateMode, values, visitedLinkStack) {
      if (!message) {
        return null;
      }
      var pathRet = this._path.getPathValue(message, key);
      if (isArray(pathRet) || isPlainObject(pathRet)) {
        return pathRet;
      }
      var ret;
      if (isNull(pathRet)) {
        if (isPlainObject(message)) {
          ret = message[key];
          if (!(isString(ret) || isFunction(ret))) {
            return null;
          }
        } else {
          return null;
        }
      } else {
        if (isString(pathRet) || isFunction(pathRet)) {
          ret = pathRet;
        } else {
          return null;
        }
      }
      if (isString(ret) && (ret.indexOf("@:") >= 0 || ret.indexOf("@.") >= 0)) {
        ret = this._link(locale, message, ret, host, "raw", values, visitedLinkStack);
      }
      return this._render(ret, interpolateMode, values, key);
    };
    VueI18n.prototype._link = function _link(locale, message, str, host, interpolateMode, values, visitedLinkStack) {
      var ret = str;
      var matches = ret.match(linkKeyMatcher);
      for (var idx in matches) {
        if (!matches.hasOwnProperty(idx)) {
          continue;
        }
        var link = matches[idx];
        var linkKeyPrefixMatches = link.match(linkKeyPrefixMatcher);
        var linkPrefix = linkKeyPrefixMatches[0];
        var formatterName = linkKeyPrefixMatches[1];
        var linkPlaceholder = link.replace(linkPrefix, "").replace(bracketsMatcher, "");
        if (includes(visitedLinkStack, linkPlaceholder)) {
          return ret;
        }
        visitedLinkStack.push(linkPlaceholder);
        var translated = this._interpolate(locale, message, linkPlaceholder, host, interpolateMode === "raw" ? "string" : interpolateMode, interpolateMode === "raw" ? void 0 : values, visitedLinkStack);
        if (this._isFallbackRoot(translated)) {
          if (!this._root) {
            throw Error("unexpected error");
          }
          var root = this._root.$i18n;
          translated = root._translate(root._getMessages(), root.locale, root.fallbackLocale, linkPlaceholder, host, interpolateMode, values);
        }
        translated = this._warnDefault(locale, linkPlaceholder, translated, host, isArray(values) ? values : [values], interpolateMode);
        if (this._modifiers.hasOwnProperty(formatterName)) {
          translated = this._modifiers[formatterName](translated);
        } else if (defaultModifiers.hasOwnProperty(formatterName)) {
          translated = defaultModifiers[formatterName](translated);
        }
        visitedLinkStack.pop();
        ret = !translated ? ret : ret.replace(link, translated);
      }
      return ret;
    };
    VueI18n.prototype._createMessageContext = function _createMessageContext(values, formatter, path, interpolateMode) {
      var this$1$1 = this;
      var _list = isArray(values) ? values : [];
      var _named = vue_i18n_esm_isObject(values) ? values : {};
      var list = function(index) {
        return _list[index];
      };
      var named = function(key) {
        return _named[key];
      };
      var messages = this._getMessages();
      var locale = this.locale;
      return {
        list,
        named,
        values,
        formatter,
        path,
        messages,
        locale,
        linked: function(linkedKey) {
          return this$1$1._interpolate(locale, messages[locale] || {}, linkedKey, null, interpolateMode, void 0, [linkedKey]);
        }
      };
    };
    VueI18n.prototype._render = function _render(message, interpolateMode, values, path) {
      if (isFunction(message)) {
        return message(this._createMessageContext(values, this._formatter || defaultFormatter, path, interpolateMode));
      }
      var ret = this._formatter.interpolate(message, values, path);
      if (!ret) {
        ret = defaultFormatter.interpolate(message, values, path);
      }
      return interpolateMode === "string" && !isString(ret) ? ret.join("") : ret;
    };
    VueI18n.prototype._appendItemToChain = function _appendItemToChain(chain, item, blocks) {
      var follow = false;
      if (!includes(chain, item)) {
        follow = true;
        if (item) {
          follow = item[item.length - 1] !== "!";
          item = item.replace(/!/g, "");
          chain.push(item);
          if (blocks && blocks[item]) {
            follow = blocks[item];
          }
        }
      }
      return follow;
    };
    VueI18n.prototype._appendLocaleToChain = function _appendLocaleToChain(chain, locale, blocks) {
      var follow;
      var tokens = locale.split("-");
      do {
        var item = tokens.join("-");
        follow = this._appendItemToChain(chain, item, blocks);
        tokens.splice(-1, 1);
      } while (tokens.length && follow === true);
      return follow;
    };
    VueI18n.prototype._appendBlockToChain = function _appendBlockToChain(chain, block, blocks) {
      var follow = true;
      for (var i = 0; i < block.length && isBoolean(follow); i++) {
        var locale = block[i];
        if (isString(locale)) {
          follow = this._appendLocaleToChain(chain, locale, blocks);
        }
      }
      return follow;
    };
    VueI18n.prototype._getLocaleChain = function _getLocaleChain(start, fallbackLocale) {
      if (start === "") {
        return [];
      }
      if (!this._localeChainCache) {
        this._localeChainCache = {};
      }
      var chain = this._localeChainCache[start];
      if (!chain) {
        if (!fallbackLocale) {
          fallbackLocale = this.fallbackLocale;
        }
        chain = [];
        var block = [start];
        while (isArray(block)) {
          block = this._appendBlockToChain(chain, block, fallbackLocale);
        }
        var defaults;
        if (isArray(fallbackLocale)) {
          defaults = fallbackLocale;
        } else if (vue_i18n_esm_isObject(fallbackLocale)) {
          if (fallbackLocale["default"]) {
            defaults = fallbackLocale["default"];
          } else {
            defaults = null;
          }
        } else {
          defaults = fallbackLocale;
        }
        if (isString(defaults)) {
          block = [defaults];
        } else {
          block = defaults;
        }
        if (block) {
          this._appendBlockToChain(chain, block, null);
        }
        this._localeChainCache[start] = chain;
      }
      return chain;
    };
    VueI18n.prototype._translate = function _translate(messages, locale, fallback, key, host, interpolateMode, args) {
      var chain = this._getLocaleChain(locale, fallback);
      var res;
      for (var i = 0; i < chain.length; i++) {
        var step = chain[i];
        res = this._interpolate(step, messages[step], key, host, interpolateMode, args, [key]);
        if (!isNull(res)) {
          if (step !== locale && false) {
            vue_i18n_esm_warn("Fall back to translate the keypath '" + key + "' with '" + step + "' locale.");
          }
          return res;
        }
      }
      return null;
    };
    VueI18n.prototype._t = function _t(key, _locale, messages, host) {
      var ref;
      var values = [], len = arguments.length - 4;
      while (len-- > 0)
        values[len] = arguments[len + 4];
      if (!key) {
        return "";
      }
      var parsedArgs = parseArgs.apply(void 0, values);
      if (this._escapeParameterHtml) {
        parsedArgs.params = escapeParams(parsedArgs.params);
      }
      var locale = parsedArgs.locale || _locale;
      var ret = this._translate(messages, locale, this.fallbackLocale, key, host, "string", parsedArgs.params);
      if (this._isFallbackRoot(ret)) {
        if (!this._root) {
          throw Error("unexpected error");
        }
        return (ref = this._root).$t.apply(ref, [key].concat(values));
      } else {
        ret = this._warnDefault(locale, key, ret, host, values, "string");
        if (this._postTranslation && ret !== null && ret !== void 0) {
          ret = this._postTranslation(ret, key);
        }
        return ret;
      }
    };
    VueI18n.prototype.t = function t2(key) {
      var ref;
      var values = [], len = arguments.length - 1;
      while (len-- > 0)
        values[len] = arguments[len + 1];
      return (ref = this)._t.apply(ref, [key, this.locale, this._getMessages(), null].concat(values));
    };
    VueI18n.prototype._i = function _i(key, locale, messages, host, values) {
      var ret = this._translate(messages, locale, this.fallbackLocale, key, host, "raw", values);
      if (this._isFallbackRoot(ret)) {
        if (!this._root) {
          throw Error("unexpected error");
        }
        return this._root.$i18n.i(key, locale, values);
      } else {
        return this._warnDefault(locale, key, ret, host, [values], "raw");
      }
    };
    VueI18n.prototype.i = function i(key, locale, values) {
      if (!key) {
        return "";
      }
      if (!isString(locale)) {
        locale = this.locale;
      }
      return this._i(key, locale, this._getMessages(), null, values);
    };
    VueI18n.prototype._tc = function _tc(key, _locale, messages, host, choice) {
      var ref;
      var values = [], len = arguments.length - 5;
      while (len-- > 0)
        values[len] = arguments[len + 5];
      if (!key) {
        return "";
      }
      if (choice === void 0) {
        choice = 1;
      }
      var predefined = {
        "count": choice,
        "n": choice
      };
      var parsedArgs = parseArgs.apply(void 0, values);
      parsedArgs.params = Object.assign(predefined, parsedArgs.params);
      values = parsedArgs.locale === null ? [parsedArgs.params] : [parsedArgs.locale, parsedArgs.params];
      return this.fetchChoice((ref = this)._t.apply(ref, [key, _locale, messages, host].concat(values)), choice);
    };
    VueI18n.prototype.fetchChoice = function fetchChoice(message, choice) {
      if (!message || !isString(message)) {
        return null;
      }
      var choices = message.split("|");
      choice = this.getChoiceIndex(choice, choices.length);
      if (!choices[choice]) {
        return message;
      }
      return choices[choice].trim();
    };
    VueI18n.prototype.tc = function tc(key, choice) {
      var ref;
      var values = [], len = arguments.length - 2;
      while (len-- > 0)
        values[len] = arguments[len + 2];
      return (ref = this)._tc.apply(ref, [key, this.locale, this._getMessages(), null, choice].concat(values));
    };
    VueI18n.prototype._te = function _te(key, locale, messages) {
      var args = [], len = arguments.length - 3;
      while (len-- > 0)
        args[len] = arguments[len + 3];
      var _locale = parseArgs.apply(void 0, args).locale || locale;
      return this._exist(messages[_locale], key);
    };
    VueI18n.prototype.te = function te(key, locale) {
      return this._te(key, this.locale, this._getMessages(), locale);
    };
    VueI18n.prototype.getLocaleMessage = function getLocaleMessage(locale) {
      return looseClone(this._vm.messages[locale] || {});
    };
    VueI18n.prototype.setLocaleMessage = function setLocaleMessage(locale, message) {
      if (this._warnHtmlInMessage === "warn" || this._warnHtmlInMessage === "error") {
        this._checkLocaleMessage(locale, this._warnHtmlInMessage, message);
      }
      this._vm.$set(this._vm.messages, locale, message);
    };
    VueI18n.prototype.mergeLocaleMessage = function mergeLocaleMessage(locale, message) {
      if (this._warnHtmlInMessage === "warn" || this._warnHtmlInMessage === "error") {
        this._checkLocaleMessage(locale, this._warnHtmlInMessage, message);
      }
      this._vm.$set(this._vm.messages, locale, merge(typeof this._vm.messages[locale] !== "undefined" && Object.keys(this._vm.messages[locale]).length ? Object.assign({}, this._vm.messages[locale]) : {}, message));
    };
    VueI18n.prototype.getDateTimeFormat = function getDateTimeFormat(locale) {
      return looseClone(this._vm.dateTimeFormats[locale] || {});
    };
    VueI18n.prototype.setDateTimeFormat = function setDateTimeFormat(locale, format) {
      this._vm.$set(this._vm.dateTimeFormats, locale, format);
      this._clearDateTimeFormat(locale, format);
    };
    VueI18n.prototype.mergeDateTimeFormat = function mergeDateTimeFormat(locale, format) {
      this._vm.$set(this._vm.dateTimeFormats, locale, merge(this._vm.dateTimeFormats[locale] || {}, format));
      this._clearDateTimeFormat(locale, format);
    };
    VueI18n.prototype._clearDateTimeFormat = function _clearDateTimeFormat(locale, format) {
      for (var key in format) {
        var id = locale + "__" + key;
        if (!this._dateTimeFormatters.hasOwnProperty(id)) {
          continue;
        }
        delete this._dateTimeFormatters[id];
      }
    };
    VueI18n.prototype._localizeDateTime = function _localizeDateTime(value, locale, fallback, dateTimeFormats, key) {
      var _locale = locale;
      var formats = dateTimeFormats[_locale];
      var chain = this._getLocaleChain(locale, fallback);
      for (var i = 0; i < chain.length; i++) {
        var current = _locale;
        var step = chain[i];
        formats = dateTimeFormats[step];
        _locale = step;
        if (isNull(formats) || isNull(formats[key])) {
          if (step !== locale && false) {
            vue_i18n_esm_warn("Fall back to '" + step + "' datetime formats from '" + current + "' datetime formats.");
          }
        } else {
          break;
        }
      }
      if (isNull(formats) || isNull(formats[key])) {
        return null;
      } else {
        var format = formats[key];
        var id = _locale + "__" + key;
        var formatter = this._dateTimeFormatters[id];
        if (!formatter) {
          formatter = this._dateTimeFormatters[id] = new Intl.DateTimeFormat(_locale, format);
        }
        return formatter.format(value);
      }
    };
    VueI18n.prototype._d = function _d(value, locale, key) {
      if (!key) {
        return new Intl.DateTimeFormat(locale).format(value);
      }
      var ret = this._localizeDateTime(value, locale, this.fallbackLocale, this._getDateTimeFormats(), key);
      if (this._isFallbackRoot(ret)) {
        if (!this._root) {
          throw Error("unexpected error");
        }
        return this._root.$i18n.d(value, key, locale);
      } else {
        return ret || "";
      }
    };
    VueI18n.prototype.d = function d(value) {
      var args = [], len = arguments.length - 1;
      while (len-- > 0)
        args[len] = arguments[len + 1];
      var locale = this.locale;
      var key = null;
      if (args.length === 1) {
        if (isString(args[0])) {
          key = args[0];
        } else if (vue_i18n_esm_isObject(args[0])) {
          if (args[0].locale) {
            locale = args[0].locale;
          }
          if (args[0].key) {
            key = args[0].key;
          }
        }
      } else if (args.length === 2) {
        if (isString(args[0])) {
          key = args[0];
        }
        if (isString(args[1])) {
          locale = args[1];
        }
      }
      return this._d(value, locale, key);
    };
    VueI18n.prototype.getNumberFormat = function getNumberFormat(locale) {
      return looseClone(this._vm.numberFormats[locale] || {});
    };
    VueI18n.prototype.setNumberFormat = function setNumberFormat(locale, format) {
      this._vm.$set(this._vm.numberFormats, locale, format);
      this._clearNumberFormat(locale, format);
    };
    VueI18n.prototype.mergeNumberFormat = function mergeNumberFormat(locale, format) {
      this._vm.$set(this._vm.numberFormats, locale, merge(this._vm.numberFormats[locale] || {}, format));
      this._clearNumberFormat(locale, format);
    };
    VueI18n.prototype._clearNumberFormat = function _clearNumberFormat(locale, format) {
      for (var key in format) {
        var id = locale + "__" + key;
        if (!this._numberFormatters.hasOwnProperty(id)) {
          continue;
        }
        delete this._numberFormatters[id];
      }
    };
    VueI18n.prototype._getNumberFormatter = function _getNumberFormatter(value, locale, fallback, numberFormats, key, options2) {
      var _locale = locale;
      var formats = numberFormats[_locale];
      var chain = this._getLocaleChain(locale, fallback);
      for (var i = 0; i < chain.length; i++) {
        var current = _locale;
        var step = chain[i];
        formats = numberFormats[step];
        _locale = step;
        if (isNull(formats) || isNull(formats[key])) {
          if (step !== locale && false) {
            vue_i18n_esm_warn("Fall back to '" + step + "' number formats from '" + current + "' number formats.");
          }
        } else {
          break;
        }
      }
      if (isNull(formats) || isNull(formats[key])) {
        return null;
      } else {
        var format = formats[key];
        var formatter;
        if (options2) {
          formatter = new Intl.NumberFormat(_locale, Object.assign({}, format, options2));
        } else {
          var id = _locale + "__" + key;
          formatter = this._numberFormatters[id];
          if (!formatter) {
            formatter = this._numberFormatters[id] = new Intl.NumberFormat(_locale, format);
          }
        }
        return formatter;
      }
    };
    VueI18n.prototype._n = function _n(value, locale, key, options2) {
      if (!VueI18n.availabilities.numberFormat) {
        return "";
      }
      if (!key) {
        var nf = !options2 ? new Intl.NumberFormat(locale) : new Intl.NumberFormat(locale, options2);
        return nf.format(value);
      }
      var formatter = this._getNumberFormatter(value, locale, this.fallbackLocale, this._getNumberFormats(), key, options2);
      var ret = formatter && formatter.format(value);
      if (this._isFallbackRoot(ret)) {
        if (!this._root) {
          throw Error("unexpected error");
        }
        return this._root.$i18n.n(value, Object.assign({}, {
          key,
          locale
        }, options2));
      } else {
        return ret || "";
      }
    };
    VueI18n.prototype.n = function n(value) {
      var args = [], len = arguments.length - 1;
      while (len-- > 0)
        args[len] = arguments[len + 1];
      var locale = this.locale;
      var key = null;
      var options2 = null;
      if (args.length === 1) {
        if (isString(args[0])) {
          key = args[0];
        } else if (vue_i18n_esm_isObject(args[0])) {
          if (args[0].locale) {
            locale = args[0].locale;
          }
          if (args[0].key) {
            key = args[0].key;
          }
          options2 = Object.keys(args[0]).reduce(function(acc, key2) {
            var obj;
            if (includes(numberFormatKeys, key2)) {
              return Object.assign({}, acc, (obj = {}, obj[key2] = args[0][key2], obj));
            }
            return acc;
          }, null);
        }
      } else if (args.length === 2) {
        if (isString(args[0])) {
          key = args[0];
        }
        if (isString(args[1])) {
          locale = args[1];
        }
      }
      return this._n(value, locale, key, options2);
    };
    VueI18n.prototype._ntp = function _ntp(value, locale, key, options2) {
      if (!VueI18n.availabilities.numberFormat) {
        return [];
      }
      if (!key) {
        var nf = !options2 ? new Intl.NumberFormat(locale) : new Intl.NumberFormat(locale, options2);
        return nf.formatToParts(value);
      }
      var formatter = this._getNumberFormatter(value, locale, this.fallbackLocale, this._getNumberFormats(), key, options2);
      var ret = formatter && formatter.formatToParts(value);
      if (this._isFallbackRoot(ret)) {
        if (!this._root) {
          throw Error("unexpected error");
        }
        return this._root.$i18n._ntp(value, locale, key, options2);
      } else {
        return ret || [];
      }
    };
    Object.defineProperties(VueI18n.prototype, vue_i18n_esm_prototypeAccessors);
    var availabilities;
    Object.defineProperty(VueI18n, "availabilities", {
      get: function get() {
        if (!availabilities) {
          var intlDefined = typeof Intl !== "undefined";
          availabilities = {
            dateTimeFormat: intlDefined && typeof Intl.DateTimeFormat !== "undefined",
            numberFormat: intlDefined && typeof Intl.NumberFormat !== "undefined"
          };
        }
        return availabilities;
      }
    });
    VueI18n.install = vue_i18n_esm_install;
    VueI18n.version = "8.26.7";
    var vue_i18n_esm = VueI18n;
    __webpack_require__(45);
    __webpack_require__(46);
    __webpack_require__(47);
    __webpack_require__(48);
    __webpack_require__(49);
    __webpack_require__(50);
    __webpack_require__(51);
    __webpack_require__(52);
    __webpack_require__(53);
    __webpack_require__(54);
    __webpack_require__(55);
    __webpack_require__(56);
    __webpack_require__(57);
    function nuxtI18nHead({
      addDirAttribute = true,
      addSeoAttributes = false
    } = {}) {
      if (!this.$i18n) {
        return {};
      }
      const metaObject = {
        htmlAttrs: {},
        link: [],
        meta: []
      };
      const currentLocale = this.$i18n.localeProperties;
      const currentLocaleIso = currentLocale.iso;
      const currentLocaleDir = currentLocale.dir || options.defaultDirection;
      if (addDirAttribute) {
        metaObject.htmlAttrs.dir = currentLocaleDir;
      }
      if (addSeoAttributes && (vue_meta_common_default.a.hasMetaInfo ? vue_meta_common_default.a.hasMetaInfo(this) : this._hasMetaInfo) && this.$i18n.locale && this.$i18n.locales && this.$options[Constants.COMPONENT_OPTIONS_KEY] !== false && !(this.$options[Constants.COMPONENT_OPTIONS_KEY] && this.$options[Constants.COMPONENT_OPTIONS_KEY].seo === false)) {
        if (currentLocaleIso) {
          metaObject.htmlAttrs.lang = currentLocaleIso;
        }
        const locales = this.$i18n.locales;
        addHreflangLinks.bind(this)(locales, this.$i18n.__baseUrl, metaObject.link);
        addCanonicalLinks.bind(this)(this.$i18n.__baseUrl, metaObject.link);
        addCurrentOgLocale.bind(this)(currentLocale, currentLocaleIso, metaObject.meta);
        addAlternateOgLocales.bind(this)(locales, currentLocaleIso, metaObject.meta);
      }
      function addHreflangLinks(locales, baseUrl, link) {
        if (options.strategy === Constants.STRATEGIES.NO_PREFIX) {
          return;
        }
        const localeMap = /* @__PURE__ */ new Map();
        for (const locale of locales) {
          const localeIso = locale.iso;
          if (!localeIso) {
            console.warn(formatMessage("Locale ISO code is required to generate alternate link"));
            continue;
          }
          const [language, region] = localeIso.split("-");
          if (language && region && (locale.isCatchallLocale || !localeMap.has(language))) {
            localeMap.set(language, locale);
          }
          localeMap.set(localeIso, locale);
        }
        for (const [iso, mapLocale] of localeMap.entries()) {
          const localePath = this.switchLocalePath(mapLocale.code);
          if (localePath) {
            link.push({
              hid: `i18n-alt-${iso}`,
              rel: "alternate",
              href: toAbsoluteUrl(localePath, baseUrl),
              hreflang: iso
            });
          }
        }
        if (options.defaultLocale) {
          const localePath = this.switchLocalePath(options.defaultLocale);
          if (localePath) {
            link.push({
              hid: "i18n-xd",
              rel: "alternate",
              href: toAbsoluteUrl(localePath, baseUrl),
              hreflang: "x-default"
            });
          }
        }
      }
      function addCanonicalLinks(baseUrl, link) {
        const currentRoute = this.localeRoute({
          ...this.$route,
          name: this.getRouteBaseName()
        });
        const canonicalPath = currentRoute ? currentRoute.path : null;
        if (canonicalPath) {
          link.push({
            hid: "i18n-can",
            rel: "canonical",
            href: toAbsoluteUrl(canonicalPath, baseUrl)
          });
        }
      }
      function addCurrentOgLocale(currentLocale2, currentLocaleIso2, meta) {
        const hasCurrentLocaleAndIso = currentLocale2 && currentLocaleIso2;
        if (!hasCurrentLocaleAndIso) {
          return;
        }
        meta.push({
          hid: "i18n-og",
          property: "og:locale",
          content: hypenToUnderscore(currentLocaleIso2)
        });
      }
      function addAlternateOgLocales(locales, currentLocaleIso2, meta) {
        const localesWithoutCurrent = locales.filter((locale) => {
          const localeIso = locale.iso;
          return localeIso && localeIso !== currentLocaleIso2;
        });
        if (localesWithoutCurrent.length) {
          const alternateLocales = localesWithoutCurrent.map((locale) => ({
            hid: `i18n-og-alt-${locale.iso}`,
            property: "og:locale:alternate",
            content: hypenToUnderscore(locale.iso)
          }));
          meta.push(...alternateLocales);
        }
      }
      function hypenToUnderscore(str) {
        return (str || "").replace(/-/g, "_");
      }
      function toAbsoluteUrl(urlOrPath, baseUrl) {
        if (urlOrPath.match(/^https?:\/\//)) {
          return urlOrPath;
        }
        return baseUrl + urlOrPath;
      }
      return metaObject;
    }
    function nuxtI18nSeo() {
      return nuxtI18nHead.call(this, {
        addDirAttribute: false,
        addSeoAttributes: true
      });
    }
    function set(obj, key, val) {
      if (typeof val.value === "object")
        val.value = klona(val.value);
      if (!val.enumerable || val.get || val.set || !val.configurable || !val.writable || key === "__proto__") {
        Object.defineProperty(obj, key, val);
      } else
        obj[key] = val.value;
    }
    function klona(x) {
      if (typeof x !== "object")
        return x;
      var i = 0, k, list, tmp, str = Object.prototype.toString.call(x);
      if (str === "[object Object]") {
        tmp = Object.create(x.__proto__ || null);
      } else if (str === "[object Array]") {
        tmp = Array(x.length);
      } else if (str === "[object Set]") {
        tmp = /* @__PURE__ */ new Set();
        x.forEach(function(val) {
          tmp.add(klona(val));
        });
      } else if (str === "[object Map]") {
        tmp = /* @__PURE__ */ new Map();
        x.forEach(function(val, key) {
          tmp.set(klona(key), klona(val));
        });
      } else if (str === "[object Date]") {
        tmp = new Date(+x);
      } else if (str === "[object RegExp]") {
        tmp = new RegExp(x.source, x.flags);
      } else if (str === "[object DataView]") {
        tmp = new x.constructor(klona(x.buffer));
      } else if (str === "[object ArrayBuffer]") {
        tmp = x.slice(0);
      } else if (str.slice(-6) === "Array]") {
        tmp = new x.constructor(x);
      }
      if (tmp) {
        for (list = Object.getOwnPropertySymbols(x); i < list.length; i++) {
          set(tmp, list[i], Object.getOwnPropertyDescriptor(x, list[i]));
        }
        for (i = 0, list = Object.getOwnPropertyNames(x); i < list.length; i++) {
          if (Object.hasOwnProperty.call(tmp, k = list[i]) && tmp[k] === x[k])
            continue;
          set(tmp, k, Object.getOwnPropertyDescriptor(x, k));
        }
      }
      return tmp || x;
    }
    vue2_bridge["default"].use(vue_i18n_esm);
    var plugin_main = async (context) => {
      const {
        app,
        route,
        store,
        req,
        res,
        redirect
      } = context;
      if (options.vuex && store) {
        registerStore(store, options.vuex, options.localeCodes);
      }
      const {
        lazy
      } = options;
      const injectInNuxtState = lazy && (lazy === true || lazy.skipNuxtState !== true);
      if (injectInNuxtState) {
        const devalue = (await Promise.resolve().then(__webpack_require__.t.bind(null, 100, 7))).default;
        context.beforeNuxtRender(({
          nuxtState
        }) => {
          const langs = {};
          const {
            fallbackLocale: fallbackLocale2,
            locale
          } = app.i18n;
          if (locale && locale !== fallbackLocale2) {
            const messages = app.i18n._getMessages()[locale];
            if (messages) {
              try {
                devalue(messages);
                langs[locale] = messages;
              } catch {
              }
            }
          }
          nuxtState.__i18n = {
            langs
          };
        });
      }
      const {
        alwaysRedirect,
        fallbackLocale,
        onlyOnNoPrefix,
        onlyOnRoot,
        useCookie,
        cookieKey,
        cookieDomain,
        cookieSecure,
        cookieCrossOrigin
      } = options.detectBrowserLanguage;
      const loadAndSetLocale = async (newLocale, {
        initialSetup = false
      } = {}) => {
        if (!newLocale) {
          return;
        }
        if (!initialSetup && app.i18n.differentDomains) {
          return;
        }
        const oldLocale = app.i18n.locale;
        if (newLocale === oldLocale) {
          return;
        }
        const localeOverride = app.i18n.onBeforeLanguageSwitch(oldLocale, newLocale, initialSetup, context);
        if (localeOverride && app.i18n.localeCodes.includes(localeOverride)) {
          if (localeOverride === oldLocale) {
            return;
          }
          newLocale = localeOverride;
        }
        if (!initialSetup) {
          app.i18n.beforeLanguageSwitch(oldLocale, newLocale);
        }
        if (useCookie) {
          app.i18n.setLocaleCookie(newLocale);
        }
        if (options.langDir) {
          const i18nFallbackLocale = app.i18n.fallbackLocale;
          if (options.lazy) {
            if (i18nFallbackLocale) {
              let localesToLoadPromises = [];
              if (Array.isArray(i18nFallbackLocale)) {
                localesToLoadPromises = i18nFallbackLocale.map((fbLocale) => loadLanguageAsync(context, fbLocale));
              } else if (typeof i18nFallbackLocale === "object") {
                if (i18nFallbackLocale[newLocale]) {
                  localesToLoadPromises = localesToLoadPromises.concat(i18nFallbackLocale[newLocale].map((fbLocale) => loadLanguageAsync(context, fbLocale)));
                }
                if (i18nFallbackLocale.default) {
                  localesToLoadPromises = localesToLoadPromises.concat(i18nFallbackLocale.default.map((fbLocale) => loadLanguageAsync(context, fbLocale)));
                }
              } else if (newLocale !== i18nFallbackLocale) {
                localesToLoadPromises.push(loadLanguageAsync(context, i18nFallbackLocale));
              }
              await Promise.all(localesToLoadPromises);
            }
            await loadLanguageAsync(context, newLocale);
          } else {
            await Promise.all(options.localeCodes.map((locale) => loadLanguageAsync(context, locale)));
          }
        }
        app.i18n.locale = newLocale;
        const newLocaleProperties = options.normalizedLocales.find((l) => l.code === newLocale) || {
          code: newLocale
        };
        for (const key of Object.keys(app.i18n.localeProperties)) {
          app.i18n.localeProperties[key] = void 0;
        }
        for (const [key, value] of Object.entries(newLocaleProperties)) {
          vue2_bridge["default"].set(app.i18n.localeProperties, key, klona(value));
        }
        if (options.vuex) {
          await syncVuex(store, newLocale, app.i18n.getLocaleMessage(newLocale), options.vuex);
        }
        const {
          route: route2
        } = context;
        const redirectPath = getRedirectPathForLocale(route2, newLocale);
        if (initialSetup) {
          app.i18n.__redirect = redirectPath;
        } else {
          app.i18n.onLanguageSwitched(oldLocale, newLocale);
          if (redirectPath) {
            redirect(redirectPath);
          }
        }
      };
      const getLocaleFromRoute = createLocaleFromRouteGetter(options.localeCodes, {
        routesNameSeparator: options.routesNameSeparator,
        defaultLocaleRouteNameSuffix: options.defaultLocaleRouteNameSuffix
      });
      const getRedirectPathForLocale = (route2, locale) => {
        if (!locale || app.i18n.differentDomains || options.strategy === Constants.STRATEGIES.NO_PREFIX) {
          return "";
        }
        if (getLocaleFromRoute(route2) === locale) {
          if (!(onlyOnRoot || onlyOnNoPrefix) || locale !== options.defaultLocale || options.strategy !== Constants.STRATEGIES.PREFIX_AND_DEFAULT) {
            return "";
          }
        }
        let redirectPath = app.switchLocalePath(locale);
        if (!redirectPath) {
          redirectPath = app.localePath(route2.fullPath, locale);
        }
        if (!redirectPath || redirectPath === route2.fullPath || redirectPath.startsWith("//")) {
          return "";
        }
        return redirectPath;
      };
      const onNavigate = async (route2) => {
        if (route2.path === "/" && options.rootRedirect) {
          let statusCode = 302;
          let path = options.rootRedirect;
          if (typeof options.rootRedirect !== "string") {
            statusCode = options.rootRedirect.statusCode;
            path = options.rootRedirect.path;
          }
          return [
            statusCode,
            `/${path}`,
            true
          ];
        }
        const storedRedirect = app.i18n.__redirect;
        if (storedRedirect) {
          app.i18n.__redirect = null;
          return [302, storedRedirect];
        }
        const resolveBaseUrlOptions2 = {
          differentDomains: options.differentDomains,
          normalizedLocales: options.normalizedLocales
        };
        app.i18n.__baseUrl = resolveBaseUrl(options.baseUrl, context, app.i18n.locale, resolveBaseUrlOptions2);
        const finalLocale2 = options.detectBrowserLanguage && doDetectBrowserLanguage(route2) || getLocaleFromRoute(route2) || app.i18n.locale || app.i18n.defaultLocale || "";
        if (options.skipSettingLocaleOnNavigate) {
          app.i18n.__pendingLocale = finalLocale2;
          app.i18n.__pendingLocalePromise = new Promise((resolve) => {
            app.i18n.__resolvePendingLocalePromise = resolve;
          });
        } else {
          await app.i18n.setLocale(finalLocale2);
        }
        return [null, null];
      };
      const finalizePendingLocaleChange = async () => {
        if (!app.i18n.__pendingLocale) {
          return;
        }
        await app.i18n.setLocale(app.i18n.__pendingLocale);
        app.i18n.__resolvePendingLocalePromise("");
        app.i18n.__pendingLocale = null;
      };
      const waitForPendingLocaleChange = async () => {
        if (app.i18n.__pendingLocale) {
          await app.i18n.__pendingLocalePromise;
        }
      };
      const getBrowserLocale = () => {
        if (req && typeof req.headers["accept-language"] !== "undefined") {
          return matchBrowserLocale(options.normalizedLocales, parseAcceptLanguage(req.headers["accept-language"]));
        } else {
          return void 0;
        }
      };
      const doDetectBrowserLanguage = (route2) => {
        if (options.strategy !== Constants.STRATEGIES.NO_PREFIX) {
          if (onlyOnRoot) {
            if (route2.path !== "/") {
              return "";
            }
          } else if (onlyOnNoPrefix) {
            if (!alwaysRedirect && route2.path.match(getLocalesRegex(options.localeCodes))) {
              return "";
            }
          }
        }
        let matchedLocale;
        if (useCookie && (matchedLocale = app.i18n.getLocaleCookie())) ; else {
          matchedLocale = getBrowserLocale();
        }
        const finalLocale2 = matchedLocale || fallbackLocale;
        if (finalLocale2 && (!useCookie || alwaysRedirect || !app.i18n.getLocaleCookie())) {
          if (finalLocale2 !== app.i18n.locale) {
            return finalLocale2;
          }
        }
        return "";
      };
      const extendVueI18nInstance = (i18n) => {
        i18n.locales = klona(options.locales);
        i18n.localeCodes = klona(options.localeCodes);
        i18n.localeProperties = vue2_bridge["default"].observable(klona(options.normalizedLocales.find((l) => l.code === i18n.locale) || {
          code: i18n.locale
        }));
        i18n.defaultLocale = options.defaultLocale;
        i18n.differentDomains = options.differentDomains;
        i18n.beforeLanguageSwitch = options.beforeLanguageSwitch;
        i18n.onBeforeLanguageSwitch = options.onBeforeLanguageSwitch;
        i18n.onLanguageSwitched = options.onLanguageSwitched;
        i18n.setLocaleCookie = (locale) => setLocaleCookie(locale, res, {
          useCookie,
          cookieDomain,
          cookieKey,
          cookieSecure,
          cookieCrossOrigin
        });
        i18n.getLocaleCookie = () => getLocaleCookie(req, {
          useCookie,
          cookieKey,
          localeCodes: options.localeCodes
        });
        i18n.setLocale = (locale) => loadAndSetLocale(locale);
        i18n.getBrowserLocale = () => getBrowserLocale();
        i18n.finalizePendingLocaleChange = finalizePendingLocaleChange;
        i18n.waitForPendingLocaleChange = waitForPendingLocaleChange;
        i18n.__baseUrl = app.i18n.__baseUrl;
        i18n.__pendingLocale = app.i18n.__pendingLocale;
        i18n.__pendingLocalePromise = app.i18n.__pendingLocalePromise;
        i18n.__resolvePendingLocalePromise = app.i18n.__resolvePendingLocalePromise;
      };
      const vueI18nOptions = typeof options.vueI18n === "function" ? await options.vueI18n(context) : klona(options.vueI18n);
      vueI18nOptions.componentInstanceCreatedListener = extendVueI18nInstance;
      app.i18n = context.i18n = new vue_i18n_esm(vueI18nOptions);
      app.i18n.locale = "";
      app.i18n.fallbackLocale = vueI18nOptions.fallbackLocale || "";
      extendVueI18nInstance(app.i18n);
      const resolveBaseUrlOptions = {
        differentDomains: options.differentDomains,
        normalizedLocales: options.normalizedLocales
      };
      app.i18n.__baseUrl = resolveBaseUrl(options.baseUrl, context, "", resolveBaseUrlOptions);
      app.i18n.__onNavigate = onNavigate;
      vue2_bridge["default"].prototype.$nuxtI18nSeo = nuxtI18nSeo;
      vue2_bridge["default"].prototype.$nuxtI18nHead = nuxtI18nHead;
      if (store) {
        store.$i18n = app.i18n;
        if (store.state.localeDomains) {
          for (const locale of app.i18n.locales) {
            if (typeof locale === "string") {
              continue;
            }
            locale.domain = store.state.localeDomains[locale.code];
          }
        }
      }
      let finalLocale = options.detectBrowserLanguage ? doDetectBrowserLanguage(route) : "";
      if (!finalLocale) {
        const {
          vuex
        } = options;
        if (vuex && vuex.syncLocale && store && store.state[vuex.moduleName].locale !== "") {
          finalLocale = store.state[vuex.moduleName].locale;
        } else if (app.i18n.differentDomains) {
          const domainLocale = getLocaleDomain(options.normalizedLocales, req);
          finalLocale = domainLocale;
        } else if (options.strategy !== Constants.STRATEGIES.NO_PREFIX) {
          const routeLocale = getLocaleFromRoute(route);
          finalLocale = routeLocale;
        }
      }
      if (!finalLocale && useCookie) {
        finalLocale = app.i18n.getLocaleCookie();
      }
      if (!finalLocale) {
        finalLocale = app.i18n.defaultLocale || "";
      }
      await loadAndSetLocale(finalLocale, {
        initialSetup: true
      });
    };
    vue2_bridge["default"].use(vue_composition_api["f"].default || vue_composition_api["f"]);
    var capi_plugin = Object(runtime["a"])((nuxtApp) => {
      const _originalSetup = nuxtApp.nuxt2Context.app.setup;
      nuxtApp.nuxt2Context.app.setup = function(...args) {
        const result = _originalSetup instanceof Function ? _originalSetup(...args) : {};
        nuxtApp.hooks.callHookWith((hooks) => hooks.map((hook) => hook()), "vue:setup");
        return result;
      };
    });
    const vueMetaRenderer = (nuxt) => {
      const meta = nuxt.ssrContext.meta.inject({
        isSSR: nuxt.ssrContext.nuxt.serverRendered,
        ln: false
      });
      return {
        htmlAttrs: meta.htmlAttrs.text(),
        headAttrs: meta.headAttrs.text(),
        headTags: meta.title.text() + meta.base.text() + meta.meta.text() + meta.link.text() + meta.style.text() + meta.script.text() + meta.noscript.text(),
        bodyAttrs: meta.bodyAttrs.text(),
        bodyScriptsPrepend: meta.meta.text({
          pbody: true
        }) + meta.link.text({
          pbody: true
        }) + meta.style.text({
          pbody: true
        }) + meta.script.text({
          pbody: true
        }) + meta.noscript.text({
          pbody: true
        }),
        bodyScripts: meta.meta.text({
          body: true
        }) + meta.link.text({
          body: true
        }) + meta.style.text({
          body: true
        }) + meta.script.text({
          body: true
        }) + meta.noscript.text({
          body: true
        })
      };
    };
    var nitro_bridge_server = Object(runtime["a"])((nuxtApp) => {
      const metaRenderers = [vueMetaRenderer];
      nuxtApp.callHook("meta:register", metaRenderers);
      nuxtApp.ssrContext.renderMeta = async () => {
        const metadata = {
          htmlAttrs: "",
          headAttrs: "",
          headTags: "",
          bodyAttrs: "",
          bodyScriptsPrepend: "",
          bodyScripts: ""
        };
        for await (const renderer of metaRenderers) {
          const result = await renderer(nuxtApp);
          for (const key in result) {
            metadata[key] += result[key];
          }
        }
        return metadata;
      };
    });
    __webpack_require__(65);
    vue2_bridge["default"].component(vue_client_only_common_default.a.name, vue_client_only_common_default.a);
    vue2_bridge["default"].component(vue_no_ssr_common_default.a.name, {
      ...vue_no_ssr_common_default.a,
      render(h, ctx) {
        return vue_no_ssr_common_default.a.render(h, ctx);
      }
    });
    vue2_bridge["default"].component(nuxt_child.name, nuxt_child);
    vue2_bridge["default"].component("NChild", nuxt_child);
    vue2_bridge["default"].component(components_nuxt.name, components_nuxt);
    Object.defineProperty(vue2_bridge["default"].prototype, "$nuxt", {
      get() {
        const globalNuxt = this.$root ? this.$root.$options.$nuxt : null;
        return globalNuxt;
      },
      configurable: true
    });
    vue2_bridge["default"].use(vue_meta_common_default.a, {
      "keyName": "head",
      "attribute": "data-n-head",
      "ssrAttribute": "data-n-head-ssr",
      "tagIDKeyName": "hid"
    });
    const defaultTransition = {
      "name": "page",
      "mode": "out-in",
      "appear": false,
      "appearClass": "appear",
      "appearActiveClass": "appear-active",
      "appearToClass": "appear-to"
    };
    async function createApp(ssrContext, config = {}) {
      const router = await createRouter(ssrContext, config);
      const app = {
        head: {
          "title": "vue-nuxt-pro",
          "htmlAttrs": {
            "lang": "en"
          },
          "meta": [{
            "charset": "utf-8"
          }, {
            "name": "viewport",
            "content": "width=device-width, initial-scale=1"
          }, {
            "hid": "description",
            "name": "description",
            "content": ""
          }, {
            "name": "format-detection",
            "content": "telephone=no"
          }],
          "link": [{
            "rel": "icon",
            "type": "image/x-icon",
            "href": "/favicon.ico"
          }, {
            "rel": "stylesheet",
            "href": "https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap"
          }, {
            "rel": "stylesheet",
            "href": "https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/static/pretendard.css"
          }],
          "style": [],
          "script": []
        },
        router,
        nuxt: {
          defaultTransition,
          transitions: [defaultTransition],
          setTransitions(transitions) {
            if (!Array.isArray(transitions)) {
              transitions = [transitions];
            }
            transitions = transitions.map((transition) => {
              if (!transition) {
                transition = defaultTransition;
              } else if (typeof transition === "string") {
                transition = Object.assign({}, defaultTransition, {
                  name: transition
                });
              } else {
                transition = Object.assign({}, defaultTransition, transition);
              }
              return transition;
            });
            this.$options.nuxt.transitions = transitions;
            return transitions;
          },
          err: null,
          dateErr: null,
          error(err) {
            err = err || null;
            app.context._errored = Boolean(err);
            err = err ? normalizeError(err) : null;
            let nuxt = app.nuxt;
            if (this) {
              nuxt = this.nuxt || this.$options.nuxt;
            }
            nuxt.dateErr = Date.now();
            nuxt.err = err;
            if (ssrContext) {
              ssrContext.nuxt.error = err;
            }
            return err;
          }
        },
        ...App
      };
      const next = ssrContext ? ssrContext.next : (location) => app.router.push(location);
      let route;
      if (ssrContext) {
        route = router.resolve(ssrContext.url).route;
      } else {
        const path = getLocation(router.options.base, router.options.mode);
        route = router.resolve(path).route;
      }
      await setContext(app, {
        route,
        next,
        error: app.nuxt.error.bind(app),
        payload: ssrContext ? ssrContext.payload : void 0,
        req: ssrContext ? ssrContext.req : void 0,
        res: ssrContext ? ssrContext.res : void 0,
        beforeRenderFns: ssrContext ? ssrContext.beforeRenderFns : void 0,
        beforeSerializeFns: ssrContext ? ssrContext.beforeSerializeFns : void 0,
        ssrContext
      });
      function inject(key, value) {
        if (!key) {
          throw new Error("inject(key, value) has no key provided");
        }
        if (value === void 0) {
          throw new Error(`inject('${key}', value) has no value provided`);
        }
        key = "$" + key;
        app[key] = value;
        if (!app.context[key]) {
          app.context[key] = value;
        }
        const installKey = "__nuxt_" + key + "_installed__";
        if (vue2_bridge["default"][installKey]) {
          return;
        }
        vue2_bridge["default"][installKey] = true;
        vue2_bridge["default"].use(() => {
          if (!Object.prototype.hasOwnProperty.call(vue2_bridge["default"].prototype, key)) {
            Object.defineProperty(vue2_bridge["default"].prototype, key, {
              get() {
                return this.$root.$options[key];
              }
            });
          }
        });
      }
      inject("config", config);
      if (typeof runtime_app_plugin_e394a3b6 === "function") {
        await runtime_app_plugin_e394a3b6(app.context, inject);
      }
      if (typeof plugin_routing === "function") {
        await plugin_routing(app.context);
      }
      if (typeof plugin_main === "function") {
        await plugin_main(app.context);
      }
      if (typeof capi_plugin === "function") {
        await capi_plugin(app.context, inject);
      }
      if (typeof nitro_bridge_server === "function") {
        await nitro_bridge_server(app.context, inject);
      }
      await new Promise((resolve, reject) => {
        router.replace(app.context.route.fullPath, resolve, (err) => {
          if (!err._isRouter)
            return reject(err);
          if (err.type !== 2)
            return resolve();
          const unregister = router.afterEach(async (to, from) => {
            if (ssrContext && ssrContext.url) {
              ssrContext.url = to.fullPath;
            }
            app.context.route = await getRouteData(to);
            app.context.params = to.params || {};
            app.context.query = to.query || {};
            unregister();
            resolve();
          });
        });
      });
      return {
        app,
        router
      };
    }
    var nuxt_link_server = {
      name: "NuxtLink",
      extends: vue2_bridge["default"].component("RouterLink"),
      props: {
        prefetch: {
          type: Boolean,
          default: true
        },
        noPrefetch: {
          type: Boolean,
          default: false
        }
      }
    };
    vue2_bridge["default"].config.optionMergeStrategies.serverPrefetch = vue2_bridge["default"].config.optionMergeStrategies.created;
    if (!vue2_bridge["default"].__nuxt__fetch__mixin__) {
      vue2_bridge["default"].mixin(fetch_server);
      vue2_bridge["default"].__nuxt__fetch__mixin__ = true;
    }
    vue2_bridge["default"].component(nuxt_link_server.name, nuxt_link_server);
    vue2_bridge["default"].component("NLink", nuxt_link_server);
    const noopApp = () => new vue2_bridge["default"]({
      render: (h) => h("div", {
        domProps: {
          id: "__nuxt"
        }
      })
    });
    const createNext = (ssrContext) => (opts) => {
      ssrContext.redirected = opts;
      if (ssrContext.target === "static" || !ssrContext.res) {
        ssrContext.nuxt.serverRendered = false;
        return;
      }
      let fullPath = Object(external_ufo_["withQuery"])(opts.path, opts.query);
      const $config = ssrContext.nuxt.config || {};
      const routerBase = $config._app && $config._app.basePath || "/";
      if (!fullPath.startsWith("http") && routerBase !== "/" && !fullPath.startsWith(routerBase)) {
        fullPath = Object(external_ufo_["joinURL"])(routerBase, fullPath);
      }
      if (decodeURI(fullPath) === decodeURI(ssrContext.url)) {
        ssrContext.redirected = false;
        return;
      }
      ssrContext.res.writeHead(opts.status, {
        Location: Object(external_ufo_["normalizeURL"])(fullPath)
      });
      ssrContext.res.end();
    };
    __webpack_exports__["default"] = async (ssrContext) => {
      ssrContext.redirected = false;
      ssrContext.next = createNext(ssrContext);
      ssrContext.beforeRenderFns = [];
      ssrContext.beforeSerializeFns = [];
      ssrContext.nuxt = {
        layout: "default",
        data: [],
        fetch: {},
        error: null,
        serverRendered: true,
        routePath: ""
      };
      ssrContext.fetchCounters = {};
      ssrContext.nuxt.config = ssrContext.runtimeConfig.public;
      if (ssrContext.nuxt.config._app) {
        __webpack_require__.p = Object(external_ufo_["joinURL"])(ssrContext.nuxt.config._app.cdnURL, ssrContext.nuxt.config._app.assetsPath);
      }
      const {
        app,
        router
      } = await createApp(ssrContext, ssrContext.runtimeConfig.private);
      const _app = new vue2_bridge["default"](app);
      ssrContext.nuxt.routePath = app.context.route.path;
      ssrContext.meta = _app.$meta();
      ssrContext.asyncData = {};
      const beforeRender = async () => {
        await Promise.all(ssrContext.beforeRenderFns.map((fn) => promisify(fn, {
          Components,
          nuxtState: ssrContext.nuxt
        })));
        ssrContext.rendered = () => {
          ssrContext.beforeSerializeFns.forEach((fn) => fn(ssrContext.nuxt));
        };
      };
      const renderErrorPage = async () => {
        if (ssrContext.target === "static") {
          ssrContext.nuxt.serverRendered = false;
        }
        const layout2 = (layouts_error.options || layouts_error).layout;
        const errLayout = typeof layout2 === "function" ? layout2.call(layouts_error, app.context) : layout2;
        ssrContext.nuxt.layout = errLayout || "default";
        await _app.loadLayout(errLayout);
        _app.setLayout(errLayout);
        await beforeRender();
        return _app;
      };
      const render404Page = () => {
        app.context.error({
          statusCode: 404,
          path: ssrContext.url,
          message: "This page could not be found"
        });
        return renderErrorPage();
      };
      const Components = getMatchedComponents(app.context.route);
      let midd = ["nuxti18n", "nuxti18n"];
      midd = midd.map((name) => {
        if (typeof name === "function") {
          return name;
        }
        if (typeof _nuxt_middleware[name] !== "function") {
          app.context.error({
            statusCode: 500,
            message: "Unknown middleware " + name
          });
        }
        return _nuxt_middleware[name];
      });
      await middlewareSeries(midd, app.context);
      if (ssrContext.redirected) {
        return noopApp();
      }
      if (ssrContext.nuxt.error) {
        return renderErrorPage();
      }
      let layout = Components.length ? Components[0].options.layout : layouts_error.layout;
      if (typeof layout === "function") {
        layout = layout(app.context);
      }
      await _app.loadLayout(layout);
      if (ssrContext.nuxt.error) {
        return renderErrorPage();
      }
      layout = _app.setLayout(layout);
      ssrContext.nuxt.layout = _app.layoutName;
      midd = [];
      layout = sanitizeComponent(layout);
      if (layout.options.middleware) {
        midd = midd.concat(layout.options.middleware);
      }
      Components.forEach((Component) => {
        if (Component.options.middleware) {
          midd = midd.concat(Component.options.middleware);
        }
      });
      midd = midd.map((name) => {
        if (typeof name === "function") {
          return name;
        }
        if (typeof _nuxt_middleware[name] !== "function") {
          app.context.error({
            statusCode: 500,
            message: "Unknown middleware " + name
          });
        }
        return _nuxt_middleware[name];
      });
      await middlewareSeries(midd, app.context);
      if (ssrContext.redirected) {
        return noopApp();
      }
      if (ssrContext.nuxt.error) {
        return renderErrorPage();
      }
      let isValid = true;
      try {
        for (const Component of Components) {
          if (typeof Component.options.validate !== "function") {
            continue;
          }
          isValid = await Component.options.validate(app.context);
          if (!isValid) {
            break;
          }
        }
      } catch (validationError) {
        app.context.error({
          statusCode: validationError.statusCode || "500",
          message: validationError.message
        });
        return renderErrorPage();
      }
      if (!isValid) {
        return render404Page();
      }
      if (!Components.length) {
        return render404Page();
      }
      const asyncDatas = await Promise.all(Components.map((Component) => {
        const promises = [];
        if (Component.options.asyncData && typeof Component.options.asyncData === "function") {
          const promise = promisify(Component.options.asyncData, app.context);
          promise.then((asyncDataResult) => {
            ssrContext.asyncData[Component.cid] = asyncDataResult;
            applyAsyncData(Component);
            return asyncDataResult;
          });
          promises.push(promise);
        } else {
          promises.push(null);
        }
        if (Component.options.fetch && Component.options.fetch.length) {
          promises.push(Component.options.fetch(app.context));
        } else {
          promises.push(null);
        }
        return Promise.all(promises);
      }));
      ssrContext.nuxt.data = asyncDatas.map((r) => r[0] || {});
      if (ssrContext.redirected) {
        return noopApp();
      }
      if (ssrContext.nuxt.error) {
        return renderErrorPage();
      }
      await beforeRender();
      return _app;
    };
  },
  function(module2, exports) {
    module2.exports = require$$40;
  }
]);
}(server$2));

var server = server$2.exports;

const server$1 = server;

export { server$1 as default };
