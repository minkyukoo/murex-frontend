function _mergeNamespaces(n, m) {
  for (var i = 0; i < m.length; i++) {
    const e = m[i];
    if (typeof e !== 'string' && !Array.isArray(e)) { for (const k in e) {
      if (k !== 'default' && !(k in n)) {
        const d = Object.getOwnPropertyDescriptor(e, k);
        if (d) {
          Object.defineProperty(n, k, d.get ? d : {
            enumerable: true,
            get: function () { return e[k]; }
          });
        }
      }
    } }
  }
  return Object.freeze(n);
}

var bannerState$1 = {};

var ids = bannerState$1.ids = [3];
var modules = bannerState$1.modules = {
  101: function(module, exports2) {
    module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTIiIGN5PSIxMiIgcj0iMTEuNSIgc3Ryb2tlPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNOS41IDdWMTZNMTMuNSA3VjE2IiBzdHJva2U9IndoaXRlIi8+Cjwvc3ZnPgo=";
  },
  126: function(module, exports2, __webpack_require__) {
    var content = __webpack_require__(137);
    if (content.__esModule)
      content = content.default;
    if (typeof content === "string")
      content = [[module.i, content, ""]];
    if (content.locals)
      module.exports = content.locals;
    var add = __webpack_require__(5).default;
    module.exports.__inject__ = function(context) {
      add("16484ab8", content, true, context);
    };
  },
  130: function(module, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var render = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", { staticClass: "container" }, [_vm._ssrNode('<div class="Banner-state" data-v-6bf08efc><div class="flex items-center" data-v-6bf08efc><div class="slideCon" data-v-6bf08efc>' + (_vm.pauseIcon ? "<img" + _vm._ssrAttr("src", __webpack_require__(101)) + ' alt="img" data-v-6bf08efc>' : !_vm.pauseIcon ? "<img" + _vm._ssrAttr("src", __webpack_require__(135)) + ' alt="img" data-v-6bf08efc>' : "<!---->") + '</div> <div class="px-4 pb-2" data-v-6bf08efc><progress id="file" max="100"' + _vm._ssrAttr("value", _vm.progressValue) + " data-v-6bf08efc></progress></div> <div data-v-6bf08efc><h5 data-v-6bf08efc><span data-v-6bf08efc>" + _vm._ssrEscape(_vm._s(_vm.slideNumber)) + "</span> / <span data-v-6bf08efc>" + _vm._ssrEscape("0" + _vm._s(_vm.TotalSlides)) + "</span></h5></div></div></div>")]);
    };
    var staticRenderFns = [];
    var BannerStatevue_type_script_lang_js_ = {
      name: "BannerState",
      props: {
        slideNumber: String,
        TotalSlides: Number,
        progressValue: Number
      },
      data() {
        return {
          pauseIcon: true
        };
      },
      methods: {
        pauseSlide() {
          this.$emit("PauseIt", false);
          this.pauseIcon = !this.pauseIcon;
        }
      }
    };
    var components_BannerStatevue_type_script_lang_js_ = BannerStatevue_type_script_lang_js_;
    var componentNormalizer = __webpack_require__(2);
    function injectStyles(context) {
      var style0 = __webpack_require__(136);
      if (style0.__inject__)
        style0.__inject__(context);
    }
    var component = Object(componentNormalizer["a"])(components_BannerStatevue_type_script_lang_js_, render, staticRenderFns, false, injectStyles, "6bf08efc", "8565412c");
    __webpack_exports__["default"] = component.exports;
  },
  135: function(module, exports2) {
    module.exports = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTUiIGhlaWdodD0iMTUiIHZpZXdCb3g9IjAgMCAxNSAxNSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTYuNSA1LjVMNi43NDgwNyA1LjA2NTg4QzYuNTkzMzIgNC45Nzc0NSA2LjQwMzE5IDQuOTc4MDggNi4yNDkwNCA1LjA2NzU0QzYuMDk0ODggNS4xNTcwMSA2IDUuMzIxNzYgNiA1LjVINi41Wk02LjUgOS41SDZDNiA5LjY3ODI0IDYuMDk0ODggOS44NDI5OSA2LjI0OTA0IDkuOTMyNDZDNi40MDMxOSAxMC4wMjE5IDYuNTkzMzIgMTAuMDIyNiA2Ljc0ODA3IDkuOTM0MTJMNi41IDkuNVpNMTAgNy41TDEwLjI0ODEgNy45MzQxMkMxMC40MDM5IDcuODQ1MSAxMC41IDcuNjc5NDMgMTAuNSA3LjVDMTAuNSA3LjMyMDU3IDEwLjQwMzkgNy4xNTQ5IDEwLjI0ODEgNy4wNjU4OEwxMCA3LjVaTTcuNSAxNEMzLjkxMDE1IDE0IDEgMTEuMDg5OSAxIDcuNUgwQzAgMTEuNjQyMSAzLjM1Nzg2IDE1IDcuNSAxNVYxNFpNMTQgNy41QzE0IDExLjA4OTkgMTEuMDg5OSAxNCA3LjUgMTRWMTVDMTEuNjQyMSAxNSAxNSAxMS42NDIxIDE1IDcuNUgxNFpNNy41IDFDMTEuMDg5OSAxIDE0IDMuOTEwMTUgMTQgNy41SDE1QzE1IDMuMzU3ODYgMTEuNjQyMSAwIDcuNSAwVjFaTTcuNSAwQzMuMzU3ODYgMCAwIDMuMzU3ODYgMCA3LjVIMUMxIDMuOTEwMTUgMy45MTAxNSAxIDcuNSAxVjBaTTYgNS41VjkuNUg3VjUuNUg2Wk02Ljc0ODA3IDkuOTM0MTJMMTAuMjQ4MSA3LjkzNDEyTDkuNzUxOTMgNy4wNjU4OEw2LjI1MTkzIDkuMDY1ODhMNi43NDgwNyA5LjkzNDEyWk0xMC4yNDgxIDcuMDY1ODhMNi43NDgwNyA1LjA2NTg4TDYuMjUxOTMgNS45MzQxMkw5Ljc1MTkzIDcuOTM0MTJMMTAuMjQ4MSA3LjA2NTg4WiIgZmlsbD0id2hpdGUiLz4KPC9zdmc+Cg==";
  },
  136: function(module, __webpack_exports__, __webpack_require__) {
    __webpack_require__.r(__webpack_exports__);
    var _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_BannerState_vue_vue_type_style_index_0_id_6bf08efc_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(126);
    for (var __WEBPACK_IMPORT_KEY__ in _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_BannerState_vue_vue_type_style_index_0_id_6bf08efc_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__)
      if (["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0)
        (function(key) {
          __webpack_require__.d(__webpack_exports__, key, function() {
            return _node_modules_unplugin_dist_webpack_loaders_transform_js_ref_36_0_node_modules_vue_style_loader_index_js_ref_9_oneOf_1_0_node_modules_nuxt_postcss8_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_nuxt_postcss8_node_modules_postcss_loader_dist_cjs_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_sass_resources_loader_lib_loader_js_ref_9_oneOf_1_4_node_modules_nuxt_components_dist_loader_js_ref_2_0_node_modules_vue_loader_lib_index_js_vue_loader_options_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_34_0_node_modules_unplugin_dist_webpack_loaders_transform_js_ref_35_0_BannerState_vue_vue_type_style_index_0_id_6bf08efc_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key];
          });
        })(__WEBPACK_IMPORT_KEY__);
  },
  137: function(module, exports2, __webpack_require__) {
    var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(4);
    var ___CSS_LOADER_GET_URL_IMPORT___ = __webpack_require__(7);
    var ___CSS_LOADER_URL_IMPORT_0___ = __webpack_require__(8);
    var ___CSS_LOADER_URL_IMPORT_1___ = __webpack_require__(9);
    var ___CSS_LOADER_URL_IMPORT_2___ = __webpack_require__(10);
    var ___CSS_LOADER_URL_IMPORT_3___ = __webpack_require__(11);
    var ___CSS_LOADER_URL_IMPORT_4___ = __webpack_require__(12);
    var ___CSS_LOADER_URL_IMPORT_5___ = __webpack_require__(13);
    var ___CSS_LOADER_URL_IMPORT_6___ = __webpack_require__(14);
    var ___CSS_LOADER_URL_IMPORT_7___ = __webpack_require__(15);
    var ___CSS_LOADER_URL_IMPORT_8___ = __webpack_require__(16);
    var ___CSS_LOADER_URL_IMPORT_9___ = __webpack_require__(17);
    var ___CSS_LOADER_URL_IMPORT_10___ = __webpack_require__(18);
    var ___CSS_LOADER_URL_IMPORT_11___ = __webpack_require__(19);
    var ___CSS_LOADER_URL_IMPORT_12___ = __webpack_require__(20);
    var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i) {
      return i[1];
    });
    var ___CSS_LOADER_URL_REPLACEMENT_0___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_0___);
    var ___CSS_LOADER_URL_REPLACEMENT_1___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_1___);
    var ___CSS_LOADER_URL_REPLACEMENT_2___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_2___);
    var ___CSS_LOADER_URL_REPLACEMENT_3___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_3___);
    var ___CSS_LOADER_URL_REPLACEMENT_4___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_4___);
    var ___CSS_LOADER_URL_REPLACEMENT_5___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_5___);
    var ___CSS_LOADER_URL_REPLACEMENT_6___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_6___);
    var ___CSS_LOADER_URL_REPLACEMENT_7___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_7___);
    var ___CSS_LOADER_URL_REPLACEMENT_8___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_8___);
    var ___CSS_LOADER_URL_REPLACEMENT_9___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_9___);
    var ___CSS_LOADER_URL_REPLACEMENT_10___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_10___);
    var ___CSS_LOADER_URL_REPLACEMENT_11___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_11___);
    var ___CSS_LOADER_URL_REPLACEMENT_12___ = ___CSS_LOADER_GET_URL_IMPORT___(___CSS_LOADER_URL_IMPORT_12___);
    ___CSS_LOADER_EXPORT___.push([module.i, '/*purgecss start ignore*/\nbody[data-v-6bf08efc],html[data-v-6bf08efc]{\n  font-family:"Poppins","Pretendard",sans-serif\n}\n.container[data-v-6bf08efc]{\n  width:100%;\n  margin:0 auto\n}\n.divider-1[data-v-6bf08efc]{\n  display:block;\n  width:100%;\n  height:1px;\n  background-color:#cfcfcf\n}\n.heading-1[data-v-6bf08efc]{\n  font-size:52px;\n  letter-spacing:-.02em\n}\n.heading-1[data-v-6bf08efc],.heading-2[data-v-6bf08efc]{\n  font-family:"Poppins","Pretendard",sans-serif;\n  font-style:normal;\n  font-weight:500;\n  line-height:100%;\n  color:#181818\n}\n.heading-2[data-v-6bf08efc]{\n  font-size:32px\n}\n.fluidContainer[data-v-6bf08efc]{\n  padding:0 36px\n}\n@media screen and (max-width:767px){\n.fluidContainer[data-v-6bf08efc]{\n    padding:0\n}\n}\n.custom-checkbox[data-v-6bf08efc]{\n  display:block;\n  position:relative;\n  padding-left:30px;\n  margin-bottom:12px;\n  cursor:pointer;\n  font-size:22px;\n  -webkit-user-select:none;\n  -moz-user-select:none;\n  -ms-user-select:none;\n  user-select:none\n}\n.custom-checkbox input[data-v-6bf08efc]{\n  position:absolute;\n  opacity:0;\n  cursor:pointer;\n  height:0;\n  width:0\n}\n.checkmark[data-v-6bf08efc]{\n  position:absolute;\n  top:0;\n  left:0;\n  height:16px;\n  width:16px;\n  background-color:#fff;\n  border:1px solid #bdbdbd\n}\n.custom-checkbox:hover input~.checkmark[data-v-6bf08efc]{\n  background-color:#ececec\n}\n.custom-checkbox input:checked~.checkmark[data-v-6bf08efc]{\n  background-color:#57195c;\n  border:1px solid #57195c\n}\n.checkmark[data-v-6bf08efc]:after{\n  content:"";\n  position:absolute;\n  display:block\n}\n.custom-checkbox input:checked~.checkmark[data-v-6bf08efc]:after{\n  display:block\n}\n.custom-checkbox .checkmark[data-v-6bf08efc]:after{\n  left:5px;\n  top:1px;\n  width:5px;\n  height:10px;\n  border:solid #bdbdbd;\n  border-width:0 1px 1px 0;\n  transform:rotate(45deg)\n}\n.icon-location-pin[data-v-6bf08efc]{\n  background:url(' + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-call[data-v-6bf08efc],.icon-location-pin[data-v-6bf08efc]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-call[data-v-6bf08efc]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax[data-v-6bf08efc]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fax[data-v-6bf08efc],.icon-mail[data-v-6bf08efc]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-mail[data-v-6bf08efc]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-train[data-v-6bf08efc]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-bus[data-v-6bf08efc],.icon-train[data-v-6bf08efc]{\n  height:20px;\n  width:20px;\n  display:inline-block\n}\n.icon-bus[data-v-6bf08efc]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb[data-v-6bf08efc]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-fb[data-v-6bf08efc],.icon-ln[data-v-6bf08efc]{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-ln[data-v-6bf08efc]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu[data-v-6bf08efc]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_8___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-menu[data-v-6bf08efc],.icon-menu-violet-bg[data-v-6bf08efc]{\n  height:18px;\n  width:26px;\n  display:inline-block\n}\n.icon-menu-violet-bg[data-v-6bf08efc]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_9___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-cross[data-v-6bf08efc]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_10___ + ") no-repeat 50%;\n  background-size:100%;\n  height:19px;\n  width:19px;\n  display:inline-block\n}\n.icon-linkedin-dark[data-v-6bf08efc]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_11___ + ") no-repeat 50%;\n  background-size:100%\n}\n.icon-facebook-dark[data-v-6bf08efc],.icon-linkedin-dark[data-v-6bf08efc]{\n  height:32px;\n  width:32px;\n  display:inline-block\n}\n.icon-facebook-dark[data-v-6bf08efc]{\n  background:url(" + ___CSS_LOADER_URL_REPLACEMENT_12___ + ") no-repeat 50%;\n  background-size:100%\n}\n.Banner-state[data-v-6bf08efc]{\n  position:absolute;\n  bottom:15%;\n  color:#fff\n}\n.slideCon img[data-v-6bf08efc]{\n  width:24px;\n  height:24px\n}\nprogress[data-v-6bf08efc]{\n  vertical-align:baseline;\n  min-width:400px;\n  color:#fff;\n  height:2px\n}\n@media screen and (max-width:765px){\nprogress[data-v-6bf08efc]{\n    min-width:280px\n}\n}\n@media screen and (max-width:560px){\nprogress[data-v-6bf08efc]{\n    min-width:180px\n}\n}\nprogress[value][data-v-6bf08efc]{\n  -webkit-appearance:none;\n  -moz-appearance:none;\n       appearance:none\n}\nprogress[value][data-v-6bf08efc]::-webkit-progress-bar{\n  background-color:#666;\n  border-radius:5px\n}\nprogress[value][data-v-6bf08efc]::-webkit-progress-value{\n  background-color:#fff;\n  height:2px;\n  -webkit-transition:width 3s ease;\n  transition:width 3s ease\n}\n\n/*purgecss end ignore*/", ""]);
    ___CSS_LOADER_EXPORT___.locals = {};
    module.exports = ___CSS_LOADER_EXPORT___;
  }
};

const bannerState = /*#__PURE__*/Object.freeze(/*#__PURE__*/_mergeNamespaces({
  __proto__: null,
  'default': bannerState$1,
  ids: ids,
  modules: modules
}, [bannerState$1]));

export { bannerState as b };
