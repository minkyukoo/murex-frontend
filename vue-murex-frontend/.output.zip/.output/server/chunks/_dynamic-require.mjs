const dynamicChunks = {
 ['components/advisory-cards.js']: () => import('./advisory-cards.mjs').then(function (n) { return n.a; }),
 ['components/banner-state.js']: () => import('./banner-state.mjs').then(function (n) { return n.b; }),
 ['components/banner.js']: () => import('./banner.mjs').then(function (n) { return n.b; }),
 ['components/contact-info-item.js']: () => import('./contact-info-item.mjs').then(function (n) { return n.c; }),
 ['components/filters.js']: () => import('./filters.mjs').then(function (n) { return n.f; }),
 ['components/founder-cards.js']: () => import('./founder-cards.mjs').then(function (n) { return n.f; }),
 ['components/modal.js']: () => import('./modal.mjs').then(function (n) { return n.m; }),
 ['components/nuxt-logo.js']: () => import('./nuxt-logo.mjs').then(function (n) { return n.n; }),
 ['components/team-card.js']: () => import('./team-card.mjs').then(function (n) { return n.t; }),
 ['components/team-cards.js']: () => import('./team-cards.mjs').then(function (n) { return n.t; }),
 ['components/top-heading.js']: () => import('./top-heading.mjs').then(function (n) { return n.t; }),
 ['components/tutorial.js']: () => import('./tutorial.mjs').then(function (n) { return n.t; }),
 ['pages/about.js']: () => import('./about.mjs').then(function (n) { return n.a; }),
 ['pages/contact.js']: () => import('./contact.mjs').then(function (n) { return n.c; }),
 ['pages/contents.js']: () => import('./contents.mjs').then(function (n) { return n.c; }),
 ['pages/founders.js']: () => import('./founders.mjs').then(function (n) { return n.f; }),
 ['pages/index.js']: () => import('./index.mjs').then(function (n) { return n.i; }),
 ['pages/philosophy.js']: () => import('./philosophy.mjs').then(function (n) { return n.p; }),
 ['pages/team.js']: () => import('./team.mjs').then(function (n) { return n.t; }),
 ['pages/users.js']: () => import('./users.mjs').then(function (n) { return n.u; })
};

function dynamicRequire(id) {
  return dynamicChunks[id]();
}

export { dynamicRequire as default };
