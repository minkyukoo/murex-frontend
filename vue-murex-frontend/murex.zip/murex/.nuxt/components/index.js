export { default as AdvisoryCards } from '../..\\components\\AdvisoryCards.vue'
export { default as Banner } from '../..\\components\\Banner.vue'
export { default as BannerState } from '../..\\components\\BannerState.vue'
export { default as ContactInfoItem } from '../..\\components\\ContactInfoItem.vue'
export { default as ContentBox } from '../..\\components\\ContentBox.vue'
export { default as ContentEmpty } from '../..\\components\\ContentEmpty.vue'
export { default as ContentTab } from '../..\\components\\ContentTab.vue'
export { default as ContentWrapper } from '../..\\components\\ContentWrapper.vue'
export { default as Filters } from '../..\\components\\Filters.vue'
export { default as Footer } from '../..\\components\\Footer.vue'
export { default as FounderCards } from '../..\\components\\FounderCards.vue'
export { default as Header } from '../..\\components\\Header.vue'
export { default as LanguageInput } from '../..\\components\\LanguageInput.vue'
export { default as LoadingBar } from '../..\\components\\LoadingBar.vue'
export { default as Modal } from '../..\\components\\Modal.vue'
export { default as NuxtLogo } from '../..\\components\\NuxtLogo.vue'
export { default as Pagination } from '../..\\components\\Pagination.vue'
export { default as TeamCard } from '../..\\components\\TeamCard.vue'
export { default as TeamCards } from '../..\\components\\TeamCards.vue'
export { default as TopHeading } from '../..\\components\\TopHeading.vue'
export { default as Tutorial } from '../..\\components\\Tutorial.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
