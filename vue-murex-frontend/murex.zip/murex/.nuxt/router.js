import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _2649ed6f = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _83fdbbfc = () => interopDefault(import('..\\pages\\contact.vue' /* webpackChunkName: "pages/contact" */))
const _299002b0 = () => interopDefault(import('..\\pages\\contents.vue' /* webpackChunkName: "pages/contents" */))
const _4601c834 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _215d0d9c = () => interopDefault(import('..\\pages\\founders.vue' /* webpackChunkName: "pages/founders" */))
const _4f6299ff = () => interopDefault(import('..\\pages\\philosophy.vue' /* webpackChunkName: "pages/philosophy" */))
const _6cd6112a = () => interopDefault(import('..\\pages\\team.vue' /* webpackChunkName: "pages/team" */))
const _e928bb2c = () => interopDefault(import('..\\pages\\users.vue' /* webpackChunkName: "pages/users" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _2649ed6f,
    name: "about___kr"
  }, {
    path: "/contact",
    component: _83fdbbfc,
    name: "contact___kr"
  }, {
    path: "/contents",
    component: _299002b0,
    name: "contents___kr"
  }, {
    path: "/en",
    component: _4601c834,
    name: "index___en"
  }, {
    path: "/founders",
    component: _215d0d9c,
    name: "founders___kr"
  }, {
    path: "/philosophy",
    component: _4f6299ff,
    name: "philosophy___kr"
  }, {
    path: "/team",
    component: _6cd6112a,
    name: "team___kr"
  }, {
    path: "/users",
    component: _e928bb2c,
    name: "users___kr"
  }, {
    path: "/en/about",
    component: _2649ed6f,
    name: "about___en"
  }, {
    path: "/en/contact",
    component: _83fdbbfc,
    name: "contact___en"
  }, {
    path: "/en/contents",
    component: _299002b0,
    name: "contents___en"
  }, {
    path: "/en/founders",
    component: _215d0d9c,
    name: "founders___en"
  }, {
    path: "/en/philosophy",
    component: _4f6299ff,
    name: "philosophy___en"
  }, {
    path: "/en/team",
    component: _6cd6112a,
    name: "team___en"
  }, {
    path: "/en/users",
    component: _e928bb2c,
    name: "users___en"
  }, {
    path: "/",
    component: _4601c834,
    name: "index___kr"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
