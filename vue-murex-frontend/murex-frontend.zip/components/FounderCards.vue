<template>
  <div class="grid grid-cols-2 lg:grid-cols-4 md:gap-4 lg:gap-8">

    <!-- <div>{{$nuxt.$route.path}}</div> -->
    <!-- <div class="Add-founder">
      <img src="../assets/images/founder-logo.png" alt="img" class="logo" />
      <div class="Adding">
        <div>
          <h4>하이메디</h4>
          <p>이정주, 서돈교</p>
        </div>
        <img src="../assets/icons/Plus.svg" />
      </div>
    </div> -->
    <TeamCard
      v-for="(team, i) of teams"
      :key="team.id || i + 1"
      :bgImage="team.image"
      :name="team.name"
      :designation="team.designation"
      v-on:openModal="OpenModal"
    />
  </div>
</template>

<script>
import TeamCard from "./TeamCard.vue";
export default {
  name: "FounderCards",
  components: { TeamCard },
  data() {
    return {
      pageHeading: "Our Team",
      teams: [
        // {
        //   id: 1,
        //   name: "하이메디",
        //   designation: "이정주, 서돈교",
        //   image: "founder-logo.png",
        //   sns_links: {
        //     fb: "https://facebook.com",
        //     ln: "https://linkedin.com",
        //   },
        // },
        {
          id: 2,
          name: "이범석",
          designation: "CEO / Co-Founder",
          image: "team-01.jpg",
          sns_links: {
            fb: "https://facebook.com",
            ln: "https://linkedin.com",
          },
        },
        {
          id: 3,
          name: "강동민",
          designation: "부사장 / Co-Founder",
          image: "team-02.jpg",
          sns_links: {
            fb: "https://facebook.com",
            ln: "https://linkedin.com",
          },
        },
        {
          id: 4,
          name: "오지성",
          designation: "부사장 / Co-Founder",
          image: "team-03.jpg",
          sns_links: {
            fb: "https://facebook.com",
            ln: "https://linkedin.com",
          },
        },
        {
          id: 5,
          name: "박진영",
          designation: "수석",
          image: "team-04.jpg",
          sns_links: {
            fb: "https://facebook.com",
            ln: "https://linkedin.com",
          },
        },
        {
          id: 6,
          name: "김세진",
          designation: "수석",
          image: "team-05.jpg",
          sns_links: {
            fb: "https://facebook.com",
            ln: "https://linkedin.com",
          },
        },
        {
          id: 7,
          name: "김세호",
          designation: "이사",
          image: "team-06.jpg",
          sns_links: {
            fb: "https://facebook.com",
            ln: "https://linkedin.com",
          },
        },
        {
          id: 8,
          name: "이은영",
          designation: "경영기획실장",
          image: "team-07.jpg",
          sns_links: {
            fb: "https://facebook.com",
            ln: "https://linkedin.com",
          },
        },
        {
          id: 9,
          name: "김윤나",
          designation: "사원",
          image: "team-08.jpg",
          sns_links: {
            fb: "https://facebook.com",
            ln: "https://linkedin.com",
          },
        },
        {
          id: 10,
          name: "신지혜",
          designation: "사원",
          image: "team-09.jpg",
          sns_links: {
            fb: "https://facebook.com",
            ln: "https://linkedin.com",
          },
        },
      ],
    };
  },
  methods: {
    OpenModal() {
      this.$emit("openModal", true);
      console.log("member click passed");
    },
  },
};
</script>

<style lang="scss" scoped>
.Add-founder {
  position: relative;
  background-color: $white;
  padding: calc(10px + 1vw);
  @include dflex-align-justify-center;
  .logo {
    max-width: calc(80px + 10vw);
    width: 100%;
  }
  .Adding {
    @include dflex-align-justify-between;
    padding: calc(10px + 1vw);
    width: 100%;
    position: absolute;
    bottom: 0;
    right: 0;
    h4 {
      font-weight: 600;
      font-size: 24px;
    }
    img {
      width: calc(10px + 2vw);
      cursor: pointer;
    }
  }
}
</style>
