<template>
  <div class="philosophy">
    <h1>philosophy -- {{$route.path}}</h1>
  </div>
</template>

<script>
  export default {
    name: 'philosophy'
  }
</script>

<style lang="scss" scoped>

</style>
