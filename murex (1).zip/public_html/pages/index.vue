<template>
  <Tutorial/>
</template>

<script>
export default {
  name: 'IndexPage'
}
</script>
